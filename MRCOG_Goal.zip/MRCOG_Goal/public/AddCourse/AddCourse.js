var firestore = firebase.firestore();

var tags = [],sptags = [], tagsKey = [];

var keyword = document.getElementById('keyword');





function AddImgForSLider(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#Image1')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}

function saveMatProduct(params) {

    var cTitle,cDiscription,cImage,Post_psd;

    cTitle = document.getElementById("coueseTitle").value;
    cDiscription = document.getElementById("ProductDiscription").value;
    cImage = document.getElementById("AddCourseImage").value;
    var Price = document.getElementById("priceid").value;
    var Dprice =  document.getElementById("dpriceid").value;
    var DpriceInPer = document.getElementById("perId").value;

if(cTitle !=="" && cDiscription !=="" && cImage !=="" && tags.length!==0 && Price!=="" && Dprice!=="" && DpriceInPer!=="" ){
   
    document.getElementById("Uploading").style.display = "flex" 
    document.getElementById("Image1").style.display = "none"
    document.getElementById("saveButton").style.display = "none"
    

    // alert("In true")
    const ref = firebase.storage().ref();
    const file = document.querySelector('#AddCourseImage').files[0]

    const name =  file.name;

    const metadata = {
    contentType: file.type
    };
    const task = ref.child('MRCOG_Goal_Images/' + name).put(file, metadata);


        task .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
  
               firestore.collection("Courses").add({
                courseTitle: cTitle,
                courseDiscription : cDiscription,
                courseImage : url,
                keywords : tagsKey,
                keysToShow : tags,
                date:firebase.firestore.Timestamp.fromDate(new Date()),
                price : Number(Price),
                dPrice : Number(Dprice),
                dPriceInPer : Number(DpriceInPer)
            })
       
    }).then(()=>{
            document.getElementById("AddoCurseImage").style.display = "" 
            document.getElementById("priceid").style.display = "" 
            document.getElementById("dpriceid").style.display = ""  
            ocument.getElementById("perId").style.display = ""
            document.getElementById("Uploading").style.display = "none"
            document.getElementById("Image1").style.display = "flex"
            document.getElementById("coueseTitle").value ="" 
            document.getElementById("ProductDiscription").value ="" 
            document.getElementById("Image1").src = "../assets/img/photo.png"
            AddoCurseImage
             while(document.getElementById("tagContainer").childElementCount!==0){
                document.getElementById("tagContainer").firstChild.remove();
             }
             document.getElementById("saveButton").style.display = ""
                swal("Course Uploaded successfully!")
                tags = [],sptags = [], tagsKey = [];
           
            // console.log("Document successfully updated!");
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });


}else{

    if(cTitle == ""){
        document.getElementById("coueseTitleSpan").style.display = ""

    }else{
        document.getElementById("coueseTitleSpan").style.display = "none"
    }

    if(cDiscription == ""){

        document.getElementById("CourseDiscriptionSpan").style.display = ""

    }else{
        document.getElementById("CourseDiscriptionSpan").style.display = "none"
    }
    if(cImage == ""){

        document.getElementById("CourseImagesSpan").style.display = ""

    }else{

        document.getElementById("CourseImagesSpan").style.display = "none"
    }

    if(tags.length == 0){

        document.getElementById("KeywordSpan").style.display = ""
    }else{

        document.getElementById("KeywordSpan").style.display = "none"
    }

    
    if(Price == ""){

        document.getElementById("priceideSpan").style.display = ""
    }else{

        document.getElementById("priceideSpan").style.display = "none"
    }

    if(Dprice == ""){

        document.getElementById("dpriceideSpan").style.display = ""
    }else{

        document.getElementById("dpriceideSpan").style.display = "none"
    }



}   

}

keyword.addEventListener("keyup",function(event){
    //console.log(event);
    if(event.keyCode === 13)
    {
        if(keyword.value == "" || keyword.value == " ")
        {
            swal("Keyword Not be Blank");
            keyword.value = "";
        }
        else
        {
            //let str = (keyword.value).replaceAll(" ","");
            addTags((keyword.value).toLowerCase());
            keyword.value = "";
        }
    }
})
DpriceInPerDpriceInPer
function addTags(val)
{
    var par = document.getElementById('tagContainer');
    var tag = document.createElement('span');
    tag.setAttribute('id',val);
    tag.classList.add('badge','bg-dark');
    tag.innerHTML = val+' <span class="closetag" onclick="removeTags(this)">&times;</span>';
    par.appendChild(tag);
    tags.push(val);
    createKeywords(val);
    //console.log(tags,tagsKey);
}
//<span id="vivek" class="badge badge-pill badge-primary">vivek <span class="closetag" onclick="removeTags(this)">×</span></span>
function createKeywords(name) 
{   
    const arrName = [];
    let curName = '';
    name.split('').forEach(letter => {
    curName += letter;
    arrName.push(curName.trim());
    });
    tagsKey = tagsKey.concat(arrName);
    console.log("tagsKey",tags)

}

function removeTags(ele)
{
    tagsKey = [];
    let tname = ele.parentElement.id;
    let i = tags.indexOf(tname);
    tags.splice(i,1);
    
    for(var k = 0;k<tags.length;k++)
    {
        createKeywords(tags[k]);
    }
    
    ele.parentElement.remove();
    //console.log(tags,tagsKey);
}

function removeAllTags()
{
    var tagbody = document.getElementById('tagContainer');
    while(tagbody.firstChild)
    {
        tagbody.removeChild(tagbody.firstChild);
    }
    //another 
    var sptagbody = document.getElementById('sptagContainer');
    while(sptagbody.firstChild)
    {
        sptagbody.removeChild(sptagbody.firstChild);
    }
}

function SetPrice(params) {
    
    var Price = Number(document.getElementById("priceid").value);
    var Dprice =  Number(document.getElementById("dpriceid").value);
    if(params=='price'){

        document.getElementById("dpriceid").value = "00";

    }else if(params=='dprice'){

      if(Dprice <= Price)  {
        document.getElementById("dpriceideSpan").style.display= "none";

      }else{
        document.getElementById("dpriceideSpan").style.display= "";
      }
      document.getElementById("perId").value = (((Price - Dprice) / Price) * 100)
    }

}