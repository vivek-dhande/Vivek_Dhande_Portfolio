var firestore = firebase.firestore();

var index=0;
var courseDoc;
var coursData = [];
var CourseDataIndex = 0;
var CourseDataDocRef;
function getCourseList(params) {

    firestore.collection("Courses").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
           $('#courseList').append(` <option value="${doc.data().courseTitle}" ></option>  `)
        });
    });
    
}
getCourseList();
function getCourseDoc(params) {

    firestore.collection("Courses").where("courseTitle", "==",params)
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            courseDoc = doc.id;
         
        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    
}

function AddData(params) {
    
    var VideoTitle = document.getElementById(`videotitle${index}`).value;
    var VideoLink = document.getElementById(`link${index}`).value;
    var Notes = document.getElementById(`fileTitle${index}`).value;

    if(VideoTitle!=="" && VideoLink!=="" && Notes !=="" ){
        document.getElementById("uploading").style.display = "flex"
        document.getElementById("addDataButton").style.display = "none"
        document.getElementById("saveButton").style.display = "none"
        
        const ref = firebase.storage().ref();
        const file = document.getElementById(`fileTitle${index}`).files[0]
    
        const name =  file.name;
    
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('MRCOG_Goal_Files/' + name).put(file, metadata);


            task .then(snapshot => snapshot.ref.getDownloadURL())
            .then((url) => {
      

                coursData[CourseDataIndex++] = {videoTitle:VideoTitle,videoLink:VideoLink,notes:url}  

                //    firestore.collection("Courses").doc(courseDoc).collection("CourseData").add({
    
                //         videoTitle : videoTitle,
                //         videoLink: videoLink,
                //         notes : url
                // })
           
        }).then(()=>{
          
  
            // document.getElementById(`"videotitle${index}"`).value ="" 
            // document.getElementById(`"link${index}"`).value =""  
            // document.getElementById(`"fileTitle${index}"`).value ="" 
            document.getElementById("uploading").style.display = "none"
            document.getElementById("addDataButton").style.display = "flex"
            document.getElementById("saveButton").style.display = "flex"    
          
            swal("Video Data Added successfully!")
          
               
                // console.log("Document successfully updated!");
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });


    }
    else if(VideoTitle!=="" && VideoLink!=="" && Notes =="" ){
        const p1 = new Promise((resolve, reject) => {
            document.getElementById("uploading").style.display = "flex"
            document.getElementById("addDataButton").style.display = "none"
            document.getElementById("saveButton").style.display = "none"

  

            coursData[CourseDataIndex++] = {videoTitle:VideoTitle,videoLink:VideoLink,notes:""}  

            resolve("Success!");
            // or
            // reject(new Error("Error!"));
          });
          
          p1.then(
            (value) => {
                document.getElementById("uploading").style.display = "none"
                document.getElementById("addDataButton").style.display = "flex"
                document.getElementById("saveButton").style.display = "flex"
                console.log("coursData",coursData)
                swal("Video Data Added successfully!")
              console.log(value); // Success!
            },
            (reason) => {
              console.error(reason); // Error!
            },
          );



    }
    else{

        if(VideoTitle == ""){

            document.getElementById("titleSpan").style.display =""

        }else{
            document.getElementById("titleSpan").style.display = "none"
        }

        if(VideoLink == ""){

            document.getElementById("linkSpan").style.display =""

        }else{
            document.getElementById("linkSpan").style.display = "none"
        }

    }
}

function SaveChapterData(params) {

    
    
         firestore.collection("Courses").doc(courseDoc).collection("CourseData").add({
            
                data:coursData
              
        }).then((docRef)=> {

            CourseDataDocRef = docRef.id;
            console.log("docRef.id",docRef.id);
            CourseDataIndex++;
            swal("Video Data Added successfully!")
        
        })
}