function verifyData() {
    userEmail = document.getElementById("userEmail").value, userPass = document.getElementById("userPass").value, "" == userEmail ? swal("Email Not Be Blank!") : "" == userPass ? swal("Password Not Be Blank!") : ValidateEmail(userEmail) ? (load.classList.add("d-none"), loading.classList.remove("d-none"), firebase.auth().signInWithEmailAndPassword(userEmail, userPass).then(function() {
        document.getElementById("userEmail").value = "", document.getElementById("userPass").value = "", window.location.href = "/ViewCourse/viewCourse.html"
    }).catch(function(a) {
        var e = a.message;
        swal(e), load.classList.remove("d-none"), loading.classList.add("d-none")
    })) : swal("Enter Valid Email!")
}

function ValidateEmail(a) {
    return !!a.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
}

firebase.auth().onAuthStateChanged(function(a) {
    a && (window.location.href = "/ViewCourse/viewCourse.html")
});
var userEmail, userPass, load = document.getElementById("load"),
    loading = document.getElementById("loading");