var firestore = firebase.firestore();
var courseDoc;
var MediaFlag;
var MediaInput;
var moduleDoc;
var lessonListArray = [];
function getCourseList(params) {

    firestore.collection("Courses").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
           $('#courseList').append(` <option value="${doc.data().courseTitle}" ></option>  `)
        });
    });
    
}
getCourseList();

function getCourseDoc(params) {

    firestore.collection("Courses").where("courseTitle", "==",params)
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            courseDoc = doc.id;

            var docRef = firestore.collection("Courses").doc(courseDoc).collection("Modules");

            docRef.get().then((querySnapshot) => {
                querySnapshot.forEach((doc) => {
                    // doc.data() is never undefined for query doc snapshots
                   $('#ModuleList').append(` <option value="${doc.data().moduleName}" ></option>  `)
                });
            });

        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    
}

function getModuleDoc(params) {
    firestore.collection("Courses").doc(courseDoc).collection("Modules").where("moduleName", "==",params)
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            moduleDoc = doc.id
        })
    }).then(()=>{

        var  docRef2 = firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc);
        docRef2.get().then((doc) => {
                if (doc.exists) {

                    console.log("Document data:", doc.data().lessonList);
                    doc.data().lessonList !== undefined ? lessonListArray = doc.data().lessonList : "";

                    // lessonListArray = doc.data().LessonList;
                } else {
                    // doc.data() will be undefined in this case
                    console.log("No such document!");
                }
            }).then(()=>{

                swal("Array Fetched");

            }).catch((error) => {
                console.log("Error getting document:", error);
            });
    })
}

function GetMediaFlag(params) {

    console.log("params",params);
 
  
  console.log("File Radio",document.getElementById("FileRadiio").checked)
  console.log("Video Radio",document.getElementById("VideoRadio").checked)
    // document.getElementById("TypePDF").style.display = "none"

    if(params == "File"){
        MediaFlag = params;
    document.getElementById("Link_File").style.display = ""
    }else if(params == "Video"){
        MediaFlag = params;
    document.getElementById("TypeLink").style.display = "" 
    document.getElementById("TypePDF").style.display = "none"
    document.getElementById("Link_File").style.display = "none"

    
    }
}

function SetInputForFile(params) {

    console.log("params",params);
    // document.getElementById("TypePDF").style.display = "flex"
    // document.getElementById("TypePDF").style.display = "none"

    if(params == "File"){
        MediaInput = params;
    document.getElementById("TypePDF").style.display = ""
    document.getElementById("TypeLink").style.display = "none"
    }else if(params == "Link"){
        MediaInput = params;
    document.getElementById("TypePDF").style.display = "none"
    document.getElementById("TypeLink").style.display = ""
    }
}

function saveLesson(params) {

    var SelectedCourse = document.getElementById("CourseListInput").value
    var SelectedModule = document.getElementById("ModuleListInput").value 
    // var lessonNo = document.getElementById("LeasonNO").value;
    var lessonTitle = document.getElementById("LeasonName").value
    var lessonDescription = document.getElementById("LessonDescription").value
    var lessonLink = document.getElementById("LeasonLink").value;
    var lessonFile = document.getElementById("lessonFile").value;

    console.log("Output",lessonListArray)

    if(SelectedCourse!=="" && SelectedModule!=="" && lessonTitle !=="" && lessonDescription !== "" && MediaFlag !== undefined ){
        document.getElementById("saveButton").style.display = "none"
  
       console.log("|Outer Validation are Valid|");

        if(MediaFlag == "File" && MediaInput !== undefined && (lessonLink!=="" || lessonFile !=="")){
            console.log("|In File Parent Section|");

       

            if(MediaInput =="Link"){
                console.log("");
                 document.getElementById("Upaloadimg").style.display = "flex"
                firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({
        
                    lessonTitle : lessonTitle,
                    lessonDescription : lessonDescription,
                    mediatype : MediaFlag,
                    media : lessonLink,
                    //sno : lessonNo,
                    date : firebase.firestore.Timestamp.fromDate(new Date())
                })
                .then(()=>{
                
    
                    document.getElementById("LeasonName").value ="" 
                    document.getElementById("LessonDescription").value =""  
                    document.getElementById("FileRadiio").checked = false
                    document.getElementById("VideoRadio").checked = false
                    document.getElementById("LinkInput").checked = false
                    document.getElementById("FileInput").checked = false 
                    document.getElementById("LeasonLink").value =""  
                    document.getElementById("lessonFile").value ="" 
                    document.getElementById("saveButton").style.display = ""
                    document.getElementById("Upaloadimg").style.display = "none"
                    swal("Video Data Added successfully!")
                    lessonListArray.push({title:lessonTitle,mediaType:MediaFlag})
                                
                    // console.log("Document successfully updated!");
            }).then(()=>{
                firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).update({

                    lessonList :  lessonListArray
                    
                })
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
                
            // var  docRef2 = firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson");
            // docRef2.get().then((doc) => {
            //         if (doc.exists) {
            //             console.log("Document data:", doc.data().LessonList);
            //         } else {
            //             // doc.data() will be undefined in this case
            //             console.log("No such document!");
            //         }
            //     }).then(()=>{
                
    
            //         document.getElementById("LeasonName").value ="" 
            //         document.getElementById("LessonDescription").value =""  
            //         document.getElementById("FileRadiio").checked = false
            //         document.getElementById("VideoRadio").checked = false
            //         document.getElementById("LinkInput").checked = false
            //         document.getElementById("FileInput").checked = false 
            //         document.getElementById("LeasonLink").value =""  
            //         document.getElementById("lessonFile").value ="" 
                
            //         document.getElementById("Upaloadimg").style.display = "none"
            //         swal("Video Data Added successfully!")
                
                    
            //             // console.log("Document successfully updated!");
            //     }).catch((error) => {
            //         console.log("Error getting document:", error);
            //     });
                
    
            }else if(MediaInput =="File"){

                alert("In File")
                if(MediaInput == "File"){
                    document.getElementById("Upaloadimg").style.display = "flex"
                    const ref = firebase.storage().ref();
                    const file = document.getElementById("lessonFile").files[0]
        
                    const name =  file.name;
        
                    const metadata = {
                    contentType: file.type
                    };
                    const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);
        
        
                        task .then(snapshot => snapshot.ref.getDownloadURL())
                        .then((url) => {
                
                            firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({
        
                                lessonTitle : lessonTitle,
                                lessonDescription : lessonDescription,
                                mediatype : MediaFlag,
                                media : url,
                                date : firebase.firestore.Timestamp.fromDate(new Date())
                            })
                    
                            }).then(()=>{
                            
                
                                document.getElementById("LeasonName").value ="" 
                                document.getElementById("LessonDescription").value =""  
                                document.getElementById("FileRadiio").checked = false
                                document.getElementById("VideoRadio").checked = false
                                document.getElementById("LinkInput").checked = false
                                document.getElementById("FileInput").checked = false 
                                document.getElementById("LeasonLink").value =""  
                                document.getElementById("lessonFile").value ="" 
                                document.getElementById("saveButton").style.display = ""
                                document.getElementById("Upaloadimg").style.display = "none"
                                swal("Video Data Added successfully!")
                                lessonListArray.push({title:lessonTitle,mediaType:MediaFlag})
                                
                                    // console.log("Document successfully updated!");
                            }).then(()=>{
                                firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).update({
        
                                    lessonList :  lessonListArray
                          
                                })
                            })
                            .catch((error) => {
                                // The document probably doesn't exist.
                                console.error("Error updating document: ", error);
                            });

              
        
                    }else if(MediaInput == "Link"){
                        alert("In File Link");
                        document.getElementById("Upaloadimg").style.display = "flex"
                        firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({
        
                            lessonTitle : lessonTitle,
                            lessonDescription : lessonDescription,
                            mediatype : MediaFlag,
                            media : lessonLink,
                            date : firebase.firestore.Timestamp.fromDate(new Date())
                        }).then(()=>{
        
                            document.getElementById("LeasonName").value ="" 
                            document.getElementById("LessonDescription").value =""  
                            document.getElementById("FileRadiio").checked = false
                            document.getElementById("VideoRadio").checked = false
                            document.getElementById("LinkInput").checked = false
                            document.getElementById("FileInput").checked = false 
                            document.getElementById("LeasonLink").value =""  
                            document.getElementById("lessonFile").value ="" 
                            document.getElementById("saveButton").style.display = ""
                            document.getElementById("Upaloadimg").style.display = "none"
                            swal("Video Data Added successfully!")
                            lessonListArray.push({title:lessonTitle,mediaType:MediaFlag})                                
                                    // console.log("Document successfully updated!");
                            }).then(()=>{
                                firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).add({
        
                                    lessonList :  lessonListArray
                          
                                })
                            })
                            .catch((error) => {
                                // The document probably doesn't exist.
                                console.error("Error updating document: ", error);
                            });
                    }
            }

        }else if(MediaFlag == "Video" && lessonLink!=="" ){

            if(MediaFlag =="Video"){
                document.getElementById("Upaloadimg").style.display = "flex"
                firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({
        
                    lessonTitle : lessonTitle,
                    lessonDescription : lessonDescription,
                    mediatype : MediaFlag,
                    media : lessonLink,
                    //sno : lessonNo,
                    date : firebase.firestore.Timestamp.fromDate(new Date())
                })
                .then(()=>{
                
    
                    document.getElementById("LeasonName").value ="" 
                    document.getElementById("LessonDescription").value =""  
                    document.getElementById("FileRadiio").checked = false
                    document.getElementById("VideoRadio").checked = false
                    document.getElementById("LinkInput").checked = false
                    document.getElementById("FileInput").checked = false 
                    document.getElementById("LeasonLink").value =""  
                    document.getElementById("lessonFile").value ="" 
                    document.getElementById("saveButton").style.display = ""
                    document.getElementById("Upaloadimg").style.display = "none"
                    swal("Video Data Added successfully!")
                    lessonListArray.push({title:lessonTitle,mediaType:MediaFlag})
                                
                    // console.log("Document successfully updated!");
            }).then(()=>{
                firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).update({

                    lessonList :  lessonListArray
          
                })
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
    
            }else if(MediaFlag =="File"){
                if(MediaInput == "File"){
                    document.getElementById("Upaloadimg").style.display = "flex"
                    alert("In File")
                    const ref = firebase.storage().ref();
                    const file = document.getElementById("lessonFile").files[0]
        
                    const name =  file.name;
        
                    const metadata = {
                    contentType: file.type
                    };
                    const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);
        
        
                        task .then(snapshot => snapshot.ref.getDownloadURL())
                        .then((url) => {
                
                            firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({
        
                                lessonTitle : lessonTitle,
                                lessonDescription : lessonDescription,
                                mediatype : MediaFlag,
                                media : url,
                                date : firebase.firestore.Timestamp.fromDate(new Date())

                            })
                    
                    }).then(()=>{
                    
        
                        document.getElementById("LeasonName").value ="" 
                        document.getElementById("LessonDescription").value =""  
                        document.getElementById("FileRadiio").checked = false
                        document.getElementById("VideoRadio").checked = false
                        document.getElementById("LinkInput").checked = false
                        document.getElementById("FileInput").checked = false 
                        document.getElementById("LeasonLink").value =""  
                        document.getElementById("lessonFile").value ="" 
                        document.getElementById("saveButton").style.display = ""
                        document.getElementById("Upaloadimg").style.display = "none"
                        lessonListArray.push(lessonTitle)
                                
                        // console.log("Document successfully updated!");
                        }).then(()=>{
                            firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).add({

                                lessonList :  lessonListArray
                    
                            })
                        })
                        .catch((error) => {
                            // The document probably doesn't exist.
                            console.error("Error updating document: ", error);
                        });
                
                    }else if(MediaInput == "Link"){
                         document.getElementById("Upaloadimg").style.display = "flex"
                        firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({
        
                            lessonTitle : lessonTitle,
                            lessonDescription : lessonDescription,
                            mediatype : MediaFlag,
                            media : lessonLink,
                            //sno : lessonNo,
                            date : firebase.firestore.Timestamp.fromDate(new Date())
                        }).then(()=>{
        
                            document.getElementById("LeasonName").value ="" 
                            document.getElementById("LessonDescription").value =""  
                            document.getElementById("FileRadiio").checked = false
                            document.getElementById("VideoRadio").checked = false
                            document.getElementById("LinkInput").checked = false
                            document.getElementById("FileInput").checked = false 
                            document.getElementById("LeasonLink").value =""  
                            document.getElementById("lessonFile").value ="" 
                            document.getElementById("saveButton").style.display = ""
                            document.getElementById("Upaloadimg").style.display = "none"
                            swal("Video Data Added successfully!")
                            lessonListArray.push(lessonTitle)
                                
                            // console.log("Document successfully updated!");
                    }).then(()=>{
                        firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).add({

                            lessonList :  lessonListArray
                  
                        })
                    })
                    .catch((error) => {
                        // The document probably doesn't exist.
                        console.error("Error updating document: ", error);
                    });
                
                    }
            }

        }else{
            if(MediaInput == undefined){
                document.getElementById("file_linkSpan").style.display = ""
            }else{
                document.getElementById("file_linkSpan").style.display ="none"
            }

            if(MediaFlag !== "Video"){
                if(lessonFile == ""){
                    document.getElementById("lessonfile_Span").style.display = ""
                }else{
                    document.getElementById("lessonfile_Span").style.display = "none"

                }

                if(lessonLink == ""){

                    document.getElementById("lessonlink_Span").style.display = ""
                
                }else{

                    document.getElementById("lessonlink_Span").style.display = "none"

                }
            }else{
                if(lessonLink == ""){

                    document.getElementById("lessonlink_Span").style.display = ""
                
                }else{

                    document.getElementById("lessonlink_Span").style.display = "none"

                }
            }
            
        }


       
           

        
    }
    else{

        if(SelectedCourse == ""){

            document.getElementById("Course_Span").style.display =""

        }else{
            document.getElementById("Course_Span").style.display = "none"
        }

        if(SelectedModule == ""){

            document.getElementById("Module_Span").style.display =""

        }else{
            document.getElementById("Module_Span").style.display = "none"
        }

        if(lessonTitle == ""){

            document.getElementById("LeasonName_Span").style.display =""

        }else{
            document.getElementById("LeasonName_Span").style.display = "none"
        }

        if(lessonDescription == ""){

            document.getElementById("Module_Discription_Span").style.display = ""

        }else{
            document.getElementById("Module_Discription_Span").style.display = "none"
        }

        if(MediaFlag == undefined){

            document.getElementById("MediaFlagSpan").style.display = ""
        }else{
            document.getElementById("MediaFlagSpan").style.display ="none"
        }



    }

}

