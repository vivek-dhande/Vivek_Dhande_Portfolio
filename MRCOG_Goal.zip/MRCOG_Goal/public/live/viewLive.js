var firestore = firebase.firestore();
var CourseDropDown = document.getElementById("courseID")
var CourseDoc;
var LiveDoc;
var courseList = [];
var courseListIndex = 0;
getCourseList();
function getCourseList(params) {
    firestore.collection("Courses").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            courseList[courseListIndex++] = {course_Name:doc.data().courseTitle,courseDoc:doc.id}

          $("#courseID").append(`<option value="${doc.data().courseTitle}" >${doc.data().courseTitle}</option>`)
        });
    });
}

CourseDropDown.addEventListener("change",function(params) {
    firestore.collection("Courses").where("courseTitle", "==", params.target.value)
    .get()
    .then((querySnapshot) => {
        while(document.getElementById("liveList").childElementCount!==0){
            document.getElementById("liveList").firstChild.remove();
        }
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            var  index = courseList.find(x => x.course_Name === doc.data().courseTitle);
            CourseDoc = index.courseDoc;
            // CourseDoc = doc.id;
            getLiveList(index.courseDoc)
            console.log(doc.id, " => ", doc.data());
        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
})

function getLiveList(params) {
    
    var docRef = firestore.collection("Courses").doc(params).collection("Live");

    docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((e)=>{
            $("#liveList").append(`<li class="list-group-item d-flex justify-content-between align-items-center">
         ${e.data().title}
            <button type="button" class="btn btn-icon btn-primary" id="${e.id}" onclick="editLive(this.id)">
              <i class='bx bx-edit'></i>
            </button>
          </li>`)
        })
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
}


function editLive(params) {
    // alert("You are that");
    LiveDoc = params

    var myModal = new bootstrap.Modal(document.getElementById('EditSliderModal'))

    

    var docRef = firestore.collection("Courses").doc(CourseDoc).collection("Live").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {

            console.log("Date", )
            document.getElementById("LiveTitle").value = doc.data().title
            document.getElementById("LiveDiscription").value = doc.data().liveDescription
            document.getElementById("html5-datetime-local-input").value = moment(doc.data().date.toDate()).format('YYYY-MM-DDThh:mm')
            document.getElementById('defaultSelect2').value = doc.data().flag == true ? "Live" : "Offline"
            document.getElementById('Meetingid').value = doc.data().meetingId
            document.getElementById('Passcodeid').value = doc.data().passcode
            document.getElementById('Image1').src = doc.data().thumb
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).then(()=>{
        myModal.show()
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

function saveEditedLive(params) {

   
    var LiveTitle = document.getElementById("LiveTitle").value
    var LiveDiscription = document.getElementById("LiveDiscription").value
    var LiveDate = document.getElementById("html5-datetime-local-input").value
    var LiveFlag =  document.getElementById('defaultSelect2').value == "Live" ? true : document.getElementById('defaultSelect2').value == "Offline" ? false : "Live Status";
    var LiveMeetingId = document.getElementById('Meetingid').value;
    var LivePasscode  = document.getElementById('Passcodeid').value;
    var LiveThambnail = document.getElementById("AddCourseImage").value;



    if( LiveTitle !=="" && LiveDiscription!=="" && LiveMeetingId!=="" && LivePasscode!=="" && LiveThambnail!=="" && LiveFlag!=="Live Status"){
        document.getElementById("saveButton").style.display = "none"
        document.getElementById("Uploading").style.display = "flex"
        document.getElementById("Image1").style.display = "none"
        const ref = firebase.storage().ref();
        const file = document.querySelector('#AddCourseImage').files[0]

        const name =  file.name;

        const metadata = {
        contentType: file.type
        };
        const task = ref.child('MRCOG_Goal_Images/' + name).put(file, metadata);


            task .then(snapshot => snapshot.ref.getDownloadURL())
            .then((url) => {
    
            var washingtonRef = firestore.collection("Courses").doc(CourseDoc).collection("Live").doc(LiveDoc);

            return washingtonRef.update({
                title : LiveTitle ,
                liveDescription : LiveDiscription ,
                date :firebase.firestore.Timestamp.fromDate(new Date(LiveDate)),
                flag:LiveFlag,
                meetingId:LiveMeetingId,
                passcode:LivePasscode,
                thumb:url
            })
            .then(() => {
                document.getElementById("Uploading").style.display = "none"
                document.getElementById("Image1").style.display = "flex"
                document.getElementById("saveButton").style.display = ""
                swal("Live Updated");
                location.reload();
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
        })
    }else if( LiveTitle !=="" && LiveDiscription!=="" && LiveMeetingId!=="" && LivePasscode!=="" && LiveFlag!=="Live Status"){
        document.getElementById("saveButton").style.display = "none"
        document.getElementById("Uploading").style.display = "flex"
        document.getElementById("Image1").style.display = "none"

        var washingtonRef = firestore.collection("Courses").doc(CourseDoc).collection("Live").doc(LiveDoc);

        return washingtonRef.update({
            title : LiveTitle ,
            liveDescription : LiveDiscription ,
            date :firebase.firestore.Timestamp.fromDate(new Date(LiveDate)),
            flag:LiveFlag,
            meetingId:LiveMeetingId,
            passcode:LivePasscode,
         
        })
        .then(() => {
            document.getElementById("Uploading").style.display = "none"
            document.getElementById("Image1").style.display = "flex"
            document.getElementById("saveButton").style.display = ""
            swal("Live Updated");
            location.reload();
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });
    }else{


            if(LiveFlag =="Live Status"){

                document.getElementById("liveornotidSpan").style.display = "";
            }else{
            
                document.getElementById("liveornotidSpan").style.display = "none";
                
            }

            if(LiveTitle == ""){

                document.getElementById("LiveTitleSpan").style.display = "";
            }else{

                document.getElementById("LiveTitleSpan").style.display = "none";
                
            }

            if(LiveDiscription == ""){

                document.getElementById("LiveDiscriptionSpan").style.display = "";
            }else{
                document.getElementById("LiveDiscriptionSpan").style.display = "none";
                
            }

            if(LiveFlag == "Live Status"){

                document.getElementById("liveornotidSpan").style.display = "";
            }else{

                document.getElementById("liveornotidSpan").style.display = "none";
                
            }

            if(LiveMeetingId == ""){

                document.getElementById("MeetingideSpan").style.display = "";
            }else{

                document.getElementById("MeetingideSpan").style.display = "none";
                
            }

            if(LivePasscode == ""){

                document.getElementById("PasscodeidSpan").style.display = "";
            }else{

                document.getElementById("PasscodeidSpan").style.display = "none";
                
            }
            
            if(LiveThambnail == ""){


                document.getElementById("CourseImagesSpan").style.display = "";
            }else{
                document.getElementById("CourseImagesSpan").style.display = "none";
            }

        }
}


function AddImgForSLider(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#Image1')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}