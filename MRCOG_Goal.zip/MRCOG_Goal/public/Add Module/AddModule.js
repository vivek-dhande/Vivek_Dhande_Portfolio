var firestore = firebase.firestore();
var courseDoc;


function getCourseList(params) {

    firestore.collection("Courses").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
           $('#courseList').append(` <option value="${doc.data().courseTitle}" ></option>  `)
        });
    });
    
}
getCourseList();

function getCourseDoc(params) {

    firestore.collection("Courses").where("courseTitle", "==",params)
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            courseDoc = doc.id;
        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    
}

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#Module_Image')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}

function AddModule(params) {
    
    var Module_Name = document.getElementById("ModuleName").value;
    var Module_Discription = document.getElementById("ModuleDescription").value;
    var Module_Thumbnail= document.getElementById("ModuleThumbnail").value;
    var Courses = document.getElementById("CourseListInput").value;
    var Sno = document.getElementById("ModuleNO").value;
    console.log("Course_Span",Courses)
    if(Module_Name!=="" && Module_Discription!=="" && Module_Thumbnail !=="" && Courses !== "" && Sno!=="" ){

        document.getElementById("preview").style.display = "none"
        document.getElementById("Upaloadimg").style.display = "flex" 
        document.getElementById("saveButton").style.display = "none"

        const ref = firebase.storage().ref();
        const file = document.getElementById("ModuleThumbnail").files[0]
    
        const name =  file.name;
    
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);


            task .then(snapshot => snapshot.ref.getDownloadURL())
            .then((url) => {
      
                   firestore.collection("Courses").doc(courseDoc).collection("Modules").add({
    
                        moduleName : Module_Name,
                        moduleDiscription: Module_Discription,
                        moduleThumbnail : url,
                        sno:Sno
                })
           
        }).then(()=>{
          
  
            document.getElementById("ModuleName").value ="" 
            document.getElementById("ModuleDescription").value =""  
            document.getElementById("ModuleThumbnail").value =""
            document.getElementById("ModuleNO").value =""

            document.getElementById("preview").style.display = "flex" 
            document.getElementById("Module_Image").src = "/assets/img/photo.png"
            document.getElementById("Upaloadimg").style.display = "none"
            document.getElementById("saveButton").style.display = ""
            swal("Module Added successfully!")
          
               
                // console.log("Document successfully updated!");
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });

    }
    else{

        if(Module_Name == ""){

            document.getElementById("ModuleName_Span").style.display =""

        }else{
            document.getElementById("ModuleName_Span").style.display = "none"
        }

        if(Module_Discription == ""){

            document.getElementById("Module_Discription_Span").style.display =""

        }else{
            document.getElementById("Module_Discription_Span").style.display = "none"
        }

        if(Module_Thumbnail == ""){

            document.getElementById("ModuleThumbnail_Span").style.display =""
        }else{
            document.getElementById("ModuleThumbnail_Span").style.display ="none"
        }

        if(Courses == ""){
            document.getElementById("Course_Span").style.display =""
        }else{
            document.getElementById("Course_Span").style.display ="none"
        }

    }
}




