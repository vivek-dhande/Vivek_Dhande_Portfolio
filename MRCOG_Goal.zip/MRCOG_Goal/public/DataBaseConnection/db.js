const firebaseConfig = {
// db config
  };

firebase.initializeApp(firebaseConfig);