
var firestore = firebase.firestore();
var batch = firestore.batch();
var data = [];
var  array = [];
var BulkUploadFlag = false;
var mobile_flag =true;
var result = [];
var i;
var counter = 0;
var KeywordsInput;
function getAllSubstrings(str) {
    result = [];
    i= 0;
    // 	for (let j = 1 ; j < str.length + 1; j++) {
    // 	  result.push(str.slice(i, j));
    
    // 	}
    // 	for (let j = str.indexOf(" ")+2 ; j < str.length + 1; j++) {
    // 	  result.push(str.slice(str.indexOf(" ")+1, j));
    //   }
    for (let j = 1 ; j < str.length + 1; j++) {
        result.push(str.slice(i, j));
    }
    for(let i = 0 ; i<str.length ;i++){
     
        if(str[i] == " "){
    
        for (let j = i+2 ; j < str.length + 1; j++) {
            result.push(str.slice(i+1, j));
        }
    
        }
    }
    return result;
    
    }

function GetCourseList(params) {
    var myModal = new bootstrap.Modal(document.getElementById('GetList'))

    
    firestore.collection("Courses").orderBy("date","desc").get().then((querySnapshot) => {

        while(document.getElementById("CourseList").childElementCount!==0 ){
            document.getElementById("CourseList").firstChild.remove();
        }
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $("#CourseList").append(`<div class="input-group" style="margin-bottom: 0.5rem;">
            <div class="input-group-text">
              <input class="form-check-input mt-0" type="checkbox" value="${doc.id}" aria-label="Checkbox for following text input" onclick="getCourseDoc(this.value)">
            </div>
            <input type="text" class="form-control" value="${doc.data().courseTitle}" aria-label="Text input with checkbox">
          </div>`)
        });
    }).then(()=>{
        array=[];
        myModal.show()
    })
    
}

function getCourseDoc(params) {
    console.log("params",params)

    array.push(params);
console.log("arr",array)
    // array.forEach((doc) => {
    //     var docRef = firestore.collection("Demo").doc(); //automatically generate unique id
    //     batch.set(docRef, doc);
    //   });
    //   batch.commit();
} 

function AddUser(params) {
 
    var userFirstName = document.getElementById("firstName").value;
    var userLastName= document.getElementById("lastName").value;
    var userEmail = document.getElementById("emailId").value; 
    var usermobile = `+91${document.getElementById("mobNo").value}`;
    var MobileNoForKeyWord = document.getElementById("mobNo").value
    var csvFileDaba = document.getElementById("uploadMainFile").value;



    if(BulkUploadFlag == true){
       if(csvFileDaba !== ""){
        if(array.length!==0){
            document.getElementById("CSV_Span").style.display = "none"

document.getElementById("saveButton").style.display = "none"
            data.forEach(element => {
        
                        firestore.collection("UsersData").add({
                            date : firebase.firestore.Timestamp.fromDate(new Date()),
                            userName : element.Name,
                            lastName : element.LastName,
                            email : element.Email,
                            mobile : `+91${element.MobNO}`,
                            coursesList : array,
                            keywords :  getAllSubstrings(`${element.Name.toLowerCase()} ${element.LastName.toLowerCase()} ${element.MobNO.toLowerCase()}`)
                        }).then(()=>{
                            document.getElementById("saveButton").style.display = ""
                            swal("Users Upload Successfully");
                        }) .catch((error) => {
                            console.error("Error adding document: ", error);
                        });

                //   .then((docRef) => {
                
        
                //     array.forEach((doc) => {
                //     var docRef = firestore.collection("UsersData").doc(docRef.id).collection("courses").doc() //automatically generate unique id
                //     batch.set(docRef, doc);
                //   });
                // }).then(()=>{
                //     batch.commit().then(()=>{
                
                //         swal("User Added Successfully");
                //       })
                // })
               
        
        });  
        
        }else{
            if(array.length == 0){
                document.getElementById("Course_Span").style.display = ""
            }else{
                document.getElementById("Course_Span").style.display = "none"
            }
        
        }
       }else{
            if(csvFileDaba == ""){
                document.getElementById("CSV_Span").style.display = ""

            }else{
                document.getElementById("CSV_Span").style.display = "none"
            }
       } 

    }else if(BulkUploadFlag == false){
        document.getElementById("saveButton").style.display = "none"
        if(userFirstName!=="" && userLastName!=="" &&userEmail!=="" && usermobile !=="" && mobile_flag!== false ){
            document.getElementById("firstName_Span").style.display ="none";
            document.getElementById("lastName_Span").style.display ="none";
            document.getElementById("emailId_Span").style.display ="none"; 
            document.getElementById("mobNo_Span").style.display ="none";

            if( array.length > 0){
      
        
                    firestore.collection("UsersData").add({
                        date : firebase.firestore.Timestamp.fromDate(new Date()),
                        userName : userFirstName,
                        lastName : userLastName,
                        email : userEmail,
                        mobile : usermobile,
                        coursesList : array,
                        keywords :  getAllSubstrings(`${userFirstName.toLowerCase()} ${userLastName.toLowerCase()} ${MobileNoForKeyWord.toLowerCase()}`)

                    })
                      .then((docRef) => {

                        result = [];
                        i=0;
                        document.getElementById("firstName").value = "";
                        document.getElementById("lastName").value = "";
                        document.getElementById("emailId").value = ""; 
                        document.getElementById("mobNo").value = "";
                        document.getElementById("saveButton").style.display = ""
                        swal("User Added Successfully");
                    })
                    .catch((error) => {
                        console.error("Error adding document: ", error);
                    });

            
            }else{
                if(array.length == 0){
                    document.getElementById("Course_Span").style.display = ""
                }else{
                    document.getElementById("Course_Span").style.display = "none"
                }
            }
        
        }else{

            if(userFirstName ==""){
                document.getElementById("firstName_Span").style.display ="";
            }else{
                document.getElementById("firstName_Span").style.display ="none";
            }

            if(userLastName ==""){
                document.getElementById("lastName_Span").style.display ="";
            }else{
                document.getElementById("lastName_Span").style.display ="none";
            }

            if(userEmail ==""){
                document.getElementById("emailId_Span").style.display ="";
            }else{
                document.getElementById("emailId_Span").style.display ="none";
            }

            if(usermobile =="+91"){
                document.getElementById("mobNo_Span").style.display ="";
            }else{
                document.getElementById("mobNo_Span").style.display ="none";
            }
            if(array.length == 0){
                document.getElementById("Course_Span").style.display = ""
            }else{
                document.getElementById("Course_Span").style.display = "none"
            }
            
        }

    }

      
}

const uploadFile = document.getElementById("uploadFIle").addEventListener('click',()=>{
    
 

    Papa.parse(document.getElementById('uploadMainFile').files[0],
    {
        download:true,
        header:true,
        skipEmptyLines:true,
        complete:function(results) {
            data = results.data;
       
            swal("File Uploaded Sucessfully")
        
        }
    }
    )
})


function UploadButtonVisibility(params) {

document.getElementById("uploadFIle").disabled = false
}

function vivek(params) {
    
    var SwitchVaribale = document.getElementById("flexSwitchCheckDefault").checked;

    if(SwitchVaribale == true){
        document.getElementById("SwitchLable").innerText = "Bulk Upload";
        document.getElementById("NotBulk").style.display = "none"
        document.getElementById("fileinput").style.display = "";
    document.getElementById("uploadFIle").style.display = ""
        BulkUploadFlag = true;
    }else if(SwitchVaribale == false){
        document.getElementById("SwitchLable").innerText = "Single Upload";
        document.getElementById("NotBulk").style.display = ""
        document.getElementById("fileinput").style.display = "none";
        document.getElementById("uploadFIle").style.display = "none"
        BulkUploadFlag = false;
    }
}

function MobileNoValidation(params) {
    var getNo = document.getElementById("mobNo").value;

    if(getNo.length>10){

        document.getElementById("mobNoval_Span").style.display = "";
    }else{
        document.getElementById("mobNoval_Span").style.display = "none";
    }

    if(getNo.length == 10){
        mobile_flag = true;
    }else{
        mobile_flag = false
    }


}

// data.forEach(element => {
//     firestore.collection("UsersData").add({
//         date : firebase.firestore.Timestamp.fromDate(new Date()),
//         userName : element.Name,
//         email : element.Email,
//         mobile : element.MobNO,
//         coursesList : array
//       })
//     //   .then((docRef) => {
       

//     //     array.forEach((doc) => {
//     //     var docRef = firestore.collection("UsersData").doc(docRef.id).collection("courses").doc() //automatically generate unique id
//     //     batch.set(docRef, doc);
//     //   });
//     // }).then(()=>{
//     //     batch.commit().then(()=>{
    
//     //         swal("User Added Successfully");
//     //       })
//     // })
//       .catch((error) => {
//           console.error("Error adding document: ", error);
//       });

// });  