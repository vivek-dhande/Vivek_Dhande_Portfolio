
var firestore = firebase.firestore();
var courseList ;
var userDoc;
var result = [];
var i= 0;
var UserList = [] ;
var UserList_index = 0;
var data = [];
var dataindex = 0;
var paginationindex=0;
var CurrentPage = 0;
var LastUserListDoc;
function getUserist(params) {
    UserList = [] ;
    UserList_index = 0;
    data = [];
    dataindex = 0;
    paginationindex=0
    CurrentPage = 0;
    firestore.collection("UsersData").orderBy("date","desc").limit(2).get().then((querySnapshot) => {
        LastUserListDoc = querySnapshot.docs[querySnapshot.docs.length-1]
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            data[dataindex++] = [doc.id,doc.data().userName,doc.data().lastName,doc.data().email,doc.data().mobile];

            $("#UserTboday").append(`<tr id="${doc.id}-postcol">
            <td>${doc.data().userName} </td>
            <td>${doc.data().lastName} </td>
            <td>${doc.data().email} </td>
            <td>${doc.data().mobile} </td>
            <td > <center     style ="display: flex;
            align-items: center; justify-content: space-evenly;">

            <div class="form-check form-switch mb-2" >
            <input class="form-check-input" type="checkbox" id="${doc.id}" checked="" onchange="activeOrnot(this.id,this.checked)">
            </div>
            <div>
            <button type="button" class="btn btn-info" id="${doc.id}" onclick="GetCourseList(this.id)" >
            Edit Course
            </button>
            <button type="button" class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#EditSliderModal"id="${doc.id}" onclick="GetUserDetials(this.id)" >
            <i class='bx bx-detail'></i>
             </button>
            <button type="button" class="btn btn-icon btn-danger" id="${doc.id}" onclick="deleteUser(this.id)">
            <i class='bx bx-trash' ></i>
            </button>
            </div> 
        </center>  
        </td>
            </tr>`)
        });
    }).then(()=>{
        UserList[UserList_index++] = data;
        paginationindex++;
        CurrentPage++;
        document.getElementById("table").style.display = ""
        
        document.getElementById("loading").style.display = "none"
    })
    
}
getUserist();

function NextUserList(params) {
    document.getElementById("previousButton").disabled = false; 

    data = [];
    dataindex = 0;
 
    if(paginationindex == CurrentPage ){

        firestore.collection("UsersData").orderBy("date","desc").startAfter(LastUserListDoc).limit(2).get().then((querySnapshot) => {
            
            if( querySnapshot.docs.length == 0 ){
                document.querySelector('#nextButton').disabled = true;
                
                 CurrentPage--;
                paginationindex--;
                 (swal("There is no Record Found"))
              
            }else{
                while(document.getElementById("UserTboday").childElementCount!==0){

                    document.getElementById("UserTboday").firstChild.remove();
                }
                LastUserListDoc = querySnapshot.docs[querySnapshot.docs.length-1]
                querySnapshot.forEach((doc) => {
                    // doc.data() is never undefined for query doc snapshots
                    data[dataindex++] = [doc.id,doc.data().userName,doc.data().lastName,doc.data().email,doc.data().mobile];
    
                    $("#UserTboday").append(`<tr id="${doc.id}-postcol">
                    <td>${doc.data().userName} </td>
                    <td>${doc.data().lastName} </td>
                    <td>${doc.data().email} </td>
                    <td>${doc.data().mobile} </td>
                    <td>
                    <center     style ="display: flex;
            align-items: center; justify-content: space-evenly;">

            <div class="form-check form-switch mb-2" >
            <input class="form-check-input" type="checkbox" id="${doc.id}" checked="" onchange="activeOrnot(this.id,this.checked)">
            </div>
            <div>
            <button type="button" class="btn btn-info" id="${doc.id}" onclick="GetCourseList(this.id)" >
            Edit Course
            </button>
            <button type="button" class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#EditSliderModal"id="${doc.id}" onclick="GetUserDetials(this.id)" >
            <i class='bx bx-detail'></i>
             </button>
            <button type="button" class="btn btn-icon btn-danger" id="${doc.id}" onclick="deleteUser(this.id)" >
            <i class='bx bx-trash' ></i>
            </button>
            </div> 
         </td></center>
                    </tr>`)
                });
                
            }    
            

        }).then(()=>{
            UserList[UserList_index++] = data;
            paginationindex++;
            CurrentPage++;
        })

    }else{

        while(document.getElementById("UserTboday").childElementCount!==0){

            document.getElementById("UserTboday").firstChild.remove();
        }
        
        UserList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

        
    
            $("#UserTboday").append(`<tr id="${doc[0]}-postcol">
            <td>${doc[1]} </td>
            <td>${doc[2]} </td>
            <td>${doc[3]} </td>
            <td>${doc[4]} </td>
            <td><center     style ="display: flex;
            align-items: center; justify-content: space-evenly;">

            <div class="form-check form-switch mb-2" >
            <input class="form-check-input" type="checkbox" id="${doc[0]}" checked="" onchange="activeOrnot(this.id,this.checked)">
            </div>
            <div>
            <button type="button" class="btn btn-info" id="${doc[0]}" onclick="GetCourseList(this.id)" >
            Edit Course
            </button>
            <button type="button" class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#EditSliderModal" id="${doc.id}" onclick="GetUserDetials(this.id)" >
            <i class='bx bx-detail'></i>
             </button>
            <button type="button" class="btn btn-icon btn-danger" id="${doc[0]}" onclick="deleteUser(this.id)" >
            <i class='bx bx-trash' ></i>
            </button>
            </div> 
         </td></center> </td>
            </tr>`)
        });

        CurrentPage++;


    }
}

function Previous_NextUserListt(params) {

    document.getElementById("nextButton").disabled = false; 

    if(CurrentPage!==1){

        while(document.getElementById("UserTboday").childElementCount!==0){ 
            
            document.getElementById("UserTboday").firstChild.remove();
        }
    
        CurrentPage--;
        console.log("Data",CurrentPage,paginationindex);
        UserList[CurrentPage-1].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());
    
            $("#UserTboday").append(`<tr id="${doc[0]}">
            <td>${doc[1]} </td>
            <td>${doc[2]} </td>
            <td>${doc[3]} </td>
            <td>${doc[4]} </td>
            <td><center     style ="display: flex;
            align-items: center; justify-content: space-evenly;">

            <div class="form-check form-switch mb-2" >
            <input class="form-check-input" type="checkbox" id="${doc[0]}" checked="" onchange="activeOrnot(this.id,this.checked)">
            </div>
            <div>
            <button type="button" class="btn btn-info" id="${doc[0]}" onclick="GetCourseList(this.id)" >
            Edit Course
            </button>
            <button type="button" class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#EditSliderModal" id="${doc.id}" onclick="GetUserDetials(this.id)" >
            <i class='bx bx-detail'></i>
             </button>
            <button type="button" class="btn btn-icon btn-danger" id="${doc[0]}" onclick="deleteUser(this.id)" >
            <i class='bx bx-trash' ></i>
            </button>
            </div> 
         </td></center> </td>
            </tr>`)
        });
        
    }else{
        document.getElementById("previousButton").disabled = true; 
    }


    
}


function EditCourseList(params,params2) {
 
    // firestore.collection("UsersData").get().then((querySnapshot) => {
    //     querySnapshot.forEach((doc) => {
    //         // doc.data() is never undefined for query doc snapshots
    //         console.log(doc.id, " => ", doc.data());
    //     });
    // });
    // console.log("params",params)

    // array.push(params);
    // console.log("arr",array)
    if(params2.checked == true){

        courseList.push(params);
        console.log(courseList); 
    }else if(params2.checked == false){
        const index = courseList.indexOf(params);
        if (index > -1) { // only splice array when item is found
            courseList.splice(index, 1); // 2nd parameter means remove one item only
        }
       
        console.log(courseList); 
    }

 
     // { name: 'cherries', quantity: 5 }


}

function GetCourseList(params) {
    
    userDoc = params
    var docRef = firestore.collection("UsersData").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {
            courseList = doc.data().coursesList;
            console.log(courseList,params); 
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });


    var myModal = new bootstrap.Modal(document.getElementById('GetList'))

    
    firestore.collection("Courses").orderBy("date","desc").get().then((querySnapshot) => {

        while(document.getElementById("CourseList").childElementCount!==0 ){
            document.getElementById("CourseList").firstChild.remove();
        }
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
          console.log("doc.id",doc.id,courseList)
            if(courseList!== undefined &&  courseList.includes(`${doc.id}`)){
                $("#CourseList").append(`<div class="input-group" style="margin-bottom: 0.5rem;">
                <div class="input-group-text">
                  <input class="form-check-input mt-0" type="checkbox" value="${doc.id}" aria-label="Checkbox for following text input" onclick="EditCourseList(this.value,this)" checked>
                </div>
                <input type="text" class="form-control" value="${doc.data().courseTitle}" aria-label="Text input with checkbox">
              </div>`)
            }else{
                $("#CourseList").append(`<div class="input-group" style="margin-bottom: 0.5rem;">
                <div class="input-group-text">
                  <input class="form-check-input mt-0" type="checkbox" value="${doc.id}" aria-label="Checkbox for following text input" onclick="EditCourseList(this.value,this)" >
                </div>
                <input type="text" class="form-control" value="${doc.data().courseTitle}" aria-label="Text input with checkbox">
              </div>`)
            }
       
        });
    }).then(()=>{
        array=[];
        myModal.show()
    })
}

function updateCourseList(params) {
    var washingtonRef = firestore.collection("UsersData").doc(userDoc);

    // Set the "capital" field of the city 'DC'
    return washingtonRef.update({
        coursesList : courseList
    })
    .then(() => {
        alert("Document successfully updated!");
    })
    .catch((error) => {
        // The document probably doesn't exist.
        console.error("Error updating document: ", error);
    });
}
function getAllSubstrings(str) {
    result = [];
    i= 0;
    // 	for (let j = 1 ; j < str.length + 1; j++) {
    // 	  result.push(str.slice(i, j));
    
    // 	}
    // 	for (let j = str.indexOf(" ")+2 ; j < str.length + 1; j++) {
    // 	  result.push(str.slice(str.indexOf(" ")+1, j));
    //   }
    for (let j = 1 ; j < str.length + 1; j++) {
        result.push(str.slice(i, j));
    }
    for(let i = 0 ; i<str.length ;i++){
     
        if(str[i] == " "){
    
        for (let j = i+2 ; j < str.length + 1; j++) {
            result.push(str.slice(i+1, j));
        }
    
        }
    }
    return result;
    
}

function GetUserDetials(params) {

    userDoc = params
    var docRef = firestore.collection("UsersData").doc(params); 
    
    docRef.get().then((doc) => {
        if (doc.exists) {
            document.getElementById("firstName").value = doc.data().userName
            document.getElementById("lastName").value = doc.data().lastName 
            document.getElementById("emailId").value = doc.data().email  
            document.getElementById("mobNo").value =  doc.data().mobile

            while(document.getElementById("courseListID").childElementCount!==0){
                document.getElementById("courseListID").firstChild.remove();
            }

            doc.data().coursesList.forEach((e)=>{

                    var docRef = firestore.collection("Courses").doc(e);

                    docRef.get().then((doc) => {
                        if (doc.exists) {
                              $("#courseListID").append(`<a href="javascript:void(0);" class="list-group-item list-group-item-action">${doc.data().courseTitle}</a>
                                `)
                        } else {
                            // doc.data() will be undefined in this case
                            console.log("No such document!");
                        }
                    }).catch((error) => {
                        console.log("Error getting document:", error);
                    });

        

         })
        
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
}
function UpdateUserDetails(params) {
    var FirstNameEdit = document.getElementById("firstName").value;
    var LastNameEdit = document.getElementById("lastName").value;
    var EmailEdit  = document.getElementById("emailId").value;
    var MobileEdit = document.getElementById("mobNo").value
    var SearchKeywords = getAllSubstrings(`${FirstNameEdit} ${LastNameEdit} ${MobileEdit}`)
    var washingtonRef = firestore.collection("UsersData").doc(userDoc);

    // Set the "capital" field of the city 'DC'
    return washingtonRef.update({
        userName : FirstNameEdit,
        lastName  : LastNameEdit,
        email: EmailEdit,
        mobile : MobileEdit,
        keywords : SearchKeywords,

    })
    .then(() => {
        swal("Document successfully updated!");
    })
    .catch((error) => {
        // The document probably doesn't exist.
        console.error("Error updating document: ", error);
    });

}

function searchUser(params) {
    alert("Vivek Dhande")
    var tobeSearch = document.getElementById("SearchUserInputId").value
    firestore.collection("UsersData").where("keywords","array-contains",tobeSearch.toLowerCase()).get()
    .then((querySnapshot) => {
  
      if( querySnapshot.docs.length == 0 ){
       
        swal("User not Found");

    }else{
        while(document.getElementById("UserTboday").childElementCount!==0){
  
            document.getElementById("UserTboday").firstChild.remove();
          }
      
          querySnapshot.forEach((doc)=>{
      
            $("#UserTboday").append(`<tr id="${doc.id}-postcol">
            <td>${doc.data().userName} </td>
            <td>${doc.data().lastName} </td>
            <td>${doc.data().email} </td>
            <td>${doc.data().mobile} </td>
            <td > <center     style ="display: flex;
            align-items: center; justify-content: space-evenly;">

            <div class="form-check form-switch mb-2" >
            <input class="form-check-input" type="checkbox" id="${doc.id}" checked="" onchange="activeOrnot(this.id,this.checked)">
            </div>
            <div>
            <button type="button" class="btn btn-info"" id="${doc.id}" onclick="GetCourseList(this.id)" >
            Edit Course
            </button>
            <button type="button" class="btn btn-icon btn-primary" data-bs-toggle="modal" data-bs-target="#EditSliderModal"id="${doc.id}" onclick="GetUserDetials(this.id)" >
            <i class='bx bx-detail'></i>
             </button>
            <button type="button" class="btn btn-icon btn-danger" >
            <i class='bx bx-trash' ></i>
            </button>
            </div> 
        </center>  
        </td>
            </tr>`)
          })

    }
  
  
    })
}

function ResetSearch(params) {

    var tobeSearch = document.getElementById("SearchUserInputId").value
   
    if(tobeSearch == ""){
      while(document.getElementById("UserTboday").childElementCount!==0){
        document.getElementById("UserTboday").firstChild.remove();
      }
      getUserist();
    }
    
}

function activeOrnot(params,params2) {

    var washingtonRef = firestore.collection("UsersData").doc(params);

    // Set the "capital" field of the city 'DC'
    return washingtonRef.update({
      userActivationFlag : params2
    })
    .then(() => {
        alert("Document successfully updated!");
    })
    .catch((error) => {
        // The document probably doesn't exist.
        console.error("Error updating document: ", error);
    });
    
}

function deleteUser(id) {

    //   firestore.collection("Courses").doc(res)
    //     .collection("Modules")
    //     .doc(id)
    //     .collection("Lesson")
    //     .get()
    //     .then((querySnapshot) => {

    //         querySnapshot.forEach(element => {
    //         //    console.log(element.data())
    //             let text = `${element.data().media}`;
    //         let result = text.includes("firebasestorage");

    //         result == true ? storage.refFromURL(element.data().media).delete() : console.log("No a File or Image")
    //         });

    //     }).then(()=>{
    //         alert("Done")
    //     })
    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Post",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        
        n && firestore.collection("UsersData").doc(id).delete()    
                    .then(function () {
                        let subsWrapper = document.getElementById(`${id}-postcol`)
                        subsWrapper.remove();
                        swal("Successfull", "Module Deleted ", "success")
                    }).catch(function (e) {
                        console.error("Error removing document: ", e)
                    })
    
            })
   

}