var firestore = firebase.firestore();
const storage = firebase.storage();
var res;  
var moduleDoc;
var courseDoc;
var lessonDoc;
var MediaInput;
var MediaFlag;
var tags = [],sptags = [], tagsKey = [];
var LessonRenderCount = 0;
var BeforeLessonEdit;
var IndexTobeEdited;
var LessonList;
var docData;
const p1 = new Promise((resolve, reject) => {
    res = localStorage.getItem("CourseDocId");
    resolve("Success!");
    // or
    // reject(new Error("Error!"));
  });
  
  p1.then(
    (value) => {
        var docRef = firestore.collection("Courses").doc(res);

        docRef.get().then((doc) => {
            if (doc.exists) {
                document.getElementById("courseTitle").innerText = doc.data().courseTitle
                document.getElementById("courseDiscription").innerText = doc.data().courseDiscription
                document.getElementById("courseImage").src = doc.data().courseImage
            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
            }
        }).catch((error) => {
            console.log("Error getting document:", error);
        });

      console.log(value); // Success!
    },
    (reason) => {
      console.error(reason); // Error!
    },
  );


  function CourseImageEdit(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#PreviewforEditedImage')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}
function OpenEditCourseDetials(params) {
    tags = [],sptags = [], tagsKey = [];
    var docRef = firestore.collection("Courses").doc(res);

    docRef.get().then((doc) => {
        if (doc.exists) {
            document.getElementById("CourseTitleEdit").value = doc.data().courseTitle
            document.getElementById("CourseDeatilsEdit").value = doc.data().courseDiscription
            document.getElementById("PreviewforEditedImage").src = doc.data().courseImage
            
            while(document.getElementById("tagContainer_EDIT").childElementCount!==0){
                document.getElementById("tagContainer_EDIT").firstChild.remove();
            }
            if(doc.data().keysToShow!==undefined){
                doc.data().keysToShow.forEach((e)=>{
                    $('#tagContainer_EDIT').append(`<span id="${e}" class="badge bg-dark">${e}<span class="closetag" onclick="removeTags_Edited(this)">×</span></span>`)
                })
            }

            if(doc.data().keysToShow!==undefined){
                doc.data().keysToShow.forEach((e)=>{
                tags.push(e);
                createKeywords_Edited(e);
                })
            }
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

function SaveEditedCourseDeatails(params) {

    var CourseTitleEdited = document.getElementById("CourseTitleEdit").value;
    var CourseDeatilsEdited = document.getElementById("CourseDeatilsEdit").value
    var CourseImageEdited = document.getElementById("EditeImage").value
    var Price = document.getElementById("priceid").value;
    var Dprice =  document.getElementById("dpriceid").value;
    var DpriceInPer = document.getElementById("perId").value;

    console.log("Price",Price,"Dprice",Dprice,"DpriceInPer",DpriceInPer)
// alert("Stop")
    if(CourseTitleEdited !== "" && CourseDeatilsEdited!=="" && CourseImageEdited!== "" ){
        document.getElementById("EditPostUploading").style.display = "flex"
        document.getElementById("PreviewforEditedImage").style.display = "none"

        const ref = firebase.storage().ref();
        const file = document.querySelector('#EditeImage').files[0]
        const name =  file.name;
        const metadata = {
            contentType: file.type
        };
        const task = ref.child('MRCOG_Goal_Images/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => { 
        
        var docRef = firestore.collection("Courses").doc(res);
    
        return docRef.update({
            courseTitle: CourseTitleEdited,
            courseDiscription:CourseDeatilsEdited,
            courseImage : url,
            keywords : tagsKey,
            keysToShow : tags,
            price : Number(Price),
            dPrice : Number(Dprice),
            dPriceInPer : Number(DpriceInPer)
        })
        .then(() => {
                tags = [],sptags = [], tagsKey = [];
                document.getElementById("EditPostUploading").style.display = "none"
                document.getElementById("PreviewforEditedImage").style.display = ""

                swal("Course Details Edited Sucessfully");
                $('#EditCourseDetails').modal('hide');
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });
    
        })
    }else if(CourseTitleEdited !== "" && CourseDeatilsEdited!=="" && CourseImageEdited== "" ){

        var docRef = firestore.collection("Courses").doc(res);
    
        return docRef.update({
            courseTitle: CourseTitleEdited,
            courseDiscription:CourseDeatilsEdited,
            keywords : tagsKey,
            keysToShow : tags,
            price : Number(Price),
            dPrice : Number(Dprice),
            dPriceInPer : Number(DpriceInPer)
  
        })
        .then(() => {
            swal("Course Details Edited Sucessfully");
            $('#EditCourseDetails').modal('hide');
            //
            location.reload();
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });
    
        
    }else{
        if(CourseTitleEdited == ""){
            document.getElementById("CourseTitleEdit_Span").style.display = "";
        }else{
            document.getElementById("CourseTitleEdit_Span").style.display = "none";

        }
        if(CourseDeatilsEdited == ""){
            document.getElementById("CourseDeatilsEdit_Span").style.display = "";

        }else{
            document.getElementById("CourseDeatilsEdit_Span").style.display = "none";
 
        }
        if(CourseImageEdited == ""){
            document.getElementById("CourseImageEdit_Span").style.display = "";

        }else{
            document.getElementById("CourseImageEdit_Span").style.display = "none";
  
        }
    }
}

var keyword2 = document.getElementById("keyword_Edited")
keyword2.addEventListener("keyup",function(event){
    //console.log(event);
    if(event.keyCode === 13)
    {
        if(keyword2.value == "" || keyword2.value == " ")
        {
            swal("Keyword Not be Blank");
            keyword2.value = "";
        }
        else
        {
            //let str = (keyword.value).replaceAll(" ","");
            addTags_Edited((keyword2.value).toLowerCase());
            keyword2.value = "";
        }
    }
})

function addTags_Edited(val)
{
    var par = document.getElementById('tagContainer_EDIT');
    var tag = document.createElement('span');
    tag.setAttribute('id',val);
    tag.classList.add('badge','bg-dark');
    tag.innerHTML = val+' <span class="closetag" onclick="removeTags_Edited(this)">&times;</span>';
    par.appendChild(tag);
    tags.push(val);
    createKeywords_Edited(val);
    //console.log(tags,tagsKey);
}
//<span id="vivek" class="badge badge-pill badge-primary">vivek <span class="closetag" onclick="removeTags(this)">×</span></span>
function createKeywords_Edited(name) 
{   
    const arrName = [];
    let curName = '';
    name.split('').forEach(letter => {
    curName += letter;
    arrName.push(curName.trim());
    });
    tagsKey = tagsKey.concat(arrName);
    console.log("tagsKey",tags)

}

function removeTags_Edited(ele)
{
    tagsKey = [];
    let tname = ele.parentElement.id;
    let i = tags.indexOf(tname);
    tags.splice(i,1);
    
    for(var k = 0;k<tags.length;k++)
    {
        createKeywords_Edited(tags[k]);
    }
    
    ele.parentElement.remove();
    //console.log(tags,tagsKey);
}

function getModuleList(params) {

    var docRef = firestore.collection("Courses").doc(res).collection("Modules").orderBy("sno","asc");

    docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
        //     $("#Module_table").append(`    <tr>
        //     <td id="${doc.id}">
        //           <span>${doc.data().moduleName}</span>
        //     </td>
        
        //     <td>
        //       <div style="    display: flex;
        //       justify-content: space-evenly;">
        //         <button type="button" class="btn btn-icon btn-outline-primary" id="${doc.id}">
        //         <i class='bx bx-detail'> </i>
        //         </button>
        
        //         <button type="button" class="btn btn-icon btn-outline-primary" id="${doc.id}"  data-bs-toggle="modal" data-bs-target="#EditModuleeDetails" onclick="OpenEditModuleDetials(this.id)">
        //        <i class='bx bxs-edit' > </i>   
        //         </button>
        //       </div>
         
        //     </td>
        //   </tr>`)

        // $("#ModuleList").append(`<div style="display:flex"><li class="list-group-item" id="${doc.id}" onclick="getContentList(this.id)" style="width: 100%;" >${doc.data().moduleName}</li> <button type="button" class="btn btn-icon btn-primary" id="${doc.id}"  data-bs-toggle="modal" data-bs-target="#EditModuleeDetails" onclick="OpenEditModuleDetials(this.id)">
        //        <i class='bx bxs-edit' > </i>   
        //        </button> </div> `)
        // });
  
        $("#ModuleList").append(`<tr id="${doc.id}-postcol">
        <td id="${doc.id}" onclick="getContentList(this.id)" style="cursor:pointer">${doc.data().moduleName}</td>
        <td><button type="button" class="btn btn-icon btn-primary" id="${doc.id}"  data-bs-toggle="modal" data-bs-target="#EditModuleeDetails" onclick="OpenEditModuleDetials(this.id)">
        <i class='bx bxs-edit' > </i>   
        </button>
        <button type="button" class="btn btn-icon btn-danger" id="${doc.id}" onclick="deleteModule(this.id)">
        <i class='bx bx-trash' ></i>
                            </button>
        </td>
        </tr> `)
        });

        
    });
}
getModuleList();

function OpenEditModuleDetials(params) {
    // tags = [],sptags = [], tagsKey = [];
    document.getElementById("ModuleNoEdit").disabled = true
    document.getElementById("ModuleTitleEdit").disabled = true
    document.getElementById("ModuleDeatilsEdit").disabled = true
    var docRef = firestore.collection("Courses").doc(res).collection("Modules").doc(params);
    moduleDoc = params
    docRef.get().then((doc) => {
        if (doc.exists) {
            document.getElementById("ModuleNoEdit").value = doc.data().sno
            document.getElementById("ModuleTitleEdit").value = doc.data().moduleName
            document.getElementById("ModuleDeatilsEdit").value = doc.data().moduleDiscription
            document.getElementById("PreviewforEditedModuleImage").src = doc.data().moduleThumbnail

        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

function ActiveEditFiled(params) {
    document.getElementById("ModuleNoEdit").disabled = false
    document.getElementById("ModuleTitleEdit").disabled = false
    document.getElementById("ModuleDeatilsEdit").disabled = false
}

function SaveEditedModuleDeatails(params) {
    var ModuleNoEdited = document.getElementById("ModuleNoEdit").value;
    var ModuleTitleEdited = document.getElementById("ModuleTitleEdit").value;
    var ModuleDeatilsEdited = document.getElementById("ModuleDeatilsEdit").value
    var ModuleImageEdited = document.getElementById("ModuleEditeImage").value

    if(ModuleNoEdited!=="" && ModuleTitleEdited !== "" && ModuleDeatilsEdited!=="" && ModuleImageEdited!== "" ){
        document.getElementById("EditModuleUploading").style.display = "flex"
        document.getElementById("PreviewforEditedModuleImage").style.display = "none"

        const ref = firebase.storage().ref();
        const file = document.querySelector('#ModuleEditeImage').files[0]
        const name =  file.name;
        const metadata = {
            contentType: file.type
        };
        const task = ref.child('MRCOG_Goal_Images/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => { 
        
        var docRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);
    
        return docRef.update({
            sno:ModuleNoEdited,
            moduleName: ModuleTitleEdited,
            moduleDiscription:ModuleDeatilsEdited,
            moduleThumbnail : url

        })
        .then(() => {
          
                document.getElementById("EditModuleUploading").style.display = "none"
                document.getElementById("PreviewforEditedModuleImage").style.display = ""
                document.getElementById("ModuleNoEdit").disabled = true
                document.getElementById("ModuleTitleEdit").disabled = true
                document.getElementById("ModuleDeatilsEdit").disabled = true
                swal("Course Details Edited Sucessfully");
                $('#EditModuleeDetails').modal('hide');
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });
    
        })
    }else if(ModuleNoEdited!=="" && ModuleTitleEdited !== "" && ModuleDeatilsEdited!=="" && ModuleImageEdited == "" ){
        document.getElementById("EditModuleUploading").style.display = "flex"
        document.getElementById("PreviewforEditedModuleImage").style.display = "none"
        var docRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);
    
        return docRef.update({
            sno:ModuleNoEdited,
            moduleName: ModuleTitleEdited,
            moduleDiscription:ModuleDeatilsEdited,
  
        })
        .then(() => {
            document.getElementById("EditModuleUploading").style.display = "flex"
            document.getElementById("PreviewforEditedModuleImage").style.display = "none"
            document.getElementById("ModuleNoEdit").disabled = true
            document.getElementById("ModuleTitleEdit").disabled = true
            document.getElementById("ModuleDeatilsEdit").disabled = true
            swal("Course Details Edited Sucessfully");
            $('#EditModuleeDetails').modal('hide');
            //
            location.reload();
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });
    
        
    }else{

        if(ModuleNoEdited == ""){
            document.getElementById("Module_No_Span").style.display = "";
        }else{
            document.getElementById("Module_No_Span").style.display = "none";

        }
        if(ModuleTitleEdited == ""){
            document.getElementById("ModuleTitleEdit_Span").style.display = "";
        }else{
            document.getElementById("ModuleTitleEdit_Span").style.display = "none";

        }
        if(ModuleDeatilsEdited == ""){
            document.getElementById("ModuleDeatilsEdit_Span").style.display = "";

        }else{
            document.getElementById("ModuleDeatilsEdit_Span").style.display = "none";
 
        }
        if(ModuleImageEdited == ""){
            document.getElementById("ModuleDeatilsEdit_Span").style.display = "";

        }else{
            document.getElementById("ModuleDeatilsEdit_Span").style.display = "none";
  
        }
    }
}

function deleteModule(id) {

    //   firestore.collection("Courses").doc(res)
    //     .collection("Modules")
    //     .doc(id)
    //     .collection("Lesson")
    //     .get()
    //     .then((querySnapshot) => {

    //         querySnapshot.forEach(element => {
    //         //    console.log(element.data())
    //             let text = `${element.data().media}`;
    //         let result = text.includes("firebasestorage");

    //         result == true ? storage.refFromURL(element.data().media).delete() : console.log("No a File or Image")
    //         });

    //     }).then(()=>{
    //         alert("Done")
    //     })
    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Post",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        
        n && 
        firestore.collection("Courses").doc(res)
        .collection("Modules")
        .doc(id)
        .collection("Lesson")
        .get()
        .then((querySnapshot) => {

            querySnapshot.forEach(element => {
            //    console.log(element.data())
                let text = `${element.data().media}`;
            let result = text.includes("firebasestorage");

            result == true ? storage.refFromURL(element.data().media).delete() : console.log("No a File or Image")
            });

        }).then(()=>{

            firestore.collection("Courses").doc(res)
        .collection("Modules")
        .doc(id)
        .collection("Lesson")
        .get()
        .then((querySnapshot) => {

            querySnapshot.forEach(element => {
                firestore.collection("Courses").doc(res)
                .collection("Modules")
                .doc(id)
                .collection("Lesson").doc(element.id).delete();
              
            });
        }).then(()=>{
         
            firestore.collection("Courses").doc(res)
            .collection("Modules")
            .doc(id)
            .get()
            .then((snapshot) => {
    
                console.log("snapshot",snapshot.data())
              storage.refFromURL(snapshot.data().moduleThumbnail).delete()
         
            }).then(()=>{
                firestore.collection("Courses").doc(res).collection("Modules").doc(id).delete()
    
    
                    .then(function () {
                        let subsWrapper = document.getElementById(`${id}-postcol`)
                        subsWrapper.remove();
                        swal("Successfull", "Module Deleted ", "success")
                    }).catch(function (e) {
                        console.error("Error removing document: ", e)
                    })
    
            })
        })
        
        })
        
        
        
        
   
    //     // n && firestore.collection("Post").doc(id).delete()


    //     //     .then(function () {
    //     //         let subsWrapper = document.getElementById(`${id}-postcol`)
    //     //         subsWrapper.remove();
    //     //         swal("Successfull", "Product Deleted ", "success")
    //     //     }).catch(function (e) {
    //     //         console.error("Error removing document: ", e)
    //     //     })

    //         // firestore()
    //         // .collection('Post')
    //         // .doc(id)
    //         // .get()
    //         // .then((snapshot) => {
    //         //   storage()
    //         //     .refFromURL(snapshot.data().image.url)
    //         //     .delete()
    //         // })
    })
}

function getContentList(params) {

    var moduleREF = firestore.collection("Courses").doc(res).collection("Modules").doc(params);

    moduleREF.get().then((doc) => {
        if (doc.exists) {

            
            LessonList = doc.data().lessonList
            console.log(LessonList)
     

          
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    })
        
    var docRef = firestore.collection("Courses").doc(res).collection("Modules").doc(params).collection("Lesson").orderBy("date","asc")

    moduleDoc = params;
    docRef.get().then((querySnapshot) => {

        while(document.getElementById("LessonList").childElementCount!==0){
            document.getElementById("LessonList").firstChild.remove();
        }
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
        //     $("#Module_table").append(`    <tr>
        //     <td id="${doc.id}">
        //           <span>${doc.data().moduleName}</span>
        //     </td>
        
        //     <td>
        //       <div style="    display: flex;
        //       justify-content: space-evenly;">
        //         <button type="button" class="btn btn-icon btn-outline-primary" id="${doc.id}">
        //         <i class='bx bx-detail'> </i>
        //         </button>
        
        //         <button type="button" class="btn btn-icon btn-outline-primary" id="${doc.id}"  data-bs-toggle="modal" data-bs-target="#EditModuleeDetails" onclick="OpenEditModuleDetials(this.id)">
        //        <i class='bx bxs-edit' > </i>   
        //         </button>
        //       </div>
         
        //     </td>
        //   </tr>`)

        // $("#LessonList").append(`<div style="display:flex" ><li class="list-group-item" id="${doc.id}" onclick="OpenLessonModel(this.id)" style="width: 100%;" >${doc.data().lessonTitle}</li><button type="button" class="btn btn-icon btn-primary" id="${doc.id}-${LessonRenderCount++}" onclick="OpenLessonModel(this.id)">
        // <i class="bx bxs-edit"> </i>   
        // </button> </div>`)

        $("#LessonList").append(`<tr id="${doc.id}-l">
        <td id="${doc.id}" style="cursor:pointer">${doc.data().lessonTitle}</td>
        <td style="display: flex;
        justify-content: center;"><button type="button" class="btn btn-icon btn-primary"  id="${doc.id}-${LessonRenderCount++}" onclick="OpenLessonModel(this.id)">
        <i class='bx bxs-edit' > </i>   
        </button>
        <button type="button" class="btn btn-icon btn-danger" id="${doc.id}" onclick="deleteLession(this.id)">
        <i class='bx bx-trash' ></i>
                            </button>
        </td>
        </tr> `)
        });
        });
  
  

}

function OpenLessonModel(params) {

    var myModal = new bootstrap.Modal(document.getElementById('EditLessonDetails'))
    myModal.show()
    lessonDoc = params.substring(0, params.indexOf("-"))
    IndexTobeEdited = params.substring(params.indexOf("-")+1,params.length);

 

    var docRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc);
   

    docRef.get().then((doc) => {
        if (doc.exists) {
            BeforeLessonEdit = doc.data().lessonTitle
            document.getElementById("LeasonName").value = doc.data().lessonTitle
            document.getElementById("LessonDescription").value = doc.data().lessonDescription
            document.getElementById("ModuleDeatilsEdit").value = doc.data().moduleDiscription
            document.getElementById("PreviewforEditedModuleImage").src = doc.data().moduleThumbnail

            if(doc.data().mediatype == "File"){

                document.getElementById("FileRadiio").checked = true;
                document.getElementById("Link_File").style.display = "";
              
                if (doc.data().media.indexOf(".pdf") > -1) {
                    document.getElementById("FileUrl").href = doc.data().media 
                    document.getElementById("FileInput").checked = true 
                    document.getElementById("TypePDF").style.display = ""
                    document.getElementById("TypeLink").style.display = "none"
                    document.getElementById("FileUrl").style.display = ""
                    document.getElementById("WebUrl").style.display = "none"
                }else{
                    document.getElementById("WebUrl").href = doc.data().media
                    document.getElementById("LinkInput").checked = true
                    document.getElementById("TypePDF").style.display = "none"
                    document.getElementById("TypeLink").style.display = ""
                    document.getElementById("FileUrl").style.display = "none"
                    document.getElementById("WebUrl").style.display = ""
                }


            }else if(doc.data().mediatype == "Video"){
                document.getElementById("WebUrl").href = doc.data().media
                document.getElementById("VideoRadio").checked = true;
            }
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

    var MyRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);

    MyRef.get().then((doc) => {
        if (doc.exists) {

            
            LessonList = doc.data().lessonList
            console.log(LessonList)
 
            console.log("docData",docData)
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).then(()=>{
        var MyLessionReff = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc);

        MyLessionReff.get().then((doc) => {
            if (doc.exists) {
    
                docData = {
                    date : doc.data().date,
                    lessonTitle:doc.data().lessonTitle,
                    lessonDescription: doc.data().lessonDescription,
                    media : doc.data().media,
                    mediatype : doc.data().mediatype
                };
    
                console.log("docData",docData)
            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
            }
        })
    }).catch((error) => {
        console.log("Error getting document:", error);
    });


}

function deleteLession(id) {

    // let obj = arr.find(o => o.name === 'string 1');

    // console.log(obj);


    
 
        // firestore.collection("Courses").doc(res)
        // .collection("Modules")
        // .doc(moduleDoc)
        // .collection("Lesson").doc(id)
        // .get()
        // .then((snapshot) => {


        // var  index = LessonList.findIndex(x => x.title === snapshot.data().lessonTitle);

        // console.log(index); 
      
        // if (index > -1) { // only splice array when item is found
        //          LessonList.splice(index, 1); // 2nd parameter means remove one item only
        // }
        // console.log(LessonList)
    
        // }).then(()=>{
        //     var washingtonRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);
        //     console.log("lessonList",LessonList)
        //     // Set the "capital" field of the city 'DC'
        //             return washingtonRef.update({
        //                 lessonList : LessonList
        //             })
        //             .then(() => {
        //                alert("Document successfully updated!");
                       
        //                 location.reload();
        //             })
        //             .catch((error) => {
        //                 // The document probably doesn't exist.
        //                 console.error("Error updating document: ", error);
        //             });
        // })

    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Post",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n=>{

        console.log("n",n)
        
       n && firestore.collection("Courses").doc(res)
        .collection("Modules")
        .doc(moduleDoc)
        .collection("Lesson").doc(id)
        .get()
        .then((snapshot) => {


        var  index = LessonList.findIndex(x => x.title === snapshot.data().lessonTitle);

        console.log(index); 
      
        if (index > -1) { // only splice array when item is found
                 LessonList.splice(index, 1); // 2nd parameter means remove one item only
        }
        console.log(LessonList)
    
        }).then(()=>{
            var washingtonRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);
            console.log("lessonList",LessonList)
            // Set the "capital" field of the city 'DC'
                    return washingtonRef.update({
                        lessonList : LessonList
                    })
                    .then(() => {
                       console.log("Document successfully updated!");
                       
                        
                    })
                    .catch((error) => {
                        // The document probably doesn't exist.
                        console.error("Error updating document: ", error);
                    });
        }).then(()=>{
        

            firestore.collection("Courses").doc(res)
            .collection("Modules")
            .doc(moduleDoc)
            .collection("Lesson").doc(id)
            .get()
            .then((snapshot) => {
    
                let text = `${snapshot.data().media}`;
                let result = text.includes("firebasestorage");
    
                result == true ? storage.refFromURL(snapshot.data().media).delete() : console.log("No a File or Image")
         
              
         
            }).then(()=>{
                firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(id).delete()
    
    
                    .then(function () {
                        let subsWrapper = document.getElementById(`${id}-l`)
                        subsWrapper.remove();
                        swal("Successfull", "Lesson Deleted ", "success")
                    }).catch(function (e) {
                        console.error("Error removing document: ", e)
                    })
    
            })
    
        })

    })
 
    
}

function SetInputForFile(params) {

    console.log("params",params);
    // document.getElementById("TypePDF").style.display = "flex"
    // document.getElementById("TypePDF").style.display = "none"
   
    if(params == "File"){
    MediaInput = params;
    document.getElementById("TypePDF").style.display = ""
    document.getElementById("TypeLink").style.display = "none"

    }else if(params == "Link"){
        MediaInput = params;
    document.getElementById("TypePDF").style.display = "none"
    document.getElementById("TypeLink").style.display = ""


    }
}
function GetMediaFlag(params) {

    console.log("params",params);
 
  

    // document.getElementById("TypePDF").style.display = "none"

    if(params == "File"){
        MediaFlag = params;
    document.getElementById("Link_File").style.display = ""
    // document.getElementById("WebUrl").style.display = "none"
    }else if(params == "Video"){
        MediaFlag = params;
    document.getElementById("FileInput").checked = false
    document.getElementById("LinkInput").checked = false

    document.getElementById("TypeLink").style.display = "" 
    document.getElementById("TypePDF").style.display = "none"
    document.getElementById("Link_File").style.display = "none"
    
    
    }
}


function saveLesson(params) {
var counter = 0;
    var lessonTitle = document.getElementById("LeasonName").value
    var lessonDescription = document.getElementById("LessonDescription").value
    var lessonLink = document.getElementById("LeasonLink").value;
    var lessonFile = document.getElementById("lessonFile").value;
    var FileRadioCheck = document.getElementById("FileRadiio").checked;
    var VideoRadioCheck = document.getElementById("VideoRadio").checked;
    var fileRadioCheck = document.getElementById("FileInput").checked;
    var linkRadioCheck = document.getElementById("LinkInput").checked;

    if(lessonTitle !== BeforeLessonEdit){

        console.log("LessonList",LessonList[LessonList.indexOf(BeforeLessonEdit)] );
        // LessonList[LessonList.indexOf(BeforeLessonEdit)] = lessonTitle;

        LessonList.forEach(element => {


            console.log(element.title == BeforeLessonEdit)

            if(element.title == BeforeLessonEdit){
                
                LessonList[counter].title = lessonTitle
            }
            if(FileRadioCheck == true){
                LessonList[counter].mediaType = "File"
            }else if(VideoRadioCheck == true){
                LessonList[counter].mediaType = "Videow"
            }
            counter++;
        });

        saveLesson_Updated();
        
    }else{
        

        if( lessonTitle !=="" && lessonDescription !== "" && FileRadioCheck == true ){

            document.getElementById("LeasonName_Span").style.display = "none"
            document.getElementById("Module_Discription_Span").style.display = "none"
            document.getElementById("lessonlink_Span").style.display = "none"
            document.getElementById("lessonfile_Span").style.display = "none"
          
          
            if(lessonLink!=="" && linkRadioCheck == true ){
                // alert("link")
                document.getElementById("Upaloadimg").style.display = "flex"
                firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc).update({
            
                    lessonTitle : lessonTitle,
                    lessonDescription : lessonDescription,
                    mediatype : "File",
                    media : lessonLink
                }).then(()=>{
    
                    document.getElementById("Upaloadimg").style.display = "none"
                    console.log("LessonList",LessonList)
                    swal("Video Data Added successfully!")
                })
                if(MediaFlag =="Video"){
    
                    firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").add({
            
                        lessonTitle : lessonTitle,
                        lessonDescription : lessonDescription,
                        mediatype : MediaFlag,
                        media : lessonLink
                    })
                    .then(()=>{
                    
        
                        document.getElementById("LeasonName").value ="" 
                        document.getElementById("LessonDescription").value =""  
                        document.getElementById("FileRadiio").checked = false
                        document.getElementById("VideoRadio").checked = false
                        document.getElementById("LinkInput").checked = false
                        document.getElementById("FileInput").checked = false 
                        document.getElementById("LeasonLink").value =""  
                        document.getElementById("lessonFile").value ="" 
                    
                        document.getElementById("Upaloadimg").style.display = "none"
                        console.log("LessonList",LessonList)
                        swal("Video Data Added successfully!")
                    
                        
                            // console.log("Document successfully updated!");
                    })
        
                }else if(MediaFlag =="File"){
                    if(MediaInput == "File"){
        
                        const ref = firebase.storage().ref();
                        const file = document.getElementById("lessonFile").files[0]
            
                        const name =  file.name;
            
                        const metadata = {
                        contentType: file.type
                        };
                        const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);
            
            
                            task .then(snapshot => snapshot.ref.getDownloadURL())
                            .then((url) => {
                    
                                firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").add({
            
                                    lessonTitle : lessonTitle,
                                    lessonDescription : lessonDescription,
                                    mediatype : MediaFlag,
                                    media : url
                                })
                        
                        }).then(()=>{
                        
            
                            document.getElementById("LeasonName").value ="" 
                            document.getElementById("LessonDescription").value =""  
                            document.getElementById("FileRadiio").checked = false
                            document.getElementById("VideoRadio").checked = false
                            document.getElementById("LinkInput").checked = false
                            document.getElementById("FileInput").checked = false 
                            document.getElementById("LeasonLink").value =""  
                            document.getElementById("lessonFile").value ="" 
                        
                            document.getElementById("Upaloadimg").style.display = "none"
                            console.log("LessonList",LessonList)
                            swal("Video Data Added successfully!")
                        
                            
                                // console.log("Document successfully updated!");
                        })
                        .catch((error) => {
                            // The document probably doesn't exist.
                            console.error("Error updating document: ", error);
                        });
            
                    }
                }
    
            }else if(lessonLink =="" && linkRadioCheck == true ){
                // alert("link")
                document.getElementById("Upaloadimg").style.display = "flex"
                firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc).update({
            
                    lessonTitle : lessonTitle,
                    lessonDescription : lessonDescription,
                    mediatype : "File",
                    media : lessonLink
                }).then(()=>{
    
                    document.getElementById("Upaloadimg").style.display = "none"
                    console.log("LessonList",LessonList)
                    swal("Video Data Added successfully!")
                })
                if(MediaFlag =="Video"){
    
                    firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").add({
            
                        lessonTitle : lessonTitle,
                        lessonDescription : lessonDescription,
                        mediatype : MediaFlag,
                        media : lessonLink
                    })
                    .then(()=>{
                    
        
                        document.getElementById("LeasonName").value ="" 
                        document.getElementById("LessonDescription").value =""  
                        document.getElementById("FileRadiio").checked = false
                        document.getElementById("VideoRadio").checked = false
                        document.getElementById("LinkInput").checked = false
                        document.getElementById("FileInput").checked = false 
                        document.getElementById("LeasonLink").value =""  
                        document.getElementById("lessonFile").value ="" 
                    
                        document.getElementById("Upaloadimg").style.display = "none"
                        console.log("LessonList",LessonList)
                        swal("Video Data Added successfully!")
                    
                        
                            // console.log("Document successfully updated!");
                    })
        
                }else if(MediaFlag =="File"){
                    if(MediaInput == "File"){
        
                        const ref = firebase.storage().ref();
                        const file = document.getElementById("lessonFile").files[0]
            
                        const name =  file.name;
            
                        const metadata = {
                        contentType: file.type
                        };
                        const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);
            
            
                            task .then(snapshot => snapshot.ref.getDownloadURL())
                            .then((url) => {
                    
                                firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").add({
            
                                    lessonTitle : lessonTitle,
                                    lessonDescription : lessonDescription,
                                    mediatype : MediaFlag,
                                    media : url
                                })
                        
                        }).then(()=>{
                        
            
                            document.getElementById("LeasonName").value ="" 
                            document.getElementById("LessonDescription").value =""  
                            document.getElementById("FileRadiio").checked = false
                            document.getElementById("VideoRadio").checked = false
                            document.getElementById("LinkInput").checked = false
                            document.getElementById("FileInput").checked = false 
                            document.getElementById("LeasonLink").value =""  
                            document.getElementById("lessonFile").value ="" 
                        
                            document.getElementById("Upaloadimg").style.display = "none"
                            console.log("LessonList",LessonList)
                            swal("Video Data Added successfully!")
                        
                            
                                // console.log("Document successfully updated!");
                        })
                        .catch((error) => {
                            // The document probably doesn't exist.
                            console.error("Error updating document: ", error);
                        });
            
                        }
                }
    
            }else if(lessonFile !=="" && fileRadioCheck ==true){
    
                // alert("File")
                const ref = firebase.storage().ref();
                const file = document.getElementById("lessonFile").files[0]
    
                const name =  file.name;
    
                const metadata = {
                contentType: file.type
                };
                const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);
    
    
                    task .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
            
                        firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc).update({
    
                            lessonTitle : lessonTitle,
                            lessonDescription : lessonDescription,
                            mediatype : "File",
                            media : url
                        })
                
                }).then(()=>{
                
    
                    document.getElementById("LeasonName").value ="" 
                    document.getElementById("LessonDescription").value =""  
                    document.getElementById("FileRadiio").checked = false
                    document.getElementById("VideoRadio").checked = false
                    document.getElementById("LinkInput").checked = false
                    document.getElementById("FileInput").checked = false 
                    document.getElementById("LeasonLink").value =""  
                    document.getElementById("lessonFile").value ="" 
                
                    document.getElementById("Upaloadimg").style.display = "none"
                    swal("Video Data Added successfully!")
                    console.log("LessonList",LessonList)
                    
                        // console.log("Document successfully updated!");
                })
                .catch((error) => {
                    // The document probably doesn't exist.
                    console.error("Error updating document: ", error);
                });
            }else if(lessonFile =="" && fileRadioCheck ==true){
    
                // alert("File")
       
                
                firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc).update({
    
                    lessonTitle : lessonTitle,
                    lessonDescription : lessonDescription,
                    // mediatype : "File",
                    // media : url
                }).then(()=>{
                
    
                    document.getElementById("LeasonName").value ="" 
                    document.getElementById("LessonDescription").value =""  
                    document.getElementById("FileRadiio").checked = false
                    document.getElementById("VideoRadio").checked = false
                    document.getElementById("LinkInput").checked = false
                    document.getElementById("FileInput").checked = false 
                    document.getElementById("LeasonLink").value =""  
                    document.getElementById("lessonFile").value ="" 
                
                    document.getElementById("Upaloadimg").style.display = "none"
                    swal("Video Data Added successfully!")
                    console.log("LessonList",LessonList)
                    
                        // console.log("Document successfully updated!");
                })
                .catch((error) => {
                    // The document probably doesn't exist.
                    console.error("Error updating document: ", error);
                });
            }
    
    var washingtonRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);
    console.log("lessonList",LessonList)
    // Set the "capital" field of the city 'DC'
            return washingtonRef.update({
                lessonList : LessonList
            })
            .then(() => {
                // alert("Document successfully updated!");
                //
                location.reload();
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
            
        }else if(lessonTitle !=="" && lessonDescription !== "" && VideoRadioCheck == true && lessonLink !==""){
            document.getElementById("LeasonName_Span").style.display = "none"
            document.getElementById("Module_Discription_Span").style.display = "none"
            document.getElementById("lessonlink_Span").style.display = "none"
            document.getElementById("lessonfile_Span").style.display = "none"
            document.getElementById("Upaloadimg").style.display = "flex"
            firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc).update({
            
                lessonTitle : lessonTitle,
                lessonDescription : lessonDescription,
                mediatype : "Video",
                media : lessonLink
            })
            .then(()=>{
            
    
            
                console.log("LessonList",LessonList)
                document.getElementById("Upaloadimg").style.display = "none"
                swal("Video Data Added successfully!")
            
                
                    // console.log("Document successfully updated!");
            })
    
          var washingtonRef =   firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);
    
    // Set the "capital" field of the city 'DC'
            return washingtonRef.update({
                lessonList : LessonList
            })
            .then(() => {
                LessonList = [];
                // alert("Document successfully updated!");
                //
                location.reload();
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
        }else if(lessonTitle !=="" && lessonDescription !== "" && VideoRadioCheck == true && lessonLink ==""){
            document.getElementById("LeasonName_Span").style.display = "none"
            document.getElementById("Module_Discription_Span").style.display = "none"
            document.getElementById("lessonlink_Span").style.display = "none"
            document.getElementById("lessonfile_Span").style.display = "none"
            document.getElementById("Upaloadimg").style.display = "flex"
            firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc).update({
            
                lessonTitle : lessonTitle,
                lessonDescription : lessonDescription,
                mediatype : "Video",
                // media : lessonLink
            })
            .then(()=>{
            
    
            
                console.log("LessonList",LessonList)
                document.getElementById("Upaloadimg").style.display = "none"
                swal("Video Data Added successfully!")
                //
                location.reload();
                
                    // console.log("Document successfully updated!");
            })
            
            var washingtonRef =  firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);
    
    // Set the "capital" field of the city 'DC'
            return washingtonRef.update({
                lessonList : LessonList
            })
            .then(() => {
                LessonList = [];
                // alert("Document successfully updated!");
                //
                location.reload();
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
        }
        else{
    
            if(lessonTitle == ""){
    
                document.getElementById("LeasonName_Span").style.display =""
    
            }else{
                document.getElementById("LeasonName_Span").style.display = "none"
            }
    
            if(lessonDescription == ""){
    
                document.getElementById("Module_Discription_Span").style.display = ""
    
            }else{
                document.getElementById("Module_Discription_Span").style.display = "none"
            }
    
            if(FileRadioCheck == true){
    
                if(fileRadioCheck == true){
    
                    if(lessonFile ==""){
                        document.getElementById("lessonfile_Span").style.display = ""
                    }else{
                 
                        document.getElementById("lessonfile_Span").style.display = "none"
                    }
    
                }else if(linkRadioCheck ==true){
                    if(lessonLink == ""){
                        document.getElementById("lessonlink_Span").style.display = ""
                    }else{
                        document.getElementById("lessonlink_Span").style.display = "none"
                    }
                }
    
            }else if(VideoRadioCheck == true){
    
                if(lessonLink == ""){
                    document.getElementById("lessonlink_Span").style.display = ""
                }else{
                    document.getElementById("lessonlink_Span").style.display = "none"
                }
            }
    
     
    
    
    
        }
    
    }
      
}

function saveLesson_Updated(params) {


    var lessonTitle = document.getElementById("LeasonName").value
    var lessonDescription = document.getElementById("LessonDescription").value
    var lessonLink = document.getElementById("LeasonLink").value;
    var lessonFile = document.getElementById("lessonFile").value;
    var FileRadioCheck = document.getElementById("FileRadiio").checked;
    var VideoRadioCheck = document.getElementById("VideoRadio").checked;
    var fileRadioCheck = document.getElementById("FileInput").checked;
    var linkRadioCheck = document.getElementById("LinkInput").checked;


    // alert("In Saved Edited")
    console.log("docData",LessonList)


    const p1 = new Promise((resolve, reject) => {
        
        if( lessonTitle!== docData.lessonTitle){

            docData = {...docData,lessonTitle:lessonTitle }
        }

        if(lessonDescription !== docData.lessonDescription ){
            docData = {...docData,lessonDescription:lessonDescription }
        }
 
        if(FileRadioCheck == true){
            if(lessonFile!==""){

                alert("In Update File")
                const ref = firebase.storage().ref();
                const file = document.getElementById("lessonFile").files[0]

                const name =  file.name;

                const metadata = {
                contentType: file.type
                };
                const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);


                    task .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
                        docData = {...docData,mediatype : "File",media : url}
    
                }).then(()=>{
                    console.log("docData",docData)
                })
            }
        }
        
        if(FileRadioCheck == true){
    
            if(linkRadioCheck == true){

                docData = {...docData,mediatype : "File",media : lessonLink }
            }
        }

        if(VideoRadioCheck == true){
    
            if(lessonLink !== ""){

                docData = {...docData,mediatype : "Video",media : lessonLink }
            }
        }



        resolve("Success!");
        // or
        // reject(new Error("Error!"));
      });
      
      p1.then(
        (value) => {
            firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set(docData)
            .then(()=>{
            
    
                firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc).delete();
                console.log("LessonList",LessonList)
                document.getElementById("Upaloadimg").style.display = "none"
                swal("Video Data Added successfully!")
                //
                location.reload();
                
                    // console.log("Document successfully updated!");
            })


            var moduleRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);

            // Set the "capital" field of the city 'DC'
            return moduleRef.update({
               lessonList : LessonList
            })
            .then(() => {
                // alert("Document successfully updated!");
                //
                location.reload();
            })
            .catch((error) => {
                // The document probably doesn't exist.
                console.error("Error updating document: ", error);
            });
            
        console.log(docData); // Success!

        console.log(value); // Success!
        },
        (reason) => {
          console.error(reason); // Error!
        },
      );
    //     if( lessonTitle !=="" && lessonDescription !== "" && FileRadioCheck == true ){

//         document.getElementById("LeasonName_Span").style.display = "none"
//         document.getElementById("Module_Discription_Span").style.display = "none"
//         document.getElementById("lessonlink_Span").style.display = "none"
//         document.getElementById("lessonfile_Span").style.display = "none"
      
      
//         if(lessonLink!=="" && linkRadioCheck == true ){
//             alert("link")
//             document.getElementById("Upaloadimg").style.display = "flex"
//             firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonDoc).set({
        
//                 lessonTitle : lessonTitle,
//                 lessonDescription : lessonDescription,
//                 mediatype : "File",
//                 media : lessonLink
//             }).then(()=>{

//                 document.getElementById("Upaloadimg").style.display = "none"
//                 console.log("LessonList",LessonList)
//                 swal("Video Data Added successfully!")
//             })
//             if(MediaFlag =="Video"){

//                 firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").add({
        
//                     lessonTitle : lessonTitle,
//                     lessonDescription : lessonDescription,
//                     mediatype : MediaFlag,
//                     media : lessonLink
//                 })
//                 .then(()=>{
                
    
//                     document.getElementById("LeasonName").value ="" 
//                     document.getElementById("LessonDescription").value =""  
//                     document.getElementById("FileRadiio").checked = false
//                     document.getElementById("VideoRadio").checked = false
//                     document.getElementById("LinkInput").checked = false
//                     document.getElementById("FileInput").checked = false 
//                     document.getElementById("LeasonLink").value =""  
//                     document.getElementById("lessonFile").value ="" 
                
//                     document.getElementById("Upaloadimg").style.display = "none"
//                     console.log("LessonList",LessonList)
//                     swal("Video Data Added successfully!")
                
                    
//                         // console.log("Document successfully updated!");
//                 })
    
//             }else if(MediaFlag =="File"){
//                 if(MediaInput == "File"){
    
//                     const ref = firebase.storage().ref();
//                     const file = document.getElementById("lessonFile").files[0]
        
//                     const name =  file.name;
        
//                     const metadata = {
//                     contentType: file.type
//                     };
//                     const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);
        
        
//                         task .then(snapshot => snapshot.ref.getDownloadURL())
//                         .then((url) => {
                
//                             firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").add({
        
//                                 lessonTitle : lessonTitle,
//                                 lessonDescription : lessonDescription,
//                                 mediatype : MediaFlag,
//                                 media : url
//                             })
                    
//                     }).then(()=>{
                    
        
//                         document.getElementById("LeasonName").value ="" 
//                         document.getElementById("LessonDescription").value =""  
//                         document.getElementById("FileRadiio").checked = false
//                         document.getElementById("VideoRadio").checked = false
//                         document.getElementById("LinkInput").checked = false
//                         document.getElementById("FileInput").checked = false 
//                         document.getElementById("LeasonLink").value =""  
//                         document.getElementById("lessonFile").value ="" 
                    
//                         document.getElementById("Upaloadimg").style.display = "none"
//                         console.log("LessonList",LessonList)
//                         swal("Video Data Added successfully!")
                    
                        
//                             // console.log("Document successfully updated!");
//                     })
//                     .catch((error) => {
//                         // The document probably doesn't exist.
//                         console.error("Error updating document: ", error);
//                     });
        
//                     }
//             }

//         }else if(lessonLink =="" && linkRadioCheck == true ){
//             alert("link")
//             document.getElementById("Upaloadimg").style.display = "flex"
//             firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({
        
//                 lessonTitle : lessonTitle,
//                 lessonDescription : lessonDescription,
//                 mediatype : "File",
//                 media : lessonLink
//             }).then(()=>{

//                 document.getElementById("Upaloadimg").style.display = "none"
//                 console.log("LessonList",LessonList)
//                 swal("Video Data Added successfully!")
//             })
//             if(MediaFlag =="Video"){

//                 firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").add({
        
//                     lessonTitle : lessonTitle,
//                     lessonDescription : lessonDescription,
//                     mediatype : MediaFlag,
//                     media : lessonLink
//                 })
//                 .then(()=>{
                
    
//                     document.getElementById("LeasonName").value ="" 
//                     document.getElementById("LessonDescription").value =""  
//                     document.getElementById("FileRadiio").checked = false
//                     document.getElementById("VideoRadio").checked = false
//                     document.getElementById("LinkInput").checked = false
//                     document.getElementById("FileInput").checked = false 
//                     document.getElementById("LeasonLink").value =""  
//                     document.getElementById("lessonFile").value ="" 
                
//                     document.getElementById("Upaloadimg").style.display = "none"
//                     console.log("LessonList",LessonList)
//                     swal("Video Data Added successfully!")
                
                    
//                         // console.log("Document successfully updated!");
//                 })
    
//             }else if(MediaFlag =="File"){
//                 if(MediaInput == "File"){
    
//                     const ref = firebase.storage().ref();
//                     const file = document.getElementById("lessonFile").files[0]
        
//                     const name =  file.name;
        
//                     const metadata = {
//                     contentType: file.type
//                     };
//                     const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);
        
        
//                         task .then(snapshot => snapshot.ref.getDownloadURL())
//                         .then((url) => {
                
//                             firestore.collection("Courses").doc(courseDoc).collection("Modules").doc(moduleDoc).collection("Lesson").add({
        
//                                 lessonTitle : lessonTitle,
//                                 lessonDescription : lessonDescription,
//                                 mediatype : MediaFlag,
//                                 media : url
//                             })
                    
//                     }).then(()=>{
                    
        
//                         document.getElementById("LeasonName").value ="" 
//                         document.getElementById("LessonDescription").value =""  
//                         document.getElementById("FileRadiio").checked = false
//                         document.getElementById("VideoRadio").checked = false
//                         document.getElementById("LinkInput").checked = false
//                         document.getElementById("FileInput").checked = false 
//                         document.getElementById("LeasonLink").value =""  
//                         document.getElementById("lessonFile").value ="" 
                    
//                         document.getElementById("Upaloadimg").style.display = "none"
//                         console.log("LessonList",LessonList)
//                         swal("Video Data Added successfully!")
                    
                        
//                             // console.log("Document successfully updated!");
//                     })
//                     .catch((error) => {
//                         // The document probably doesn't exist.
//                         console.error("Error updating document: ", error);
//                     });
        
//                     }
//             }

//         }else if(lessonFile !=="" && fileRadioCheck ==true){

//             alert("File")
//             const ref = firebase.storage().ref();
//             const file = document.getElementById("lessonFile").files[0]

//             const name =  file.name;

//             const metadata = {
//             contentType: file.type
//             };
//             const task = ref.child('MRCOG_Goal_Image' + name).put(file, metadata);


//                 task .then(snapshot => snapshot.ref.getDownloadURL())
//                 .then((url) => {
        
//                     firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({

//                         lessonTitle : lessonTitle,
//                         lessonDescription : lessonDescription,
//                         mediatype : "File",
//                         media : url
//                     })
            
//             }).then(()=>{
            

//                 document.getElementById("LeasonName").value ="" 
//                 document.getElementById("LessonDescription").value =""  
//                 document.getElementById("FileRadiio").checked = false
//                 document.getElementById("VideoRadio").checked = false
//                 document.getElementById("LinkInput").checked = false
//                 document.getElementById("FileInput").checked = false 
//                 document.getElementById("LeasonLink").value =""  
//                 document.getElementById("lessonFile").value ="" 
            
//                 document.getElementById("Upaloadimg").style.display = "none"
//                 swal("Video Data Added successfully!")
//                 console.log("LessonList",LessonList)
                
//                     // console.log("Document successfully updated!");
//             })
//             .catch((error) => {
//                 // The document probably doesn't exist.
//                 console.error("Error updating document: ", error);
//             });
//         }else if(lessonFile =="" && fileRadioCheck ==true){

//             alert("File")
   
            
//             firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc).collection("Lesson").doc(lessonTitle).set({

//                 lessonTitle : lessonTitle,
//                 lessonDescription : lessonDescription,
//                 // mediatype : "File",
//                 // media : url
//             }).then(()=>{
            

//                 document.getElementById("LeasonName").value ="" 
//                 document.getElementById("LessonDescription").value =""  
//                 document.getElementById("FileRadiio").checked = false
//                 document.getElementById("VideoRadio").checked = false
//                 document.getElementById("LinkInput").checked = false
//                 document.getElementById("FileInput").checked = false 
//                 document.getElementById("LeasonLink").value =""  
//                 document.getElementById("lessonFile").value ="" 
            
//                 document.getElementById("Upaloadimg").style.display = "none"
//                 swal("Video Data Added successfully!")
//                 console.log("LessonList",LessonList)
                
//                     // console.log("Document successfully updated!");
//             })
//             .catch((error) => {
//                 // The document probably doesn't exist.
//                 console.error("Error updating document: ", error);
//             });
//         }

//         var washingtonRef = firestore.collection("Courses").doc(res).collection("Modules").doc(moduleDoc);

// // Set the "capital" field of the city 'DC'
//         return washingtonRef.update({
//             lessonList : LessonList
//         })
//         .then(() => {
//             alert("Document successfully updated!");
//         })
//         .catch((error) => {
//             // The document probably doesn't exist.
//             console.error("Error updating document: ", error);
//         });
        
// }
    
}

function SetPrice(params) {
    var Price = Number(document.getElementById("priceid").value);
    var Dprice =  Number(document.getElementById("dpriceid").value);
    if(params=='price'){

        document.getElementById("dpriceid").value = "00";

    }else if(params=='dprice'){

      if(Dprice <= Price)  {
        document.getElementById("dpriceideSpan").style.display= "none";

      }else{
        document.getElementById("dpriceideSpan").style.display= "";
      }
      document.getElementById("perId").value = (((Price - Dprice) / Price) * 100)
    }

}

