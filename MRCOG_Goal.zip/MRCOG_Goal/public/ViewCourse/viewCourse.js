var firestore = firebase.firestore();
var lastCourseDoc;

function GetCourses(params) {

    firestore.collection("Courses").orderBy("date","desc").limit(6).get().then((querySnapshot) => {
        lastCourseDoc = querySnapshot.docs[querySnapshot.size-1]
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots

                $('#CouseParentDiv').append(`<div  class="col-md-6 col-lg-4 mb-3" id="${doc.id}-postcol"  >
                <div class="card" >
                  <img class="card-img-top" src="${doc.data().courseImage}" alt="Card image cap" style="width:350px;height:197px">

                  <div class="card-body">
                    <h5 class="card-title" style="width:302px;height:40px"><center>${doc.data().courseTitle}</center></h5>
                    <center>
                    <button  class="btn btn-outline-primary" id="${doc.id}" onclick="RedirectToViewCourse(this.id)">View Course</button>
                    <button  class="btn btn-outline-danger" id="${doc.id}" onclick="DeleteCourse(this.id)">Delete</button>

                    </center>
                  </div>
                </div>
              </div>`)
        });
    }).then(()=>{
      
      document.getElementById("LoadmoreButtondiv").style.display = "flex"
      document.getElementById("Loading").style.display = "none"
    })
    

}
GetCourses();


function LoadMoreCourses(params) {
  
    firestore.collection("Courses").orderBy("date","desc").startAfter(lastCourseDoc).limit(6).get().then((querySnapshot) => {
        lastCourseDoc = querySnapshot.docs[querySnapshot.size-1]
        
        if(querySnapshot.size == 0){
          swal("No More courses")
          document.getElementById("LoadmoreButtondiv").style.display = "none"
        }else{
        
          querySnapshot.forEach((doc) => {
            currentId = doc.id
            // doc.data() is never undefined for query doc snapshots
            $('#CouseParentDiv').append(`<div  class="col-md-6 col-lg-4 mb-3" id="${doc.id}-postcol"  >
            <div class="card" >
              <img class="card-img-top" src="${doc.data().courseImage}" alt="Card image cap" style="width:350px;height:197px">

              <div class="card-body">
                <h5 class="card-title" style="width:302px;height:40px"><center>${doc.data().courseTitle}</center></h5>
                <center>
                <button  class="btn btn-outline-primary" id="${doc.id}" onclick="RedirectToViewCourse(this.id)">View Course</button>
                <button  class="btn btn-outline-danger" id="${doc.id}" onclick="DeleteCourse(this.id)">Delete</button>
                </center>
              </div>
            </div>
          </div>`)
              
        });
        }
        
    }).then(()=>{

      // document.getElementById(`${currentId}`).style.display = "none"
      // document.getElementById("Loading2").style.display = "none"

    })
}


function searchCourse(params) {
var SearchInput =  document.getElementById("searchId").value

  firestore.collection("Courses").where("keywords", "array-contains", SearchInput.toLowerCase())
    .get()
    .then((querySnapshot) => {
      while(document.getElementById("CouseParentDiv").childElementCount!==0){
        document.getElementById("CouseParentDiv").firstChild.remove();
      }
        querySnapshot.forEach((doc) => {
          $('#CouseParentDiv').append(`<div  class="col-md-6 col-lg-4 mb-3" >
          <div class="card h-100">
            <img class="card-img-top" src="${doc.data().courseImage}" alt="Card image cap" >
            <div class="card-body">
              <h5 class="card-title"><center>${doc.data().courseTitle}</center></h5>
              <center>
              <a href="javascript:void(0)" class="btn btn-outline-primary">View Course</a>
              </center>
            </div>
          </div>
        </div>`)
            
        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    
} 

function ResetSearch(params) {

  var SearchInput =  document.getElementById("searchId").value
  if(SearchInput == ""){
    while(document.getElementById("CouseParentDiv").childElementCount!==0){
      document.getElementById("CouseParentDiv").firstChild.remove();
    }
    GetCourses();
  }
  
}

function RedirectToViewCourse(params) {
  
  localStorage.setItem("CourseDocId", params);  
  location.assign("/ViewCourse/ShowCourse.html");

}
function DeleteCourse(params) {

  swal({
    title: "Are you sure?",
    text: "Do you want to Delete this Post",
    icon: "warning",
    buttons: !0,
    dangerMode: !0
}).then(n => {
    
    n && firestore.collection("Courses").doc(params).collection("Modules").get().then((querySnapshot) => {
    
      console.log("querySnapshot",querySnapshot.size)

      if(querySnapshot.size !==0){
        swal("Delete Modules and Lives")
      }else{
        document.getElementById(`${params}-postcol`).remove();
      firestore.collection("Courses").doc(params).delete()
 
      }
  
    }).then(()=>{

      
      swal("Courses Deleted Successfuly")
  })
 
})



}