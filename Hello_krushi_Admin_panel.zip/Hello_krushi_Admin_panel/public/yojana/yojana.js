var firestore = firebase.firestore();
var database = firebase.database();
const storage = firebase.storage();
var storageRef = storage.ref();
var SliderDoc;
var ResetSearchCount = 0;
var YojanToBeEdit;
var count = 0;
var lastYojanaDoc;


var data = [];
var index = 0;
var YojanaList = [];
var YojanaListIndex= 0;
var paginationindex = 0;
var CurrentPage = 0;


function ShowImage(params) {
    document.getElementById("blah").style.display = ""
    if (params.files && params.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah')
                .attr('src', e.target.result)
                .width(300)
                .height(350);
        };

        reader.readAsDataURL(params.files[0]);
    }
}

function SaveSlider(params) {

    var SliderFlag = document.getElementById("SliderFlag").value;
    var SliderLink = document.getElementById("SliderLink").value;
    var SliderImage = document.getElementById("InserSliderImg").value;  


    if(SliderFlag!=="Choose..." && SliderLink!=="" && SliderImage!==""){

        const ref = firebase.storage().ref();
        const file = document.querySelector('#InserSliderImg').files[0]
        const name =  file.name;
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('CommodityImages/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
        console.log(url);
        firestore.collection("Slider").add({
            date: firebase.firestore.Timestamp.fromDate(new Date()).toDate() ,
            image:url,
            flag :SliderFlag,
            link :SliderLink,
        })
        
        }).then(()=>{
            swal("successful", "Slider Added successfully ", "success")
  
        })

        document.getElementById("flagSpan").style.display = "none"
        document.getElementById("linkSpan").style.display = "none"
        document.getElementById("imgspan").style.display = "none"

    }else{

        if(SliderFlag == "Choose..."){

            document.getElementById("flagSpan").style.display = ""
        }else{
            document.getElementById("flagSpan").style.display = "none"
        }

        if(SliderLink == ""){

            document.getElementById("linkSpan").style.display = ""
        }else{

            document.getElementById("linkSpan").style.display = "none"
        }
        if(SliderImage == ""){

          
            document.getElementById("imgspan").style.display = ""
        }else{

            document.getElementById("imgspan").style.display = "none"

        }
    }



}




function Slider_Show_Insert(params) {

    if(params == "Show"){

        document.getElementById("Show_slider").style.display = "";
        document.getElementById("Input_Slider").style.display = "none";
        GetYojana();
      
    }else if(params == "Add"){

        document.getElementById("Show_slider").style.display = "none";
        document.getElementById("Input_Slider").style.display = "";
        document.getElementById("MoreSlider").style.display = "none";
        

    }
    
} 

{/* <tr>
<th id="7aL5dBuJrGVVeBcJFH0J" onclick="shetiInfo(this.id)" style="cursor: pointer;"><a id="7aL5dBuJrGVVeBcJFH0J">01/06/2022</a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">shubham </a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">7447665519</a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">ऊस</a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">नगदी पिके</a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">4 एकर</a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">मध्यम काळी जमिन</a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">अहमदनगर</a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">शेवगाव</a> </th>
<th><a id="7aL5dBuJrGVVeBcJFH0J">सोनेसांगवी</a> </th>
</tr> */}


 function GetYojana(params) {
    data = [];
    index = 0;
    YojanaList = [];
    YojanaListIndex= 0;
    paginationindex = 0;
    CurrentPage = 0;

    firestore.collection("Yojna").orderBy("date","desc").limit(5).get().then((querySnapshot) => {
        while(document.getElementById("Yojantbody").childElementCount!==0){
            document.getElementById("Yojantbody").firstChild.remove();
          }
        lastYojanaDoc = querySnapshot.docs[querySnapshot.docs.length - 1];
        querySnapshot.forEach((doc) => {
            data[index++] = [`${doc.id}`,`${doc.data().title}`]

            $('#Yojantbody').append(`<tr id="${doc.id}-Delete" >
    
            <th style="height: 1rem" ><a id="7aL5dBuJrGVVeBcJFH0J">${doc.data().title} </a> </th>
            <th ><button class="btn btn-primary" id="${doc.id}" onclick="shetiInfo(this.id)" ><i class="fa fa-eye" aria-hidden="true" ></i> View</button> 
            <button class="btn btn-danger" id=${doc.id} onclick="DeleteYojana(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
            </th>

            </tr>`)
        });
    }).then(()=>{
        YojanaList[YojanaListIndex++] = data;
        paginationindex++;
        CurrentPage++;
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      })
    
    

}

function nextPage(params) {

    CurrentPage >0 ? document.querySelector('#previous').disabled = false : document.querySelector('#previous').disabled = true

    
      if(CurrentPage==paginationindex){
  
      
        paginationindex++;
      
    
        firestore.collection("Yojna").orderBy("date","desc").startAfter(lastYojanaDoc).limit(5).get().then((querySnapshot) => {
            console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
            document.querySelector('#next').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
            console.log("At the End",YojanaList);
          }
          else{
            data = [];
            index = 0;
        
            while(document.getElementById("Yojantbody").childElementCount!==0){
              document.getElementById("Yojantbody").firstChild.remove();
            }

            lastYojanaDoc = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
              //   console.log(doc.data().userName);
                 // doc.data() is never undefined for query doc snapshots
                 data[index++] = [`${doc.id}`,`${doc.data().title}`]
        
                 $('#Yojantbody').append(`<tr id="${doc.id}-Delete" >
    
                    <th style="height: 1rem" ><a id="7aL5dBuJrGVVeBcJFH0J">${doc.data().title} </a> </th>
                    <th ><button class="btn btn-primary" id="${doc.id}" onclick="shetiInfo(this.id)" ><i class="fa fa-eye" aria-hidden="true" ></i> View</button> 
                    <button class="btn btn-danger" id=${doc.id} onclick="DeleteYojana(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
                    </th>

                </tr>`)
            //  document.getElementById("NoProduct").style.display = "none"
              })
              
             
          }
          // <th><button type="button" id= ${doc.id} class="btn btn-danger" onclick = "DeleteUser(this.id)">Delete</button></th>
         
      }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        YojanaList[YojanaListIndex++] = data;
        CurrentPage++;
      })
       
      }
      else{
    

        while(document.getElementById("Yojantbody").childElementCount!==0){
          document.getElementById("Yojantbody").firstChild.remove();
        }
        YojanaList[CurrentPage].forEach(doc => {
         
         // console.log("demo Array",element)
      
         $('#Yojantbody').append(`<tr id="${doc[0]}-Delete" >
    
         <th style="height: 1rem" ><a id="7aL5dBuJrGVVeBcJFH0J">${doc[1]} </a> </th>
         <th ><button class="btn btn-primary" id="${doc[0]}" onclick="shetiInfo(this.id)" ><i class="fa fa-eye" aria-hidden="true" ></i> View</button> 
         <button class="btn btn-danger" id=${doc[0]} onclick="DeleteYojana(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
         </th>

        </tr>`)
        });
        CurrentPage++;
      }
  
}

function previousPage(params) {

  document.querySelector('#next').disabled = false;

 
  CurrentPage--;


  if(CurrentPage > 0){
    

    while(document.getElementById("Yojantbody").childElementCount!==0){
        document.getElementById("Yojantbody").firstChild.remove();
    }
  
    
    YojanaList[CurrentPage-1].forEach(doc => {
       
        $('#Yojantbody').append(`<tr id="${doc[0]}-Delete" >
    
        <th style="height: 1rem" ><a id="7aL5dBuJrGVVeBcJFH0J">${doc[1]} </a> </th>
        <th ><button class="btn btn-primary" id="${doc[0]}" onclick="shetiInfo(this.id)" ><i class="fa fa-eye" aria-hidden="true" ></i> View</button> 
        <button class="btn btn-danger" id=${doc[0]} onclick="DeleteYojana(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
        </th>

       </tr>`)
      });
      // <th><button type="button" id= ${element[0]} class="btn btn-danger" onclick = "DeleteUser(this.id)">Delete</button></th>
  }
  else{
    CurrentPage = 1
    console.log("Current-Page",CurrentPage)
    document.querySelector('#previous').disabled = true;

  }

}

function shetiInfo(params) {
    YojanToBeEdit = params
    ResetModal();
    // document.getElementById("Yojana_intro").innerHTML = '';
    document.getElementById("Yojana_discription").innerHTML = '';
    document.getElementById("Yojana_Link").innerHTML = '';
    
    // <span id="Yojana_intro"></span>
    // <img  id="yojana image" style="width:300px;height: 300px;">
    // <span id="Yojana_discription"></span>
    // <span id="Yojana_Link"></span>
    var docRef = firestore.collection("Yojna").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {
            // document.getElementById("Yojana_intro").innerText = doc.data().intro;
            document.getElementById("yojana_image").src = doc.data().img;
            document.getElementById("yojana_tile").innerText = doc.data().title;
            // document.getElementById("Yojana_discription").innerText = doc.data().description;
            // document.getElementById("Yojana_Link").innerText = doc.data().applyLink;
            var intro = doc.data().intro;
            var description = doc.data().description;
            var applyLink = doc.data().applyLink;

         
        document.getElementById("Yojana_Link").href = `${doc.data().applyLink}`
            // $('#Yojana_intro').append(`${doc.data().intro}`)
            // $('#yojana_image').append(`${doc.data().img}`)
            $('#Yojana_discription').append(`${doc.data().description}`)
            document.getElementById("Yojana_Link").innerHTML = `${doc.data().applyLink}`
            // $('#Yojana_Link').append(`${doc.data().applyLink}`)

        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });



    $('#EditYojanaModal').modal();
}
function ResetModal(params) {
    document.getElementById("yojana_tile").style.display = ""
    document.getElementById("Yojana_discription").style.display = ""
    document.getElementById("Yojana_Link").style.display = ""
    document.getElementById("EditYojanaButton").style.display = ""
    document.getElementById("yojana_tile_Edit").style.display = "none"
    document.getElementById("Yojana_discription_Edit").style.display = "none"
    document.getElementById("Yojana_Link_Edit").style.display = "none"
    document.getElementById("saveYojanaButton").style.display = "none"

}

function getAllSubstrings(str) {
    var result = [],i;
	for (let j = 1 ; j < str.length + 1; j++) {
	  result.push(str.slice(i, j));

	}
	for (let j = str.indexOf(" ")+2 ; j < str.length + 1; j++) {
	  result.push(str.slice(str.indexOf(" ")+1, j));
  }
return result;
}
function EditYojana(params) {
    var TextAreaTOStrech = document.getElementById("Yojana_discription_Edit");


    var docRef = firestore.collection("Yojna").doc(YojanToBeEdit);

    docRef.get().then((doc) => {
        if (doc.exists) {
            // document.getElementById("Yojana_intro").innerText = doc.data().intro;

            document.getElementById("Edit_Image_For_Yojana").style.display = "flex"
            document.getElementById("yojana_tile_Edit").value = doc.data().title;
            document.getElementById("Yojana_discription_Edit").innerText = doc.data().description;
            document.getElementById("Yojana_Link_Edit").value = doc.data().applyLink;
            
            document.getElementById("yojana_tile").style.display = "none"
            document.getElementById("Yojana_discription").style.display = "none"
            document.getElementById("Yojana_Link").style.display = "none"
            document.getElementById("EditYojanaButton").style.display = "none"
            document.getElementById("yojana_tile_Edit").style.display = ""
            document.getElementById("Yojana_discription_Edit").style.display = ""
            document.getElementById("Yojana_Link_Edit").style.display = ""
            document.getElementById("saveYojanaButton").style.display = ""
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
}

function SaveEditedYojana(params) {
   
    // alert("In Eidt")
    document.getElementById("LoadingtoSave").style.display ="";
    
    var washingtonRef = firestore.collection("Yojna").doc(YojanToBeEdit);
    var YojanaTitle = document.getElementById("yojana_tile_Edit").value;
    var YojanaDiscription = document.getElementById("Yojana_discription_Edit").value;
    var YojanaApplyLink = document.getElementById("Yojana_Link_Edit").value;
    var YojanaImage = document.getElementById("ImageFileToBeChangeforYoajana").value;
    var UpdatedUserNameKeyWords = getAllSubstrings(YojanaTitle.toLowerCase())
   if(YojanaImage !==""){

    const ref = firebase.storage().ref();
    const file = document.querySelector('#ImageFileToBeChangeforYoajana').files[0]
    const name =  file.name;
    const metadata = {
    contentType: file.type
    };
    const task = ref.child('CommodityImages/' + name).put(file, metadata);
    task
    .then(snapshot => snapshot.ref.getDownloadURL())
    .then((url) => {

        return washingtonRef.update({
            // title : YojanaTitle,
            // description : YojanaDiscription,
            // applyLink : YojanaApplyLink,
            // img : url,
            // keywords : UpdatedUserNameKeyWords,
            // date: firebase.firestore.Timestamp.fromDate(new Date()).toDate()

        })
    })
    .then(() => {
        document.getElementById("LoadingtoSave").style.display ="none";
        swal(" Yojana Edited Successfully");
    })
    .catch((error) => {
        // The document probably doesn't exist.
        console.error("Error updating document: ", error);
    });
    
   }else{
    return washingtonRef.update({
        title : YojanaTitle,
        description : YojanaDiscription,
        applyLink : YojanaApplyLink,
        keywords : UpdatedUserNameKeyWords,
        date: firebase.firestore.Timestamp.fromDate(new Date()).toDate()
       
    }).then(() => {
        document.getElementById("LoadingtoSave").style.display ="none";
        swal(" Yojana Edited Successfully");
    }).then(()=>{
    
    })
   }

    

}

function readURLForImageYojana(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#yojana_image')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}

function AddYojana(params) {

    var Addtitle = document.getElementById("AddYojanaTitle").value;
    var AddIntro = document.getElementById("AddYojanaIntro").value;
    var AddDiscription = document.getElementById("AddYojanaDiscription").value;
    var AddApplylink = document.getElementById("AddYojanaApplyLink").value;
    var AddImg = document.getElementById("InserYojanaImg").value;
    document.getElementById("LoadingtoSave").style.display ="";
    var UpdatedUserNameKeyWords = getAllSubstrings(Addtitle.toLowerCase())

    if( Addtitle!=="" && AddIntro!=="" && AddDiscription!=="" && AddApplylink!=="" && AddImg!==""){
        const ref = firebase.storage().ref();
        const file = document.querySelector('#InserYojanaImg').files[0]
        const name =  file.name;
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('CommodityImages/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
    
            firestore.collection("Yojna").add({
                title : Addtitle,
                intro: AddIntro,
                description : AddDiscription,
                applyLink : AddApplylink,
                img : url,
                date: firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                keywords : UpdatedUserNameKeyWords
            })
        })
        .then(() => {
            document.getElementById("LoadingtoSave").style.display ="none";
            document.getElementById("AddYojanaTitle").value = ""
            document.getElementById("AddYojanaIntro").value =""
            document.getElementById("AddYojanaDiscription").value ="";
            document.getElementById("AddYojanaApplyLink").value ="";
            document.getElementById("InserYojanaImg").value="";
            document.getElementById("yojanaAddimg").style.display="none";
            document.getElementById("AddYojanaDiscription").style.height ="112px";
            document.getElementById("LoadingtoSave").style.display ="none";
            swal(" Yojana Added Successfully");
        }).then(()=>{
            
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });



    }else{
       if(Addtitle == ""){
        document.getElementById("titleSpan").style.display = ""
       }else{
        document.getElementById("titleSpan").style.display = "none"
       }

       if(AddIntro == ""){
        document.getElementById("introSpan").style.display = ""
       }else{
        document.getElementById("introSpan").style.display = "none"
       }

       if(AddDiscription == " "){
        document.getElementById("discrSpan").style.display = ""
       }else{
        
        document.getElementById("discrSpan").style.display = "none"
       }

       if(AddApplylink == ""){
        document.getElementById("linkSpan").style.display = ""
       }else{
        document.getElementById("linkSpan").style.display = "none"
       }

       if(AddImg == ""){
        // console.log("Image", document.getElementById("InserYojanaImg").value)
        document.getElementById("imgspan").style.display = ""
       }else{
        document.getElementById("imgspan").style.display = "none"
       }

    }
}

function ShowYojanaImage(input) {
    document.getElementById("yojanaAddimg").style.display = ""
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#yojanaAddimg')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}

DeleteYojana = (id) => {

    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Yojana",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        n && firestore.collection("Yojna").doc(id).delete()


            .then(function () {
                let subsWrapper = document.getElementById(`${id}-Delete`)
                subsWrapper.remove();
                swal("Successfull", "Yojana Deleted ", "success")
            }).catch(function (e) {
                console.error("Error removing document: ", e)
            })
    })
}
function searchYojana(params) {

    var TobeSearch = document.getElementById("MySearch").value.toLowerCase();;
    if(TobeSearch!==""){
        firestore.collection("Yojna").where("keywords", "array-contains", TobeSearch)
        .get()
        .then((querySnapshot) => {
            while (document.getElementById("Yojantbody").childElementCount != 0) {

                document.getElementById("Yojantbody").firstChild.remove();
        
            }
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                $('#Yojantbody').append(`<tr>
                <th id="${doc.id}" onclick="shetiInfo(this.id)"><a>${doc.data().title}</a> </th>
                <th><button>View </button> </th>

                </tr>`)
            });
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });

    }
        

}

function ResetYojanaSearch(params) {
    

        if(document.getElementById("MySearch").value == "" ){
          
            if(ResetSearchCount<1){
                while (document.getElementById("Yojantbody").childElementCount != 0) {
     
                    document.getElementById("Yojantbody").firstChild.remove();
            
                }
                ResetSearchCount++;
                GetYojana();
            }
            
         }else{
             ResetSearchCount = 0;
         }

}

