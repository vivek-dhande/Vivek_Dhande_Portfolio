

// Call the dataTables jQuery plugin
var firestore = firebase.firestore();
var database = firebase.database();
const messaging = firebase.messaging();

// console.log('getToken()',messaging.getToken({ vapidKey: "BDrHOVYmMrcwOOW30BVY-oMWIUsmGgUwc8mLv16-vDQ5qHYVav0XJnxhW8HAzg5Q8Hyzpx1PhVLKSDIuNFWoFzw" }))

var ExportDataList = [];
var exportIndex = 0;
var filterType;

var Pagination_Filter_Flag;
var Pagination_Filter_Value;
var Pagination_Filter_Both ;
var Pagination_Filter_Both_Value ;

var Profession_Filter;
var Profession_Filter_Type;

var DateFilterLastDoc;
var Onlycat_Crop_Last
var index = 0;
var index_Filter_dist = 0;
var index1 = 0;
var index1_Filter_dist;
var data = [];
var data_Filter_Dist = []
var UserList = [];
var UserList_Filter_dist
var lastUser;
var lastUser_Dist_Filter;
var lastUser_Main_Cat;
var lastuser_Pika;
var FixLastVeriable;
var lastUser_Date_with_Main_Cat;
var lastUser_Date_with_Taluka_Cat
var lastUser_Date_with_Crop;
var lastUser_Date_with_Crop_Dist;

var paginationindex = 0 ;
var paginationindex_Filter_Dist = 0;
var CurrentPage = 0 ;
var CurrentPage_Filter_Dist = 0;
var CurrentDistCode ;
var first;
var End;
var currentDistrict;
var currentVibhag;
var currentTaluka;
var currentMainCat;
var index3 = 0; 

var Special_Index = 0; 

var Selected_Data;
var Selected_Vibhag;
var Selected_District;
var Selected_Taluka;
var Selected_Village;
var Selected_Category
var Selected_Crop;
var Date_Selected_From;
var Date_Selected_To;
var Selected_Main_Category;
var Selected_Main_Category_Doc;
var Selected_pika_Db_Reffrence;
var WhichFilterSelected;
var Selected_Pika_Mode;
var Selected_UserType;

var VibhagSlected;
var DistrictFilterSelected;
var TalukaFilterSelected;
var VillageFilterSlected;
var MainCategorySelected;
var CropSelected;
var UserTypeFilter;
var CurrentSelectedFilter; 

var Pagination_Filter_Flag;

var Parent_Filter;

var Get_UserDoc_For_Main_cat = []; 
var Get_UserDoc_For_Main_cat_index = 0;

var ForProcessing = [];

var Filtered_User_Data = [];
var Filtered_User_Data_index = 0;

var pika_list_User_Data = [];
var pika_list_User_Data_index = 0; 

var Special_Index_2 = 0;


var proffesionMenu = ["शेतकरी","शेतमाल व्यापारी","शेती निगडीत व्यवसाय","थेट ग्राहक (नोकरदार वगैरे)"];

buildDropDown_Proffesion(proffesionMenu);
function buildDropDown_Proffesion(values) {
  let contents = []
  for (let name of values) {
    console.log("name",name);
  contents.push(`<input type="button" class="dropdown-item" type="button" value="${name}" onclick="Get_District(this.value)"/>`)
  }
  $('#Profession_menuItems').append(contents.join(" "))

  //Hide the row that shows no items were found
  $('#empty').hide()
}


$('#Profession_menuItems').on('click', '.dropdown-item', function(){

  Selected_UserType = $(this)[0].value;
  UserTypeFilter = 'userType';
    $('#User_Proffesion').text($(this)[0].value)
    $("#User_Proffesion").dropdown('toggle');


})


function getUserlist(params) {
   
  lastUser = "";
  data = [];
  index = 0;
  UserList = [];
  index1= 0;
  paginationindex = 0;
  CurrentPage = 0;

  ExportDataList = []
  exportIndex = 0;
  first = firestore.collection("Userinfo").orderBy("date","desc").limit(10).get().then((querySnapshot) => {

    lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

    querySnapshot.forEach((doc) => {
   // console.log(doc.data().userName); 
      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`,`${doc.data().userContact}`,]



      // doc.data() is never undefined for query doc snapshots
      $("#tbody").append(`<tr id ="${doc.id}" onclick="showprofile(this.id)">
      <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
      <th>${doc.data().userName}</th>
      <th>${doc.data().userType}</th>
      <th>${doc.data().district}</th>
      <th>${doc.data().tahsil}</th>
      <th>${doc.data().village}</th>
      <th>${doc.data().userContact}</th>
     

      </tr>`);
      document.getElementById("NoProduct").style.display = "none"
      document.getElementById("UserListTable").style.display = ""
  

   });                                                       
  
  //  <th><button type="button" id= ${doc.id} class="btn btn-danger" onclick = "DeleteUser(this.id)">Delete</button></th>

}).then(()=>{
  UserList[index1++] = data;
  paginationindex++;
  CurrentPage++;
  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
  console.log("Data Puted Sucessfully",UserList);
})

// first = firestore.collection("Userinfo").orderBy("date","desc").get().then((querySnapshot) => {



//   querySnapshot.forEach((doc) => {
//  // console.log(doc.data().userName); 

//     ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`,`${doc.data().userContact}`]                 


//  });

// //  <th><button type="button" id= ${doc.id} class="btn btn-danger" onclick = "DeleteUser(this.id)">Delete</button></th>

// }).then(()=>{

// console.log("Data Puted Sucessfully",ExportDataList);
// })


}

getUserlist();


function DeleteUser(params) {
  swal({
    title: "Are you sure?",
    text: "Do you want to Delete this Product",
    icon: "warning",
    buttons: !0,
    dangerMode: !0
}).then(n => {
    n && firestore.collection("Userinfo").doc(params).delete()
  
    
    .then(function() {
        let subsWrapper = document.getElementById(`${params}`)
        subsWrapper.remove();
        swal("Successfull", "Product Deleted ", "success")
    }).catch(function(e) {
        console.error("Error removing document: ", e)
    })
})
 
}



function nextPage(params) {

  CurrentPage >0 ? document.querySelector('#previous').disabled = false : document.querySelector('#previous').disabled = true
  
  
  // CurrentPage++;
  

    console.log("  ",lastUser)


  if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected === undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
           
    // //alert("In Date")
     document.getElementById("WithFilter_pikar").style.display = "none";   
     document.getElementById("WithFilter").style.display = "none";
     document.getElementById("WithoutFilter").style.display = "";   
     
     document.querySelector('#next_Main_cat').disabled = false;
     // //alert("In Special Case");

 

    if(CurrentPage==paginationindex){

      data = [];
      index = 0;
      firestore.collection("Userinfo").where("date",">=",Date_Selected_From).where("date","<=",Date_Selected_To).orderBy("date","desc").startAfter(DateFilterLastDoc).limit(10).get().then((querySnapshot) => {
      
      
  
  
        if( querySnapshot.docs.length == 0 ){
          document.querySelector('#next').disabled = true;
          
           CurrentPage--;
          paginationindex--;
           (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }else{
              while(document.getElementById("tbody").childElementCount!==0){
              document.getElementById("tbody").firstChild.remove();
        }
        DateFilterLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((docI)=>{
            console.log("Date",docI.data())
            data[index++] = [`${docI.id}`,`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                    // doc.data() is never undefined for query doc snapshots
                    $("#tbody").append(`<tr>
                    <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                    <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                    <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                    <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                    <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                    <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                    <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                </tr>`);
                    document.getElementById("NoProduct").style.display = "none"
                    // document.getElementById("UserListTable").style.display = ""
      
          })
        }

       }).then(()=>{
       UserList[index1++] = data;
       paginationindex++;
       CurrentPage++;
       console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
       console.log("Data Puted Sucessfully",UserList);
     })

    }else{
      
      console.log("  ",lastUser)
      while(document.getElementById("tbody").childElementCount!==0){
        document.getElementById("tbody").firstChild.remove();
      }
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[CurrentPage].forEach(element => {
       
       // console.log("demo Array",element)
    
        $("#tbody").append(`<tr id= ${element[0]}>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
      
        </tr>`);
      });
      CurrentPage++;
      console.log("Data from local",UserList);

    }

  }else{
    if(CurrentPage==paginationindex){

    
      paginationindex++;
    
  
      firestore.collection("Userinfo").orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
          document.querySelector('#next').disabled = true;
          
           CurrentPage--;
          paginationindex--;
           (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          data = [];
          index = 0;
      
          while(document.getElementById("tbody").childElementCount!==0){
            document.getElementById("tbody").firstChild.remove();
          }
          lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            // console.log(doc.data().userName); 
               data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
         
         
         
               // doc.data() is never undefined for query doc snapshots
               $("#tbody").append(`<tr id ="${doc.id}" onclick="showprofile(this.id)">
               <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
               <th>${doc.data().userName}</th>
               <th>${doc.data().userType}</th>
               <th>${doc.data().district}</th>
               <th>${doc.data().tahsil}</th>
               <th>${doc.data().village}</th>
               <th>${doc.data().userContact}</th>
              
         
               </tr>`);
               document.getElementById("NoProduct").style.display = "none"
               document.getElementById("UserListTable").style.display = ""
           
         
            });   
          // querySnapshot.forEach((doc) => {
          //   //   console.log(doc.data().userName);
          //      // doc.data() is never undefined for query doc snapshots
          //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
      
          //      $("#tbody").append(`<tr id= ${doc.id}>
          //      <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
          //      <th>${doc.data().userName}</th
          //      <th>${doc.data().userType}</th>>
          //      <th>${doc.data().village}</th>
          //      <th>${doc.data().tahsil}</th>
          //      <th>${doc.data().district}</th>
          //      <th>${doc.data().userContact}</th>
  
         
          //  </tr>`);
          //  document.getElementById("NoProduct").style.display = "none"
          //   })
            
           
        }
        // <th><button type="button" id= ${doc.id} class="btn btn-danger" onclick = "DeleteUser(this.id)">Delete</button></th>
       
    }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      CurrentPage++;
      console.log("Data Puted Sucessfully",UserList);
    })
     
    }
    else{
  
      console.log("  ",lastUser)
      while(document.getElementById("tbody").childElementCount!==0){
        document.getElementById("tbody").firstChild.remove();
      }
      UserList[CurrentPage].forEach(element => {
       
       // console.log("demo Array",element)
    
        $("#tbody").append(`<tr id= ${element[0]}>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
        </tr>`);
      });
      console.log("Data from local",UserList);
      CurrentPage++;
    }
    

  }

}


function previousPage(params) {

  document.querySelector('#next').disabled = false;

 
  CurrentPage--;
  console.log("demo Array",CurrentPage)

  if(CurrentPage > 0){
    

    console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
    while(document.getElementById("tbody").childElementCount!==0){
      document.getElementById("tbody").firstChild.remove();
    }
  
    
      UserList[CurrentPage-1].forEach(element => {
       
        $("#tbody").append(`<tr id= ${element[0]}>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
      
        </tr>`);
      });
      // <th><button type="button" id= ${element[0]} class="btn btn-danger" onclick = "DeleteUser(this.id)">Delete</button></th>
  }
  else{
    CurrentPage = 1
    console.log("Current-Page",CurrentPage)
    document.querySelector('#previous').disabled = true;

  }

}

function ResetUserSearch(params) {
  var USERLISTCHILD = document.getElementById("tbody");
  if(document.getElementById('MySearch').value == ""){
    while( USERLISTCHILD.childElementCount !== 0){
      USERLISTCHILD.firstChild.remove();
     }
     getUserlist();
  }

}


function searchUser(params) {

  var USERLISTCHILD = document.getElementById("tbody");
  var searchboxtext = document.getElementById('MySearch').value
  var NeedToBeSearch = searchboxtext.toLowerCase();
  console.log("NeedToBeSearch",NeedToBeSearch);
  if(searchboxtext!==""){
     while( USERLISTCHILD.childElementCount !== 0){
      USERLISTCHILD.firstChild.remove();
     }
    //  document.getElementById("load").style.display = "none"
      
  }else{
    getUserlist();
      while( USERLISTCHILD.childElementCount !== 0){
          USERLISTCHILD.firstChild.remove();
         }
         
      // document.getElementById("load").style.display = ""
  }

  

  firestore.collection("Userinfo").where("keywords", "array-contains", NeedToBeSearch).orderBy("date","desc").limit(10).get().then(function(querySnapshot){
   
       querySnapshot.forEach((doc)=>{
         
          // searchData[index++]= [e.id,e.data().date.toDate(),e.data().userName,e.data().userProfilePic]  

          $("#tbody").append(`<tr>
          <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
          <th>${doc.data().userName}</th>
          <th>${doc.data().userType}</th>
          <th>${doc.data().district}</th>
          <th>${doc.data().tahsil}</th>
          <th>${doc.data().village}</th>
          <th>${doc.data().userContact}</th>
         
      </tr>`);
       })
      // creatTable(searchData[0])
   })

  //  <th><button type="button" id= ${SearchUser.id} class="btn btn-danger" onclick = "DeleteUser(this.id)">Delete</button></th>
}

// const myDiv = document.querySelector('#onlyTable')  

// myDiv.addEventListener('scroll', () => {  
//   var searchboxtext = document.getElementById("MySearch");


//       if(searchboxtext.value==""){
//           if (myDiv.offsetHeight + myDiv.scrollTop + 1>= myDiv.scrollHeight) {  
        
//             console.log('scrolled to bottom');  
//             myDiv.scrollTop = myDiv.scrollTop - 50
//             var no = getMoreUserlist(lastUser);
          
//           }  
//       }
      
// })

function showprofile(params) {

  localStorage.setItem('userDocId', params);
  console.log("UserdocID",localStorage.getItem('userDocId'));


  window.location.href = "/userProfile.html";


}


function OpenFilter(params) {
  
  $('#FilterModal').modal();
}


//Initialize with the list of symbols
let names = []
let Vibhag_List = [];
let Vibhag_List_index = 0;

let District_List = [];
let District_List_index = 0;

let Tahasil_List = [];
let Tahasil_List_index = 0;

let Village_List = [];
let Village_List_index = 0;

let CropCategory_list = [];
let CropCategory_list_index = 0;

let CropCategory_User_list = [];
let CropCategory_User_list_index = 0;

let pika_list = [];
let pika_list_index = 0;

//Find the input search box
let search = document.getElementById("searchCoin") 
let search1 = document.getElementById("searchCoin1") 


//Find every item inside the dropdown
let items = document.getElementsByClassName("dropdown-item")
function buildDropDown(values) {
    let contents = []
    for (let name of values) {
      console.log("name",name);
    contents.push(`<input type="button" class="dropdown-item" type="button" value="${name}" onclick="Get_District(this.value)"/>`)
    }
    $('#menuItems').append(contents.join(" "))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box
search.addEventListener('input', function () {


    filter(search.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems').on('click', '.dropdown-item', function(){
  if(VibhagSlected!==undefined){

    DistrictFilterSelected = undefined ; 
    Selected_District = undefined;
    $('#District_Drop_Down').text('जिल्हा')

    TalukaFilterSelected = undefined;
    Selected_Taluka =undefined;
    $('#Tahasil').text('तालुका')
 
    VillageFilterSlected = undefined ;
    Selected_Village = undefined;
    $('#village').text('गाव')

    Selected_Data = ""
    
   }
   VibhagSlected = "0";
  Selected_District = $(this)[0].value
    
    $('#dropdown_coins').text($(this)[0].value)
    $("#dropdown_coins").dropdown('toggle');

    document.querySelector('#ResetFilterInModal').style.display = ""
    document.querySelector('#District_Drop_Down').disabled = false
})


//Find the input search box
let search_Dist = document.getElementById("searchCoin1")

//Find every item inside the dropdown
let Dist_items = document.getElementById("menuItems-dist");

function buildDropDown_dist(values) {


    let contents = []
    for (let dist of values) {
    contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${dist}" onclick="Get_Taluka(this.value,'District')"/>`)
    }
    $('#menuItems-dist').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}


function filter(word) {
  let length = items.length
  let collection = []
  let hidden = 0
  console.log(Dist_items.children[0])
  for (let i = 0; i < length; i++) {
  if (items[i].value.toLowerCase().startsWith(word)) {
      $(items[i]).show()
  }
  else {
      $(items[i]).hide()
      hidden++
  }
  }

  //If all items are hidden, show the empty view
  if (hidden === length) {
  $('#empty').show()
  }
  else {
  $('#empty').hide()
  }
}

//Capture the event when user types into the search box
search1.addEventListener('input', function () {
  
  filter_dist(search_Dist.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_dist(word) {
    let length = Dist_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Dist_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Dist_items.children[i]).show()
    }
    else {
        $(Dist_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-dist').on('click', '.dropdown-item', function(){

  if(DistrictFilterSelected!==undefined){

    TalukaFilterSelected = undefined;
    Selected_Taluka = undefined ;
    $('#Tahasil').text('तालुका')
 
    VillageFilterSlected = undefined ;
    Selected_Village = undefined;
    $('#village').text('गाव')

    Selected_Data = ""
 
   }


  DistrictFilterSelected = "district"  
  Selected_District = $(this)[0].value
    $('#District_Drop_Down').text($(this)[0].value)
    $("#District_Drop_Down").dropdown('toggle');

    WhichFilterSelected = "district";

    document.querySelector('#Tahasil').disabled = false
})


let search_Taluka = document.getElementById("searchCoin2")

//Find every item inside the dropdown
let Taluka_items = document.getElementById("menuItems-Taluka");

function buildDropDown_tahasil(values) {
    let contents = []
    for (let taluka of values) {
    contents.push(`<input type="button" id="dropdown-item-taha" class="dropdown-item"  type="button" value="${taluka}" onclick="Get_village(this.value,'Tahasil')"/>`)
    }
    $('#menuItems-Taluka').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_Taluka.addEventListener('input', function () {
  
  
  filter_taha(search_Taluka.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_taha(word) {
    let length = Taluka_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Taluka_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Taluka_items.children[i]).show()
    }
    else {
        $(Taluka_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-Taluka').on('click', '.dropdown-item', function(){
  if(TalukaFilterSelected!==undefined){

    VillageFilterSlected = undefined ;
    $('#village').text('गाव')

    Selected_Data = ""
    
   }
 
  TalukaFilterSelected = "tahsil";
  WhichFilterSelected = "tahsil";
  Selected_Taluka = $(this)[0].value
    $('#Tahasil').text($(this)[0].value)
    $("#Tahasil").dropdown('toggle');
    document.querySelector('#village').disabled = false
})

let search_village = document.getElementById("searchCoin3")

//Find every item inside the dropdown
let village_items = document.getElementById("menuItems-village");

function buildDropDown_village(values) {
    let contents = []
    for (let village of values) {
    contents.push(`<input type="button" id="dropdown-item-village" class="dropdown-item"  type="button" value="${village}" onclick="Get_village_Flag('Village')" />`)
    }
    $('#menuItems-village').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_village.addEventListener('input', function () {
  
  
  filter_villa(search_village.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_villa(word) {
    let length = village_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (village_items.children[i].value.toLowerCase().startsWith(word)) {
        $(village_items.children[i]).show()
    }
    else {
        $(village_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-village').on('click', '.dropdown-item', function(){
  Selected_Data = ""
  VillageFilterSlected = "village";
  WhichFilterSelected = "village";
  Selected_Village = $(this)[0].value
    $('#village').text($(this)[0].value)
    $("#village").dropdown('toggle');
})


let search_Main_Category = document.getElementById("searchCoin4")

//Find every item inside the dropdown
let Main_Category_items = document.getElementById("menuItems-MainCatgory");

function buildDropDown_Main_cat(values) {
    let contents = []
    for (let MainCategory of values) {
    contents.push(`<input type="button" id="dropdown-item-MainCategory" class="dropdown-item"  type="button" value="${MainCategory}" onclick="Get_Pika_Sub_Category(this.value,'Main_Cat')" />`)
    }
    $('#menuItems-MainCatgory').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_Main_Category.addEventListener('input', function () {
  
  
  filter_Main_Cat(search_Main_Category.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_Main_Cat(word) {
    let length = Main_Category_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Main_Category_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Main_Category_items.children[i]).show()
    }
    else {
        $(Main_Category_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
  $('#menuItems-MainCatgory').on('click', '.dropdown-item', function(){
    document.querySelector('#ResetFilterInModal').style.display = ""
  
    if(MainCategorySelected !== undefined){

      CropSelected = undefined ;
      Selected_Crop = undefined ;
      $('#User_Peka_Sub_filter').text('पीक')
      
    }
    MainCategorySelected = "cropMainCat";
    Selected_Category = $(this)[0].value
      $('#User_Peka_filter').text($(this)[0].value)
      $("#User_Peka_filter").dropdown('toggle');
      document.querySelector('#User_Peka_Sub_filter').disabled = false
    })

  let search_pika = document.getElementById("searchCoin5")

  //Find every item inside the dropdown
  let Main_pika_items = document.getElementById("menuItems-pika");
  
  function buildDropDown_pika(values) {
      let contents = []
      for (let pika of values) {
      contents.push(`<input type="button" id="dropdown-menuItems-pika" class="dropdown-item"  type="button" value="${pika}" />`) 
      }
      $('#menuItems-pika').append(contents.join(""))
  
      //Hide the row that shows no items were found
      $('#empty').hide()
  }
  
 // onclick="getPikaData(this.value,'pika')"
  
  //Capture the event when user types into the search box
  search_pika.addEventListener('input', function () {
    
    
    filter_Main_pik(search_pika.value.trim().toLowerCase())
  })
  
  //For every word entered by the user, check if the symbol starts with that word
  //If it does show the symbol, else hide it
  function filter_Main_pik(word) {
      let length = Main_pika_items.children.length
      let collection = []
      let hidden = 0
      for (let i = 0; i < length; i++) {
      if (Main_pika_items.children[i].value.toLowerCase().startsWith(word)) {
          $(Main_pika_items.children[i]).show()
      }
      else {
          $(Main_pika_items.children[i]).hide()
          hidden++
      }
      }
  
      //If all items are hidden, show the empty view
      if (hidden === length) {
      $('#empty').show()
      }
      else {
      $('#empty').hide()
      }
  }
  
  //If the user clicks on any item, set the title of the button as the text of the item
    $('#menuItems-pika').on('click', '.dropdown-item', function(){
      CropSelected = "crop";
      Selected_Crop = $(this)[0].value
        $('#User_Peka_Sub_filter').text($(this)[0].value)
        $("#User_Peka_Sub_filter").dropdown('toggle');
    })


    $('#datepicker_from').on('change', function(){
      ////alert("From",$(this)[0].value)
      document.querySelector('#ResetFilterInModal').style.display = ""

      // if(MainCategorySelected !== undefined){
  
      //   CropSelected = undefined ;
      //   Selected_Crop = undefined ;
      //   $('#User_Peka_Sub_filter').text('पीक')
        
      // }
      // MainCategorySelected = "cropMainCat";
      Date_Selected_From = moment($(this)[0].value,"DD/MM/YYYY").toDate()

      // var myDate = firebase.firestore.Timestamp.fromDate(new Date());
      console.log("myDate",)
        // document.querySelector('#User_Peka_Sub_filter').disabled = false
    })

    $('#datepicker_to').on('change', function(){

      ////alert("TO",$(this)[0].value)
      document.querySelector('#ResetFilterInModal').style.display = ""

      // if(MainCategorySelected !== undefined){
  
      //   CropSelected = undefined ;
      //   Selected_Crop = undefined ;
      //   $('#User_Peka_Sub_filter').text('पीक')
        
      // }
      // MainCategorySelected = "cropMainCat";
      Date_Selected_To  = moment($(this)[0].value,"DD/MM/YYYY").add(1, 'days').toDate()
      
      // var myDate = firebase.firestore.Timestamp.fromDate(new Date());
      console.log("myDate",Date_Selected_To)
        // document.querySelector('#User_Peka_Sub_filter').disabled = false
      })




function Get_Vibhag(params) {
  
  firestore.collection("SaatBara").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        console.log(doc.id, " => ", doc.data().call);

        Vibhag_List [Vibhag_List_index++] = doc.data().name;
    });
  }).then(()=>{
  

    buildDropDown(Vibhag_List);

    console.log("Vibhag_List",Vibhag_List);
  })

}

Get_Vibhag();

function Get_District(params,flag) {

  District_List = [];
  District_List_index = 0;
  var Dist_child = document.getElementById("menuItems-dist");

  console.log("menuItems-dist",Dist_child.childElementCount)
   
  firestore.collection("SaatBara").where("name","==",params).get().then((querySnapshot)=>{
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      currentVibhag = doc.id; 
    });
  }).then(()=>{
    var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District");
    docRef.get().then((querySnapshot) => {
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
          District_List[District_List_index++] = doc.data().name;
      });
    }).then(()=>{
      while(Dist_child.childElementCount !== 0){
  
        Dist_child.firstChild.remove();
      }
      console.log("Tahasil Karyalay",District_List)
      buildDropDown_dist(District_List);
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

  })

}


function Get_Taluka (params,flag) {
  var Talu_child = document.getElementById("menuItems-Taluka");

  Tahasil_List = [];
  Tahasil_List_index = 0;


  CurrentSelectedFilter = flag;

  firestore.collection("SaatBara").doc(currentVibhag).collection("District").where("name","==",params).get().then((querySnapshot)=>{
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
     
        currentDistrict = doc.id;
  });
  }).then(()=>{

      var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas")

      docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log()
            Tahasil_List[Tahasil_List_index++] = doc.data().dtname;
    
        
        });
      }).then(()=>{
        console.log("Tahasil Karyalay",Tahasil_List)
        while(Talu_child.childElementCount !== 0){
  
          Talu_child.firstChild.remove();
        }
        buildDropDown_tahasil(Tahasil_List);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });
  })

}

function Get_village (params,flag) {
  var Village_child = document.getElementById("menuItems-village");
  Village_List = [];
  Village_List_index = 0;
  CurrentSelectedFilter = flag;

  firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").where("dtname","==",params).get().then((querySnapshot)=>{
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
     
        currentTaluka = doc.id
  });
  }).then(()=>{

      var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").doc(currentTaluka).collection("Villages")

      docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
     
            Village_List[Village_List_index++] = doc.data().village_name;
    
        
        });
      }).then(()=>{
        console.log("Village Karyalay",Village_List)
        while(Village_child.childElementCount !== 0){
  
          Village_child.firstChild.remove();
        }
        buildDropDown_village(Village_List);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });
  })

}



function ApplyFilter(params) {
    
  GetFilterTypeName();

  if(DistrictFilterSelected !== undefined){
    document.getElementById("District_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("District_Checked_Only_Region").style.display = "none";
  }

  if(TalukaFilterSelected !== undefined){
    document.getElementById("Taluka_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("Taluka_Checked_Only_Region").style.display = "none";
  }

  if(VillageFilterSlected !== undefined){
    document.getElementById("Taluka_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("Taluka_Checked_Only_Region").style.display = "none";
  }

  if(MainCategorySelected !== undefined){
    document.getElementById("Category_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("Category_Checked_Only_Region").style.display = "none";
  }

  if(CropSelected !== undefined){
    document.getElementById("Crop_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("Crop_Checked_Only_Region").style.display = "none";
  }
  if(UserTypeFilter !== undefined){
    document.getElementById("Profession_Only_Region").style.display = "";
  }else{
    document.getElementById("Profession_Only_Region").style.display = "none";
  }

  if(DistrictFilterSelected !== undefined){
    document.getElementById("District_Checked_P").style.display = "";
  }else{
    document.getElementById("District_Checked_P").style.display = "none";
  }

  if(TalukaFilterSelected !== undefined){
    document.getElementById("Taluka_Checked_P").style.display = "";
  }else{
    document.getElementById("Taluka_Checked_P").style.display = "none";
  }

  if(VillageFilterSlected !== undefined){
    document.getElementById("Village_Checked_P").style.display = "";
  }else{
    document.getElementById("Village_Checked_P").style.display = "none";
  }

  if(MainCategorySelected !== undefined){
    document.getElementById("Category_Checked").style.display = "";
  }else{
    document.getElementById("Category_Checked").style.display = "none";
  }

  if(CropSelected !== undefined){
    document.getElementById("Crop_Checked").style.display = "";
  }else{
    document.getElementById("Crop_Checked").style.display = "none";
  }

  if(UserTypeFilter !== undefined){
    document.getElementById("Profession_Checked_p").style.display = "";
  }else{
    document.getElementById("Profession_Checked_p").style.display = "none";
  }

  


  if((DistrictFilterSelected == undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected == undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined ) && Selected_UserType !== undefined)){
    ////alert("In UserType Tab");
    DistrictFilter(UserTypeFilter,Selected_UserType);
  }else if(Selected_UserType !== undefined){
      if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

      //Disctrict // Maincat
      // //alert("Disctrict - Maincat - Proffession");

      // document.getElementById("District_Checked_P").style.display = "";
      // document.getElementById("Category_Checked").style.display = "";
      DistrictFilter(MainCategorySelected,Selected_Category,DistrictFilterSelected,Selected_District,UserTypeFilter,Selected_UserType,);
      
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("Taluka - Maincat - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(MainCategorySelected,Selected_Category,TalukaFilterSelected,Selected_Taluka,UserTypeFilter,Selected_UserType);
        
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

          //Disctrict // Maincat
          // //alert("Viillage - Maincat - Proffession");
    
          // document.getElementById("District_Checked_P").style.display = "";
          // document.getElementById("Category_Checked").style.display = "";
          DistrictFilter(MainCategorySelected,Selected_Category,VillageFilterSlected,Selected_Village,UserTypeFilter,Selected_UserType);
          
      }
      
      else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("Disctrict - Crop - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(CropSelected,Selected_Crop,DistrictFilterSelected,Selected_District,UserTypeFilter,Selected_UserType);
        
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("Taluka - Crop - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(CropSelected,Selected_Crop,TalukaFilterSelected,Selected_Taluka,UserTypeFilter,Selected_UserType);
        
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("Village - Crop - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(CropSelected,Selected_Crop,VillageFilterSlected,Selected_Village,UserTypeFilter,Selected_UserType);
        
      }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && (MainCategorySelected !== undefined && CropSelected == undefined) && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("Only MainCat - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(MainCategorySelected,Selected_Category,UserTypeFilter,Selected_UserType);
        
      }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && (MainCategorySelected !== undefined && CropSelected !== undefined) && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("Only Crop - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(CropSelected,Selected_Crop,UserTypeFilter,Selected_UserType);
        
      }
      
       else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && (MainCategorySelected == undefined && CropSelected == undefined) && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("District - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(DistrictFilterSelected,Selected_District,UserTypeFilter,Selected_UserType);
        
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && (MainCategorySelected == undefined && CropSelected == undefined) && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("Taluka - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(TalukaFilterSelected,Selected_Taluka,UserTypeFilter,Selected_UserType);
        
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && (MainCategorySelected == undefined && CropSelected == undefined) && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
        // //alert("Villge - Proffession");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(VillageFilterSlected,Selected_Village,UserTypeFilter,Selected_UserType);
        
      }


      else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && (MainCategorySelected == undefined && CropSelected == undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
     // //alert("Only Date - Proffesiion")
        DistrictFilter(Date_Selected_From,Date_Selected_To,UserTypeFilter,Selected_UserType);
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && (MainCategorySelected == undefined && CropSelected == undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - District - Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,DistrictFilterSelected,Selected_District,UserTypeFilter,Selected_UserType);
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && (MainCategorySelected == undefined && CropSelected == undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - taluka - Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,TalukaFilterSelected,Selected_Taluka,UserTypeFilter,Selected_UserType);
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && (MainCategorySelected == undefined && CropSelected == undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - Village - Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,VillageFilterSlected,Selected_Village,UserTypeFilter,Selected_UserType);
      }   
      else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && (MainCategorySelected !== undefined && CropSelected == undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - District - Main Cat -  Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,DistrictFilterSelected,Selected_District,MainCategorySelected,Selected_Category);
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && (MainCategorySelected !== undefined && CropSelected == undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - Taluka - Main Cat -  Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,TalukaFilterSelected,Selected_Taluka,MainCategorySelected,Selected_Category);
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && (MainCategorySelected !== undefined && CropSelected == undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - Village - Main Cat -  Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,VillageFilterSlected,Selected_Village,MainCategorySelected,Selected_Category);
      }

      else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && (MainCategorySelected !== undefined && CropSelected !== undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - Dsitrict - Crop -  Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,DistrictFilterSelected,Selected_District,CropSelected,Selected_Crop);
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && (MainCategorySelected !== undefined && CropSelected !== undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - Ta;ika - Crop -  Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,TalukaFilterSelected,Selected_Taluka,CropSelected,Selected_Crop);
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && (MainCategorySelected !== undefined && CropSelected !== undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
       // //alert(" Date - Village - Crop -  Proffesiion")
          DistrictFilter(Date_Selected_From,Date_Selected_To,VillageFilterSlected,Selected_Village,CropSelected,Selected_Crop);
      }
      



  }
  else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

      //Disctrict // Maincat
       //////alert("Disctrict - Maincat");

      // document.getElementById("District_Checked_P").style.display = "";
      // document.getElementById("Category_Checked").style.display = "";
      DistrictFilter(MainCategorySelected,Selected_Category,DistrictFilterSelected,Selected_District);

  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
      
      //Disctrict // Crop
      //////alert("Disctrict - CROP");
      // document.getElementById("District_Checked_P").style.display = "";
      // document.getElementById("Crop_Checked").style.display = "";
      DistrictFilter(CropSelected,Selected_Crop,DistrictFilterSelected,Selected_District);
  }
  else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

      //Taluka // Mincat
       //////alert("Taluka - Mincat");
      // document.getElementById("Category_Checked").style.display = "";
      // document.getElementById("Taluka_Checked_P").style.display = "";
      // document.getElementById("District_Checked_P").style.display = "";
      DistrictFilter(MainCategorySelected,Selected_Category,TalukaFilterSelected,Selected_Taluka);
  }
  else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined ) ){

    //Taluka // CROP
       //////alert("Taluka - CROP");
      // document.getElementById("Crop_Checked").style.display = "";
      // document.getElementById("Taluka_Checked_P").style.display = "";
      // document.getElementById("District_Checked_P").style.display = "";
      DistrictFilter(CropSelected,Selected_Crop,TalukaFilterSelected,Selected_Taluka);

  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined ) ){

    //Village // main cat
     ////alert("Village -  main cat");
    // document.getElementById("Category_Checked").style.display = "";
    // document.getElementById("Village_Checked_P").style.display = "";
    // document.getElementById("Taluka_Checked_P").style.display = "";
    // document.getElementById("District_Checked_P").style.display = "";
    DistrictFilter(MainCategorySelected,Selected_Category,VillageFilterSlected,Selected_Village);

  }
  else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

    //Village // main cat
     ////alert("Village - CROP");
    // document.getElementById("Crop_Checked").style.display = "";
    // document.getElementById("Village_Checked_P").style.display = "";
    // document.getElementById("Taluka_Checked_P").style.display = "";
    // document.getElementById("District_Checked_P").style.display = "";
    DistrictFilter(CropSelected,Selected_Crop,VillageFilterSlected,Selected_Village);
    
  }else if(DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

    //Village // main cat
     ////alert("Only Main Category");
    // document.getElementById("Category_Checked").style.display = "";
    DistrictFilter(MainCategorySelected,Selected_Category);
    
  }
  else if(DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined ) ){


     ////alert("Only Main CROP");
    // document.getElementById("Crop_Checked").style.display = "";
    DistrictFilter(CropSelected,Selected_Crop);
    
  }
  else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
    //District
     ////alert("District only");
    // document.getElementById("District_Checked_Only_Region").style.display = "";
    DistrictFilter(DistrictFilterSelected,Selected_District);
  }
  else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

      //Taluka
       ////alert("Taluka");
      // document.getElementById("District_Checked_Only_Region").style.display = "";
      // document.getElementById("Taluka_Checked_Only_Region").style.display = "";
    DistrictFilter(TalukaFilterSelected,Selected_Taluka);

  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Village
      ////alert("Village");
      // document.getElementById("District_Checked_Only_Region").style.display = "";
      // document.getElementById("Taluka_Checked_Only_Region").style.display = "";
      // document.getElementById("Village_Checked_Only_Region").style.display = "";
    DistrictFilter(VillageFilterSlected,Selected_Village);
        
  }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected === undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){

    ////alert("With Only Date")
    DistrictFilter(Date_Selected_From,Date_Selected_To);
    
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined  && MainCategorySelected === undefined && CropSelected === undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
    
    //District
    // //alert("District with Date");
    // document.getElementById("District_Checked_Only_Region").style.display = "";

    console.log("Before Actul Filter",DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To)
    DistrictFilter(DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To);
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected === undefined && CropSelected === undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined  ){
    
    //District
    // //alert("Taluka with Date");
    // document.getElementById("District_Checked_Only_Region").style.display = "";
    
    console.log("Before Actul Filter",DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To)
    DistrictFilter(TalukaFilterSelected,Selected_Taluka,Date_Selected_From,Date_Selected_To);
  }
  else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
    
    //District
    // //alert("Village with Date");

     DistrictFilter(VillageFilterSlected,Selected_Village,Date_Selected_From,Date_Selected_To);
    // document.getElementById("District_Checked_Only_Region").style.display = "";
    
    // console.log("Before Actul Filter",DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To)
  }
 else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
           // //alert("Vivek Dhande")
            DistrictFilter(DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To);
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
   // //alert("Taluka Filter Data")
           DistrictFilter(TalukaFilterSelected,Selected_Taluka,Date_Selected_From,Date_Selected_To);
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
   // //alert("Taluka Filter Data")
           DistrictFilter(VillageFilterSlected,Selected_Village,Date_Selected_From,Date_Selected_To);
  }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected == undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
   // //alert("Only Main-Cat Date")
           DistrictFilter(MainCategorySelected,Selected_Category,Date_Selected_From,Date_Selected_To);
  }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
   // //alert("Only Crop Date")
          
      DistrictFilter(CropSelected,Selected_Crop,Date_Selected_From,Date_Selected_To);
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
   // //alert("District Crop Date")
          
      DistrictFilter(DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To);
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
   //// //alert("Taluka Crop Date")
          
      DistrictFilter(TalukaFilterSelected,Selected_Taluka,Date_Selected_From,Date_Selected_To);
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
   // //alert("village Crop Date")
          
      DistrictFilter(VillageFilterSlected,Selected_Village,Date_Selected_From,Date_Selected_To);
  }

}

function Get_village_Flag(params) {
  
  CurrentSelectedFilter = params;
  
}




function searchFilterUser(params) {

  var USERLISTCHILD = document.getElementById("tbody_filter");
  var searchboxtext = document.getElementById('MyFilterSearch').value
  var NeedToBeSearch = searchboxtext.toLowerCase();
  console.log("NeedToBeSearch",NeedToBeSearch);
  if(searchboxtext!==""){
     while( USERLISTCHILD.childElementCount !== 0){
      USERLISTCHILD.firstChild.remove();
     }
    //  document.getElementById("load").style.display = "none"
      
  }else{
    ApplyFilter();
      while( USERLISTCHILD.childElementCount !== 0){
          USERLISTCHILD.firstChild.remove();
         }
         
      // document.getElementById("load").style.display = ""
  }

  

  firestore.collection("Userinfo").where("keywords", "array-contains", NeedToBeSearch).orderBy("date","desc").limit(1).get().then(function(querySnapshot){
   
       querySnapshot.forEach((SearchUser)=>{
         
          // searchData[index++]= [e.id,e.data().date.toDate(),e.data().userName,e.data().userProfilePic]  


          $("#tbody_filter").append(`<tr>
          <th style="cursor:pointer"><a id ="${SearchUser.id}" onclick="showprofile(this.id)">${SearchUser.data().userName}</a> </th>
          <th>${SearchUser.data().userType}</th>
          <th>${SearchUser.data().village}</th>
          <th>${SearchUser.data().tahsil}</th>
          <th>${SearchUser.data().district}</th>
          <th>${SearchUser.data().userContact}</th>
    
      </tr>`);
       })
      // creatTable(searchData[0])
   })

 
}


function ResetFilterSearch (params) {
  var USERLISTCHILD = document.getElementById("tbody_filter");
  if(document.getElementById('MyFilterSearch').value == ""){
    while( USERLISTCHILD.childElementCount !== 0){
      USERLISTCHILD.firstChild.remove();
     }
     ApplyFilter();
  }

}


function ResetFilter(params) {


  document.querySelector('#ResetFilterInModal').style.display = "none"

  document.getElementById("WithoutFilter").style.display = "";
  document.getElementById("WithFilter").style.display = "none";
  document.getElementById("WithFilter_pikar").style.display = "none";

  document.getElementById("Category_Checked").style.display = "none";
  document.getElementById("Village_Checked_P").style.display = "none";
  document.getElementById("Taluka_Checked_P").style.display = "none";
  document.getElementById("District_Checked_P").style.display = "none";
  document.getElementById("Crop_Checked").style.display = "none";
  document.getElementById("Profession_Checked_p").style.display = "none";

  document.getElementById("Village_Checked").style.display = "none";
  document.getElementById("Taluka_Checked").style.display = "none";
  document.getElementById("District_Checked").style.display = "none";

  document.getElementById("previous").disabled = "false";
  document.getElementById("next").disabled = "false";



    while(document.getElementById("tbody").childElementCount!==0){
            document.getElementById("tbody").firstChild.remove();
    }
  
     Selected_Data= undefined
     Selected_Vibhag= undefined
     Selected_District= undefined
     Selected_Taluka= undefined
     Selected_Village= undefined
     Selected_Category
     Selected_Crop= undefined
     Date_Selected_From = undefined
     Date_Selected_To = undefined
 
    
    
     VibhagSlected= undefined
     DistrictFilterSelected= undefined
     TalukaFilterSelected= undefined
     VillageFilterSlected= undefined
     MainCategorySelected= undefined
     CropSelected= undefined
  
  
  $('#dropdown_coins').text('विभाग')
  $('#District_Drop_Down').text('जिल्हा')
  $('#Tahasil').text('तालुका')
  $('#village').text('गाव')
  
  lastUser = "";
  data = [];
  index = 0;
  UserList = [];
  index1= 0;
  paginationindex = 0;
  CurrentPage = 0;
  console.log("Inside function  data Puting",UserList);
  
  
  first = firestore.collection("Userinfo").orderBy("date","desc").limit(10).get().then((querySnapshot) => {

    lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

    querySnapshot.forEach((doc) => {
   // console.log(doc.data().userName); 
   data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

    

      // doc.data() is never undefined for query doc snapshots
      $("#tbody").append(`<tr>
      <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
      <th>${doc.data().userName}</th>
      <th>${doc.data().userType}</th>
      <th>${doc.data().district}</th>
      <th>${doc.data().tahsil}</th>
      <th>${doc.data().village}</th>
      <th>${doc.data().userContact}</th>

      </tr>`);
      document.getElementById("NoProduct").style.display = "none"
      document.getElementById("UserListTable").style.display = ""
  

   });
  


}).then(()=>{
  UserList[index1++] = data;
  paginationindex++;
  CurrentPage++;
  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
  console.log("Data Puted Sucessfully",UserList);
})

}


function Get_Main_Category() {



   docRef = firestore.collection("ShetiPik").get().then((querySnapshot) => {
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots

          CropCategory_list[CropCategory_list_index++] = doc.data().mainCatName;

      });
    }).then(()=>{

      console.log("Village Karyalay",Village_List)
      buildDropDown_Main_cat(CropCategory_list);
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

Get_Main_Category();

function Get_Pika_Sub_Category(params,flag) {

  Get_UserDoc_For_Main_cat = [];
  Get_UserDoc_For_Main_cat_index = 0 ; 
  Filtered_User_Data = [] ;
  Filtered_User_Data_index = 0;


  UserList = [];
  Special_Index = 0;

console.log("Pagination_Filter_Flag",WhichFilterSelected===undefined)


  Selected_pika_Db_Reffrence = 'cropMainCat';
    CurrentSelectedFilter = flag;
    // Selected_Main_Category_Title = params
    getpika(params);

    // where(`${WhichFilterSelected}`,"==",Selected_District)
    // where("cropMainCat","==",params)
    if(WhichFilterSelected!==undefined){

      firestore.collection("Sheti").where(WhichFilterSelected,"==",Selected_District).where("cropMainCat","==",params).orderBy("userId").limit(10).get().then((querySnapshot) => {
        lastUser_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
          console.log("UserData",doc.data());
          Get_UserDoc_For_Main_cat[Get_UserDoc_For_Main_cat_index++] = [doc.data().userId,doc.data().cropMainCat,doc.data().crop]
       
      })
  }).then(()=>{
  
    // ForProcessing = [...new Set(Get_UserDoc_For_Main_cat)]
  
    Get_UserDoc_For_Main_cat.forEach(element => {
  
      console.log("element",element[0])
      
      firestore.collection("Userinfo").where("userID","==",element[0]).orderBy("date","desc").get().then((querySnapshot) => {
   
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
  
            Filtered_User_Data[Filtered_User_Data_index++] = [`${doc.id}`,`${doc.data().userName}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,element[0],element[1],element[2]]
  
        })
      })
    });
  
  }).then(()=>{
  
            console.log("Vivek Dhande :   ",Filtered_User_Data)
            UserList[Special_Index++] = Filtered_User_Data;
            Filtered_User_Data.forEach(element => {
              console.log("Filtered_Data",element)
            });
  })
      
    }
    else{
      firestore.collection("Sheti").where("cropMainCat","==",params).orderBy("userId").limit(10).get().then((querySnapshot) => {
        lastUser_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
  
          Get_UserDoc_For_Main_cat[Get_UserDoc_For_Main_cat_index++] = [doc.data().userId,doc.data().cropMainCat,doc.data().crop]
       
      })
  }).then(()=>{
  
    // ForProcessing = [...new Set(Get_UserDoc_For_Main_cat)]
  
    Get_UserDoc_For_Main_cat.forEach(element => {
  
      console.log("element",element[0])
      
      firestore.collection("Userinfo").where("userID","==",element[0]).orderBy("date","desc").get().then((querySnapshot) => {
   
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
  
            Filtered_User_Data[Filtered_User_Data_index++] = [`${doc.id}`,`${doc.data().userName}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,element[0],element[1],element[2]]
  
        })
      })
    });
  
  }).then(()=>{
  
            console.log("Vivek Dhande :   ",Filtered_User_Data)
            UserList[Special_Index++] = Filtered_User_Data;
            Filtered_User_Data.forEach(element => {
              console.log("Filtered_Data",element)
            });
  })

  }

}

function getpika (params) {


   pik_child = document.getElementById("menuItems-pika");

  pika_list = [];
  pika_list_index = 0;

  var docRef = firestore.collection("ShetiPik").where("mainCatName","==", params).get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        Selected_Main_Category_Doc = doc.id
        //  console.log("Vivek Dhande",  doc.data())
      

    });
  }).then(()=>{
  // console.log("Village Karyalay",Village_List)
  // var docRef = firestore.collection("ShetiPik").doc(Selected_Main_Category_Doc).get().then((querySnapshot) => {
  //   querySnapshot.forEach((e) => {
  //       // doc.data() is never undefined for query doc snapshots

  //       console.log("Vivek Dhande",  e.data())
        
  //       //pika_list[pika_list_index++] = doc.data().mainCatName;

  //   })
  // })

  var docRef = firestore.collection("ShetiPik").doc(Selected_Main_Category_Doc).collection("SubCat")

      docRef.get().then((querySnapshot) => {
          
        querySnapshot.forEach(element => {
          
          pika_list[pika_list_index++] = element.data().pikName;
     //     console.log("Pika Data",element.data().pikName) 
        });
      }).then(()=>{
        while(pik_child.childElementCount!==0){
          pik_child.firstChild.remove();
        }
        console.log("Pika Data",pika_list); 
        buildDropDown_pika(pika_list);

      }).catch((error) => {
          console.log("Error getting document:", error);
      });

     
  }).catch((error) => {
      console.log("Error getting document:", error);
  });
  
}

function DistrictFilter(params,params2,params3,params4,params5,params6) {

  Onlycat_Crop_Last = ""
  lastUser = "";
  toalLandSum = 0;
  ExportDataList = [];
  exportIndex = 0;
  document.getElementById("WithoutFilter").style.display = "none";
  // document.getElementById("WithFilter").style.display = ""; 

  document.getElementById("WithFilter").style.display = "none";
  document.getElementById("WithFilter_pikar").style.display = "";  

  Pagination_Filter_Flag = params;
  Pagination_Filter_Value =params2;

  Pagination_Filter_Both = params3;
  Pagination_Filter_Both_Value = params4

  Profession_Filter_Type = params5
  Profession_Filter = params6 ;


  
  data = [];
  UserList = [];
  index1 = 0;
  index = 0;
  CurrentPage=0;
  paginationindex=0;
  while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
  }

          // console.log("params",params);
          // console.log("params2",params2);
          // console.log("params3",params3);
          // console.log("params4",params4);
          // console.log("params4",params5);
          // console.log("params4",params6);




          if(params5 !== undefined && params6 !== undefined && UserTypeFilter == undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

            //alert("In Proffesion Filter")
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

              if(UserTypeFilter == undefined){
                firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                  lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                  querySnapshot.forEach((doc) => {

                console.log(doc.data().daa); 
                // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter_Pika").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                      
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""

                          
                  })

                })
        
                });

              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })

              firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              
                querySnapshot.forEach((doc) => {

        
              // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                querySnapshot.forEach((docI)=>{
                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                })

              })
      
              });

              })

              }else{
                  
                  if(params3 == "village"){

                  
                    firestore.collection("Sheti").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(2).get().then((querySnapshot) => {

                      lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                      querySnapshot.forEach((doc) => {

                    console.log(doc.data().daa); 
                    // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                    firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                      querySnapshot.forEach((docI)=>{
                        // data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
                        data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                                // doc.data() is never undefined for query doc snapshots
                                $("#tbody_filter_Pika").append(`<tr>
                                <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                               
                                <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                            </tr>`);
                                document.getElementById("NoProduct").style.display = "none"
                                // document.getElementById("UserListTable").style.display = ""

                              
                      })

                      })
                    });

                  }).then(()=>{
                    UserList[index1++] = data;
                    paginationindex++;
                    CurrentPage++;
                    console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                    console.log("Data Puted Sucessfully",UserList);
                  })

                  firestore.collection("Sheti").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                  
                    querySnapshot.forEach((doc) => {

            
                  // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((docI)=>{
                      ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                    })

                  })
          
                  });

                  })

                  }else{
                    firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(2).get().then((querySnapshot) => {

                      lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                      querySnapshot.forEach((doc) => {

                    console.log(doc.data().daa); 
                    // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                    firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                      querySnapshot.forEach((docI)=>{
                        // data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
                        data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                                // doc.data() is never undefined for query doc snapshots
                                $("#tbody_filter_Pika").append(`<tr>
                                <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                            </tr>`);
                                document.getElementById("NoProduct").style.display = "none"
                                // document.getElementById("UserListTable").style.display = ""

                              
                      })

                    })
            
                    });

                  }).then(()=>{
                    UserList[index1++] = data;
                    paginationindex++;
                    CurrentPage++;
                    console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                    console.log("Data Puted Sucessfully",UserList);
                  })

                  firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                  
                    querySnapshot.forEach((doc) => {

            
                  // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((docI)=>{
                      ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                    })

                  })
          
                  });

                  })

                  }
                
              }
          

          }else if(params5 !== undefined && params6 !== undefined && UserTypeFilter !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

            alert("In Proffesion Filter Pro max")
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

              if(UserTypeFilter == undefined){
                firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                  lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                  querySnapshot.forEach((doc) => {

                console.log(doc.data().daa); 
                // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter_Pika").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                      
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""

                          
                  })

                })
        
                });

              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })

              firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              
                querySnapshot.forEach((doc) => {

        
              // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                querySnapshot.forEach((docI)=>{
                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                })

              })
      
              });

              })

              }else{
                  
                  if(params3 == "village"){

                  
                    firestore.collection("Sheti").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(2).get().then((querySnapshot) => {

                      lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                      querySnapshot.forEach((doc) => {

                    console.log(doc.data().daa); 
                    // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                    firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                      querySnapshot.forEach((docI)=>{
                        // data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
                        data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                                // doc.data() is never undefined for query doc snapshots
                                $("#tbody_filter_Pika").append(`<tr>
                                <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                               
                                <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                            </tr>`);
                                document.getElementById("NoProduct").style.display = "none"
                                // document.getElementById("UserListTable").style.display = ""

                              
                      })

                      })
                    });

                  }).then(()=>{
                    UserList[index1++] = data;
                    paginationindex++;
                    CurrentPage++;
                    console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                    console.log("Data Puted Sucessfully",UserList);
                  })

                  firestore.collection("Sheti").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                  
                    querySnapshot.forEach((doc) => {

            
                  // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((docI)=>{
                      ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                    })

                  })
          
                  });

                  })

                  }else{
                    firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(2).get().then((querySnapshot) => {

                      lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                      querySnapshot.forEach((doc) => {

                    console.log(doc.data().daa); 
                    // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                    firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                      querySnapshot.forEach((docI)=>{
                        // data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
                        data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                                // doc.data() is never undefined for query doc snapshots
                                $("#tbody_filter_Pika").append(`<tr>
                                <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                            </tr>`);
                                document.getElementById("NoProduct").style.display = "none"
                                // document.getElementById("UserListTable").style.display = ""

                              
                      })

                    })
            
                    });

                  }).then(()=>{
                    UserList[index1++] = data;
                    paginationindex++;
                    CurrentPage++;
                    console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                    console.log("Data Puted Sucessfully",UserList);
                  })

                  firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                  
                    querySnapshot.forEach((doc) => {

            
                  // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((docI)=>{
                      ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                    })

                  })
          
                  });

                  })

                  }
                
              }
          

          }else if(UserTypeFilter == undefined && params5 !== undefined && params6 !== undefined && MainCategorySelected == undefined && CropSelected == undefined &&  (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){

            alert("In Proffesion Filter with Date")

            
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }


            firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {

            console.log(doc.data().daa); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{
                data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                         // doc.data() is never undefined for query doc snapshots
                         $("#tbody_filter_Pika").append(`<tr>
                         <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                         <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                         <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                        
                         <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                     </tr>`);
                         document.getElementById("NoProduct").style.display = "none"
                         // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

               
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })

          firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

            querySnapshot.forEach((doc) => {

          firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{

                ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
                      
              })
                
            })
          });
          


          })

          }else if(UserTypeFilter == undefined && params5 !== undefined && params6 !== undefined && (MainCategorySelected !== undefined || CropSelected !== undefined) &&  (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){

            //alert("In Proffesion Filter with Date AND cAT cROP")
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

      
            firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).where(`${UserTypeFilter}`,"==",Selected_UserType).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              
              querySnapshot.forEach((doc) => {

        
            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{
                ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

              })

            })

            });

          })


          }else if(UserTypeFilter !== undefined && params5 !== undefined && params6 !== undefined && (MainCategorySelected == undefined && CropSelected == undefined) &&  (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){

            console.log(params)
            console.log(params2)
            console.log(params3)
            console.log(params4)
            console.log(Selected_UserType)

          alert("In District Date")
             document.getElementById("WithFilter").style.display = "";
             document.getElementById("WithoutFilter").style.display = "none";
             document.getElementById("WithFilter_pikar").style.display = "none";  
             
             document.querySelector('#next_withFilter').disabled = false;
            if(params3 == "village"){
              first = firestore.collection("Userinfo").where("tahsil","==",Selected_Taluka).where("userType","==",Selected_UserType).where(`${params3}`,"==",params4).where("date",">=",params).where("date","<=",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
                  
    
                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
  
                querySnapshot.forEach((doc) => {
                console.log()
              // console.log(doc.data().userName); 
              data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
  
              
  
                  // doc.data() is never undefined for query doc snapshots
                  $("#tbody_filter").append(`<tr>
                  <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                  <th>${doc.data().userName}</th>
                  <th>${doc.data().userType}</th>
                  <th>${doc.data().district}</th>
                  <th>${doc.data().tahsil}</th>
                  <th>${doc.data().village}</th>
                  <th>${doc.data().userContact}</th>
              </tr>`);
                  document.getElementById("NoProduct").style.display = "none"
                  // document.getElementById("UserListTable").style.display = ""
              
              });
              
  
  
              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              }) 

            }else{
              first = firestore.collection("Userinfo").where("userType","==",Selected_UserType).where(`${params3}`,"==",params4).where("date",">=",params).where("date","<=",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
                  
    
                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
  
                querySnapshot.forEach((doc) => {
                console.log()
              // console.log(doc.data().userName); 
              data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
  
              
  
                  // doc.data() is never undefined for query doc snapshots
                  $("#tbody_filter").append(`<tr>
                  <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                  <th>${doc.data().userName}</th>
                  <th>${doc.data().userType}</th>
                  <th>${doc.data().district}</th>
                  <th>${doc.data().tahsil}</th>
                  <th>${doc.data().village}</th>
                  <th>${doc.data().userContact}</th>
              </tr>`);
                  document.getElementById("NoProduct").style.display = "none"
                  // document.getElementById("UserListTable").style.display = ""
              
              });
              
  
  
              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              }) 
            }
                

          }else if(UserTypeFilter !== undefined && params5 !== undefined && params6 !== undefined && (MainCategorySelected !== undefined || CropSelected !== undefined) &&  (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
            console.log("params",params);
            console.log("params2",params2);
            console.log("params3",params3);
            console.log("params4",params4);
            console.log("params5",params5);
            console.log("params6",params6);
            console.log("params6",Selected_Taluka);
            alert("In Proffesion Filter with Date AND cAT cROP")
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

            if(params3 == "village"){
              alert("Rucha")
              firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
  
                  querySnapshot.forEach((doc) => {
                // console.log(doc.data().userName); 
                // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${UserTypeFilter}`,"==",Selected_UserType).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter_Pika").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""
                })
              })
           });
                
  
  
              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })
  
        
              firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                
                querySnapshot.forEach((doc) => {
  
          
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${UserTypeFilter}`,"==",Selected_UserType).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                querySnapshot.forEach((docI)=>{
                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                })
  
              })
  
              });
  
              })
            }else{
              firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
  
                  querySnapshot.forEach((doc) => {
                // console.log(doc.data().userName); 
                // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${UserTypeFilter}`,"==",Selected_UserType).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter_Pika").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""
                })
              })
           });
                
  
  
              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })
  
        
                firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    
                  
                  querySnapshot.forEach((doc) => {
    
            
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${UserTypeFilter}`,"==",Selected_UserType).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    
                  querySnapshot.forEach((docI)=>{
                    ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
    
                  })
    
                })
    
                });
    
              })
            }
          

          }
          else if( UserTypeFilter == undefined && params3 !== undefined && params4 !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

             alert("Testing 2 Paramestes for Proffesion")

             console.log(params3,params4,UserTypeFilter)
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }

            if(params3 == "village" && UserTypeFilter == undefined){

              alert("crop - viilage")
                firestore.collection("Sheti").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                    querySnapshot.forEach((doc) => {
                  // console.log(doc.data().userName); 
                  // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((docI)=>{
                      data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                              // doc.data() is never undefined for query doc snapshots
                              $("#tbody_filter_Pika").append(`<tr>
                              <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                          </tr>`);
                              document.getElementById("NoProduct").style.display = "none"
                              // document.getElementById("UserListTable").style.display = ""

                            
                    })

                  })

                    
                  
                  });
                  


                }).then(()=>{
                  UserList[index1++] = data;
                  paginationindex++;
                  CurrentPage++;
                  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                  console.log("Data Puted Sucessfully",UserList);
                })

                firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((doc) => {
              
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((docI)=>{

                      ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                    })
                  })
                  });

                })


            }else if(params!=="cropMainCat" && params!=="crop" && UserTypeFilter == "userType" ){
                document.getElementById("WithFilter").style.display = ""
                document.getElementById("WithoutFilter").style.display = "none";
                document.getElementById("WithFilter_pikar").style.display = "none";  

                firestore.collection("Userinfo").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
                  lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${docI.data().crop}`,`${docI.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
                  
                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""
  
                          
                  })
  
                }).then(()=>{
                  UserList[index1++] = data;
                  paginationindex++;
                  CurrentPage++;
                  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                  console.log("Data Puted Sucessfully",UserList);
                })

               
            }else{

                firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                    querySnapshot.forEach((doc) => {
                  // console.log(doc.data().userName); 
                  // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((docI)=>{
                      data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                              // doc.data() is never undefined for query doc snapshots
                              $("#tbody_filter_Pika").append(`<tr>
                              <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                          </tr>`);
                              document.getElementById("NoProduct").style.display = "none"
                              // document.getElementById("UserListTable").style.display = ""

                            
                    })

                  })

                  });
                }).then(()=>{
                  UserList[index1++] = data;
                  paginationindex++;
                  CurrentPage++;
                  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                  console.log("Data Puted Sucessfully",UserList);
                })

                  firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((doc) => {
              
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                    querySnapshot.forEach((docI)=>{

                      ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                    })
                  })
                  });

                })

            }



              //   firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              //     lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              //     querySnapshot.forEach((doc) => {
              //   // console.log(doc.data().userName); 
              //   // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              //   firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              //     querySnapshot.forEach((docI)=>{
              //       data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

              //               // doc.data() is never undefined for query doc snapshots
              //               $("#tbody_filter_Pika").append(`<tr>
              //               <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
              //               <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
              //               <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
              //               <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
              //               <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
              //               <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
              //               <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
              //               <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
              //               <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
              //           </tr>`);
              //               document.getElementById("NoProduct").style.display = "none"
              //               // document.getElementById("UserListTable").style.display = ""

                          
              //     })

              //   })

                  
                
              //   });
                


              // }).then(()=>{
              //   UserList[index1++] = data;
              //   paginationindex++;
              //   CurrentPage++;
              //   console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
              //   console.log("Data Puted Sucessfully",UserList);
              // })

              //   firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              //     querySnapshot.forEach((doc) => {
            
              //   firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              //     querySnapshot.forEach((docI)=>{

              //       ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

              //     })
              //   })
              //   });

              // })


          }else if( UserTypeFilter !== undefined && params3 !== undefined && params4 !== undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){

            alert("Here")
          if((DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined) && (MainCategorySelected !== undefined || CropSelected !== undefined )){
                    //alert("Testing 2 Paramestes for Proffesion with Date")
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

            firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
            // console.log(doc.data().userName); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${UserTypeFilter}`,'==',Selected_UserType).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{
                data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                        // doc.data() is never undefined for query doc snapshots
                        $("#tbody_filter_Pika").append(`<tr>
                        <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                        <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                        <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
  
                        <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                    </tr>`);
                        document.getElementById("NoProduct").style.display = "none"
                        // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

              
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })

          firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).where(`${params5}`,"==",params6).where(`${UserTypeFilter}`,'==',Selected_UserType).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

        

            querySnapshot.forEach((doc) => {
          // console.log(doc.data().userName); 
          // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

          firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

            querySnapshot.forEach((docI)=>{
              ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

            })

          })

            
          
          });


        })


          }else if((DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined) && (MainCategorySelected == undefined && CropSelected == undefined )){
            alert("Testing 2 Paramestes for Proffesion with Date")

            document.getElementById("WithoutFilter").style.display = "none";
            // document.getElementById("WithFilter").style.display = ""; 
          
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithFilter_pikar").style.display = "none"; 
              document.querySelector('#next_Main_cat').disabled = false;


              while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
              }

              firestore.collection("Userinfo").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${docI.data().cropMainCat}`,`${docI.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
  
                        
                })
  
              })
              .then(()=>{
              UserList[index1++] = data;
              paginationindex++;
              CurrentPage++;
              console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
              console.log("Data Puted Sucessfully",UserList);
              })

              firestore.collection("Userinfo").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                querySnapshot.forEach((docI)=>{
                  ExportDataList[exportIndex++] = [`${docI.id}`,`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${docI.data().cropMainCat}`,`${docI.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
  
                        
                })
  
              })
             

          }else if((DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined) && (MainCategorySelected == undefined || CropSelected == undefined )){
                          //alert("Testing 2 Paramestes for Proffesion with Date")
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

            firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
            // console.log(doc.data().userName); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{
                data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                        // doc.data() is never undefined for query doc snapshots
                        $("#tbody_filter_Pika").append(`<tr>
                        <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                        <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                        <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                        <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                    </tr>`);
                        document.getElementById("NoProduct").style.display = "none"
                        // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

              
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })

          firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

            querySnapshot.forEach((doc) => {
          // console.log(doc.data().userName); 
          // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

          firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

            querySnapshot.forEach((docI)=>{
              ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]


            })

          })

            
          
          });
          


        })

          }
      
          }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined) && (MainCategorySelected !== undefined ) && (Date_Selected_From == undefined && Date_Selected_To == undefined ) ){
            document.getElementById("WithFilter").style.display = "none";
            document.getElementById("WithFilter_pikar").style.display = "";   
            document.querySelector('#next_Main_cat').disabled = false;
            // //alert("In Special Case");

            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

            firestore.collection("Sheti").where(`${params}`,"==",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              Onlycat_Crop_Last = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
       

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{
                data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${doc.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                         // doc.data() is never undefined for query doc snapshots
                         $("#tbody_filter_Pika").append(`<tr>
                         <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                         <th><a id ="${docI.id}" >${doc.data().userType}</a> </th>
                         <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                         <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                     </tr>`);
                         document.getElementById("NoProduct").style.display = "none"
                         // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

               
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })
           
          }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected === undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
           
          alert("In Date")
            document.getElementById("WithFilter_pikar").style.display = "none";   
            document.getElementById("WithFilter").style.display = "none";
            document.getElementById("WithoutFilter").style.display = "";   
            
            document.querySelector('#next_Main_cat').disabled = false;
            // //alert("In Special Case");

            while(document.getElementById("tbody").childElementCount!==0){
              document.getElementById("tbody").firstChild.remove();
            }

      
       

            firestore.collection("Userinfo").where("date",">=",params).where("date","<=",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
              DateFilterLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((docI)=>{
                console.log("Date",docI.data())
                data[index++] = [`${docI.id}`,`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                         // doc.data() is never undefined for query doc snapshots
                         $("#tbody").append(`<tr>
                         <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                     </tr>`);
                         document.getElementById("NoProduct").style.display = "none"
                         // document.getElementById("UserListTable").style.display = ""

                      
              })

            }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })
           
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
             
          //  //alert("In District Date")
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";
            document.getElementById("WithFilter_pikar").style.display = "none";  
            
            document.querySelector('#next_withFilter').disabled = false;

            first = firestore.collection("Userinfo").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
              

              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
              console.log()
            // console.log(doc.data().userName); 
            data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

            

                // doc.data() is never undefined for query doc snapshots
                $("#tbody_filter").append(`<tr>
                <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                <th>${doc.data().userName}</th>
                <th>${doc.data().userType}</th>
                <th>${doc.data().district}</th>
                <th>${doc.data().tahsil}</th>
                <th>${doc.data().village}</th>
                <th>${doc.data().userContact}</th>
            </tr>`);
                document.getElementById("NoProduct").style.display = "none"
                // document.getElementById("UserListTable").style.display = ""
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })    
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined &&  MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
             
         //   //alert("In Taluka Date")
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";
            document.getElementById("WithFilter_pikar").style.display = "none";  
            
            document.querySelector('#next_withFilter').disabled = false;

            first = firestore.collection("Userinfo").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
              

              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
              console.log()
            // console.log(doc.data().userName); 
            data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

            

                // doc.data() is never undefined for query doc snapshots
                $("#tbody_filter").append(`<tr>
                <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                <th>${doc.data().userName}</th>
                <th>${doc.data().userType}</th>
                <th>${doc.data().district}</th>
                <th>${doc.data().tahsil}</th>
                <th>${doc.data().village}</th>
                <th>${doc.data().userContact}</th>
            </tr>`);
                document.getElementById("NoProduct").style.display = "none"
                // document.getElementById("UserListTable").style.display = ""
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })    
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined &&  MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
             
          alert("In Village Date")
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";
            document.getElementById("WithFilter_pikar").style.display = "none";  
            
            document.querySelector('#next_withFilter').disabled = false;

            if(params == "village"){

              // alert("Vivek Dhande")
                    first = firestore.collection("Userinfo").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
                  

                  lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                  querySnapshot.forEach((doc) => {
                
                // console.log(doc.data().userName); 
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

                

                    // doc.data() is never undefined for query doc snapshots
                    $("#tbody_filter").append(`<tr>
                    <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                    <th>${doc.data().userName}</th>
                    <th>${doc.data().userType}</th>
                    <th>${doc.data().district}</th>
                    <th>${doc.data().tahsil}</th>
                    <th>${doc.data().village}</th>
                    <th>${doc.data().userContact}</th>
                </tr>`);
                    document.getElementById("NoProduct").style.display = "none"
                    // document.getElementById("UserListTable").style.display = ""
                
                });
                


              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })

            }else{
                    first = firestore.collection("Userinfo").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
                  

                  lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                  querySnapshot.forEach((doc) => {
                
                // console.log(doc.data().userName); 
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

                

                    // doc.data() is never undefined for query doc snapshots
                    $("#tbody_filter").append(`<tr>
                    <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                    <th>${doc.data().userName}</th>
                    <th>${doc.data().userType}</th>
                    <th>${doc.data().district}</th>
                    <th>${doc.data().tahsil}</th>
                    <th>${doc.data().village}</th>
                    <th>${doc.data().userContact}</th>
                </tr>`);
                    document.getElementById("NoProduct").style.display = "none"
                    // document.getElementById("UserListTable").style.display = ""
                
                });
                


              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })

            }

                  


          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
         //  //alert("In Special Filter")
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];

                querySnapshot.forEach((doc) => {
              // console.log(doc.data().userName); 
              // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
          
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""

                        
                })

              })

                
              
              });
              


            }).then(()=>{
              UserList[index1++] = data;
              paginationindex++;
              CurrentPage++;
              console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
              console.log("Data Puted Sucessfully",UserList);
            })
          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
          //  //alert("In Taluka Filter")
             document.querySelector('#next_Main_cat').disabled = false;
           
             
             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
         //   //alert("In Village Filter")
             document.querySelector('#next_Main_cat').disabled = false;
           
             
             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
            if(params == "village"){
               alert("In Village Filter with maincat")
                firestore.collection("Sheti").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                    lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
      
                    querySnapshot.forEach((doc) => {
                  // console.log(doc.data().userName); 
                  // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
      
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                    querySnapshot.forEach((docI)=>{
                      data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                                // doc.data() is never undefined for query doc snapshots
                                $("#tbody_filter_Pika").append(`<tr>
                                <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                            </tr>`);
                                document.getElementById("NoProduct").style.display = "none"
                                // document.getElementById("UserListTable").style.display = ""
      
                            
                    })
      
                  })
      
                      
                  
                  });
                  
      
      
                }).then(()=>{
                  UserList[index1++] = data;
                  paginationindex++;
                  CurrentPage++;
                  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                  console.log("Data Puted Sucessfully",UserList);
                })

            }else{

                  firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                    lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
      
                    querySnapshot.forEach((doc) => {
                  // console.log(doc.data().userName); 
                  // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
      
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                    querySnapshot.forEach((docI)=>{
                      data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                                // doc.data() is never undefined for query doc snapshots
                                $("#tbody_filter_Pika").append(`<tr>
                                <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                                <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                                <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                            </tr>`);
                                document.getElementById("NoProduct").style.display = "none"
                                // document.getElementById("UserListTable").style.display = ""
      
                            
                    })
      
                  })
      
                      
                  
                  });
                  
      
      
                }).then(()=>{
                  UserList[index1++] = data;
                  paginationindex++;
                  CurrentPage++;
                  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                  console.log("Data Puted Sucessfully",UserList);
                })
              
            }
                    
          }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
            
           // //alert("In Only Main-Cat Date")
             document.querySelector('#next_Main_cat').disabled = false;
           
             
             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
         //   //alert("In Only Crop Date")
             document.querySelector('#next_Main_cat').disabled = false;
           
             
             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
                lastUser_Date_with_Crop = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
        //    //alert("District - Crop  - Date")
             document.querySelector('#next_Main_cat').disabled = false;

             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
                lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
         
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
        //    //alert("Taluka - Crop  - Date")
             document.querySelector('#next_Main_cat').disabled = false;

             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
                lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
               
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
         //   //alert("Village - Crop  - Date")
             document.querySelector('#next_Main_cat').disabled = false;

             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
                lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                     
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          
          }
          else{
          alert("In Else")
   
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";
            document.getElementById("WithFilter_pikar").style.display = "none";  
            
            document.querySelector('#next_withFilter').disabled = false;

            if(params == 'village'){
                console.log("Selected Taluka",Selected_Taluka);
                 
                first = firestore.collection("Userinfo").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
                      

                      lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                      querySnapshot.forEach((doc) => {
                    // console.log(doc.data().userName); 
                    data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

                    

                        // doc.data() is never undefined for query doc snapshots
                        $("#tbody_filter").append(`<tr>
                        <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                        <th>${doc.data().userName}</th>
                        <th>${doc.data().userType}</th>
                        <th>${doc.data().district}</th>
                        <th>${doc.data().tahsil}</th>
                        <th>${doc.data().village}</th>
                        <th>${doc.data().userContact}</th>
                    </tr>`);
                        document.getElementById("NoProduct").style.display = "none"
                        // document.getElementById("UserListTable").style.display = ""
                    
                    });
                    


                  }).then(()=>{
                    UserList[index1++] = data;
                    paginationindex++;
                    CurrentPage++;
                    console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                    console.log("Data Puted Sucessfully",UserList);
                  })

            }else{
                  first = firestore.collection("Userinfo").where(`${params}`,"==",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
                    

                    lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

                    querySnapshot.forEach((doc) => {
                  // console.log(doc.data().userName); 
                  data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

                  

                      // doc.data() is never undefined for query doc snapshots
                      $("#tbody_filter").append(`<tr>
                      <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                      <th>${doc.data().userName}</th>
                      <th>${doc.data().userType}</th>
                      <th>${doc.data().district}</th>
                      <th>${doc.data().tahsil}</th>
                      <th>${doc.data().village}</th>
                      <th>${doc.data().userContact}</th>
                  </tr>`);
                      document.getElementById("NoProduct").style.display = "none"
                      // document.getElementById("UserListTable").style.display = ""
                  
                  });
                  


                }).then(()=>{
                  UserList[index1++] = data;
                  paginationindex++;
                  CurrentPage++;
                  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                  console.log("Data Puted Sucessfully",UserList);
                })
            }
                  

          }

          // Create Report 
         
          if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && Date_Selected_From == undefined && Date_Selected_To ==  undefined) || (DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From == undefined && Date_Selected_To ==  undefined)){
 
            firestore.collection("Sheti").where(`${params}`,"==",params2).orderBy("date","desc").get().then((querySnapshot) => {

              // lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
             console.log("Special Case :-",doc.data().userName); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{
                
                ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${doc.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
             

             
              })

            })
    
            
            });
            


          }).then(()=>{
   
          })

          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){

            first = firestore.collection("Userinfo").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").get().then((querySnapshot) => {

              querySnapshot.forEach((doc) => {
       
            ExportDataList[exportIndex++] =  [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName.replace(/[\n\r]/g,' ')}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
        
            });

          })   
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined &&  MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
             
          
            first = firestore.collection("Userinfo").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").get().then((querySnapshot) => {

              querySnapshot.forEach((doc) => {
             
            // console.log(doc.data().userName); 
            ExportDataList[exportIndex++] =  [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName.replace(/[\n\r]/g,' ')}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`]

            });

          })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined &&  MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
             
            console.log("params",params);
            console.log("params",params2);
            console.log("params",params3);
            console.log("params",params4);
         
              if(params == "village"){
                    alert("vivek Dhande 2")
                    first = firestore.collection("Userinfo").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").get().then((querySnapshot) => {

                      querySnapshot.forEach((doc) => {
                    
                    // console.log(doc.data().userName); 

                    ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName.replace(/[\n\r]/g,' ')}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`]
                    
                    });
                    
                  }) 
              }else{

                  first = firestore.collection("Userinfo").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").get().then((querySnapshot) => {

                      querySnapshot.forEach((doc) => {
                    
                    // console.log(doc.data().userName); 

                    ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName.replace(/[\n\r]/g,' ')}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`]
                    
                    });
                    
                  }) 
                
              }
                  
          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
          
            //alert("Date with Only Main_Cat")
             firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).get().then((querySnapshot) => {

             

              querySnapshot.forEach((doc) => {
        

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{

                ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
              
              })

            })

            });

          })
          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
           
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).get().then((querySnapshot) => {
 
             
 
               querySnapshot.forEach((doc) => {
            
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{

                 ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

               })
 
             })

             });

           })
          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
            
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).get().then((querySnapshot) => {
 
          
               querySnapshot.forEach((doc) => {
            
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
 
                 ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]


               })
 
             })
 
                
             
             });
             
 
 
           })
          }else if((DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected == undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
            
            //alert("In Only Manin Cat weith date");

              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).get().then((querySnapshot) => {
 

 
               querySnapshot.forEach((doc) => {
           
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
             
                 ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

               })
 
             })
 
             });
             
 
 
           })
          }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
         
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").get().then((querySnapshot) => {
 
          
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
             
                 ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
       
               })
 
             })

             });

           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
           
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").get().then((querySnapshot) => {
 
            
 
               querySnapshot.forEach((doc) => {
           
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
 
                 ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
               })
 
             })
 
                
             
             });
             
 
 
           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
            
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").get().then((querySnapshot) => {
 

 
               querySnapshot.forEach((doc) => {
            
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
 
                 ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

               })
 
             })

             });
             
 
 
           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
         
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
 
               querySnapshot.forEach((doc) => {
          
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{

                 ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

               })
 
             })
 
                
             
             });

           })
          }else if(params3 !== undefined && params4 !== undefined){
            //alert("DownLoad Report")

            first = firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").get().then((querySnapshot) => {

              querySnapshot.forEach((doc) => {

             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {

              querySnapshot.forEach((docI) => {

                ExportDataList[exportIndex++] = [`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\n\r]/g,' ')}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
              })
            })
          })

          }).then(()=>{

              console.log("ExportDataList",ExportDataList)
          })

          }else{

           
                if(params=="village"){
                  alert("In village Download")

                        first = firestore.collection("Userinfo").where("tahsil","==",Selected_Taluka).where(`${params}`,"==",params2).orderBy("date","desc").get().then((querySnapshot) => {
                      querySnapshot.forEach((doc) => {
                          // console.log(doc.data().userName); 
                          ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName.replace(/[\n\r]/g,' ')}`,`${doc.data().userType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`,`${doc.data().userContact}`]                 
                        
                        })

                          // firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

                          //   querySnapshot.forEach((userdoc) => {

                          //     ExportDataList[exportIndex++] = [userdoc.data().userName,userdoc.data().userContact,moment(doc.data().date.toDate()).format('DD/MM/YYYY'),doc.data().crop,doc.data().cropMainCat,doc.data().farmArea,doc.data().selectedFarmAreaUnit,doc.data().landType,doc.data().district,doc.data().tahsil,doc.data().village]                  })
                          // })

                    }).then(()=>{
                
                      //console.log("ExportDataList",ExportDataList);
                    })

                }else{

                        first = firestore.collection("Userinfo").where(`${params}`,"==",params2).orderBy("date","desc").get().then((querySnapshot) => {
                      querySnapshot.forEach((doc) => {
                          // console.log(doc.data().userName); 
                          ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName.replace(/[\n\r]/g,' ')}`,`${doc.data().userType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`,`${doc.data().userContact}`]                 
                        
                        })

                          // firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

                          //   querySnapshot.forEach((userdoc) => {

                          //     ExportDataList[exportIndex++] = [userdoc.data().userName,userdoc.data().userContact,moment(doc.data().date.toDate()).format('DD/MM/YYYY'),doc.data().crop,doc.data().cropMainCat,doc.data().farmArea,doc.data().selectedFarmAreaUnit,doc.data().landType,doc.data().district,doc.data().tahsil,doc.data().village]                  })
                          // })

                    }).then(()=>{
                
                      //console.log("ExportDataList",ExportDataList);
                    })
      
                  }
          }          


}


function nextPage_Filter(params) {



  CurrentPage >0 ? document.querySelector('#previous_withFilter').disabled = false : document.querySelector('#previous_withFilter').disabled = true

  if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && Date_Selected_From === undefined && Date_Selected_To === undefined){

    alert("Outer")
    if(UserTypeFilter==undefined){
      if(CurrentPage==paginationindex){
      
        paginationindex++;

        console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
        
        firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
          
            document.querySelector('#next_withFilter').disabled = true
            
            CurrentPage--;
            paginationindex--;
            
            (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""

                        
                })

              })




            
            
            
            })
              
            
          }
        
        
        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_filter_Pika").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
        
        // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>
          <th>${element[8]}</th>
          <th>${element[9]}</th>
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        CurrentPage++;
    }else{
      alert("Inner")
      if(CurrentPage==paginationindex){
      
        paginationindex++;

        console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
        
        firestore.collection("Userinfo").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
   
          if( querySnapshot.docs.length == 0 ){
          
            document.querySelector('#next_withFilter').disabled = true
            
            CurrentPage--;
            paginationindex--;
            
            (swal("There is no Record Found"))

          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((docI) => {

              console.log("docI",docI.data())

                  data[index++] = [`${docI.id}`,`${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(docI.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""

                        
                })

          }
        
        
        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_filter_Pika").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
        
        // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>
 
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        CurrentPage++;
      
      
    }
        
  
  }else if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined){
   
    console.log(Pagination_Filter_Both,Pagination_Filter_Both_Value)
    console.log(Pagination_Filter_Flag,Pagination_Filter_Value)

    if(UserTypeFilter!== undefined){
      if(Pagination_Filter_Both=="village"){
alert("I am Here")
        if(CurrentPage==paginationindex){
              
          paginationindex++;
          
          firestore.collection("Userinfo").where("tahsil","==",Selected_Taluka).where("userType","==",Selected_UserType).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).where("date",">=", Pagination_Filter_Flag).where("date","<=", Pagination_Filter_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
            
              document.querySelector('#next_withFilter').disabled = true
              
              CurrentPage--;
              paginationindex--;
              
              (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter").childElementCount!==0){
                document.getElementById("tbody_filter").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
                //   console.log(doc.data().userName);
                  // doc.data() is never undefined for query doc snapshots
                  data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
          
                  $("#tbody_filter").append(`<tr>
                  <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                  <th>${doc.data().userName}</th>
                  <th>${doc.data().userType}</th>
                  <th>${doc.data().district}</th>
                  <th>${doc.data().tahsil}</th>
                  <th>${doc.data().village}</th>
                  <th>${doc.data().userContact}</th>
              </tr>`);
              document.getElementById("NoProduct").style.display = "none"
                })
                
              
            }
          
          
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
          
          // console.log("demo Array",element)
          
            $("#tbody_filter").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>
      
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          CurrentPage++;

      }else{
        if(CurrentPage==paginationindex){
              
          paginationindex++;
          
          firestore.collection("Userinfo").where("userType","==",Selected_UserType).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).where("date",">=", Pagination_Filter_Flag).where("date","<=", Pagination_Filter_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
            
              document.querySelector('#next_withFilter').disabled = true
              
              CurrentPage--;
              paginationindex--;
              
              (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter").childElementCount!==0){
                document.getElementById("tbody_filter").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
                //   console.log(doc.data().userName);
                  // doc.data() is never undefined for query doc snapshots
                  data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
          
                  $("#tbody_filter").append(`<tr>
                  <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                  <th>${doc.data().userName}</th>
                  <th>${doc.data().userType}</th>
                  <th>${doc.data().district}</th>
                  <th>${doc.data().tahsil}</th>
                  <th>${doc.data().village}</th>
                  <th>${doc.data().userContact}</th>
              </tr>`);
              document.getElementById("NoProduct").style.display = "none"
                })
                
              
            }
          
          
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
          
          // console.log("demo Array",element)
          
            $("#tbody_filter").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>
      
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          CurrentPage++;
      }
  
    }else{
      if(CurrentPage==paginationindex){
              
        paginationindex++;
        
        firestore.collection("Userinfo").where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).where("date",">=", Pagination_Filter_Flag).where("date","<=", Pagination_Filter_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
          
            document.querySelector('#next_withFilter').disabled = true
            
            CurrentPage--;
            paginationindex--;
            
            (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
              //   console.log(doc.data().userName);
                // doc.data() is never undefined for query doc snapshots
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
        
                $("#tbody_filter").append(`<tr>
                <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                <th>${doc.data().userName}</th>
                <th>${doc.data().userType}</th>
                <th>${doc.data().district}</th>
                <th>${doc.data().tahsil}</th>
                <th>${doc.data().village}</th>
                <th>${doc.data().userContact}</th>
            </tr>`);
            document.getElementById("NoProduct").style.display = "none"
              })
              
            
          }
        
        
        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter").childElementCount!==0){
          document.getElementById("tbody_filter").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
        
        // console.log("demo Array",element)
        
          $("#tbody_filter").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>
    
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        CurrentPage++;
    } 
          
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
    alert("Alert2")
    if(CurrentPage==paginationindex){
  
      paginationindex++;
      
      firestore.collection("Userinfo").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
         
          document.querySelector('#next_withFilter').disabled = true
          
           CurrentPage--;
          paginationindex--;
          
           (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          
          data = [];
          index = 0;
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            //   console.log(doc.data().userName);
               // doc.data() is never undefined for query doc snapshots
               data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
      
               $("#tbody_filter").append(`<tr>
               <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
               <th>${doc.data().userName}</th>
               <th>${doc.data().userType}</th>
               <th>${doc.data().district}</th>
               <th>${doc.data().tahsil}</th>
               <th>${doc.data().village}</th>
               <th>${doc.data().userContact}</th>
           </tr>`);
           document.getElementById("NoProduct").style.display = "none"
            })
            
           
        }
      
       
      }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      console.log("Data Puted Sucessfully",UserList);
      })
      
      }
      else{
      while(document.getElementById("tbody_filter").childElementCount!==0){
        document.getElementById("tbody_filter").firstChild.remove();
      }
      UserList[CurrentPage].forEach(element => {
       
       // console.log("demo Array",element)
      
        $("#tbody_filter").append(`<tr>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
      
        </tr>`);
      });
      console.log("Data from local",UserList);
      }
      CurrentPage++;
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
   

    if(CurrentPage==paginationindex){
  
      paginationindex++;
      
      firestore.collection("Userinfo").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
         
          document.querySelector('#next_withFilter').disabled = true
          
           CurrentPage--;
          paginationindex--;
          
           (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          
          data = [];
          index = 0;
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            //   console.log(doc.data().userName);
               // doc.data() is never undefined for query doc snapshots
               data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
      
               $("#tbody_filter").append(`<tr>
               <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
               <th>${doc.data().userName}</th>
               <th>${doc.data().userType}</th>
               <th>${doc.data().district}</th>
               <th>${doc.data().tahsil}</th>
               <th>${doc.data().village}</th>
               <th>${doc.data().userContact}</th>
           </tr>`);
           document.getElementById("NoProduct").style.display = "none"
            })
            
           
        }
      
       
      }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      console.log("Data Puted Sucessfully",UserList);
      })
      
      }
      else{
      while(document.getElementById("tbody_filter").childElementCount!==0){
        document.getElementById("tbody_filter").firstChild.remove();
      }
      UserList[CurrentPage].forEach(element => {
       
       // console.log("demo Array",element)
      
        $("#tbody_filter").append(`<tr>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
      
        </tr>`);
      });
      console.log("Data from local",UserList);
      }
      CurrentPage++;
  }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
   
        if(Pagination_Filter_Flag == "village" ){
          if(CurrentPage==paginationindex){
        
            paginationindex++;
            
            firestore.collection("Userinfo").where("tahsil","==",Selected_Taluka).where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
              console.log("Get New Data");
              if( querySnapshot.docs.length == 0 ){
              
                document.querySelector('#next_withFilter').disabled = true
                
                CurrentPage--;
                paginationindex--;
                
                (swal("There is no Record Found"))
                console.log("At the End",UserList);
              }
              else{
                
                data = [];
                index = 0;
                while(document.getElementById("tbody_filter").childElementCount!==0){
                  document.getElementById("tbody_filter").firstChild.remove();
                }
                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
                querySnapshot.forEach((doc) => {
                  //   console.log(doc.data().userName);
                    // doc.data() is never undefined for query doc snapshots
                    data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
            
                    $("#tbody_filter").append(`<tr>
                    <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                    <th>${doc.data().userName}</th>
                    <th>${doc.data().userType}</th>
                    <th>${doc.data().district}</th>
                    <th>${doc.data().tahsil}</th>
                    <th>${doc.data().village}</th>
                    <th>${doc.data().userContact}</th>
                </tr>`);
                document.getElementById("NoProduct").style.display = "none"
                  })
                  
                
              }
            
            
            }).then(()=>{
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            UserList[index1++] = data;
            console.log("Data Puted Sucessfully",UserList);
            })
            
            }
            else{
            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }
            UserList[CurrentPage].forEach(element => {
            
            // console.log("demo Array",element)
            
              $("#tbody_filter").append(`<tr>
              <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
              <th>${element[2]}</th>
              <th>${element[3]}</th>
              <th>${element[4]}</th>
              <th>${element[5]}</th>
              <th>${element[6]}</th>
              <th>${element[7]}</th>
        
              </tr>`);
            });
            console.log("Data from local",UserList);
            }
            CurrentPage++;

        }else{

          if(CurrentPage==paginationindex){
        
            paginationindex++;
            
            firestore.collection("Userinfo").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
              console.log("Get New Data");
              if( querySnapshot.docs.length == 0 ){
              
                document.querySelector('#next_withFilter').disabled = true
                
                CurrentPage--;
                paginationindex--;
                
                (swal("There is no Record Found"))
                console.log("At the End",UserList);
              }
              else{
                
                data = [];
                index = 0;
                while(document.getElementById("tbody_filter").childElementCount!==0){
                  document.getElementById("tbody_filter").firstChild.remove();
                }
                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
                querySnapshot.forEach((doc) => {
                  //   console.log(doc.data().userName);
                    // doc.data() is never undefined for query doc snapshots
                    data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
            
                    $("#tbody_filter").append(`<tr>
                    <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                    <th>${doc.data().userName}</th>
                    <th>${doc.data().userType}</th>
                    <th>${doc.data().district}</th>
                    <th>${doc.data().tahsil}</th>
                    <th>${doc.data().village}</th>
                    <th>${doc.data().userContact}</th>
                </tr>`);
                document.getElementById("NoProduct").style.display = "none"
                  })
                  
                
              }
            
            
            }).then(()=>{
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            UserList[index1++] = data;
            console.log("Data Puted Sucessfully",UserList);
            })
            
            }
            else{
            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }
            UserList[CurrentPage].forEach(element => {
            
            // console.log("demo Array",element)
            
              $("#tbody_filter").append(`<tr>
              <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
              <th>${element[2]}</th>
              <th>${element[3]}</th>
              <th>${element[4]}</th>
              <th>${element[5]}</th>
              <th>${element[6]}</th>
              <th>${element[7]}</th>
        
              </tr>`);
            });
            console.log("Data from local",UserList);
            }
            CurrentPage++;
        }

          
  }
  else{

    if(Pagination_Filter_Flag == "village"){

      if(CurrentPage==paginationindex){

   paginationindex++;
   
   firestore.collection("Userinfo").where("tahsil","==",Selected_Taluka).where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
     console.log("Get New Data");
     if( querySnapshot.docs.length == 0 ){
      
       document.querySelector('#next_withFilter').disabled = true
       
        CurrentPage--;
       paginationindex--;
       
        (swal("There is no Record Found"))
       console.log("At the End",UserList);
     }
     else{
       
       data = [];
       index = 0;
       while(document.getElementById("tbody_filter").childElementCount!==0){
         document.getElementById("tbody_filter").firstChild.remove();
       }
       lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
       querySnapshot.forEach((doc) => {
         //   console.log(doc.data().userName);
            // doc.data() is never undefined for query doc snapshots
            data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
   
            $("#tbody_filter").append(`<tr>
            <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
            <th>${doc.data().userName}</th>
            <th>${doc.data().userType}</th>
            <th>${doc.data().district}</th>
            <th>${doc.data().tahsil}</th>
            <th>${doc.data().village}</th>
            <th>${doc.data().userContact}</th>
        </tr>`);
        document.getElementById("NoProduct").style.display = "none"
         })
         
        
     }
   
    
   }).then(()=>{
   console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
   UserList[index1++] = data;
   console.log("Data Puted Sucessfully",UserList);
   })
   
   }
   else{
   while(document.getElementById("tbody_filter").childElementCount!==0){
     document.getElementById("tbody_filter").firstChild.remove();
   }
   UserList[CurrentPage].forEach(element => {
    
    // console.log("demo Array",element)
   
     $("#tbody_filter").append(`<tr>
     <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
     <th>${element[2]}</th>
     <th>${element[3]}</th>
     <th>${element[4]}</th>
     <th>${element[5]}</th>
     <th>${element[6]}</th>
     <th>${element[7]}</th>
   
   
     </tr>`);
   });
   console.log("Data from local",UserList);
   }
   CurrentPage++;

    }else{
      alert("Alert3")
    if(CurrentPage==paginationindex){

      paginationindex++;
      
      firestore.collection("Userinfo").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
          
          document.querySelector('#next_withFilter').disabled = true
          
            CurrentPage--;
          paginationindex--;
          
            (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          
          data = [];
          index = 0;
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            //   console.log(doc.data().userName);
                // doc.data() is never undefined for query doc snapshots
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName}`,`${doc.data().userType}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]
      
                $("#tbody_filter").append(`<tr>
                <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                <th>${doc.data().userName}</th>
                <th>${doc.data().userType}</th>
                <th>${doc.data().district}</th>
                <th>${doc.data().tahsil}</th>
                <th>${doc.data().village}</th>
                <th>${doc.data().userContact}</th>
            </tr>`);
            document.getElementById("NoProduct").style.display = "none"
            })
            
            
        }
      
        
      }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      console.log("Data Puted Sucessfully",UserList);
      })
      
      }
      else{
      while(document.getElementById("tbody_filter").childElementCount!==0){
        document.getElementById("tbody_filter").firstChild.remove();
      }
      UserList[CurrentPage].forEach(element => {
        
        // console.log("demo Array",element)
      
        $("#tbody_filter").append(`<tr>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
      
      
        </tr>`);
      });
      console.log("Data from local",UserList);
      }
      CurrentPage++;

    }

  }
  
  
  
  
}
  
  function Previous_Page_filter(params) {
  
  
  document.querySelector('#next_withFilter').disabled = false;
  
  
  CurrentPage--;
  console.log("demo Array",UserList)
  
  if(CurrentPage > 0){
  
  
  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
  while(document.getElementById("tbody_filter").childElementCount!==0){
    document.getElementById("tbody_filter").firstChild.remove();
  }
  
  
    UserList[CurrentPage-1].forEach(element => {
     
      $("#tbody_filter").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
 
      
    
      </tr>`);
    });
     
  }
  else{
  CurrentPage = 1
  document.querySelector('#previous_withFilter').disabled = true;
  
  } 
  
}


function Get_Pika_Sub_Category_Next_Pika(params) {
  document.querySelector('#previous_Main_cat').disabled = false;

console.log("Pagination_Filter_Both",Pagination_Filter_Both);
console.log("Pagination_Filter_Both_Value",Pagination_Filter_Both_Value); 
console.log("Pagination_Filter_Flag",Pagination_Filter_Flag);  
console.log("Pagination_Filter_Value",Pagination_Filter_Value); 


    if(Profession_Filter!== undefined){

      if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && (MainCategorySelected !== undefined || CropSelected !== undefined)  && Date_Selected_From == undefined && Date_Selected_To == undefined ){

      if(Pagination_Filter_Both == "village"){

        if(CurrentPage==paginationindex){
        
          paginationindex++;
      
          // console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
          
          firestore.collection("Sheti").where("tahsil","==",Selected_Taluka).where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
              
              document.querySelector('#next_Main_cat').disabled = true
              
                CurrentPage--;
              paginationindex--;
              
                (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
      
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${Profession_Filter_Type}`,"==",Profession_Filter).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                              // doc.data() is never undefined for query doc snapshots
                              $("#tbody_filter_Pika").append(`<tr>
                              <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>

                              <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                          </tr>`);
                              document.getElementById("NoProduct").style.display = "none"
                              // document.getElementById("UserListTable").style.display = ""
      
                          
                  })
      
                })

              
              })
                
                
            }

          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
            document.getElementById("tbody_filter_Pika").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
            
            // console.log("demo Array",element)
          
            $("#tbody_filter_Pika").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>     
            <th>${element[8]}</th>    
            <th>${element[9]}</th>
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          
          CurrentPage++;

      }else{
        if(CurrentPage==paginationindex){
        
          paginationindex++;
      
          // console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
          
          firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
              
              document.querySelector('#next_Main_cat').disabled = true
              
                CurrentPage--;
              paginationindex--;
              
                (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
      
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(`${Profession_Filter_Type}`,"==",Profession_Filter).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                              // doc.data() is never undefined for query doc snapshots
                              $("#tbody_filter_Pika").append(`<tr>
                              <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                     
                              <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                          </tr>`);
                              document.getElementById("NoProduct").style.display = "none"
                              // document.getElementById("UserListTable").style.display = ""
      
                          
                  })
      
                })

              
              })
                
                
            }

          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
            document.getElementById("tbody_filter_Pika").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
            
            // console.log("demo Array",element)
          
            $("#tbody_filter_Pika").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>     
            <th>${element[8]}</th>    
            <th>${element[9]}</th>
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          
          CurrentPage++;
      }

   

      }
      else if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && (MainCategorySelected == undefined && CropSelected == undefined) && Date_Selected_From == undefined && Date_Selected_To == undefined ){
        //alert("In Proffesion next with Places")

        console.log("2")
        if(CurrentPage==paginationindex){
    
          paginationindex++;
      
          console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
          
          firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Profession_Filter}`,"==",Profession_Filter_Type).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
            
              document.querySelector('#next_withFilter').disabled = true
              
              CurrentPage--;
              paginationindex--;
              
              (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
      
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter_Pika").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                  
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""
      
                          
                  })
      
                })
      
      

              
              
              
              })
                
              
            }
          
          
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
            document.getElementById("tbody_fitbody_filter_Pikalter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
          
          // console.log("demo Array",element)
          
            $("#tbody_filter_Pika").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>     
            <th>${element[8]}</th>  
            <th>${element[9]}</th>  
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          
          CurrentPage++;
      }
      else if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && (MainCategorySelected == undefined && CropSelected == undefined) && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
        //alert("In Proffesion next with District Date")
        console.log("3")

      if(CurrentPage==paginationindex){
  
        paginationindex++;
    
        console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
        
        firestore.collection("Sheti").where( Pagination_Filter_Both,"==",Pagination_Filter_Both_Value).where("date",">=",Pagination_Filter_Flag).where("date","<=",Pagination_Filter_Value).where(UserTypeFilter,"==",Selected_UserType).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
            
            document.querySelector('#next_withFilter').disabled = true
            
              CurrentPage--;
            paginationindex--;
            
              (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
    
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
    
                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter_Pika").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
       >
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""
    
                        
                })
    
              })
    
    

              
            
            
            })
              
              
          }
        
          
        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_fitbody_filter_Pikalter").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
          
          // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>     
          <th>${element[8]}</th>  
          <th>${element[9]}</th>  
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        
        CurrentPage++;
      }
    else if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && (MainCategorySelected !== undefined || CropSelected !== undefined) && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
      //alert("In Proffesion next with District main cat Date")
      console.log("4")
      if(UserTypeFilter == undefined){
        if(CurrentPage==paginationindex){

          paginationindex++;
      
          console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
          
          firestore.collection("Sheti").where( Pagination_Filter_Both,"==",Pagination_Filter_Both_Value).where("date",">=",Pagination_Filter_Flag).where("date","<=",Pagination_Filter_Value).where(Profession_Filter,"==",Pagination_Filter_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
              
              document.querySelector('#next_withFilter').disabled = true
              
                CurrentPage--;
              paginationindex--;
              
                (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
      
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).where(UserTypeFilter,"==",Selected_UserType).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                              // doc.data() is never undefined for query doc snapshots
                              $("#tbody_filter_Pika").append(`<tr>
                              <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                          </tr>`);
                              document.getElementById("NoProduct").style.display = "none"
                              // document.getElementById("UserListTable").style.display = ""
      
                          
                  })
      
                })
      
      

                
              
              
              })
                
                
            }
          
            
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
            document.getElementById("tbody_fitbody_filter_Pikalter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
            
            // console.log("demo Array",element)
          
            $("#tbody_filter_Pika").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>     
            <th>${element[8]}</th>  
            <th>${element[9]}</th>  
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          CurrentPage++;
      }else{
        if(CurrentPage==paginationindex){

          paginationindex++;
      
          console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
          
          firestore.collection("Sheti").where( Pagination_Filter_Both,"==",Pagination_Filter_Both_Value).where("date",">=",Pagination_Filter_Flag).where("date","<=",Pagination_Filter_Value).where(Profession_Filter,"==",Pagination_Filter_Value).where(UserTypeFilter,"==",Selected_UserType).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
              
              document.querySelector('#next_withFilter').disabled = true
              
                CurrentPage--;
              paginationindex--;
              
                (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
      
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                              // doc.data() is never undefined for query doc snapshots
                              $("#tbody_filter_Pika").append(`<tr>
                              <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                              <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                       
                              <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                              <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                          </tr>`);
                              document.getElementById("NoProduct").style.display = "none"
                              // document.getElementById("UserListTable").style.display = ""
      
                          
                  })
      
                })
      
      

                
              
              
              })
                
                
            }
          
            
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
            document.getElementById("tbody_fitbody_filter_Pikalter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
            
            // console.log("demo Array",element)
          
            $("#tbody_filter_Pika").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>     
            <th>${element[8]}</th>  
            <th>${element[9]}</th>  
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          CurrentPage++;
      }

      }

    }else if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined  && Date_Selected_From == undefined && Date_Selected_To == undefined ){

      if(CurrentPage==paginationindex){
  
        paginationindex++;
    
        // console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
        
        firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
           
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
    
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
    
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
    
                        
                })
    
              })
    
    
    
              //   console.log(doc.data().userName);
                 // doc.data() is never undefined for query doc snapshots
            //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
        
            //      $("#tbody_filter").append(`<tr>
            //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            //  </tr>`);
            //  document.getElementById("NoProduct").style.display = "none"
             
            
            
            })
              
             
          }

        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_filter_Pika").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
         
         // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>     
          <th>${element[8]}</th>    
          <th>${element[9]}</th>
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        
        CurrentPage++;

    }else if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && MainCategorySelected !== undefined && CropSelected == undefined  && Date_Selected_From == undefined && Date_Selected_To == undefined ){



      if(CurrentPage==paginationindex){
  
        paginationindex++;
    
        // console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
        
        firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
           
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
    
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
    
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
          
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
    
                        
                })
    
              })
    
    
    
              //   console.log(doc.data().userName);
                 // doc.data() is never undefined for query doc snapshots
            //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
        
            //      $("#tbody_filter").append(`<tr>
            //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            //  </tr>`);
            //  document.getElementById("NoProduct").style.display = "none"
             
            
            
            })
              
             
          }

        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_filter_Pika").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
         
         // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>     
          <th>${element[8]}</th>    
          <th>${element[9]}</th>
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        
        CurrentPage++;

    }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && Date_Selected_From === undefined && Date_Selected_To === undefined) || (DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From === undefined && Date_Selected_To === undefined )){
      ////alert("In Next Day")
      if(CurrentPage==paginationindex){
  
        paginationindex++;
    
        // console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
        
        firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).orderBy("date","desc").startAfter(Onlycat_Crop_Last).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
           
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            Onlycat_Crop_Last = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
    
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
    
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
    
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
          
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
    
                        
                })
    
              })
    
  

             
            
            
            })
              
             
          }
         
        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_filter_Pika").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
         
         // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>     
          <th>${element[8]}</th>     
          <th>${element[9]}</th>  
        
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        
        CurrentPage++;

    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
     // //alert("In Maincat - District - Date")
      if(CurrentPage==paginationindex){
    
        
            document.querySelector('#next_Main_cat').disabled = false;

             firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").startAfter(lastUser_Date_with_Main_Cat).limit(10).get().then((querySnapshot) => {

      
              if( querySnapshot.docs.length == 0 ){
           
                document.querySelector('#next_Main_cat').disabled = true
                
                 CurrentPage--;
                paginationindex--;
                
                 (swal("There is no Record Found"))
                console.log("At the End",UserList);
              }else{
                data = [];
                index = 0;
                lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
                while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                  document.getElementById("tbody_filter_Pika").firstChild.remove();
                }
                querySnapshot.forEach((doc) => {
           
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                    querySnapshot.forEach((docI)=>{
                      data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                               // doc.data() is never undefined for query doc snapshots
                               $("#tbody_filter_Pika").append(`<tr>
                               <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                               <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                               <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                               <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                               <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                               <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                               <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                               <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                               <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                           </tr>`);
                               document.getElementById("NoProduct").style.display = "none"
                               // document.getElementById("UserListTable").style.display = ""
      
                            
                    })
      
                  })
      
                     
                  
                  });
              }
          
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })
        
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_filter_Pika").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
         
         // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>
          <th>${element[8]}</th>
          <th>${element[9]}</th>
          </tr>`);
        });
        console.log("Data from local",UserList);
        CurrentPage++;
        }
       
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
    
    //  //alert("In Maincat - Taluka - Date")
      if(CurrentPage==paginationindex){
    
        
        document.querySelector('#next_Main_cat').disabled = false;

         firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").startAfter(lastUser_Date_with_Main_Cat).limit(10).get().then((querySnapshot) => {

  
          if( querySnapshot.docs.length == 0 ){
       
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }else{
            data = [];
            index = 0;
            lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            querySnapshot.forEach((doc) => {
       
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
  
                        
                })
  
              })
  
                 
              
              });
          }
      
        


      }).then(()=>{
        UserList[index1++] = data;
        paginationindex++;
        CurrentPage++;
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        console.log("Data Puted Sucessfully",UserList);
      })
    
    }
    else{
    while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
      document.getElementById("tbody_filter_Pika").firstChild.remove();
    }
    UserList[CurrentPage].forEach(element => {
     
     // console.log("demo Array",element)
    
      $("#tbody_filter_Pika").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      </tr>`);
    });
    console.log("Data from local",UserList);
    CurrentPage++;
    }
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
    
      // alert("In Maincat - Village - Date")
      if(Pagination_Filter_Flag == "village"){

        if(CurrentPage==paginationindex){
        
            
          document.querySelector('#next_Main_cat').disabled = false;

          firestore.collection("Sheti").where("tahsil","==",Selected_Taluka).where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").startAfter(lastUser_Date_with_Main_Cat).limit(10).get().then((querySnapshot) => {

    
            if( querySnapshot.docs.length == 0 ){
        
              document.querySelector('#next_Main_cat').disabled = true
              
              CurrentPage--;
              paginationindex--;
              
              (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }else{
              data = [];
              index = 0;
              lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              querySnapshot.forEach((doc) => {
        
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
    
                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter_Pika").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""
    
                          
                  })
    
                })
    
                  
                
                });
            }
        
          


        }).then(()=>{
          UserList[index1++] = data;
          paginationindex++;
          CurrentPage++;
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          console.log("Data Puted Sucessfully",UserList);
        })
      
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_filter_Pika").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
        
        // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>
          <th>${element[8]}</th>
          <th>${element[9]}</th>
          </tr>`);
        });
        console.log("Data from local",UserList);
        CurrentPage++;
        }

      }else{

        if(CurrentPage==paginationindex){
        
            
          document.querySelector('#next_Main_cat').disabled = false;

          firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").startAfter(lastUser_Date_with_Main_Cat).limit(10).get().then((querySnapshot) => {

    
            if( querySnapshot.docs.length == 0 ){
        
              document.querySelector('#next_Main_cat').disabled = true
              
              CurrentPage--;
              paginationindex--;
              
              (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }else{
              data = [];
              index = 0;
              lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              querySnapshot.forEach((doc) => {
        
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
    
                            // doc.data() is never undefined for query doc snapshots
                            $("#tbody_filter_Pika").append(`<tr>
                            <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                            <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                    
                            <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                            <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                        </tr>`);
                            document.getElementById("NoProduct").style.display = "none"
                            // document.getElementById("UserListTable").style.display = ""
    
                          
                  })
    
                })
    
                  
                
                });
            }
        
          


        }).then(()=>{
          UserList[index1++] = data;
          paginationindex++;
          CurrentPage++;
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          console.log("Data Puted Sucessfully",UserList);
        })
      
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_filter_Pika").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
        
        // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>
          <th>${element[8]}</th>
          <th>${element[9]}</th>
          </tr>`);
        });
        console.log("Data from local",UserList);
        CurrentPage++;
        }

      }
          

    }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){

     // //alert("In Maincat- Date")
      if(CurrentPage==paginationindex){
    
        
        document.querySelector('#next_Main_cat').disabled = false;

         firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(MainCategorySelected,"==",Selected_Category).orderBy("date","desc").startAfter(lastUser_Date_with_Main_Cat).limit(10).get().then((querySnapshot) => {

  
          if( querySnapshot.docs.length == 0 ){
       
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }else{
            data = [];
            index = 0;
            lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            querySnapshot.forEach((doc) => {
       
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                  
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
  
                        
                })
  
              })
  
                 
              
              });
          }
      
        


      }).then(()=>{
        UserList[index1++] = data;
        paginationindex++;
        CurrentPage++;
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        console.log("Data Puted Sucessfully",UserList);
      })
    
    }
    else{
    while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
      document.getElementById("tbody_filter_Pika").firstChild.remove();
    }
    UserList[CurrentPage].forEach(element => {
     
     // console.log("demo Array",element)
    
      $("#tbody_filter_Pika").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      </tr>`);
    });
    console.log("Data from local",UserList);
    CurrentPage++;
    }
    }else if(DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined){

   //   //alert("In Crop - Date")
      if(CurrentPage==paginationindex){
    
        
        document.querySelector('#next_Main_cat').disabled = false;

         firestore.collection("Sheti").where(Pagination_Filter_Flag,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser_Date_with_Crop).limit(10).get().then((querySnapshot) => {

  
          if( querySnapshot.docs.length == 0 ){
       
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }else{
            data = [];
            index = 0;
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            lastUser_Date_with_Crop = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
            
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
  
                        
                })
  
              })
  
                 
              
              });
          }
      

      }).then(()=>{
        UserList[index1++] = data;
        paginationindex++;
        CurrentPage++;
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        console.log("Data Puted Sucessfully",UserList);
      })
    
    }
    else{
    while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
      document.getElementById("tbody_filter_Pika").firstChild.remove();
    }
    UserList[CurrentPage].forEach(element => {
     
     // console.log("demo Array",element)
    
      $("#tbody_filter_Pika").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      </tr>`);
    });
    console.log("Data from local",UserList);
    CurrentPage++;
    }
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined){

      ////alert("In District - Crop - Date")
      if(CurrentPage==paginationindex){
    
        
        document.querySelector('#next_Main_cat').disabled = false;

         firestore.collection("Sheti").where(Pagination_Filter_Flag,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").startAfter(lastUser_Date_with_Crop_Dist).limit(10).get().then((querySnapshot) => {

  
          if( querySnapshot.docs.length == 0 ){
       
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }else{
            data = [];
            index = 0;
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                     
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
  
                        
                })
  
              })
  
                 
              
              });
          }
      

      }).then(()=>{
        UserList[index1++] = data;
        paginationindex++;
        CurrentPage++;
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        console.log("Data Puted Sucessfully",UserList);
      })
    
    }
    else{
    while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
      document.getElementById("tbody_filter_Pika").firstChild.remove();
    }
    UserList[CurrentPage].forEach(element => {
     
     // console.log("demo Array",element)
    
      $("#tbody_filter_Pika").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      </tr>`);
    });
    console.log("Data from local",UserList);
    CurrentPage++;
    }
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined){

      ////alert("In taluka - Crop - Date")
      if(CurrentPage==paginationindex){
    
        
        document.querySelector('#next_Main_cat').disabled = false;

         firestore.collection("Sheti").where(Pagination_Filter_Flag,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").startAfter(lastUser_Date_with_Crop_Dist).limit(10).get().then((querySnapshot) => {

  
          if( querySnapshot.docs.length == 0 ){
       
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }else{
            data = [];
            index = 0;
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                         
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
  
                        
                })
  
              })
  
                 
              
              });
          }
      

      }).then(()=>{
        UserList[index1++] = data;
        paginationindex++;
        CurrentPage++;
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        console.log("Data Puted Sucessfully",UserList);
      })
    
    }
    else{
    while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
      document.getElementById("tbody_filter_Pika").firstChild.remove();
    }
    UserList[CurrentPage].forEach(element => {
     
     // console.log("demo Array",element)
    
      $("#tbody_filter_Pika").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      </tr>`);
    });
    console.log("Data from local",UserList);
    CurrentPage++;
    }
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined){

      ////alert("In Village - Crop - Date")
      if(CurrentPage==paginationindex){
    
        
        document.querySelector('#next_Main_cat').disabled = false;

         firestore.collection("Sheti").where(Pagination_Filter_Flag,"==",Pagination_Filter_Value).where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").startAfter(lastUser_Date_with_Crop_Dist).limit(10).get().then((querySnapshot) => {

  
          if( querySnapshot.docs.length == 0 ){
       
            document.querySelector('#next_Main_cat').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }else{
            data = [];
            index = 0;
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
  
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
  
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                        
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
  
                        
                })
  
              })
  
                 
              
              });
          }
      

      }).then(()=>{
        UserList[index1++] = data;
        paginationindex++;
        CurrentPage++;
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        console.log("Data Puted Sucessfully",UserList);
      })
    
    }
    else{
    while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
      document.getElementById("tbody_filter_Pika").firstChild.remove();
    }
    UserList[CurrentPage].forEach(element => {
     
     // console.log("demo Array",element)
    
      $("#tbody_filter_Pika").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      </tr>`);
    });
    console.log("Data from local",UserList);
    CurrentPage++;
    }
    }
    else{
 
      if(UserTypeFilter!==undefined){

   

      if(Date_Selected_From !== undefined && Date_Selected_To !== undefined){
        //alert("In Date with Form")
        if(CurrentPage==paginationindex){
    
          paginationindex++;
      
          console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
          
          firestore.collection("Sheti").where("date",">=",Pagination_Filter_Flag).where("date","<=",Pagination_Filter_Value).where(Pagination_Filter_Both,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
             
              document.querySelector('#next_withFilter').disabled = true
              
               CurrentPage--;
              paginationindex--;
              
               (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
      
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                             // doc.data() is never undefined for query doc snapshots
                             $("#tbody_filter_Pika").append(`<tr>
                             <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                             <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                             <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                      
                             <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                         </tr>`);
                             document.getElementById("NoProduct").style.display = "none"
                             // document.getElementById("UserListTable").style.display = ""
      
                          
                  })
      
                })
      
      
  
               
              
              
              })
                
               
            }
          
           
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
            document.getElementById("tbody_fitbody_filter_Pikalter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
           
           // console.log("demo Array",element)
          
            $("#tbody_filter_Pika").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>     
            <th>${element[8]}</th>  
            <th>${element[9]}</th>  
            </tr>`);
          });
          console.log("Data from local",UserList);
        }
          
          CurrentPage++;

      }else{
        if(CurrentPage==paginationindex){
    
          paginationindex++;
      
          console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
          
          firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
             
              document.querySelector('#next_withFilter').disabled = true
              
               CurrentPage--;
              paginationindex--;
              
               (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
                document.getElementById("tbody_filter_Pika").firstChild.remove();
              }
              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
      
                firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
      
                  querySnapshot.forEach((docI)=>{
                    data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
      
                             // doc.data() is never undefined for query doc snapshots
                             $("#tbody_filter_Pika").append(`<tr>
                             <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                             <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                             <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                           
                             <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                             <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                         </tr>`);
                             document.getElementById("NoProduct").style.display = "none"
                             // document.getElementById("UserListTable").style.display = ""
      
                          
                  })
      
                })
      
      
  
               
              
              
              })
                
               
            }
          
           
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
            document.getElementById("tbody_fitbody_filter_Pikalter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
           
           // console.log("demo Array",element)
          
            $("#tbody_filter_Pika").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>     
            <th>${element[8]}</th>  
            <th>${element[9]}</th>  
            </tr>`);
          });
          console.log("Data from local",UserList);
        }
          
          CurrentPage++;

      }
       

      }else{

      console.log(Pagination_Filter_Both , Pagination_Filter_Both_Value , Pagination_Filter_Flag ,Pagination_Filter_Both)
      if(CurrentPage==paginationindex){
  
        paginationindex++;
    
        console.log("User Data",Pagination_Filter_Flag,Pagination_Filter_Value,Pagination_Filter_Both,Pagination_Filter_Both_Value)
        
        firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
           
            document.querySelector('#next_withFilter').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
    
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    
                querySnapshot.forEach((docI)=>{
                  data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName}`,`${docI.data().userType}`,`${doc.data().cropMainCat}`,`${doc.data().crop}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
    
                           // doc.data() is never undefined for query doc snapshots
                           $("#tbody_filter_Pika").append(`<tr>
                           <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userName}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userType}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                           <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                    
                           <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                           <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                       </tr>`);
                           document.getElementById("NoProduct").style.display = "none"
                           // document.getElementById("UserListTable").style.display = ""
    
                        
                })
    
              })
    
    

             
            
            
            })
              
             
          }
        
         
        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
          document.getElementById("tbody_fitbody_filter_Pikalter").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
         
         // console.log("demo Array",element)
        
          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>     
          <th>${element[8]}</th>  
          <th>${element[9]}</th>  
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        
        CurrentPage++;
      }
    }
}


function Previous_Page_filter__MainCategory(params) {
  document.querySelector('#next_Main_cat').disabled = false;
  
  
  CurrentPage--;
  console.log("demo Array",UserList)
  
  if(CurrentPage > 0){
  
  
  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
  while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
    document.getElementById("tbody_filter_Pika").firstChild.remove();
  }
  
  
    UserList[CurrentPage-1].forEach(element => {
     
      $("#tbody_filter_Pika").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="showprofile(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      </tr>`);
    });
     
  }
  else{
  CurrentPage = 1
  document.querySelector('#previous_Main_cat').disabled = true;
  
  } 
}



function searchFilterUser_Main_cat(params) {

  var USERLISTCHILD = document.getElementById("tbody_filter_Pika");
  var searchboxtext = document.getElementById('MyFilterSearch_MatCat').value
  var NeedToBeSearch = searchboxtext.toLowerCase();
  console.log("NeedToBeSearch",NeedToBeSearch);
  if(searchboxtext!==""){
     while( USERLISTCHILD.childElementCount !== 0){
      USERLISTCHILD.firstChild.remove();
     }
    //  document.getElementById("load").style.display = "none"
      
  }else{
    ApplyFilter();
      while( USERLISTCHILD.childElementCount !== 0){
          USERLISTCHILD.firstChild.remove();
         }
         
      // document.getElementById("load").style.display = ""
  }

  

  firestore.collection("Userinfo").where("keywords", "array-contains", NeedToBeSearch).orderBy("date","desc").limit(1).get().then(function(querySnapshot){
   
       querySnapshot.forEach((doc)=>{
         
          // searchData[index++]= [e.id,e.data().date.toDate(),e.data().userName,e.data().userProfilePic]  


          $("#tbody_filter_Pika").append(`<tr>
          <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
          <th>${doc.data().userName}</th>
          <th>${doc.data().userType}</th>
          <th>${doc.data().district}</th>
          <th>${doc.data().tahsil}</th>
          <th>${doc.data().village}</th>
          <th>${doc.data().userContact}</th>
          
    
      </tr>`);
       })
      // creatTable(searchData[0])
   })

}

function ResetFilterSearch_Main_cat (params) {
  var USERLISTCHILD = document.getElementById("tbody_filter_Pika");
  if(document.getElementById('MyFilterSearch_MatCat').value == ""){
    while( USERLISTCHILD.childElementCount !== 0){
      USERLISTCHILD.firstChild.remove();
     }
     ApplyFilter();
  }

}

function GetFilterTypeName(params) {
  
  if(UserTypeFilter!==undefined){
    if(MainCategorySelected !== undefined && CropSelected !== undefined){

      if(VillageFilterSlected!==undefined){

        filterType = `${Selected_UserType - Selected_Village - Selected_Crop}`;
      }else if(TalukaFilterSelected!==undefined){

        filterType = `${Selected_UserType - Selected_Taluka - Selected_Crop}`
      }else if(VillageFilterSlected!==undefined){

        filterType = `${Selected_UserType - Selected_Village - Selected_Crop}`
      }
  }else if(MainCategorySelected !== undefined && CropSelected == undefined){

      if(VillageFilterSlected!==undefined){

        filterType = `${ Selected_UserType - Selected_Village - Selected_Category}`;
      }else if(TalukaFilterSelected!==undefined){

        filterType = `${ Selected_UserType - Selected_Taluka - Selected_Category}`
      }else if(VillageFilterSlected!==undefined){
        
        filterType = `${ Selected_UserType - Selected_Village - Selected_Category}`
      }

  }else{
    
      if(VillageFilterSlected!==undefined){

        filterType = `${Selected_UserType - Selected_Village }`;
      }else if(TalukaFilterSelected!==undefined){

        filterType = `${Selected_UserType - Selected_Taluka}`
      }else if(VillageFilterSlected!==undefined){
        
        filterType = `${ Selected_UserType -Selected_Village}`
      }
  }

}else{

  if(MainCategorySelected !== undefined && CropSelected !== undefined){

    if(VillageFilterSlected!==undefined){

      filterType = `${Selected_Village - Selected_Crop}`;
    }else if(TalukaFilterSelected!==undefined){

      filterType = `${Selected_Taluka - Selected_Crop}`
    }else if(VillageFilterSlected!==undefined){

      filterType = `${Selected_Village - Selected_Crop}`
    }
}else if(MainCategorySelected !== undefined && CropSelected == undefined){

    if(VillageFilterSlected!==undefined){

      filterType = `${Selected_Village - Selected_Category}`;
    }else if(TalukaFilterSelected!==undefined){

      filterType = `${Selected_Taluka - Selected_Category}`
    }else if(VillageFilterSlected!==undefined){
      
      filterType = `${Selected_Village - Selected_Category}`
    }

}else{
  
    if(VillageFilterSlected!==undefined){

      filterType = `${Selected_Village }`;
    }else if(TalukaFilterSelected!==undefined){

      filterType = `${Selected_Taluka}`
    }else if(VillageFilterSlected!==undefined){
      
      filterType = `${Selected_Village}`
    }
}

}
}


function ExportData(params) {




  // if( Pagination_Filter_Both!==undefined && Pagination_Filter_Both_Value !==undefined ){
  //   var csv = 'User Name,Crop,Crop Category,Village,Taluka,District,Contact,\n';

  //   //merge the data with CSV
  //   ExportDataList.forEach(function (row) {
  //     //console.log(row)
  //     csv += row.join(',');
  //     csv += "\n";
  //   });
  
  //   //display the created CSV data on the web browser 
  //   //document.write(csv);
  
  
  //   var hiddenElement = document.createElement('a');
  //   hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  //   hiddenElement.target = '_blank';
  
  //   //provide the name for the CSV file to be downloaded
  //   hiddenElement.download = `Exported data.csv`;
  
  //   hiddenElement.click();

  // }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) || (DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined )){
  //   var csv = 'User Name,Crop,Crop Category,Village,Taluka,District,Contact,\n';

  //   //merge the data with CSV
  //   ExportDataList.forEach(function (row) {
  //     //console.log(row)
  //     csv += row.join(',');
  //     csv += "\n";
  //   });
  
  //   //display the created CSV data on the web browser 
  //   //document.write(csv);
  
  
  //   var hiddenElement = document.createElement('a');
  //   hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  //   hiddenElement.target = '_blank';
  
  //   //provide the name for the CSV file to be downloaded
  //   hiddenElement.download = `Exported data.csv`;
  
  //   hiddenElement.click();
  // }else{
  //   var csv = 'Date,User Name,Village,Taluka,District,Contact,\n';

  //   //merge the data with CSV
  //   ExportDataList.forEach(function (row) {
  //     //console.log(row)
  //     csv += row.join(',');
  //     csv += "\n";
  //   });
  
  //   //display the created CSV data on the web browser 
  //   //document.write(csv);
  
  
  //   var hiddenElement = document.createElement('a');
  //   hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  //   hiddenElement.target = '_blank';
  
  //   //provide the name for the CSV file to be downloaded
  //   hiddenElement.download = `Exported data.csv`;
  
  //   hiddenElement.click();
  // }


   

    


  if( MainCategorySelected !== undefined || CropSelected !== undefined){
      var csv = `Date,User Name,Profession,Crop,Crop Category,District,Taluka,Village,Contact,\n`;

      //merge the data with CSV
      ExportDataList.forEach(function (row) {
        //console.log(row)
        csv += row.join(',');
        csv += "\n";
      });
    
      //display the created CSV data on the web browser 
      //document.write(csv);
    
    
      var hiddenElement = document.createElement('a');
      hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
      hiddenElement.target = '_blank';
    
      //provide the name for the CSV file to be downloaded
      hiddenElement.download = `Exported data.csv`;
    
      hiddenElement.click();
  }else{
    var csv = `Date,User Name,Profession,District,Taluka,Village,Contact,\n`;

    //merge the data with CSV
    ExportDataList.forEach(function (row) {
      //console.log(row)
      csv += row.join(',');
      csv += "\n";
    });
  
    //display the created CSV data on the web browser 
    //document.write(csv);
  
  
    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
  
    //provide the name for the CSV file to be downloaded
    hiddenElement.download = `Exported data.csv`;
  
    hiddenElement.click();
  }

}


$(function () {
  $('#datepicker_from').datepicker({  format: 'dd/mm/yyyy'})
  $('#datepicker_to').datepicker({  format: 'dd/mm/yyyy'})
});

