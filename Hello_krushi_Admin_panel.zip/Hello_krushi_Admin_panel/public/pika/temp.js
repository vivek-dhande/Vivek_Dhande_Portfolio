
var firestore = firebase.firestore();
const storage = firebase.storage();
var storageRef = storage.ref();



var LastCatNo ;
firestore.collection("ShetiPik").orderBy("catSno","desc").limit(1).get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        LastCatNo = doc.data().catSno + 1 
    });
}).then(()=>{


    // firestore.collection("ShetiPik").add({
    //     catSno: LastCatNo ,
    //     mainCatName: `Category${LastCatNo}`
    // })
    // .then((docRef) => {
    //     console.log("Document written with ID: ", docRef.id);
    // })
    // .catch((error) => {
    //     console.error("Error adding document: ", error);
    // });
    

}).then(()=>{

    firestore.collection("ShetiPik").orderBy("catSno","desc").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log("Category Data",doc.data().mainCatName)
        });
    })
})


// var messageRef = db.collection('rooms').doc('roomA')
//                 .collection('messages').doc('message1');


firestore.collection("ShetiPik").orderBy("catSno").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        $("#inputState").append(`<option>${doc.data().mainCatName}</option>`)
    });
})

function AddSubCategory(params) {
  

}
// $('.custom-file-input').on('change', function() { 
//     let fileName = $(this).val().split("\\").pop();
//     $(this).next('.custom-file-label').addClass("selected").html(fileName); 

//     // document.getElementById("vivekDhande").src = document.querySelector('#inputGroupFile04').files[0]
//  });



function GetSubCategoryData(params) {
    
   var Category =  document.getElementById("inputState").value
   var SubCategory =  document.getElementById("subcat").value
   var img =  document.getElementById("inputGroupFile04").value
   var imgurl ;
   var categoryDocId;
   var LastSubCategoryNo;

   console.log("URL",params)
    const ref = firebase.storage().ref();
    const file = document.querySelector('#inputGroupFile04').files[0]
    const name =  file.name;
    const metadata = {
    contentType: file.type
    };
    const task = ref.child('CommodityImages/' + name).put(file, metadata);
    task
    .then(snapshot => snapshot.ref.getDownloadURL())
    .then((url) => {
    console.log(url);
    imgurl = url
    }).then(()=>{
        firestore.collection("ShetiPik").where("mainCatName", "==", Category)
        .get()
        .then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                categoryDocId = doc.id
                console.log(doc.id, " => ", doc.data());
            });
        }).then(()=>{
     
            firestore.collection('ShetiPik').doc(categoryDocId).collection('SubCat').orderBy("sno","desc").limit(1).get().then((querySnapshot) => {
                        querySnapshot.forEach((shrtipic) => {
                            // doc.data() is never undefined for query doc snapshots
                            LastSubCategoryNo = shrtipic.data().sno + 1;
                        });
                    }).then(()=>{
                        firestore.collection('ShetiPik').doc(categoryDocId)
                        .collection('SubCat').add({
                            sno: LastSubCategoryNo ,
                            pikName: `${SubCategory}`,
                            img : `${imgurl}`
                            })
                
                    }).then(()=>{
                        console.log("Data Added Subcessfully");
                    })
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });


    })
    .catch(console.error);


}


// function viewImagename(params) {

//     console.log("URL",params)
//     const ref = firebase.storage().ref();
// const file = document.querySelector('#inputGroupFile04').files[0]
// const name =  file.name;
// const metadata = {
//   contentType: file.type
// };
// const task = ref.child('CommodityImages/' + name).put(file, metadata);
// task
//   .then(snapshot => snapshot.ref.getDownloadURL())
//   .then((url) => {
//     console.log(url);
//     document.querySelector('#vivekDhande').src = url;
//   })
//   .catch(console.error);
// //   document.getElementById("inputGroupFile04").value = params
    
// }



// $('#inputGroupFile04').change( function(event) {
//     var tmppath = URL.createObjectURL(event.target.files[0]);
//         $("img").fadeIn("fast").attr('src',tmppath);       
//     });