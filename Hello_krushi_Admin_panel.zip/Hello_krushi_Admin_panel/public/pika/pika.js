var firestore = firebase.firestore();
const storage = firebase.storage();
var storageRef = storage.ref();
var current_Ediited_category_document;
var current_Ediited_main_category_document;
var current_Ediited_Sub_category_document ;
var current_doc_Main_cat_for_sub;
var SerialNo = 1 ;
var lastDocCategory ;
var lastDocSubCategory;
var result = [];
var i;
var count = 0;
var imgURL;
var CheckCount = 0;
var CheckCount = 0;
function ActiveTheAddCategory(params) {
    if(params == 'AddCat'){
       document.getElementById("Input_Main_Category_Data").style.display = "flex"
       document.getElementById("Input_SubCategory_Data").style.display = "none"
       document.getElementById("ShowMainCategoryData").style.display = "none"
       document.getElementById("ShowSubCategoryData").style.display = "none"
       
    }
    else if(params == 'AddSubCat'){
        console.log("In the Sub-Category");
        document.getElementById("Input_Main_Category_Data").style.display = "none"
        document.getElementById("Input_SubCategory_Data").style.display = "inline-grid"
        document.getElementById("Input_SubCategory_Data").style.display = "justify-items: center "
        document.getElementById("ShowMainCategoryData").style.display = "none"
        document.getElementById("ShowSubCategoryData").style.display = "none"
                 
    }
}

SaveCategory = () =>{
   
   
    var LastCatNo ;
    var category = document.getElementById("AddMainCategory").value;
    var imgFile2 =  document.getElementById("exampleFormControlFile2").value
    

    if(category !=="" && imgFile2 !==""){

        firestore.collection("ShetiPik").orderBy("catSno","desc").limit(1).get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                LastCatNo = doc.data().catSno + 1 
            });
        }).then(()=>{
            const ref = firebase.storage().ref();
            const file = document.querySelector('#exampleFormControlFile2').files[0]
            const name =  file.name;
            const metadata = {
            contentType: file.type
            };
            const task = ref.child('CommodityImages/' + name).put(file, metadata);
            task
            .then(snapshot => snapshot.ref.getDownloadURL())
            .then((url) => {
            console.log(url);
            firestore.collection("ShetiPik").add({
                catSno: LastCatNo ,
                mainCatName:`${category}`,
                keywords : getAllSubstrings(category.toLowerCase()),
                catImg : url
            })
            
            }).then(()=>{
                swal("successful", "Main Category Added successfully ", "success")
                document.getElementById("AddMainCategory").value = ""; 
                document.getElementById("exampleFormControlFile2").value = "";
                // firestore.collection("ShetiPik").add({
                //     catSno: LastCatNo ,
                //     mainCatName:`${category}`,
                //     keywords : getAllSubstrings(category.toLowerCase()),
                //     catImg : imgURL
                // })
                // .then((docRef) => {
                //     swal("successful", "Main Category Added successfully ", "success")
                // })
                // .catch((error) => {
                //     console.error("Error adding document: ", error);
                // });
                
            })
        }).then(()=>{
        
            firestore.collection("ShetiPik").orderBy("catSno","desc").get().then((querySnapshot) => {
                querySnapshot.forEach((doc) => {
                    // doc.data() is never undefined for query doc snapshots
                    console.log("Category Data",doc.data().mainCatName)
                });
            })
        })

    }else{
        document.getElementById("AddMainCat").style.display = "";
        document.getElementById("img_Cat").style.display = ""; 

        if(category !==""){
            document.getElementById("AddMainCat").style.display = "none";
        }

       
    }




}

function getAllSubstrings(str) {

	for (let j = 1 ; j < str.length + 1; j++) {
	  result.push(str.slice(i, j));

	}
	for (let j = str.indexOf(" ")+2 ; j < str.length + 1; j++) {
	  result.push(str.slice(str.indexOf(" ")+1, j));
  }
return result;
}



firestore.collection("ShetiPik").orderBy("catSno").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        $("#inputState").append(`<option>${doc.data().mainCatName}</option>`)
    });
})

SaveSubCategory = () =>{

    var Category =  document.getElementById("inputState").value
    console.log(Category)
    var SubCategory =  document.getElementById("SubCategoryInput").value
    console.log("SubCategory",SubCategory)
     var imgFile =  document.getElementById("exampleFormControlFile1").value
    var imgurl ;
    var categoryDocId;
    var LastSubCategoryNo;


    if(Category!=="Choose..." && SubCategory!=="" &&  imgFile!==""){

     const ref = firebase.storage().ref();
     const file = document.querySelector('#exampleFormControlFile1').files[0]
     const name =  file.name;
     const metadata = {
     contentType: file.type
     };
     const task = ref.child('CommodityImages/' + name).put(file, metadata);
     task
     .then(snapshot => snapshot.ref.getDownloadURL())
     .then((url) => {
     console.log(url);
     imgurl = url
     }).then(()=>{
         firestore.collection("ShetiPik").where("mainCatName", "==", Category).limit(1)
         .get()
         .then((querySnapshot) => {
             querySnapshot.forEach((doc) => {
                 // doc.data() is never undefined for query doc snapshots
                 categoryDocId = doc.id
                 console.log(doc.id, " => ", doc.data());
             });
         }).then(()=>{
      
             firestore.collection('ShetiPik').doc(categoryDocId).collection('SubCat').orderBy("sno","desc").limit(1).get().then((querySnapshot) => {
                console.log("Vivek",querySnapshot.size)
                querySnapshot.size == 0 ? LastSubCategoryNo = 1 : "";
                querySnapshot.forEach((shrtipic) => {
                    console.log("In 1")
                    // doc.data() is never undefined for query doc snapshots
                    LastSubCategoryNo =  shrtipic.data().sno + 1
                    
                });
                
                     }).then(()=>{
                        if(CheckCount<1){
                         CheckCount++;
                         firestore.collection('ShetiPik').doc(categoryDocId)
                         .collection('SubCat').add({
                             sno: LastSubCategoryNo ,
                             pikName: `${SubCategory}`,
                             img : `${imgurl}`,
                             keywords : getAllSubstrings(SubCategory.toLowerCase())
                             })
                        }
                 
                     }).then(()=>{
                        swal("successful", "Main Category Added successfully ", "success")
                         document.getElementById("inputState").value = "Choose..." ;
                         document.getElementById("SubCategoryInput").value = "";
                         document.getElementById("exampleFormControlFile1").value ="";
                         
                         
                     })
         })
         .catch((error) => {
             console.log("Error getting documents: ", error);
         });
 
 
     })
     .catch(console.error);

    }else {

        if(Category==="Choose..."){
            document.getElementById("maincat").style.display =""
        }else{
            document.getElementById("maincat").style.display ="none"
        }

        if(SubCategory===""){
            document.getElementById("subcate").style.display =""
        }else{
            document.getElementById("subcate").style.display ="none"
        }

        if(imgFile ===""){
            document.getElementById("img_f").style.display =""
        }else{
            document.getElementById("img_f").style.display ="none"
        }

    

     const ref = firebase.storage().ref();
     const file = document.querySelector('#exampleFormControlFile1').files[0]
     const name =  file.name;
     const metadata = {
     contentType: file.type
     };
     const task = ref.child('CommodityImages/' + name).put(file, metadata);
     task
     .then(snapshot => snapshot.ref.getDownloadURL())
     .then((url) => {
     console.log(url);
     imgurl = url
     }).then(()=>{
         firestore.collection("ShetiPik").where("mainCatName", "==", Category).limit(1)
         .get()
         .then((querySnapshot) => {
             querySnapshot.forEach((doc) => {
                 // doc.data() is never undefined for query doc snapshots
                 categoryDocId = doc.id
                 console.log(doc.id, " => ", doc.data());
             });
         }).then(()=>{
      
             firestore.collection('ShetiPik').doc(categoryDocId).collection('SubCat').orderBy("sno","desc").limit(1).get().then((querySnapshot) => {
                console.log("Vivek",querySnapshot.size)
                querySnapshot.size == 0 ? LastSubCategoryNo = 1 : "";
                querySnapshot.forEach((shrtipic) => {
                    console.log("In 1")
                    // doc.data() is never undefined for query doc snapshots
                    LastSubCategoryNo =  shrtipic.data().sno + 1
                    
                });

                
                     }).then(()=>{
                         firestore.collection('ShetiPik').doc(categoryDocId)
                         .collection('SubCat').add({
                             sno: LastSubCategoryNo ,
                             pikName: `${SubCategory}`,
                             img : `${imgurl}`,
                             keywords : getAllSubstrings(SubCategory.toLowerCase())
                             })
                 
                     }).then(()=>{
                        swal("successful", "Main Category Added successfully ", "success")
                         document.getElementById("inputState").value = "Choose..." ;
                         document.getElementById("SubCategoryInput").value = "";
                         document.getElementById("exampleFormControlFile1").value ="";
                         
                         
                     })
         })
         .catch((error) => {
             console.log("Error getting documents: ", error);
         });
 
 
     })
     .catch(console.error);
    }
}


ViewCategoryCard = () =>{
var clean_Data = document.getElementById("ShowMainCategoryDataCardDiv"); 
document.getElementById("LoadMore").style.display = ""
    while(clean_Data.childElementCount!==0){
        clean_Data.firstChild.remove();
    }

    document.getElementById("ShowMainCategoryData").style.display = "flex"
    document.getElementById("Input_Main_Category_Data").style.display = "none" 
    document.getElementById("Input_SubCategory_Data").style.display = "none" 
    document.getElementById("ShowSubCategoryData").style.display = "none"

    firestore.collection("ShetiPik").limit(10).get().then((querySnapshot) => {
        lastDocCategory = querySnapshot.docs[querySnapshot.docs.length-1];
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", );
            $("#ShowMainCategoryDataCardDiv").append(`
           
              <tr id="${doc.id}">
             
                <td id="${doc.id}" onclick="show(this.id,this)"><span id="CategoryName">${doc.data().mainCatName}</span></td>
                <td><button  class="btn btn-info btn-icon-split" id="${doc.id}" onclick="editCategory(this.id)">
                    
                    <span class="text">Edit</span>
                </button></td>

                <td><button id="${doc.id}" class="btn btn-danger btn-icon-split" onclick="deleteCategory(this.id)">
                    
                    <span class="text">Remove</span>
                </button></td>
              </tr>
              
          
            `)
        });
    });
    
}

editCategory = (id) =>{
    current_Ediited_category_document = id;

    var docRef = firestore.collection("ShetiPik").doc(id);

docRef.get().then((doc) => {
    if (doc.exists) {
        console.log("Document data:",);
        document.getElementById("categoryNameEdit").value =  doc.data().mainCatName
    
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

   
    $('#ViewCategoryEditModal').modal();
}

editSubCategory = (id,subid) =>{
    current_Ediited_main_category_document = id;
    current_Ediited_Sub_category_document = subid;


    var docRef = firestore.collection("ShetiPik").doc(id).collection("SubCat").doc(subid)

docRef.get().then((doc) => {
    if (doc.exists) {
    
        document.getElementById("subcategoryNameEdit").value =  doc.data().pikName;
        document.getElementById("product-post-img").src = doc.data().img
    
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

   
    $('#ViewSubCategoryEditModal').modal();
}


SaveEditiedCategory = () =>{

    var CNE = document.getElementById("categoryNameEdit").value;
    var CategoryIMG = document.getElementById("exampleFormControlFile3").value;

    if(CategoryIMG!==""){

        const ref = firebase.storage().ref();
        const file = document.querySelector('#exampleFormControlFile3').files[0]
        const name =  file.name;
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('CommodityImages/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
        console.log(url);
        firestore.collection("ShetiPik").doc(current_Ediited_category_document).update({
            mainCatName: CNE,
            catImg:url,
            keywords: getAllSubstrings(CNE.toLowerCase())
        })
        }).then(function() {
            swal("Successfull!", "Category Updated Successfully", "success")
        })
        .then(()=>{
           
            setTimeout(function(){ location.reload()}, 500);
        }).catch(function(e) {
            console.log("Error:" + e)
        })
        
    }else{
        firestore.collection("ShetiPik").doc(current_Ediited_category_document).update({
            mainCatName: CNE,
            keywords: getAllSubstrings(CNE.toLowerCase())
        })
    }

  

}
SaveSubEditiedCategory = () =>{
    var ImgUrl_Sub;
    var CNE = document.getElementById("subcategoryNameEdit").value;
    const ref = firebase.storage().ref();
    const file = document.querySelector('#exampleFormControlFile1_sub').files[0]
    const name =  file.name;
    const metadata = {
    contentType: file.type
    };
    const task = ref.child('CommodityImages/' + name).put(file, metadata);
    task
    .then(snapshot => snapshot.ref.getDownloadURL())
    .then((url) => {
    console.log(url);
    ImgUrl_Sub = url
    }).then(()=>{

        firestore.collection("ShetiPik").doc(current_Ediited_main_category_document).collection("SubCat").doc(current_Ediited_Sub_category_document).update({
            pikName: CNE,
            img: ImgUrl_Sub,
            keywords: getAllSubstrings(CNE.toLowerCase())
          
        }).then(function() {
       
            swal("Successfull!", "Sub-Category Updated Successfully", "success")
        }).then(()=>{
            location.reload();
        }).catch(function(e) {
            console.log("Error:" + e)
        })


    })
    


    



}

deleteCategory = (id) =>{
    // document.getElementById(`${id}`).remove();
    // firestore.collection("ShetiPik").doc(id).delete()

    // swal({
    //     title: "Are you sure?",
    //     text: "Do you want to Delete this Category",
    //     icon: "warning",
    //     buttons: !0,
    //     dangerMode: !0
    // }).then(n => {

    //     n && firestore.collection("ShetiPik").doc(id).delete()
        // let subsWrapper = document.getElementById(`${id}`)
        // subsWrapper.remove();
    //     swal("Successfull", "Category Deleted ", "success")
     
    // }).catch(function(e) {
    //     console.error("Error removing document: ", e)
    // })

    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Category",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
            let subsWrapper = document.getElementById(`${id}`)
            subsWrapper.remove();
          firestore.collection("ShetiPik").doc(id).delete()
          swal("Category Deleted", {
            icon: "success",
          });
        } else {
          swal("Category NOT Deleted");
        }
      });
}

deleteSubCategory = (id) =>{
  

    swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover this imaginary file!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
      .then((willDelete) => {
        if (willDelete) {
         firestore.collection("ShetiPik").doc(current_doc_Main_cat_for_sub).collection("SubCat").doc(id).delete()
          swal("Sub Category Deleted", {
            icon: "success",
          });
        } else {
          swal("Sub_Category NOT Deleted");
        }
      });
}




function RenderNextCategories (){

    firestore.collection("ShetiPik").startAfter(lastDocCategory).limit(10).get().then((querySnapshot) => {
        if( querySnapshot.docs.length == 0 ){
            document.getElementById("LoadMore").style.display = "none"
            }
            else{
                document.getElementById("LoadMore").style.display = "flex"
            }
        lastDocCategory = querySnapshot.docs[querySnapshot.docs.length-1];
        querySnapshot.forEach((doc) => {
        
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", );
            $("#ShowMainCategoryDataCardDiv").append(`
           
              <tr id="${doc.id}">
             
              <td id="${doc.id}" onclick="show(this.id,this)"><span id="CategoryName">${doc.data().mainCatName}</span></td>
                <td><button  class="btn btn-info btn-icon-split" id="${doc.id}" onclick="editCategory(this.id)">
                    
                    <span class="text">Edit</span>
                </button></td>

                <td><button id="${doc.id}" class="btn btn-danger btn-icon-split" onclick="deleteCategory(this.id)">
                    
                    <span class="text">Remove</span>
                </button></td>
              </tr>
              
          
            `)
        });
    });
}




searchcategory = ()=>{

    var getSearchedText = document.getElementById("Search_Category").value;
    var GettableChild = document.getElementById("ShowMainCategoryDataCardDiv");
    while(GettableChild.childElementCount!==0){
        GettableChild.firstChild.remove();
    }

    firestore.collection("ShetiPik").where("keywords", "array-contains", getSearchedText).limit(1).get().then(function(querySnapshot){
 
        querySnapshot.forEach((CategorySearch)=>{

            $("#ShowMainCategoryDataCardDiv").append(`  
            <tr id="${CategorySearch.id}">
           
            <td id="CategoryName" >${CategorySearch.data().mainCatName}</td>
            <td><button  class="btn btn-info btn-icon-split" id="${CategorySearch.id}" onclick="editCategory(this.id)">
                <span class="icon text-white-50">
                    <i class="fas fa-info-circle"></i>
                </span>
                <span class="text">Edit</span>
            </button></td>

            <td><button id="${CategorySearch.id}" class="btn btn-danger btn-icon-split" onclick="deleteCategory(this.id)">
                <span class="icon text-white-50">
                    <i class="fas fa-trash"></i>
                </span>
                <span class="text">Remove</span>
            </button></td>
          </tr>
            
            `);

        })
    })


  
}

searchSubcategory = ()=>{

   

    var getSearchedText = document.getElementById("Search_Sub_Category").value;
    var GettableChild = document.getElementById("ShowSubCategoryDataDataCardDiv");
    while(GettableChild.childElementCount!==0){
        GettableChild.firstChild.remove();
    }


firestore.collection("ShetiPik").doc(current_doc_Main_cat_for_sub).collection("SubCat").get().then((querySnapshot) => {

    querySnapshot.forEach((e)=>{

        //console.log("Vivek Dhande",e.data());

    })
})
    firestore.collection("ShetiPik").doc(current_doc_Main_cat_for_sub).collection("SubCat").where("keywords", "array-contains", getSearchedText).limit(1).get().then(function(querySnapshot){
 
        querySnapshot.forEach((CategorySearch)=>{

      
            $("#ShowSubCategoryDataDataCardDiv").append(`  
            <tr id="${CategorySearch.id}">
           
            <td id="CategoryName" >${CategorySearch.data().pikName}</td>
            <td><button  class="btn btn-info btn-icon-split" id="${CategorySearch.id}" onclick="editSubCategory('${current_doc_Main_cat_for_sub}',this.id)">
                <span class="icon text-white-50">
                    <i class="fas fa-info-circle"></i>
                </span>
                <span class="text">Edit</span>
            </button></td>

            <td><button id="${CategorySearch.id}" class="btn btn-danger btn-icon-split" onclick="deleteCategory(this.id)">
                <span class="icon text-white-50">
                    <i class="fas fa-trash"></i>
                </span>
                <span class="text">Remove</span>
            </button></td>
          </tr>
            
            `);

        })
    })


  
}

ResetSearchInput = ()=>{

    var Search_Category = document.getElementById("Search_Category").value;
    var GettableChild = document.getElementById("ShowMainCategoryDataCardDiv");

    if(Search_Category!==""){
        count = 0;
        
    }
    else{
        if(count<1){
        count++;
        while(GettableChild.childElementCount!==0){
            GettableChild.firstChild.remove();
        }
    
            ViewCategoryCard();
        }
    }
}



ViewSubCategoryCard = () =>{

    document.getElementById("ShowMainCategoryData").style.display = "flex"
    document.getElementById("Input_Main_Category_Data").style.display = "none" 
    document.getElementById("ShowSubCategoryData").style.display = "none"

    firestore.collection("ShetiPik").limit(10).get().then((querySnapshot) => {
        lastDocCategory = querySnapshot.docs[querySnapshot.docs.length-1];
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", );
            $("#ShowMainCategoryDataCardDiv").append(`
           
              <tr id="${doc.id}">
             
                <td id="CategoryName">${doc.data().mainCatName}</td>
                <td><button  class="btn btn-info btn-icon-split" id="${doc.id}" onclick="editCategory(this.id)">
                    <span class="icon text-white-50">
                        <i class="fas fa-info-circle"></i>
                    </span>
                    <span class="text">Edit</span>
                </button></td>

                <td><button id="${doc.id}" class="btn btn-danger btn-icon-split" onclick="deleteSubCategory(this.id)">
                    <span class="icon text-white-50">
                        <i class="fas fa-trash"></i>
                    </span>
                    <span class="text">Remove</span>
                </button></td>
              </tr>
              
          
            `)
        });
    });
    
}


show = (id,text)=>{
    document.getElementById("ShowSubCategoryData").style.display = "flex"
    var CleanSubCat = document.getElementById("ShowSubCategoryDataDataCardDiv");
   
    current_doc_Main_cat_for_sub = id ;
     document.getElementById("subcategory").innerText = text.innerText
    firestore.collection("ShetiPik").doc(id).collection("SubCat").limit(10).get().then((querySnapshot) => {
        lastDocSubCategory = querySnapshot.docs[querySnapshot.docs.length-1];
        while(CleanSubCat.childElementCount!==0){
            CleanSubCat.firstChild.remove();
        }
        querySnapshot.forEach((doc) => {


            $("#ShowSubCategoryDataDataCardDiv").append(`
           
            <tr id="${doc.id}">
           
              <td id="CategoryName">${doc.data().pikName}</td>
              <td><button  class="btn btn-info btn-icon-split" id="${doc.id}" onclick="editSubCategory('${id}',this.id)">
               
                  <span class="text">Edit</span>
              </button></td>

              <td><button id="${doc.id}" class="btn btn-danger btn-icon-split" onclick="deleteSubCategory(this.id)">

                  <span class="text">Remove</span>
              </button></td>
            </tr>
            
          `)

       
        })

    })
}