importScripts('https://www.gstatic.com/firebasejs/8.2.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.2.0/firebase-messaging.js');

var firebaseConfig = {
    apiKey: "XXX",
    authDomain: "XXX",
    projectId: "XXX",
    storageBucket: "XXX",
    messagingSenderId: "XXX",
    appId: "XXX",
 };

firebase.initializeApp(firebaseConfig);

// Retrieve firebase messaging
const messaging = firebase.messaging();

 messaging.setBackgroundMessageHandler(function (payload) {
    console.log('setBackgroundMessageHandler background message ', payload);

    const promiseChain = clients
       .matchAll({
           type: "window",
           includeUncontrolled: true
       })
      .then(windowClients => {
           for (let i = 0; i < windowClients.length; i++) {
              const windowClient = windowClients[i];
              windowClient.postMessage(payload);
           }
      })
    
    })