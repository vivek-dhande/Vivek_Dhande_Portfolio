var firestore = firebase.firestore();
document.getElementById("LoadMoreButton").style.display = "none";
var category_unlfiltered_index = 0;
var category_unlfiltered = [];
var ExportDataList = [];
var exportIndex = 0;
var defaultRednerCount = 0;
var dropdown_index = 0;
var index = 0;
var userdoc = localStorage.getItem('userDocId');
var userId = localStorage.getItem('UserId');
var lastVisibleProduct;
var dropdown_category_name = [];
var current_Category;
var counter = 0;
var lastVisibleProduct_other, lastVisibleProduct_withFilter, lastVisibleProduct_withFilter_No_All;
var VibhagSlected;
var DistrictFilterSelected;
var TalukaFilterSelected;
var VillageFilterSlected;
var MainCategorySelected;
var CropSelected;
var Selected_District;
var Selected_Taluka;
var Selected_Village
var Selected_Vibhag;
var Selected_Category;
var Selected_Crop;
var Selected_Product;
var Selected_Place;
var CurrentSelectedFilter;
var Pagination_Filter_Flag;
var CurrentSelectedFilter_Product;
var Selected_Product;
var Pagination_index_1;
var Pagination_index_2;
var Pagination_Category;
var id_Edits;
var PriflePicForOrder_Edits;
var UserName_Edits;
var contact_edits;
var keyword = document.getElementById('keyword');

var tags = [],sptags = [], tagsKey = [];

    var landUnits  = ["","गुंठा","बिघा","एकर","हेक्टर","चौरस फूट"];
    var शेतमाल = ["","kg","ml","क्विंटल","टन","बॅग","बोनी","पीस"];
    var अवजारे_व_वाहने= ["","KG","ML","बॅग","पीस"];
    var भाडेतत्वावर_सेवा = ["","भाडे कशानुसार घेता.?(तास/गुंठा/एकर/दिवस)","तास","दिवस","गुंठा","एकर","हेक्टर"];
    var बी_बियाणे_खरेदी_विक्री = ["","KG","बॅग"];
    var रोपवाटीका = ["","युनिट","नग","पिशवी","ट्रे"];
    var खते = ["","युनिट","Kg","टन","ट्रॉली"];
    var MainDropDownCategory = ["शेतमाल","खत दुकान / कृषी सेवा केंद्र","भाडेतत्वावर सेवा","रोपवाटीका","खते","अवजारे व वाहने","जमीन खरेदी विक्री","पशू खरेदी विक्री","बी-बियाणे खरेदी विक्री","शेतीपूरक व्यवसाय","कृषी पर्यटन केंद्र","मजूर/कामगार/चिटबाॅय","मजूर/कामगार/चिटबाॅय","प्लंबर/वायरमन","पशू चिकित्सक","पोल्ट्री फार्म","शेळी/मेंढीपालन","दुग्धव्यवसाय","शेतीविषयक सेवा","कृषी प्रक्रीया उद्योग","इतर व्यवसाय"];
  

// ECDoc.data().description.replaceAll(',', ' ')
function get_drop_down(params) {

    MainDropDownCategory.forEach((e) => {
    
        var Category = $(`<option >${e}</option>`);
        Category.appendTo('#product_Category_list');
      

    });

    // firestore.collection("ECommerce").onSnapshot((querySnapshot) => {
    //     querySnapshot.forEach((doc) => {
    //         category_unlfiltered[category_unlfiltered_index] = doc.data().category

    //         category_unlfiltered_index++;
    //     });
    //     var a = [...new Set(category_unlfiltered)]

    //     var temp = `${a[0]}`

    //     if (dropdown_index <= 0) {


    //         a.forEach((e) => {
    //             dropdown_category_name[index] = e;
    //             var Category = $(`<option >${e}</option>`);
    //             Category.appendTo('#product_Category_list');
    //             index++;

    //         });
    //         dropdown_index++
    //     }
    // });

    // if(temp==undefined){
    //     console.log(`"${a[0]}"`)
    //     getData_by_category(`"${a[0]}"`);
    // }

}
get_drop_down();

function get_drop_down_Edits(params) {

    var category_unlfiltered_E = [];
    var category_unlfiltered_index_E = 0; 
    var dropdown_category_name_E = [];
    var dropdown_index_E = 0;
    var index_E = 0;

    firestore.collection("ECommerce").onSnapshot((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            category_unlfiltered_E[category_unlfiltered_index_E] = doc.data().category

            category_unlfiltered_index_E++;
        });
        var a = [...new Set(category_unlfiltered_E)]

        var temp = `${a[0]}`

        if (dropdown_index_E <= 0) {

            a.forEach((e) => {
                dropdown_category_name_E[index_E] = e;
                var Category = $(`<option >${e}</option>`);
                Category.appendTo('#E_product-Category_other');
                index_E++;

            });
            dropdown_index_E++
        }
    });

    // if(temp==undefined){
    //     console.log(`"${a[0]}"`)
    //     getData_by_category(`"${a[0]}"`);
    // }

}

get_drop_down_Edits();

All_products();

function All_products(params) {
    Selected_Category = "All"
    ExportDataList = [];
    exportIndex = 0;

    firestore.collection("ECommerce").orderBy("date", "desc")

        .get().then((querySnapshot) => {

            querySnapshot.forEach((ECDoc) => {
                firestore.collection("Userinfo").where("userID", "==", ECDoc.data().ownerId)
                    .get()
                    .then((querySnapshot) => {
                        querySnapshot.forEach((UrDoc) => {

                            ExportDataList[exportIndex++] = [UrDoc.data().userName, UrDoc.data().userContact, ECDoc.data().quantity, ECDoc.data().title, ECDoc.data().category, ECDoc.data().price.replaceAll(',', ' '), ECDoc.data().discountPrice.replaceAll(',', ' '), ECDoc.data().unit, ECDoc.data().discount, ECDoc.data().district, ECDoc.data().tahsil, ECDoc.data().village, ECDoc.data().pinCode]

                        })
                    })


            })


        }).then(() => {

            console.log("Data", ExportDataList);
        })


    firestore.collection("ECommerce").limit(6).orderBy("date", "desc")

        .get().then((querySnapshot) => {

            current_Category = "All"
            lastVisibleProduct = querySnapshot.docs[querySnapshot.docs.length - 1];
            if (querySnapshot.docs.length == 0) {
                document.getElementById("LoadMoreButton").style.display = "none"
            }
            else {
                document.getElementById("LoadMoreButton").style.display = "flex"
            }

            querySnapshot.forEach((productdoc) => {
                // doc.data() is never undefined for query doc snapshots

                firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                    .get()
                    .then((querySnapshot) => {
                        querySnapshot.forEach((userDoc) => {

                            console.log("Data", userDoc.data().userName, userDoc.data().userName)
                            // doc.data() is never undefined for query doc snapshots
                            var PriflePic;

                            var english = /^[A-Za-z0-9]*$/;
                            var check = userDoc.data().userName


                            if (userDoc.data().userProfilePic == "") {

                                if (english.test(check.charAt(0)) == true) {
                                    var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                    switch (UserName_Copy.charAt(0).toLowerCase()) {

                                        case 'a':
                                            PriflePic = "/img/a.svg";
                                            break;

                                        case 'b':
                                            PriflePic = "/img/b.svg";
                                            break;

                                        case 'c':
                                            PriflePic = "/img/c.svg";
                                            break;

                                        case 'd':
                                            PriflePic = "/img/d.svg";
                                            break;

                                        case 'e':
                                            PriflePic = "/img/e.svg";
                                            break;

                                        case 'f':
                                            PriflePic = "/img/f.svg";
                                            break;

                                        case 'g':
                                            PriflePic = "/img/g.svg";
                                            break;

                                        case 'h':
                                            PriflePic = "/img/h.svg";
                                            break;

                                        case 'i':
                                            PriflePic = "/img/i.svg";
                                            break;

                                        case 'j':
                                            PriflePic = "/img/j.svg";
                                            break;

                                        case 'k':
                                            PriflePic = "/img/k.svg";
                                            break;

                                        case 'l':
                                            PriflePic = "/img/l.svg";
                                            break;

                                        case 'm':
                                            PriflePic = "/img/m.svg";
                                            break;

                                        case 'n':
                                            PriflePic = "/img/n.svg";
                                            break;

                                        case 'o':
                                            PriflePic = "/img/o.svg";
                                            break;

                                        case 'p':
                                            PriflePic = "/img/p.svg";
                                            break;

                                        case 'q':
                                            PriflePic = "/img/q.svg";
                                            break;

                                        case 'r':
                                            PriflePic = "/img/r.svg";
                                            break;

                                        case 's':
                                            PriflePic = "/img/s.svg";
                                            break;

                                        case 't':
                                            PriflePic = "/img/t.svg";
                                            break;

                                        case 'u':
                                            PriflePic = "/img/u.svg";
                                            break;

                                        case 'v':
                                            PriflePic = "/img/v.svg";
                                            break;

                                        case 'w':
                                            PriflePic = "/img/w.svg";
                                            break;

                                        case 'x':
                                            PriflePic = "/img/x.svg";
                                            break;

                                        case 'y':
                                            PriflePic = "/img/y.svg";
                                            break;

                                        case 'z':
                                            PriflePic = "/img/z.svg";
                                            break;

                                    }
                                }
                                else {
                                    PriflePic = "/img/person.svg";
                                }
                            }
                            else {
                                PriflePic = userDoc.data().userProfilePic

                            }


                            $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                    <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                        <div class="card-body" >
                                        <div>
                                        <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                        <span style="margin-left:1rem;color: black;
                                        font-weight: 700"> ${userDoc.data().userName}</span>
                                        <span style="display: flex;
                                        justify-content: flex-end;">${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                        <hr>

                                        </div>
                                        <div id="Product_title" style="display: flex;justify-content: space-between;">
                                
                                        <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h5>
                              
                                        </div>
                                        
                                        <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                    </div>

                                    <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                    <div id="utilities" style="
                                    display: flex;
                                    justify-content: space-around;
                                    margin-bottom: 1rem;
                                
                                ">
                                        <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                            <span  class="icon text-white-50" >
                                                <i class="fas fa-info-circle"></i>
                                            </span>
                                            <span class="text" style="color: white">View</span>
                                        </a>
                                        <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                            <span class="icon text-white-50">
                                                <i class="fas fa-trash"></i>
                                            </span>
                                            <span class="text" style="color: white">Remove</span>
                                        </a>
                                    </div>
                                    </div>
                                    
                                    </div>`)
                            document.getElementById("LoadMoreButton").style.display = "flex";
                            document.getElementById("NoProduct").style.display = "none"

                        });
                    })
                    .catch((error) => {
                        console.log("Error getting documents: ", error);
                    });


            });
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });

}

function ApplyFilter(params) {




    if (DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined && VillageFilterSlected === undefined) {

        //District
        console.log("Vivek Dhande")
        // alert("District");
        document.getElementById("District_Checked").style.display = "";
        //   DistrictFilter(DistrictFilterSelected,Selected_District);
        filters(current_Category, DistrictFilterSelected, Selected_District)
    }
    else if (DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined && VillageFilterSlected === undefined) {

        //Taluka
        // alert("Taluka");
        // DistrictFilter(TalukaFilterSelected,Selected_Taluka);
        document.getElementById("District_Checked").style.display = "";
        document.getElementById("Taluka_Checked").style.display = "";
        console.log("Selected_Category,TalukaFilterSelected,Selected_Taluka", Selected_Category, TalukaFilterSelected, Selected_Taluka)
        filters(Selected_Category, TalukaFilterSelected, Selected_Taluka)

    } else if (DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined && VillageFilterSlected !== undefined) {

        //Village
        // alert("Village");
        document.getElementById("District_Checked").style.display = "";
        document.getElementById("Taluka_Checked").style.display = "";
        document.getElementById("Village_Checked").style.display = "";
        // DistrictFilter(VillageFilterSlected,Selected_Village);
        filters(Selected_Category, VillageFilterSlected, Selected_Village)

    }

}



function filters(params, params2, params3) {
    ExportDataList = [];
    exportIndex = 0;

    Pagination_Category = params;
    Pagination_index_1 = params2;
    Pagination_index_2 = params3;

    while (document.getElementById("userproductsList").childElementCount != 0) {

        document.getElementById("userproductsList").firstChild.remove();

    }

    console.log("current_Category", current_Category)

    if (current_Category !== "All") {

        firestore.collection("ECommerce").where("category", "==", params).where(params2, "==", params3).orderBy("date", "desc")

            .get().then((querySnapshot) => {

                querySnapshot.forEach((ECDoc) => {
                    firestore.collection("Userinfo").where("userID", "==", ECDoc.data().ownerId)
                        .get()
                        .then((querySnapshot) => {
                            querySnapshot.forEach((UrDoc) => {


                                ExportDataList[exportIndex++] = [UrDoc.data().userName, UrDoc.data().userContact, ECDoc.data().quantity, ECDoc.data().title, ECDoc.data().category, ECDoc.data().price.replaceAll(',', ' '), ECDoc.data().discountPrice.replaceAll(',', ' '), ECDoc.data().unit, ECDoc.data().discount, ECDoc.data().district, ECDoc.data().tahsil, ECDoc.data().village, ECDoc.data().pinCode]

                            })
                        })


                })


            })



        firestore.collection("ECommerce").where("category", "==", params).where(params2, "==", params3).limit(6).orderBy("date", "desc")
            .get()
            .then((querySnapshot) => {
                current_Category = params
                lastVisibleProduct_withFilter = querySnapshot.docs[querySnapshot.docs.length - 1];
                if (querySnapshot.docs.length == 0) {
                    document.getElementById("LoadMoreButton").style.display = "none"
                }
                else {
                    document.getElementById("LoadMoreButton").style.display = "flex"
                }
                querySnapshot.forEach((productdoc) => {
                    // doc.data() is never undefined for query doc snapshots

                    console.log("OwnerData", productdoc.data().ownerId)
                    firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                        .get()
                        .then((querySnapshot) => {
                            querySnapshot.forEach((userDoc) => {
                                // doc.data() is never undefined for query doc snapshots

                                var PriflePic;

                                var english = /^[A-Za-z0-9]*$/;
                                var check = userDoc.data().userName


                                if (userDoc.data().userProfilePic == "") {

                                    if (english.test(check.charAt(0)) == true) {
                                        var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                        switch (UserName_Copy.charAt(0).toLowerCase()) {

                                            case 'a':
                                                PriflePic = "/img/a.svg";
                                                break;

                                            case 'b':
                                                PriflePic = "/img/b.svg";
                                                break;

                                            case 'c':
                                                PriflePic = "/img/c.svg";
                                                break;

                                            case 'd':
                                                PriflePic = "/img/d.svg";
                                                break;

                                            case 'e':
                                                PriflePic = "/img/e.svg";
                                                break;

                                            case 'f':
                                                PriflePic = "/img/f.svg";
                                                break;

                                            case 'g':
                                                PriflePic = "/img/g.svg";
                                                break;

                                            case 'h':
                                                PriflePic = "/img/h.svg";
                                                break;

                                            case 'i':
                                                PriflePic = "/img/i.svg";
                                                break;

                                            case 'j':
                                                PriflePic = "/img/j.svg";
                                                break;

                                            case 'k':
                                                PriflePic = "/img/k.svg";
                                                break;

                                            case 'l':
                                                PriflePic = "/img/l.svg";
                                                break;

                                            case 'm':
                                                PriflePic = "/img/m.svg";
                                                break;

                                            case 'n':
                                                PriflePic = "/img/n.svg";
                                                break;

                                            case 'o':
                                                PriflePic = "/img/o.svg";
                                                break;

                                            case 'p':
                                                PriflePic = "/img/p.svg";
                                                break;

                                            case 'q':
                                                PriflePic = "/img/q.svg";
                                                break;

                                            case 'r':
                                                PriflePic = "/img/r.svg";
                                                break;

                                            case 's':
                                                PriflePic = "/img/s.svg";
                                                break;

                                            case 't':
                                                PriflePic = "/img/t.svg";
                                                break;

                                            case 'u':
                                                PriflePic = "/img/u.svg";
                                                break;

                                            case 'v':
                                                PriflePic = "/img/v.svg";
                                                break;

                                            case 'w':
                                                PriflePic = "/img/w.svg";
                                                break;

                                            case 'x':
                                                PriflePic = "/img/x.svg";
                                                break;

                                            case 'y':
                                                PriflePic = "/img/y.svg";
                                                break;

                                            case 'z':
                                                PriflePic = "/img/z.svg";
                                                break;

                                        }
                                    }
                                    else {
                                        PriflePic = "/img/person.svg";
                                    }
                                }
                                else {
                                    PriflePic = userDoc.data().userProfilePic

                                }


                                $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                            <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                <div class="card-body" >
                                                <div>
                                                <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                                                <span style="display: flex;
                                                justify-content: flex-end;">${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                <hr>
    
                                                </div>
                                                <div id="Product_title" style="display: flex;justify-content: space-between;">
                                        
                                                <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                </div>
                                                <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                            </div>
                                           
                                            <div style="display: flex;
                                            justify-content: space-around;margin-bottom: 0.5rem;">
                                            <span> Taluka: ${productdoc.data().tahsil} </span>
                                            <span> Village: ${productdoc.data().village} </span>
                                            </div>
                                           
                                            <div id="utilities" style="
                                            display: flex;
                                            justify-content: space-around;
                                            margin-bottom: 1rem;
                                        
                                        
                                        ">
                                                <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                    <span  class="icon text-white-50" >
                                                        <i class="fas fa-info-circle"></i>
                                                    </span>
                                                    <span class="text" style="color: white">View</span>
                                                </a>
                                                <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-trash"></i>
                                                    </span>
                                                    <span class="text" style="color: white">Remove</span>
                                                </a>
                                            </div>
                                            </div>
                                            
                                            </div>`)
                                document.getElementById("LoadMoreButton").style.display = "flex";
                            });
                        })
                        .catch((error) => {
                            console.log("Error getting documents: ", error);
                        });

                });
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });

    } else {

        firestore.collection("ECommerce").where(params2, "==", params3).orderBy("date", "desc")

            .get().then((querySnapshot) => {

                querySnapshot.forEach((ECDoc) => {
                    firestore.collection("Userinfo").where("userID", "==", ECDoc.data().ownerId)
                        .get()
                        .then((querySnapshot) => {
                            querySnapshot.forEach((UrDoc) => {


                                ExportDataList[exportIndex++] = [UrDoc.data().userName, UrDoc.data().userContact, ECDoc.data().quantity, ECDoc.data().title, ECDoc.data().category, ECDoc.data().price.replaceAll(',', ' '), ECDoc.data().discountPrice.replaceAll(',', ' '), ECDoc.data().unit, ECDoc.data().discount, ECDoc.data().district, ECDoc.data().tahsil, ECDoc.data().village, ECDoc.data().pinCode]

                            })
                        })


                })


            })

        firestore.collection("ECommerce").where(params2, "==", params3).limit(6).orderBy("date", "desc")
            .get()
            .then((querySnapshot) => {
                current_Category = params
                lastVisibleProduct_withFilter_No_All = querySnapshot.docs[querySnapshot.docs.length - 1];
                if (querySnapshot.docs.length == 0) {
                    document.getElementById("LoadMoreButton").style.display = "none"
                }
                else {
                    document.getElementById("LoadMoreButton").style.display = "flex"
                }
                querySnapshot.forEach((productdoc) => {
                    // doc.data() is never undefined for query doc snapshots

                    console.log("OwnerData", productdoc.data().ownerId)
                    firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                        .get()
                        .then((querySnapshot) => {
                            querySnapshot.forEach((userDoc) => {
                                // doc.data() is never undefined for query doc snapshots

                                var PriflePic;

                                var english = /^[A-Za-z0-9]*$/;
                                var check = userDoc.data().userName


                                if (userDoc.data().userProfilePic == "") {

                                    if (english.test(check.charAt(0)) == true) {
                                        var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                        switch (UserName_Copy.charAt(0).toLowerCase()) {

                                            case 'a':
                                                PriflePic = "/img/a.svg";
                                                break;

                                            case 'b':
                                                PriflePic = "/img/b.svg";
                                                break;

                                            case 'c':
                                                PriflePic = "/img/c.svg";
                                                break;

                                            case 'd':
                                                PriflePic = "/img/d.svg";
                                                break;

                                            case 'e':
                                                PriflePic = "/img/e.svg";
                                                break;

                                            case 'f':
                                                PriflePic = "/img/f.svg";
                                                break;

                                            case 'g':
                                                PriflePic = "/img/g.svg";
                                                break;

                                            case 'h':
                                                PriflePic = "/img/h.svg";
                                                break;

                                            case 'i':
                                                PriflePic = "/img/i.svg";
                                                break;

                                            case 'j':
                                                PriflePic = "/img/j.svg";
                                                break;

                                            case 'k':
                                                PriflePic = "/img/k.svg";
                                                break;

                                            case 'l':
                                                PriflePic = "/img/l.svg";
                                                break;

                                            case 'm':
                                                PriflePic = "/img/m.svg";
                                                break;

                                            case 'n':
                                                PriflePic = "/img/n.svg";
                                                break;

                                            case 'o':
                                                PriflePic = "/img/o.svg";
                                                break;

                                            case 'p':
                                                PriflePic = "/img/p.svg";
                                                break;

                                            case 'q':
                                                PriflePic = "/img/q.svg";
                                                break;

                                            case 'r':
                                                PriflePic = "/img/r.svg";
                                                break;

                                            case 's':
                                                PriflePic = "/img/s.svg";
                                                break;

                                            case 't':
                                                PriflePic = "/img/t.svg";
                                                break;

                                            case 'u':
                                                PriflePic = "/img/u.svg";
                                                break;

                                            case 'v':
                                                PriflePic = "/img/v.svg";
                                                break;

                                            case 'w':
                                                PriflePic = "/img/w.svg";
                                                break;

                                            case 'x':
                                                PriflePic = "/img/x.svg";
                                                break;

                                            case 'y':
                                                PriflePic = "/img/y.svg";
                                                break;

                                            case 'z':
                                                PriflePic = "/img/z.svg";
                                                break;

                                        }
                                    }
                                    else {
                                        PriflePic = "/img/person.svg";
                                    }
                                }
                                else {
                                    PriflePic = userDoc.data().userProfilePic

                                }


                                $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                            <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                <div class="card-body" >
                                                <div>
                                                <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                                                <span style="display: flex;
                                                justify-content: flex-end;">${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                <hr>
    
                                                </div>
                                                <div id="Product_title" style="display: flex;justify-content: space-between;">
                                        
                                                <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                </div>
                                                <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                            </div>
                                            <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                            <div id="utilities" style="
                                            display: flex;
                                            justify-content: space-around;
                                            margin-bottom: 1rem;
                                        
                                        
                                        ">
                                                <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                    <span  class="icon text-white-50" >
                                                        <i class="fas fa-info-circle"></i>
                                                    </span>
                                                    <span class="text" style="color: white">View</span>
                                                </a>
                                                <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-trash"></i>
                                                    </span>
                                                    <span class="text" style="color: white">Remove</span>
                                                </a>
                                            </div>
                                            </div>
                                            
                                            </div>`)
                                document.getElementById("LoadMoreButton").style.display = "flex";
                            });
                        })
                        .catch((error) => {
                            console.log("Error getting documents: ", error);
                        });

                });
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });

    }

}

function otherThanAll(params) {
    ExportDataList = [];
    exportIndex = 0;
    DistrictFilterSelected = undefined;
    TalukaFilterSelected = undefined;
    VillageFilterSlected = undefined;

    $('#District_Drop_Down').text("जिल्हा");
    $('#Tahasil').text("तालुका")
    $('#village').text("गाव")


    while (document.getElementById("userproductsList").childElementCount != 0) {

        document.getElementById("userproductsList").firstChild.remove();

    }
    if (params == "All") {
        current_Category = "All"

        All_products();
    }
    else {

        firestore.collection("ECommerce").where("category", "==", params).orderBy("date", "desc")

            .get().then((querySnapshot) => {

                querySnapshot.forEach((ECDoc) => {
                    firestore.collection("Userinfo").where("userID", "==", ECDoc.data().ownerId)
                        .get()
                        .then((querySnapshot) => {
                            querySnapshot.forEach((UrDoc) => {


                                ExportDataList[exportIndex++] = [UrDoc.data().userName, UrDoc.data().userContact, ECDoc.data().quantity, ECDoc.data().title, ECDoc.data().category, ECDoc.data().price.replaceAll(',', ' '), ECDoc.data().discountPrice.replaceAll(',', ' '), ECDoc.data().unit, ECDoc.data().discount, ECDoc.data().district, ECDoc.data().tahsil, ECDoc.data().village, ECDoc.data().pinCode]

                            })
                        })


                })


            })


        firestore.collection("ECommerce").where("category", "==", params).limit(6).orderBy("date", "desc")
            .get()
            .then((querySnapshot) => {
                current_Category = params
                lastVisibleProduct_other = querySnapshot.docs[querySnapshot.docs.length - 1];
                if (querySnapshot.docs.length == 0) {
                    document.getElementById("LoadMoreButton").style.display = "none"
                }
                else {
                    document.getElementById("LoadMoreButton").style.display = "flex"
                }
                querySnapshot.forEach((productdoc) => {
                    // doc.data() is never undefined for query doc snapshots


                    firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                        .get()
                        .then((querySnapshot) => {
                            querySnapshot.forEach((userDoc) => {
                                // doc.data() is never undefined for query doc snapshots

                                var PriflePic;

                                var english = /^[A-Za-z0-9]*$/;
                                var check = userDoc.data().userName


                                if (userDoc.data().userProfilePic == "") {

                                    if (english.test(check.charAt(0)) == true) {
                                        var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                        switch (UserName_Copy.charAt(0).toLowerCase()) {

                                            case 'a':
                                                PriflePic = "/img/a.svg";
                                                break;

                                            case 'b':
                                                PriflePic = "/img/b.svg";
                                                break;

                                            case 'c':
                                                PriflePic = "/img/c.svg";
                                                break;

                                            case 'd':
                                                PriflePic = "/img/d.svg";
                                                break;

                                            case 'e':
                                                PriflePic = "/img/e.svg";
                                                break;

                                            case 'f':
                                                PriflePic = "/img/f.svg";
                                                break;

                                            case 'g':
                                                PriflePic = "/img/g.svg";
                                                break;

                                            case 'h':
                                                PriflePic = "/img/h.svg";
                                                break;

                                            case 'i':
                                                PriflePic = "/img/i.svg";
                                                break;

                                            case 'j':
                                                PriflePic = "/img/j.svg";
                                                break;

                                            case 'k':
                                                PriflePic = "/img/k.svg";
                                                break;

                                            case 'l':
                                                PriflePic = "/img/l.svg";
                                                break;

                                            case 'm':
                                                PriflePic = "/img/m.svg";
                                                break;

                                            case 'n':
                                                PriflePic = "/img/n.svg";
                                                break;

                                            case 'o':
                                                PriflePic = "/img/o.svg";
                                                break;

                                            case 'p':
                                                PriflePic = "/img/p.svg";
                                                break;

                                            case 'q':
                                                PriflePic = "/img/q.svg";
                                                break;

                                            case 'r':
                                                PriflePic = "/img/r.svg";
                                                break;

                                            case 's':
                                                PriflePic = "/img/s.svg";
                                                break;

                                            case 't':
                                                PriflePic = "/img/t.svg";
                                                break;

                                            case 'u':
                                                PriflePic = "/img/u.svg";
                                                break;

                                            case 'v':
                                                PriflePic = "/img/v.svg";
                                                break;

                                            case 'w':
                                                PriflePic = "/img/w.svg";
                                                break;

                                            case 'x':
                                                PriflePic = "/img/x.svg";
                                                break;

                                            case 'y':
                                                PriflePic = "/img/y.svg";
                                                break;

                                            case 'z':
                                                PriflePic = "/img/z.svg";
                                                break;

                                        }
                                    }
                                    else {
                                        PriflePic = "/img/person.svg";
                                    }
                                }
                                else {
                                    PriflePic = userDoc.data().userProfilePic

                                }


                                $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                            <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                <div class="card-body" >
                                                <div>
                                                <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                                                <span style="display: flex;
                                                justify-content: flex-end;">${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                <hr>

                                                </div>
                                                <div id="Product_title" style="display: flex;justify-content: space-between;">
                                        
                                                <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                </div>
                                                <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                            </div>
                                            <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                            <div id="utilities" style="
                                            display: flex;
                                            justify-content: space-around;
                                            margin-bottom: 1rem;
                                        
                                        
                                        ">
                                                <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                    <span  class="icon text-white-50" >
                                                        <i class="fas fa-info-circle"></i>
                                                    </span>
                                                    <span class="text" style="color: white">View</span>
                                                </a>
                                                <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-trash"></i>
                                                    </span>
                                                    <span class="text" style="color: white">Remove</span>
                                                </a>
                                            </div>
                                            </div>
                                            
                                            </div>`)
                                document.getElementById("LoadMoreButton").style.display = "flex";
                            });
                        })
                        .catch((error) => {
                            console.log("Error getting documents: ", error);
                        });

                });
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });
    }
}


function GetMoreproduct() {
    console.log("current_Category", current_Category);


    if (DistrictFilterSelected !== undefined || TalukaFilterSelected !== undefined || VillageFilterSlected || undefined) {
        if (current_Category !== "All") {

            firestore.collection("ECommerce").where("category", "==", current_Category).where(Pagination_index_1, "==", Pagination_index_2).limit(6).orderBy("date", "desc").startAfter(lastVisibleProduct_withFilter)
                .get()
                .then((querySnapshot) => {

                    lastVisibleProduct_withFilter = querySnapshot.docs[querySnapshot.docs.length - 1];
                    if (querySnapshot.docs.length == 0) {
                        document.getElementById("LoadMoreButton").style.display = "none"
                    }
                    else {
                        document.getElementById("LoadMoreButton").style.display = "flex"
                    }
                    querySnapshot.forEach((productdoc) => {
                        // doc.data() is never undefined for query doc snapshots

                        console.log("OwnerData", productdoc.data().ownerId)
                        firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                            .get()
                            .then((querySnapshot) => {
                                querySnapshot.forEach((userDoc) => {
                                    // doc.data() is never undefined for query doc snapshots

                                    var PriflePic;

                                    var english = /^[A-Za-z0-9]*$/;
                                    var check = userDoc.data().userName


                                    if (userDoc.data().userProfilePic == "") {

                                        if (english.test(check.charAt(0)) == true) {
                                            var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                            switch (UserName_Copy.charAt(0).toLowerCase()) {

                                                case 'a':
                                                    PriflePic = "/img/a.svg";
                                                    break;

                                                case 'b':
                                                    PriflePic = "/img/b.svg";
                                                    break;

                                                case 'c':
                                                    PriflePic = "/img/c.svg";
                                                    break;

                                                case 'd':
                                                    PriflePic = "/img/d.svg";
                                                    break;

                                                case 'e':
                                                    PriflePic = "/img/e.svg";
                                                    break;

                                                case 'f':
                                                    PriflePic = "/img/f.svg";
                                                    break;

                                                case 'g':
                                                    PriflePic = "/img/g.svg";
                                                    break;

                                                case 'h':
                                                    PriflePic = "/img/h.svg";
                                                    break;

                                                case 'i':
                                                    PriflePic = "/img/i.svg";
                                                    break;

                                                case 'j':
                                                    PriflePic = "/img/j.svg";
                                                    break;

                                                case 'k':
                                                    PriflePic = "/img/k.svg";
                                                    break;

                                                case 'l':
                                                    PriflePic = "/img/l.svg";
                                                    break;

                                                case 'm':
                                                    PriflePic = "/img/m.svg";
                                                    break;

                                                case 'n':
                                                    PriflePic = "/img/n.svg";
                                                    break;

                                                case 'o':
                                                    PriflePic = "/img/o.svg";
                                                    break;

                                                case 'p':
                                                    PriflePic = "/img/p.svg";
                                                    break;

                                                case 'q':
                                                    PriflePic = "/img/q.svg";
                                                    break;

                                                case 'r':
                                                    PriflePic = "/img/r.svg";
                                                    break;

                                                case 's':
                                                    PriflePic = "/img/s.svg";
                                                    break;

                                                case 't':
                                                    PriflePic = "/img/t.svg";
                                                    break;

                                                case 'u':
                                                    PriflePic = "/img/u.svg";
                                                    break;

                                                case 'v':
                                                    PriflePic = "/img/v.svg";
                                                    break;

                                                case 'w':
                                                    PriflePic = "/img/w.svg";
                                                    break;

                                                case 'x':
                                                    PriflePic = "/img/x.svg";
                                                    break;

                                                case 'y':
                                                    PriflePic = "/img/y.svg";
                                                    break;

                                                case 'z':
                                                    PriflePic = "/img/z.svg";
                                                    break;

                                            }
                                        }
                                        else {
                                            PriflePic = "/img/person.svg";
                                        }
                                    }
                                    else {
                                        PriflePic = userDoc.data().userProfilePic

                                    }


                                    $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                                <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                    <div class="card-body" >
                                                    <div>
                                                    <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                    <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                                                    <span style="display: flex;
                                                    justify-content: flex-end;">${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                    <hr>

                                                    </div>
                                                    <div id="Product_title" style="display: flex;justify-content: space-between;">
                                            
                                                    <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                    </div>
                                                    <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                                </div>
                                                <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                                <div id="utilities" style="
                                                display: flex;
                                                justify-content: space-around;
                                                margin-bottom: 1rem;
                                            
                                            
                                            ">
                                                    <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                        <span  class="icon text-white-50" >
                                                            <i class="fas fa-info-circle"></i>
                                                        </span>
                                                        <span class="text" style="color: white">View</span>
                                                    </a>
                                                    <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                        <span class="icon text-white-50">
                                                            <i class="fas fa-trash"></i>
                                                        </span>
                                                        <span class="text" style="color: white">Remove</span>
                                                    </a>
                                                </div>
                                                </div>
                                                
                                                </div>`)
                                    document.getElementById("LoadMoreButton").style.display = "flex";
                                });
                            })
                            .catch((error) => {
                                console.log("Error getting documents: ", error);
                            });

                    });
                })
                .catch((error) => {
                    console.log("Error getting documents: ", error);
                });



        }
        else {
            firestore.collection("ECommerce").where(Pagination_index_1, "==", Pagination_index_2).limit(6).orderBy("date", "desc").startAfter(lastVisibleProduct_withFilter_No_All)
                .get()
                .then((querySnapshot) => {

                    lastVisibleProduct_withFilter_No_All = querySnapshot.docs[querySnapshot.docs.length - 1];
                    if (querySnapshot.docs.length == 0) {
                        document.getElementById("LoadMoreButton").style.display = "none"
                    }
                    else {
                        document.getElementById("LoadMoreButton").style.display = "flex"
                    }
                    querySnapshot.forEach((productdoc) => {
                        // doc.data() is never undefined for query doc snapshots

                        console.log("OwnerData", productdoc.data().ownerId)
                        firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                            .get()
                            .then((querySnapshot) => {
                                querySnapshot.forEach((userDoc) => {
                                    // doc.data() is never undefined for query doc snapshots

                                    var PriflePic;

                                    var english = /^[A-Za-z0-9]*$/;
                                    var check = userDoc.data().userName


                                    if (userDoc.data().userProfilePic == "") {

                                        if (english.test(check.charAt(0)) == true) {
                                            var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                            switch (UserName_Copy.charAt(0).toLowerCase()) {

                                                case 'a':
                                                    PriflePic = "/img/a.svg";
                                                    break;

                                                case 'b':
                                                    PriflePic = "/img/b.svg";
                                                    break;

                                                case 'c':
                                                    PriflePic = "/img/c.svg";
                                                    break;

                                                case 'd':
                                                    PriflePic = "/img/d.svg";
                                                    break;

                                                case 'e':
                                                    PriflePic = "/img/e.svg";
                                                    break;

                                                case 'f':
                                                    PriflePic = "/img/f.svg";
                                                    break;

                                                case 'g':
                                                    PriflePic = "/img/g.svg";
                                                    break;

                                                case 'h':
                                                    PriflePic = "/img/h.svg";
                                                    break;

                                                case 'i':
                                                    PriflePic = "/img/i.svg";
                                                    break;

                                                case 'j':
                                                    PriflePic = "/img/j.svg";
                                                    break;

                                                case 'k':
                                                    PriflePic = "/img/k.svg";
                                                    break;

                                                case 'l':
                                                    PriflePic = "/img/l.svg";
                                                    break;

                                                case 'm':
                                                    PriflePic = "/img/m.svg";
                                                    break;

                                                case 'n':
                                                    PriflePic = "/img/n.svg";
                                                    break;

                                                case 'o':
                                                    PriflePic = "/img/o.svg";
                                                    break;

                                                case 'p':
                                                    PriflePic = "/img/p.svg";
                                                    break;

                                                case 'q':
                                                    PriflePic = "/img/q.svg";
                                                    break;

                                                case 'r':
                                                    PriflePic = "/img/r.svg";
                                                    break;

                                                case 's':
                                                    PriflePic = "/img/s.svg";
                                                    break;

                                                case 't':
                                                    PriflePic = "/img/t.svg";
                                                    break;

                                                case 'u':
                                                    PriflePic = "/img/u.svg";
                                                    break;

                                                case 'v':
                                                    PriflePic = "/img/v.svg";
                                                    break;

                                                case 'w':
                                                    PriflePic = "/img/w.svg";
                                                    break;

                                                case 'x':
                                                    PriflePic = "/img/x.svg";
                                                    break;

                                                case 'y':
                                                    PriflePic = "/img/y.svg";
                                                    break;

                                                case 'z':
                                                    PriflePic = "/img/z.svg";
                                                    break;

                                            }
                                        }
                                        else {
                                            PriflePic = "/img/person.svg";
                                        }
                                    }
                                    else {
                                        PriflePic = userDoc.data().userProfilePic

                                    }


                                    $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                                <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                    <div class="card-body" >
                                                    <div>
                                                    <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                    <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                                                    <span style="display: flex;
                                                    justify-content: flex-end;">${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                    <hr>

                                                    </div>
                                                    <div id="Product_title" style="display: flex;justify-content: space-between;">
                                            
                                                    <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                    </div>
                                                    <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                                </div>
                                                <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                                <div id="utilities" style="
                                                display: flex;
                                                justify-content: space-around;
                                                margin-bottom: 1rem;
                                            
                                            
                                            ">
                                                    <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                        <span  class="icon text-white-50" >
                                                            <i class="fas fa-info-circle"></i>
                                                        </span>
                                                        <span class="text" style="color: white">View</span>
                                                    </a>
                                                    <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                        <span class="icon text-white-50">
                                                            <i class="fas fa-trash"></i>
                                                        </span>
                                                        <span class="text" style="color: white">Remove</span>
                                                    </a>
                                                </div>
                                                </div>
                                                
                                                </div>`)
                                    document.getElementById("LoadMoreButton").style.display = "flex";
                                });
                            })
                            .catch((error) => {
                                console.log("Error getting documents: ", error);
                            });

                    });
                })
                .catch((error) => {
                    console.log("Error getting documents: ", error);
                });

        }

    } else {

        if (current_Category !== "All") {

            firestore.collection("ECommerce").where("category", "==", current_Category).limit(6).orderBy("date", "desc").startAfter(lastVisibleProduct_other)
                .get()
                .then((querySnapshot) => {

                    lastVisibleProduct_other = querySnapshot.docs[querySnapshot.docs.length - 1];
                    if (querySnapshot.docs.length == 0) {
                        document.getElementById("LoadMoreButton").style.display = "none"
                    }
                    else {
                        document.getElementById("LoadMoreButton").style.display = "flex"
                    }
                    querySnapshot.forEach((productdoc) => {
                        // doc.data() is never undefined for query doc snapshots

                        console.log("OwnerData", productdoc.data().ownerId)
                        firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                            .get()
                            .then((querySnapshot) => {
                                querySnapshot.forEach((userDoc) => {
                                    // doc.data() is never undefined for query doc snapshots

                                    var PriflePic;

                                    var english = /^[A-Za-z0-9]*$/;
                                    var check = userDoc.data().userName


                                    if (userDoc.data().userProfilePic == "") {

                                        if (english.test(check.charAt(0)) == true) {
                                            var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                            switch (UserName_Copy.charAt(0).toLowerCase()) {

                                                case 'a':
                                                    PriflePic = "/img/a.svg";
                                                    break;

                                                case 'b':
                                                    PriflePic = "/img/b.svg";
                                                    break;

                                                case 'c':
                                                    PriflePic = "/img/c.svg";
                                                    break;

                                                case 'd':
                                                    PriflePic = "/img/d.svg";
                                                    break;

                                                case 'e':
                                                    PriflePic = "/img/e.svg";
                                                    break;

                                                case 'f':
                                                    PriflePic = "/img/f.svg";
                                                    break;

                                                case 'g':
                                                    PriflePic = "/img/g.svg";
                                                    break;

                                                case 'h':
                                                    PriflePic = "/img/h.svg";
                                                    break;

                                                case 'i':
                                                    PriflePic = "/img/i.svg";
                                                    break;

                                                case 'j':
                                                    PriflePic = "/img/j.svg";
                                                    break;

                                                case 'k':
                                                    PriflePic = "/img/k.svg";
                                                    break;

                                                case 'l':
                                                    PriflePic = "/img/l.svg";
                                                    break;

                                                case 'm':
                                                    PriflePic = "/img/m.svg";
                                                    break;

                                                case 'n':
                                                    PriflePic = "/img/n.svg";
                                                    break;

                                                case 'o':
                                                    PriflePic = "/img/o.svg";
                                                    break;

                                                case 'p':
                                                    PriflePic = "/img/p.svg";
                                                    break;

                                                case 'q':
                                                    PriflePic = "/img/q.svg";
                                                    break;

                                                case 'r':
                                                    PriflePic = "/img/r.svg";
                                                    break;

                                                case 's':
                                                    PriflePic = "/img/s.svg";
                                                    break;

                                                case 't':
                                                    PriflePic = "/img/t.svg";
                                                    break;

                                                case 'u':
                                                    PriflePic = "/img/u.svg";
                                                    break;

                                                case 'v':
                                                    PriflePic = "/img/v.svg";
                                                    break;

                                                case 'w':
                                                    PriflePic = "/img/w.svg";
                                                    break;

                                                case 'x':
                                                    PriflePic = "/img/x.svg";
                                                    break;

                                                case 'y':
                                                    PriflePic = "/img/y.svg";
                                                    break;

                                                case 'z':
                                                    PriflePic = "/img/z.svg";
                                                    break;

                                            }
                                        }
                                        else {
                                            PriflePic = "/img/person.svg";
                                        }
                                    }
                                    else {
                                        PriflePic = userDoc.data().userProfilePic

                                    }


                                    $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                            <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                <div class="card-body" >
                                                <div>
                                                <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                                                <span style="display: flex;
                                                justify-content: flex-end;">${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                <hr>

                                                </div>
                                                <div id="Product_title" style="display: flex;justify-content: space-between;">
                                        
                                                <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                </div>
                                                <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                            </div>
                                            <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                            <div id="utilities" style="
                                            display: flex;
                                            justify-content: space-around;
                                            margin-bottom: 1rem;
                                        
                                        
                                        ">
                                                <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                    <span  class="icon text-white-50" >
                                                        <i class="fas fa-info-circle"></i>
                                                    </span>
                                                    <span class="text" style="color: white">View</span>
                                                </a>
                                                <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-trash"></i>
                                                    </span>
                                                    <span class="text" style="color: white">Remove</span>
                                                </a>
                                            </div>
                                            </div>
                                            
                                            </div>`)
                                    document.getElementById("LoadMoreButton").style.display = "flex";
                                });
                            })
                            .catch((error) => {
                                console.log("Error getting documents: ", error);
                            });

                    });
                })
                .catch((error) => {
                    console.log("Error getting documents: ", error);
                });



        }
        else {
            firestore.collection("ECommerce").limit(6).orderBy("date", "desc").startAfter(lastVisibleProduct)
                .get()
                .then((querySnapshot) => {

                    lastVisibleProduct = querySnapshot.docs[querySnapshot.docs.length - 1];
                    if (querySnapshot.docs.length == 0) {
                        document.getElementById("LoadMoreButton").style.display = "none"
                    }
                    else {
                        document.getElementById("LoadMoreButton").style.display = "flex"
                    }
                    querySnapshot.forEach((productdoc) => {
                        // doc.data() is never undefined for query doc snapshots

                        console.log("OwnerData", productdoc.data().ownerId)
                        firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                            .get()
                            .then((querySnapshot) => {
                                querySnapshot.forEach((userDoc) => {
                                    // doc.data() is never undefined for query doc snapshots

                                    var PriflePic;

                                    var english = /^[A-Za-z0-9]*$/;
                                    var check = userDoc.data().userName


                                    if (userDoc.data().userProfilePic == "") {

                                        if (english.test(check.charAt(0)) == true) {
                                            var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                            switch (UserName_Copy.charAt(0).toLowerCase()) {

                                                case 'a':
                                                    PriflePic = "/img/a.svg";
                                                    break;

                                                case 'b':
                                                    PriflePic = "/img/b.svg";
                                                    break;

                                                case 'c':
                                                    PriflePic = "/img/c.svg";
                                                    break;

                                                case 'd':
                                                    PriflePic = "/img/d.svg";
                                                    break;

                                                case 'e':
                                                    PriflePic = "/img/e.svg";
                                                    break;

                                                case 'f':
                                                    PriflePic = "/img/f.svg";
                                                    break;

                                                case 'g':
                                                    PriflePic = "/img/g.svg";
                                                    break;

                                                case 'h':
                                                    PriflePic = "/img/h.svg";
                                                    break;

                                                case 'i':
                                                    PriflePic = "/img/i.svg";
                                                    break;

                                                case 'j':
                                                    PriflePic = "/img/j.svg";
                                                    break;

                                                case 'k':
                                                    PriflePic = "/img/k.svg";
                                                    break;

                                                case 'l':
                                                    PriflePic = "/img/l.svg";
                                                    break;

                                                case 'm':
                                                    PriflePic = "/img/m.svg";
                                                    break;

                                                case 'n':
                                                    PriflePic = "/img/n.svg";
                                                    break;

                                                case 'o':
                                                    PriflePic = "/img/o.svg";
                                                    break;

                                                case 'p':
                                                    PriflePic = "/img/p.svg";
                                                    break;

                                                case 'q':
                                                    PriflePic = "/img/q.svg";
                                                    break;

                                                case 'r':
                                                    PriflePic = "/img/r.svg";
                                                    break;

                                                case 's':
                                                    PriflePic = "/img/s.svg";
                                                    break;

                                                case 't':
                                                    PriflePic = "/img/t.svg";
                                                    break;

                                                case 'u':
                                                    PriflePic = "/img/u.svg";
                                                    break;

                                                case 'v':
                                                    PriflePic = "/img/v.svg";
                                                    break;

                                                case 'w':
                                                    PriflePic = "/img/w.svg";
                                                    break;

                                                case 'x':
                                                    PriflePic = "/img/x.svg";
                                                    break;

                                                case 'y':
                                                    PriflePic = "/img/y.svg";
                                                    break;

                                                case 'z':
                                                    PriflePic = "/img/z.svg";
                                                    break;

                                            }
                                        }
                                        else {
                                            PriflePic = "/img/person.svg";
                                        }
                                    }
                                    else {
                                        PriflePic = userDoc.data().userProfilePic

                                    }


                                    $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                            <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                <div class="card-body" >
                                                <div>
                                                <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                                                <span style="display: flex;
                                                justify-content: flex-end;">${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                <hr>

                                                </div>
                                                <div id="Product_title" style="display: flex;justify-content: space-between;">
                                        
                                                <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                </div>
                                                <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                            </div>
                                            <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                            <div id="utilities" style="
                                            display: flex;
                                            justify-content: space-around;
                                            margin-bottom: 1rem;
                                        
                                        
                                        ">
                                                <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                    <span  class="icon text-white-50" >
                                                        <i class="fas fa-info-circle"></i>
                                                    </span>
                                                    <span class="text" style="color: white">View</span>
                                                </a>
                                                <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-trash"></i>
                                                    </span>
                                                    <span class="text" style="color: white">Remove</span>
                                                </a>
                                            </div>
                                            </div>
                                            
                                            </div>`)
                                    document.getElementById("LoadMoreButton").style.display = "flex";
                                });
                            })
                            .catch((error) => {
                                console.log("Error getting documents: ", error);
                            });

                    });
                })
                .catch((error) => {
                    console.log("Error getting documents: ", error);
                });

        }

    }

}

function openProductInfo(id, PriflePicForOrder, UserName, contact) {
    tags = [] 
    tagsKey = [];
    ResetModal();
    console.log("this is modal fucntiom", UserName)

    id_Edits = id,
    PriflePicForOrder_Edits =  PriflePicForOrder,
    UserName_Edits = UserName,
    contact_edits = contact
    var docRef = firestore.collection("ECommerce").doc(id);

    docRef.get().then((doc) => {
        if (doc.exists) {

            while(document.getElementById("tagContainer").childElementCount!==0){
                document.getElementById("tagContainer").firstChild.remove();
            }
            if(doc.data().keysToShow!==undefined){
                doc.data().keysToShow.forEach((e)=>{
                    $('#tagContainer').append(`<span id="${e}" class="badge badge-pill badge-primary">${e}<span class="closetag" onclick="removeTags(this)">×</span></span>`)
                })
            }
            
            while(document.getElementById("Unit_other").childElementCount!==0){
                document.getElementById("Unit_other").firstChild.remove();
            }
            while(document.getElementById("Unit_Edit").childElementCount!==0){
                document.getElementById("Unit_Edit").firstChild.remove();
            }

            document.getElementById("product-Category").innerText = doc.data().category
        if(document.getElementById("product-Category").innerText == "शेतमाल"){
           
            शेतमाल.forEach((e)=>{
                var Category = $(`<option >${e}</option>`);
                Category.appendTo('#Unit_other');
            })
        }else if(document.getElementById("product-Category").innerText == "अवजारे व वाहने"){
            // alert("अवजारे व वाहने")
    
            अवजारे_व_वाहने.forEach((e)=>{
                var Category = $(`<option >${e}</option>`);
                Category.appendTo('#Unit_other');
            })
           
        }else if(document.getElementById("product-Category").innerText == "भाडेतत्वावर सेवा"){
            भाडेतत्वावर_सेवा.forEach((e)=>{
                var Category = $(`<option >${e}</option>`);
                Category.appendTo('#Unit_other');
            })
        }else if(document.getElementById("product-Category").innerText == "बी-बियाणे खरेदी विक्री"){
            बी_बियाणे_खरेदी_विक्री.forEach((e)=>{
                var Category = $(`<option >${e}</option>`);
                Category.appendTo('#Unit_other');
            })
        }else if(document.getElementById("product-Category").innerText == "रोपवाटीका"){
            रोपवाटीका.forEach((e)=>{
                var Category = $(`<option >${e}</option>`);
                Category.appendTo('#Unit_other');
            })
        }else if(document.getElementById("product-Category").innerText == "खते"){
            खते.forEach((e)=>{
                var Category = $(`<option >${e}</option>`);
                Category.appendTo('#Unit_other');
            })
        }else if(document.getElementById("product-Category").innerText == "जमीन खरेदी विक्री"){
            landUnits.forEach((e)=>{
                var Category = $(`<option >${e}</option>`);
                Category.appendTo('#Unit_other');
            })
        }  

            if (doc.data().unit !== "noUnit" || doc.data().unit !== "") {
                console.log("Document data:", doc.data());
                document.getElementById("product_tile").innerText = doc.data().title
                document.getElementById("product-post-img").src = doc.data().image
                document.getElementById("product-discription").innerHTML = doc.data().description
                document.getElementById("product-price").innerText = `${doc.data().price} / ${doc.data().unit}`
                document.getElementById("discount-price").innerHTML = `${doc.data().discountPrice} / ${doc.data().unit}`
                document.getElementById("Unit_other").value = doc.data().unit
                document.getElementById("discount-in-percent").innerText = doc.data().discount
                document.getElementById("quantity").innerText = `${doc.data().quantity}`
                document.getElementById("Product_District").innerText = doc.data().district
                document.getElementById("Product_Taluka").innerText = doc.data().tahsil
                document.getElementById("Product_Village").innerText = doc.data().village
                document.getElementById("product-user-photo").src = PriflePicForOrder
                document.getElementById("product-user-name").innerText = UserName
                document.getElementById("product-owner-contact").innerText = contact

                
            } else {
                console.log("Document data:", doc.data());
                document.getElementById("product_tile").innerText = doc.data().title
                document.getElementById("product-post-img").src = doc.data().image
                document.getElementById("product-Category").innerText = doc.data().category
                document.getElementById("product-discription").innerHTML = doc.data().description
                document.getElementById("product-price").innerText = doc.data().price
                document.getElementById("discount-price").innerHTML = doc.data().discountPrice
                // document.getElementById("unitofProduct").innerHTML = doc.data().unit
                document.getElementById("discount-in-percent").innerText = doc.data().discount
                document.getElementById("quantity").innerText = doc.data().quantity
                document.getElementById("Product_District").innerText = doc.data().district
                document.getElementById("Product_Taluka").innerText = doc.data().tahsil
                document.getElementById("Product_Village").innerText = doc.data().village
                document.getElementById("product-user-photo").src = PriflePicForOrder
                document.getElementById("product-user-name").innerText = UserName
                document.getElementById("product-owner-contact").innerText = contact

               
            }

            if(doc.data().keysToShow!==undefined){
                doc.data().keysToShow.forEach((e)=>{
                tags.push(e);
                createKeywords(e);
                })
            }

            $('#viewProductModelPost').modal();
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });





    //    document.getElementById("profile_pic")
    // var PriflePic;

    // var english = /^[A-Za-z0-9]*$/;
    // var check = doc.data().userName


    // if(doc.data().userProfilePic == ""){

    //     if( english.test(check.charAt(0)) == true){
    //         var UserName_Copy = (doc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
    //         switch (UserName_Copy.charAt(0).toLowerCase()) {

    //             case 'a':
    //                 PriflePic= "/img/a.svg";
    //                 break;

    //             case 'b':
    //                 PriflePic= "/img/b.svg";
    //                 break;

    //             case 'c':
    //                 PriflePic= "/img/c.svg";
    //                 break;

    //             case 'd':
    //                 PriflePic= "/img/d.svg";
    //                 break;

    //             case 'e':
    //                 PriflePic= "/img/e.svg";
    //                 break;

    //             case 'f':
    //                 PriflePic= "/img/f.svg";
    //                 break;

    //             case 'g':
    //                 PriflePic= "/img/g.svg";
    //                 break;

    //             case 'h':
    //                 PriflePic= "/img/h.svg";
    //                 break;

    //             case 'i':
    //                 PriflePic= "/img/i.svg";
    //                 break;

    //             case 'j':
    //                 PriflePic= "/img/j.svg";
    //                 break;

    //             case 'k':
    //                 PriflePic= "/img/k.svg";
    //                 break;

    //             case 'l':
    //                 PriflePic= "/img/l.svg";
    //                 break;

    //             case 'm':
    //                 PriflePic= "/img/m.svg";
    //                 break;

    //             case 'n':
    //                 PriflePic= "/img/n.svg";
    //                 break;

    //             case 'o':
    //                 PriflePic= "/img/o.svg";
    //                 break;

    //             case 'p':
    //                 PriflePic= "/img/p.svg";
    //                 break;

    //             case 'q':
    //                 PriflePic= "/img/q.svg";
    //                 break;

    //             case 'r':
    //                 PriflePic= "/img/r.svg";
    //                 break;

    //             case 's':
    //                 PriflePic= "/img/s.svg";
    //                 break;

    //             case 't':
    //                 PriflePic= "/img/t.svg";
    //                 break;

    //             case 'u':
    //                 PriflePic= "/img/u.svg";
    //                 break;

    //             case 'v':
    //                 PriflePic= "/img/v.svg";
    //                 break;

    //             case 'w':
    //                 PriflePic= "/img/w.svg";
    //                 break;

    //             case 'x':
    //                 PriflePic= "/img/x.svg";
    //                 break;

    //             case 'y':
    //                 PriflePic= "/img/y.svg";
    //                 break;

    //             case 'z':
    //                 PriflePic= "/img/z.svg";
    //                 break;

    //     }
    //     }
    //     else{
    //         PriflePic= "/img/person.svg";
    //     }  
    //     }
    //     else{
    //         PriflePic = doc.data().userProfilePic

    //     } 
    // document.getElementById("product_tile").innerText = doc.data().title
    // document.getElementById("product-post-img").src = doc.data().image
    // document.getElementById("product-discription").innerHTML = doc.data().description
    // document.getElementById("product-price").innerText = doc.data().price
    // document.getElementById("discount-price").innerHTML = doc.data().discountPrice
    // document.getElementById("discount-in-percent").innerText = doc.data().discount
    // document.getElementById("quantity").innerText =  doc.data().quantity



    // $('#viewProductModelPost').modal();


}

deleteproduct = (id) => {

    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Product",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        n && firestore.collection("ECommerce").doc(id).delete()


            .then(function () {
                let subsWrapper = document.getElementById(`${id}`)
                subsWrapper.remove();
                swal("Successfull", "Product Deleted ", "success")
            }).catch(function (e) {
                console.error("Error removing document: ", e)
            })
    })
}

function getProfile(params) {

    firestore.collection("Userinfo").where("userID", "==", params)
        .get()
        .then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots


                $("#pp").append(`<img src="${doc.data().userProfilePic}" class="rounded " alt="Responsive image" style="width: 50px;height=50px">`)
                console.log(doc.id, " => ", doc.data().userName);
            });
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });



}

function ResetSearchInput() {

    var USERLISTCHILD = document.getElementById("userproductsList");
    if (document.getElementById("Search_Product").value == "") {
        console.log("Reset Data");
        while (USERLISTCHILD.childElementCount !== 0) {
            USERLISTCHILD.firstChild.remove();
        }

        if (current_Category == "All") {
            All_products();

        }
        else {
            otherThanAll(current_Category);
        }

    }


}

function searchUser(params) {
    document.getElementById("LoadMoreButton").style.display = "none";
    console.log("Data", counter++);

    var USERLISTCHILD = document.getElementById("userproductsList");
    var searchboxtext = document.getElementById("Search_Product").value.toLowerCase();
    //  console.log(searchboxtext);
    if (searchboxtext !== "") {
        while (USERLISTCHILD.childElementCount !== 0) {
            USERLISTCHILD.firstChild.remove();
        }
        //  document.getElementById("load").style.display = "none"

    } else {
        while (USERLISTCHILD.childElementCount !== 0) {
            USERLISTCHILD.firstChild.remove();
        }

        if (current_Category == "All") {
            All_products();

        }
        else {
            otherThanAll(current_Category);
        }


        // document.getElementById("load").style.display = ""
    }

    if (searchboxtext !== "") {
        console.log(searchboxtext);

        if (current_Category == "All") {
            firestore.collection("ECommerce").where("keywords", "array-contains", searchboxtext).limit(1).orderBy("date").get().then(function (querySnapshot) {
                var index = 0;
                querySnapshot.forEach((productdoc) => {

                    console.log("Searched Data", productdoc.data());

                    // searchData[index++]= [e.id,e.data().date.toDate(),e.data().userName,e.data().userProfilePic]  

                    firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                        .get()
                        .then((querySnapshot) => {
                            querySnapshot.forEach((userDoc) => {

                                // doc.data() is never undefined for query doc snapshots
                                var PriflePic;

                                var english = /^[A-Za-z0-9]*$/;
                                var check = userDoc.data().userName

                                if (userDoc.data().userProfilePic == "") {

                                    if (english.test(check.charAt(0)) == true) {
                                        var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                        switch (UserName_Copy.charAt(0).toLowerCase()) {

                                            case 'a':
                                                PriflePic = "/img/a.svg";
                                                break;

                                            case 'b':
                                                PriflePic = "/img/b.svg";
                                                break;

                                            case 'c':
                                                PriflePic = "/img/c.svg";
                                                break;

                                            case 'd':
                                                PriflePic = "/img/d.svg";
                                                break;

                                            case 'e':
                                                PriflePic = "/img/e.svg";
                                                break;

                                            case 'f':
                                                PriflePic = "/img/f.svg";
                                                break;

                                            case 'g':
                                                PriflePic = "/img/g.svg";
                                                break;

                                            case 'h':
                                                PriflePic = "/img/h.svg";
                                                break;

                                            case 'i':
                                                PriflePic = "/img/i.svg";
                                                break;

                                            case 'j':
                                                PriflePic = "/img/j.svg";
                                                break;

                                            case 'k':
                                                PriflePic = "/img/k.svg";
                                                break;

                                            case 'l':
                                                PriflePic = "/img/l.svg";
                                                break;

                                            case 'm':
                                                PriflePic = "/img/m.svg";
                                                break;

                                            case 'n':
                                                PriflePic = "/img/n.svg";
                                                break;

                                            case 'o':
                                                PriflePic = "/img/o.svg";
                                                break;

                                            case 'p':
                                                PriflePic = "/img/p.svg";
                                                break;

                                            case 'q':
                                                PriflePic = "/img/q.svg";
                                                break;

                                            case 'r':
                                                PriflePic = "/img/r.svg";
                                                break;

                                            case 's':
                                                PriflePic = "/img/s.svg";
                                                break;

                                            case 't':
                                                PriflePic = "/img/t.svg";
                                                break;

                                            case 'u':
                                                PriflePic = "/img/u.svg";
                                                break;

                                            case 'v':
                                                PriflePic = "/img/v.svg";
                                                break;

                                            case 'w':
                                                PriflePic = "/img/w.svg";
                                                break;

                                            case 'x':
                                                PriflePic = "/img/x.svg";
                                                break;

                                            case 'y':
                                                PriflePic = "/img/y.svg";
                                                break;

                                            case 'z':
                                                PriflePic = "/img/z.svg";
                                                break;

                                        }
                                    }
                                    else {
                                        PriflePic = "/img/person.svg";
                                    }
                                }
                                else {
                                    PriflePic = userDoc.data().userProfilePic

                                }
                                $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                                <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                    <div class="card-body" >
                                                    <div>
                                                    <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                    <span style="margin-left:1rem;color: black;
    font-weight: 700"> ${userDoc.data().userName}</span>
                                                    <hr>
    
                                                    </div>
                                                    <div id="Product_title" style="display: flex;justify-content: space-between;">
                                            
                                                    <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                    </div>
                                                    <span>${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                    <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                                </div>
                                                <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                                <div id="utilities" style="
                                                display: flex;
                                                justify-content: space-around;
                                                margin-bottom: 1rem;
                                            
                                            
                                            ">
                                                    <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                        <span  class="icon text-white-50" >
                                                            <i class="fas fa-info-circle"></i>
                                                        </span>
                                                        <span class="text" style="color: white">View</span>
                                                    </a>
                                                    <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                        <span class="icon text-white-50">
                                                            <i class="fas fa-trash"></i>
                                                        </span>
                                                        <span class="text" style="color: white">Remove</span>
                                                    </a>
                                                </div>
                                                </div>
                                                
                                                </div>`)

                            });
                        })
                        .catch((error) => {
                            console.log("Error getting documents: ", error);
                        });
                })
                // creatTable(searchData[0])
            })

        }
        else {

            firestore.collection("ECommerce").where("category", "==", current_Category).where("keywords", "array-contains", searchboxtext).limit(1).orderBy("date").get().then(function (querySnapshot) {
                var index = 0;
                querySnapshot.forEach((productdoc) => {
                    console.log("Searched Data", productdoc.data());
                    // searchData[index++]= [e.id,e.data().date.toDate(),e.data().userName,e.data().userProfilePic]  

                    firestore.collection("Userinfo").where("userID", "==", productdoc.data().ownerId).limit(1)
                        .get()
                        .then((querySnapshot) => {
                            querySnapshot.forEach((userDoc) => {


                                // doc.data() is never undefined for query doc snapshots
                                var PriflePic;

                                var english = /^[A-Za-z0-9]*$/;
                                var check = userDoc.data().userName

                                if (userDoc.data().userProfilePic == "") {

                                    if (english.test(check.charAt(0)) == true) {
                                        var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                        switch (UserName_Copy.charAt(0).toLowerCase()) {

                                            case 'a':
                                                PriflePic = "/img/a.svg";
                                                break;

                                            case 'b':
                                                PriflePic = "/img/b.svg";
                                                break;

                                            case 'c':
                                                PriflePic = "/img/c.svg";
                                                break;

                                            case 'd':
                                                PriflePic = "/img/d.svg";
                                                break;

                                            case 'e':
                                                PriflePic = "/img/e.svg";
                                                break;

                                            case 'f':
                                                PriflePic = "/img/f.svg";
                                                break;

                                            case 'g':
                                                PriflePic = "/img/g.svg";
                                                break;

                                            case 'h':
                                                PriflePic = "/img/h.svg";
                                                break;

                                            case 'i':
                                                PriflePic = "/img/i.svg";
                                                break;

                                            case 'j':
                                                PriflePic = "/img/j.svg";
                                                break;

                                            case 'k':
                                                PriflePic = "/img/k.svg";
                                                break;

                                            case 'l':
                                                PriflePic = "/img/l.svg";
                                                break;

                                            case 'm':
                                                PriflePic = "/img/m.svg";
                                                break;

                                            case 'n':
                                                PriflePic = "/img/n.svg";
                                                break;

                                            case 'o':
                                                PriflePic = "/img/o.svg";
                                                break;

                                            case 'p':
                                                PriflePic = "/img/p.svg";
                                                break;

                                            case 'q':
                                                PriflePic = "/img/q.svg";
                                                break;

                                            case 'r':
                                                PriflePic = "/img/r.svg";
                                                break;

                                            case 's':
                                                PriflePic = "/img/s.svg";
                                                break;

                                            case 't':
                                                PriflePic = "/img/t.svg";
                                                break;

                                            case 'u':
                                                PriflePic = "/img/u.svg";
                                                break;

                                            case 'v':
                                                PriflePic = "/img/v.svg";
                                                break;

                                            case 'w':
                                                PriflePic = "/img/w.svg";
                                                break;

                                            case 'x':
                                                PriflePic = "/img/x.svg";
                                                break;

                                            case 'y':
                                                PriflePic = "/img/y.svg";
                                                break;

                                            case 'z':
                                                PriflePic = "/img/z.svg";
                                                break;

                                        }
                                    }
                                    else {
                                        PriflePic = "/img/person.svg";
                                    }
                                }
                                else {
                                    PriflePic = userDoc.data().userProfilePic

                                }
                                $("#userproductsList").append(`<div id="${productdoc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                                <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                    <div class="card-body" >
                                                    <div>
                                                    <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                    <span style="margin-left:1rem;color: black;
    font-weight: 700"> ${userDoc.data().userName}</span>
                                                    <hr>
    
                                                    </div>
                                                    <div id="Product_title" style="display: flex;justify-content: space-between;">
                                            
                                                    <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${productdoc.data().title}</h>
                                                    </div>
                                                    <span>${moment(productdoc.data().date.toDate()).format('LL')}</span>
                                                    <img src="${productdoc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                                </div>
                                                <div style="display: flex;
                                    justify-content: space-around;margin-bottom: 0.5rem;">
                                    <span> Taluka: ${productdoc.data().tahsil} </span>
                                    <span> Village: ${productdoc.data().village} </span>
                                    </div>
                                                <div id="utilities" style="
                                                display: flex;
                                                justify-content: space-around;
                                                margin-bottom: 1rem;
                                            
                                            
                                            ">
                                                    <a  class="btn btn-info btn-icon-split" id="${productdoc.id}" onclick= "openProductInfo(this.id,'${PriflePic}','${userDoc.data().userName}','${userDoc.data().userContact}')" >
                                                        <span  class="icon text-white-50" >
                                                            <i class="fas fa-info-circle"></i>
                                                        </span>
                                                        <span class="text" style="color: white">View</span>
                                                    </a>
                                                    <a  class="btn btn-danger btn-icon-split" id="${productdoc.id}" onclick = "deleteproduct(this.id)">
                                                        <span class="icon text-white-50">
                                                            <i class="fas fa-trash"></i>
                                                        </span>
                                                        <span class="text" style="color: white">Remove</span>
                                                    </a>
                                                </div>
                                                </div>
                                                
                                                </div>`)
                                document.getElementById("LoadMoreButton").style.display = "flex";
                            });
                        })
                        .catch((error) => {
                            console.log("Error getting documents: ", error);
                        });
                })
                // creatTable(searchData[0])
            })
        }


    }
    else {

    }


}


function Product_Filter(params) {

    $('#FilterModal').modal();

}

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#product-post-img_e')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}


function ResetModal(params) {
    document.getElementById("saveButton").style.display = "none";
    document.getElementById("Edit_Vibhag_div").style.display = "none"
    document.getElementById("Edit_district_div").style.display = "none"
    document.getElementById("Edit_Taluka_div").style.display = "none"
    document.getElementById("Edit_Gav_div").style.display = "none" 
    
       document.getElementById("product_tile_show").style.display = "" 
    document.getElementById("product_tile_Edit").style.display = "none" 
    document.getElementById("Product_District_div").style.display = "" 
    document.getElementById("Product_Taluka_div").style.display = "" 
    document.getElementById("Product_Village_div").style.display = ""
    document.getElementById("product-Category").style.display = ""
    document.getElementById("E_product-Category").style.display = "none"
    document.getElementById("product-discription").style.display = ""
    document.getElementById("product-discription_E").style.display = "none"
    document.getElementById("Product_Qty").style.display = "flex"
    document.getElementById("product-Qty_Edit_Div").style.display = "none"
    document.getElementById("product-price").style.display = ""
    document.getElementById("product-price_Edits").style.display = "none"
    document.getElementById("discount-price").style.display = ""
    document.getElementById("discount-price_Edits").style.display = "none"
    document.getElementById("discount-in-percent").style.display = ""
    document.getElementById("discount-in-percent_Edits").style.display = "none" 
    document.getElementById("product-post-img").style.display = ""
    document.getElementById("product-post-img_edit").style.display = "none"
}

function EditProduct(params) {
    
    document.getElementById("saveButton").style.display = "";
    document.getElementById("keyword").disabled = false
    document.getElementById("Edit_Vibhag_div").style.display = ""
    document.getElementById("Edit_district_div").style.display = ""
    document.getElementById("Edit_Taluka_div").style.display = ""
    document.getElementById("Edit_Gav_div").style.display = "" 
    document.getElementById("product_tile_show").style.display = "none" 
    document.getElementById("product_tile_Edit").style.display = "" 
    document.getElementById("Product_District_div").style.display = "none" 
    document.getElementById("Product_Taluka_div").style.display = "none" 
    document.getElementById("Product_Village_div").style.display = "none"
    document.getElementById("product-Category").style.display = "none"
    document.getElementById("E_product-Category").style.display = ""
    document.getElementById("product-discription").style.display = "none"
    document.getElementById("product-discription_E").style.display = ""
    document.getElementById("Product_Qty").style.display = "none"
    document.getElementById("product-Qty_Edit_Div").style.display = "flex"
    document.getElementById("product-price").style.display = "none"
    document.getElementById("product-price_Edits").style.display = ""
    document.getElementById("discount-price").style.display = "none"
    document.getElementById("discount-price_Edits").style.display = ""
    document.getElementById("discount-in-percent").style.display = "none"
    document.getElementById("discount-in-percent_Edits").style.display = "" 
    document.getElementById("product-post-img").style.display = "none"
    document.getElementById("product-post-img_edit").style.display = ""

    
// console.log("E_product-Category_other",document.getElementById("E_product-Category_other").value)
  
    var docRef = firestore.collection("ECommerce").doc(id_Edits);

    docRef.get().then((doc) => {
        if (doc.exists) {



            document.getElementById("E_product-Category_other").value = doc.data().category;
      
        
            if(document.getElementById("E_product-Category_other").value == "शेतमाल"){
       
                शेतमाल.forEach((e)=>{
                    var Category = $(`<option >${e}</option>`);
                    Category.appendTo('#Unit_Edit');
                })
            }else if(document.getElementById("E_product-Category_other").value == "अवजारे व वाहने"){
                // alert("अवजारे व वाहने")
        
                अवजारे_व_वाहने.forEach((e)=>{
                    var Category = $(`<option >${e}</option>`);
                    Category.appendTo('#Unit_Edit');
                })
               
            }else if(document.getElementById("E_product-Category_other").value == "भाडेतत्वावर सेवा"){
                भाडेतत्वावर_सेवा.forEach((e)=>{
                    var Category = $(`<option >${e}</option>`);
                    Category.appendTo('#Unit_Edit');
                })
            }else if(document.getElementById("E_product-Category_other").value == "बी-बियाणे खरेदी विक्री"){
                बी_बियाणे_खरेदी_विक्री.forEach((e)=>{
                    var Category = $(`<option >${e}</option>`);
                    Category.appendTo('#Unit_Edit');
                })
            }else if(document.getElementById("E_product-Category_other").value == "रोपवाटीका"){
                रोपवाटीका.forEach((e)=>{
                    var Category = $(`<option >${e}</option>`);
                    Category.appendTo('#Unit_Edit');
                })
            }else if(document.getElementById("E_product-Category_other").value == "खते"){
                खते.forEach((e)=>{
                    var Category = $(`<option >${e}</option>`);
                    Category.appendTo('#Unit_Edit');
                })
            }else if(document.getElementById("E_product-Category_other").value == "जमीन खरेदी विक्री"){
          
                landUnits.forEach((e)=>{
                    var Category = $(`<option >${e}</option>`);
                    Category.appendTo("#Unit_Edit");
                })
            }   
         
            if (doc.data().unit !== "noUnit" ||  doc.data().unit !== "" ) {
                console.log("Document data:", doc.data());
                document.getElementById("product_tile_Edit_Data").value = doc.data().title;
                document.getElementById("product-post-img_e").src = doc.data().image;
                document.getElementById("E_product-Category_other").value = doc.data().category;
                document.getElementById("product-discription_other").innerText = doc.data().description;
                document.getElementById("product-price_Edits").value = `${doc.data().price}`;
                document.getElementById("discount-price_Edits").value = `${doc.data().discountPrice}`;
                document.getElementById("discount-in-percent_Edits").value = doc.data().discount;
                document.getElementById("product-Qty_Edit").value = `${doc.data().quantity}`;
                document.getElementById("Unit_Edit").value =  doc.data().unit;
                document.getElementById("dropdown_Edit_District").innerHTML = doc.data().district;
                document.getElementById("dropdown_Edit_Taluka").innerHTML = doc.data().tahsil;
                document.getElementById("dropdown_Edit_Gav").innerHTML = doc.data().village;
                document.getElementById("product-user-name").innerText = UserName_Edits
                document.getElementById("product-owner-contact").innerText = contact_edits
            } else {
                console.log("Document data:", doc.data());
                // document.getElementById("product_tile").innerText = doc.data().title
                // document.getElementById("product-post-img").src = doc.data().image
                // document.getElementById("product-Category").innerText = doc.data().category
                // document.getElementById("product-discription").innerHTML = doc.data().description
                // document.getElementById("product-price").innerText = doc.data().price
                // document.getElementById("discount-price").innerHTML = doc.data().discountPrice
                // document.getElementById("discount-in-percent").innerText = doc.data().discount
                // document.getElementById("quantity").innerText = doc.data().quantity
                // document.getElementById("Product_District").innerText = doc.data().district
                // document.getElementById("Product_Taluka").innerText = doc.data().tahsil
                // document.getElementById("Product_Village").innerText = doc.data().village
                // document.getElementById("product-user-name").innerText = UserName_Edits
                // document.getElementById("product-owner-contact").innerText = contact_edits
                document.getElementById("product_tile").innerText = doc.data().title
                document.getElementById("product-post-img_e").src = doc.data().image
                document.getElementById("E_product-Category_other").value = doc.data().category
                document.getElementById("product-discription_other").innerText = doc.data().description
                document.getElementById("product-price_Edits").value = `${doc.data().price}`
                document.getElementById("discount-price_Edits").value = `${doc.data().discountPrice}`
                document.getElementById("discount-in-percent_Edits").value = doc.data().discount
                document.getElementById("product-Qty_Edit").value = `${doc.data().quantity}`
                document.getElementById("Unit_Edit").value = `${doc.data().unit}`
                document.getElementById("dropdown_Edit_District").innerHTML = doc.data().district
                document.getElementById("dropdown_Edit_Taluka").innerHTML = doc.data().tahsil
                document.getElementById("dropdown_Edit_Gav").innerHTML = doc.data().village
                // document.getElementById("product-user-name").innerText = UserName
                // document.getElementById("product-owner-contact").innerText = contact

                

            }

            // $('#viewProductModelPost').modal();
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).then(()=>{
   
})
    
    .catch((error) => {
        console.log("Error getting document:", error);
    });

}


function SaveEditProduct(params) {

var IsImageTobeChange =  document.getElementById("ImageFileToBeChange").value;
var ptitle = document.getElementById("product_tile_Edit_Data").value 
// var pimg =   document.getElementById("product-post-img_e").src 
var pcategory = document.getElementById("E_product-Category_other").value 
var pdiscription = document.getElementById("product-discription_other").value 
var pprice =  document.getElementById("product-price_Edits").value 
var pdiscount = document.getElementById("discount-price_Edits").value 
var pdiscountinper = document.getElementById("discount-in-percent_Edits").value 
var pqty = document.getElementById("product-Qty_Edit").value 
var pedits = document.getElementById("Unit_Edit").value  
var pdistrict = document.getElementById("dropdown_Edit_District").innerHTML 
var ptaluka =  document.getElementById("dropdown_Edit_Taluka").innerHTML 
var pgav =  document.getElementById("dropdown_Edit_Gav").innerHTML 

console.log("pdiscription",pdiscription);

    var docRef = firestore.collection("ECommerce").doc(id_Edits);

    if(IsImageTobeChange == "" && pdiscount!==""){

        return docRef.update({
            title : ptitle, 
            category :pcategory,
            description : pdiscription ,
            price : pprice ,
            discountPrice :pdiscount ,
            discount :Number(pdiscountinper),
            quantity:pqty,
            unit: pedits,
            district :pdistrict,
            tahsil:ptaluka,
            village:pgav,
            nextPrice:Number(pdiscount.replace(/\,/g,"")),
            keywords : tagsKey,
            keysToShow : tags

        }).then(()=>{

            swal("Product Edited Sucessfully");
           
        }).then(()=>{
            location.reload();
        })
        .catch((error) => {
            console.log("Error getting document:", error);
        });

    }else if(IsImageTobeChange !== "" && pdiscount!==""){

        const ref = firebase.storage().ref();
        const file = document.querySelector('#ImageFileToBeChange').files[0]
        const name =  file.name;
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('CommodityImages/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
            return docRef.update({
                title : ptitle, 
                category :pcategory,
                description : pdiscription ,
                price : pprice ,
                discountPrice :pdiscount ,
                discount :Number(pdiscountinper),
                quantity:pqty,
                unit: pedits,
                district :pdistrict,
                tahsil:ptaluka,
                village:pgav,
                nextPrice:Number(pdiscount.replace(/\,/g,"")),
                keywords : tagsKey,
                keysToShow : tags,
                image : url
            }).then(()=>{

                swal("Product Edited Sucessfully");
               
            }).then(()=>{
                // location.reload();
            })
        })

    }else{
        swal("Must Fill Discount Price")
    }

}      


function validatePrice(params) {
    var pprice =  document.getElementById("product-price_Edits").value 
    var pdiscount = document.getElementById("discount-price_Edits").value 
 
    if(Number(pdiscount)<Number(pprice)){

        console.log("Vlidate Price",)
        document.getElementById("discount-in-percent_Edits").value = (((Number(pprice)-Number(pdiscount))/Number(pprice))*100).toFixed(2)
        document.getElementById("discount-price_Validation").style.display = "none"
        document.getElementById("saveButton").disabled = false;
    }else{
        document.getElementById("discount-in-percent_Edits").value = (((Number(pprice)-Number(pdiscount))/Number(pprice))*100).toFixed(2)
        document.getElementById("discount-price_Validation").style.display = "flex"
        document.getElementById("saveButton").disabled = true;
    }

}

function ResetDiscountedPrice(params) {
    document.getElementById("discount-price_Edits").value ="";
  
}




keyword.addEventListener("keyup",function(event){
    //console.log(event);
    if(event.keyCode === 13)
    {
        if(keyword.value == "" || keyword.value == " ")
        {
            swal("Keyword Not be Blank");
            keyword.value = "";
        }
        else
        {
            //let str = (keyword.value).replaceAll(" ","");
            addTags((keyword.value).toLowerCase());
            keyword.value = "";
        }
    }
})

function addTags(val)
{
    var par = document.getElementById('tagContainer');
    var tag = document.createElement('span');
    tag.setAttribute('id',val);
    tag.classList.add('badge','badge-pill','badge-primary');
    tag.innerHTML = val+' <span class="closetag" onclick="removeTags(this)">&times;</span>';
    par.appendChild(tag);
    tags.push(val);
    createKeywords(val);
    //console.log(tags,tagsKey);
}
//<span id="vivek" class="badge badge-pill badge-primary">vivek <span class="closetag" onclick="removeTags(this)">×</span></span>
function createKeywords(name) 
{   
    const arrName = [];
    let curName = '';
    name.split('').forEach(letter => {
    curName += letter;
    arrName.push(curName.trim());
    });
    tagsKey = tagsKey.concat(arrName);
    console.log("tagsKey",tags)

}

function removeTags(ele)
{
    tagsKey = [];
    let tname = ele.parentElement.id;
    let i = tags.indexOf(tname);
    tags.splice(i,1);
    
    for(var k = 0;k<tags.length;k++)
    {
        createKeywords(tags[k]);
    }
    
    ele.parentElement.remove();
    //console.log(tags,tagsKey);
}

function removeAllTags()
{
    var tagbody = document.getElementById('tagContainer');
    while(tagbody.firstChild)
    {
        tagbody.removeChild(tagbody.firstChild);
    }
    //another 
    var sptagbody = document.getElementById('sptagContainer');
    while(sptagbody.firstChild)
    {
        sptagbody.removeChild(sptagbody.firstChild);
    }
}

// Filter Data //
let Vibhag_List = [];
let Vibhag_List_index = 0;

let District_List = [];
let District_List_index = 0;

let Tahasil_List = [];
let Tahasil_List_index = 0;

let Village_List = [];
let Village_List_index = 0;

let CropCategory_list = [];
let CropCategory_list_index = 0;

let CropCategory_User_list = [];
let CropCategory_User_list_index = 0;

let pika_list = [];
let pika_list_index = 0;

var Product_List = [];
var Product_List_index = 0;

var Product_Category_list = [];
var Product_Category_List_index = 0;


//Find the input search box
let search = document.getElementById("searchCoin")
let search1 = document.getElementById("searchCoin1")


//Find every item inside the dropdown
let items = document.getElementsByClassName("dropdown-item")
function buildDropDown(values) {
    let contents = []
    for (let name of values) {
        contents.push(`<input type="button" class="dropdown-item" type="button" value="${name}" onclick="Get_District(this.value)"/>`)
    }
    $('#menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box
search.addEventListener('input', function () {


    filter(search.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems').on('click', '.dropdown-item', function () {

    Selected_Place = $(this)[0].value

    $('#dropdown_coins').text($(this)[0].value)
    $("#dropdown_coins").dropdown('toggle');

    document.querySelector('#ResetFilterInModal').style.display = ""
    document.querySelector('#District_Drop_Down').disabled = false
})


//Find the input search box
let search_Dist = document.getElementById("searchCoin1")

//Find every item inside the dropdown
let Dist_items = document.getElementById("menuItems-dist");

function buildDropDown_dist(values) {


    let contents = []
    for (let dist of values) {
        contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${dist}" onclick="Get_Taluka(this.value,'District')"/>`)
    }
    $('#menuItems-dist').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}


function filter(word) {
    let length = items.length
    let collection = []
    let hidden = 0
    console.log(Dist_items.children[0])
    for (let i = 0; i < length; i++) {
        if (items[i].value.toLowerCase().startsWith(word)) {
            $(items[i]).show()
        }
        else {
            $(items[i]).hide()
            hidden++
        }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
        $('#empty').show()
    }
    else {
        $('#empty').hide()
    }
}

//Capture the event when user types into the search box
search1.addEventListener('input', function () {

    filter_dist(search_Dist.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_dist(word) {
    let length = Dist_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
        if (Dist_items.children[i].value.toLowerCase().startsWith(word)) {
            $(Dist_items.children[i]).show()
        }
        else {
            $(Dist_items.children[i]).hide()
            hidden++
        }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
        $('#empty').show()
    }
    else {
        $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-dist').on('click', '.dropdown-item', function () {

    // alert("District");

    DistrictFilterSelected = 'district';
    Selected_District = $(this)[0].value;

    Selected_Place = $(this)[0].value
    CurrentSelectedFilter = 'District'
    $('#District_Drop_Down').text($(this)[0].value)
    $("#District_Drop_Down").dropdown('toggle');

    WhichFilterSelected = "district";

    document.querySelector('#Tahasil').disabled = false
})


let search_Taluka = document.getElementById("searchCoin2")

//Find every item inside the dropdown
let Taluka_items = document.getElementById("menuItems-Taluka");

function buildDropDown_tahasil(values) {
    let contents = []
    for (let taluka of values) {
        contents.push(`<input type="button" id="dropdown-item-taha" class="dropdown-item"  type="button" value="${taluka}" onclick="Get_village(this.value,'Tahasil')"/>`)
    }
    $('#menuItems-Taluka').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_Taluka.addEventListener('input', function () {


    filter_taha(search_Taluka.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_taha(word) {
    let length = Taluka_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
        if (Taluka_items.children[i].value.toLowerCase().startsWith(word)) {
            $(Taluka_items.children[i]).show()
        }
        else {
            $(Taluka_items.children[i]).hide()
            hidden++
        }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
        $('#empty').show()
    }
    else {
        $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-Taluka').on('click', '.dropdown-item', function () {


    TalukaFilterSelected = 'tahsil';
    Selected_Taluka = $(this)[0].value
    CurrentSelectedFilter = 'Tahasil'
    WhichFilterSelected = "tahsil";
    Selected_Place = $(this)[0].value
    $('#Tahasil').text($(this)[0].value)
    $("#Tahasil").dropdown('toggle');
    document.querySelector('#village').disabled = false
})

let search_village = document.getElementById("searchCoin3")

//Find every item inside the dropdown
let village_items = document.getElementById("menuItems-village");

function buildDropDown_village(values) {
    let contents = []
    for (let village of values) {
        contents.push(`<input type="button" id="dropdown-item-village" class="dropdown-item"  type="button" value="${village}"  />`)
    }
    $('#menuItems-village').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_village.addEventListener('input', function () {


    filter_villa(search_village.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_villa(word) {
    let length = village_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
        if (village_items.children[i].value.toLowerCase().startsWith(word)) {
            $(village_items.children[i]).show()
        }
        else {
            $(village_items.children[i]).hide()
            hidden++
        }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
        $('#empty').show()
    }
    else {
        $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-village').on('click', '.dropdown-item', function () {

    VillageFilterSlected = 'village';
    Selected_Village = $(this)[0].value;

    WhichFilterSelected = "village";
    CurrentSelectedFilter = 'Village'
    Selected_Place = $(this)[0].value
    $('#village').text($(this)[0].value)
    $("#village").dropdown('toggle');
})



// let search_Main_Category = document.getElementById("searchCoin4")

// //Find every item inside the dropdown
// let Main_Category_items = document.getElementById("menuItems-MainCatgory");

// function buildProductCategoryListDropDown(values) {
//     let contents = []
//     for (let MainCategory of values) {
//     contents.push(`<input type="button" id="dropdown-item-MainCategory" class="dropdown-item"  type="button" value="${MainCategory}" onclick="GetProductList(this.value)" />`)
//     }
//     $('#menuItems-MainCatgory').append(contents.join(""))

//     //Hide the row that shows no items were found
//     $('#empty').hide()
// }



// //Capture the event when user types into the search box
// search_Main_Category.addEventListener('input', function () {


//   filter_Main_Cat(search_Main_Category.value.trim().toLowerCase())
// })

// //For every word entered by the user, check if the symbol starts with that word
// //If it does show the symbol, else hide it
// function filter_Main_Cat(word) {
//     let length = Main_Category_items.children.length
//     let collection = []
//     let hidden = 0
//     for (let i = 0; i < length; i++) {
//     if (Main_Category_items.children[i].value.toLowerCase().startsWith(word)) {
//         $(Main_Category_items.children[i]).show()
//     }
//     else {
//         $(Main_Category_items.children[i]).hide()
//         hidden++
//     }
//     }

//     //If all items are hidden, show the empty view
//     if (hidden === length) {
//     $('#empty').show()
//     }
//     else {
//     $('#empty').hide()
//     }
// }

// //If the user clicks on any item, set the title of the button as the text of the item
//   $('#menuItems-MainCatgory').on('click', '.dropdown-item', function(){
//     document.querySelector('#ResetFilterInModal').style.display = ""


//     alert("Selcted Category");

//     Selected_Category = $(this)[0].value

//     CurrentSelectedFilter_Product = 'title';

//     $('#User_Product_Category').text($(this)[0].value)
//       $("#User_Product_Category").dropdown('toggle');

//     })


//     let Search_Product = document.getElementById("searchCoin5")

//     //Find every item inside the dropdown
//     let Product_items = document.getElementById("menuItems-Product");

//     function buildProductListDropDown(values) {
//         let contents = []
//         for (let product of values) {
//         contents.push(`<input type="button" id="dropdown-item-MainCategory" class="dropdown-item"  type="button" value="${product}"  />`)
//         }
//         $('#menuItems-Product').append(contents.join(""))

//         //Hide the row that shows no items were found
//         $('#empty').hide()
//     }



//     //Capture the event when user types into the search box
//     Search_Product.addEventListener('input', function () {


//       filter_Main_Cat(Search_Product.value.trim().toLowerCase())
//     })

//     //For every word entered by the user, check if the symbol starts with that word
//     //If it does show the symbol, else hide it
//     function filter_Main_Cat(word) {
//         let length = Product_items.children.length
//         let collection = []
//         let hidden = 0
//         for (let i = 0; i < length; i++) {
//         if (Product_items.children[i].value.toLowerCase().startsWith(word)) {
//             $(Product_items.children[i]).show()
//         }
//         else {
//             $(Product_items.children[i]).hide()
//             hidden++
//         }
//         }

//         //If all items are hidden, show the empty view
//         if (hidden === length) {
//         $('#empty').show()
//         }
//         else {
//         $('#empty').hide()
//         }
//     }

//     //If the user clicks on any item, set the title of the button as the text of the item
//       $('#menuItems-Product').on('click', '.dropdown-item', function(){
//         document.querySelector('#ResetFilterInModal').style.display = ""
//         alert("Selcted Product");

//         Selected_Product = $(this)[0].value

//         CurrentSelectedFilter_Product = 'title';

//         $('#User_Peka_filter').text($(this)[0].value)
//           $("#User_Peka_filter").dropdown('toggle');

//         })

function Get_Vibhag(params) {

    firestore.collection("SaatBara").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data().call);

            Vibhag_List[Vibhag_List_index++] = doc.data().name;
        });
    }).then(() => {


        buildDropDown(Vibhag_List);
    })

}

Get_Vibhag();

function Get_District(params, flag) {

    District_List = [];
    District_List_index = 0;
    var Dist_child = document.getElementById("menuItems-dist");

    console.log("menuItems-dist", Dist_child.childElementCount)

    firestore.collection("SaatBara").where("name", "==", params).get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            currentVibhag = doc.id;
        });
    }).then(() => {
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District");
        docRef.get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                District_List[District_List_index++] = doc.data().name;
            });
        }).then(() => {
            while (Dist_child.childElementCount !== 0) {

                Dist_child.firstChild.remove();
            }
            console.log("Tahasil Karyalay", District_List)
            buildDropDown_dist(District_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });

    })

}

function Get_Taluka(params, flag) {
    var Talu_child = document.getElementById("menuItems-Taluka");

    Tahasil_List = [];
    Tahasil_List_index = 0;


    //   CurrentSelectedFilter = flag;

    firestore.collection("SaatBara").doc(currentVibhag).collection("District").where("name", "==", params).get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots

            currentDistrict = doc.id;
        });
    }).then(() => {

        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas")

        docRef.get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                console.log()
                Tahasil_List[Tahasil_List_index++] = doc.data().dtname;


            });
        }).then(() => {
            console.log("Tahasil Karyalay", Tahasil_List)
            while (Talu_child.childElementCount !== 0) {

                Talu_child.firstChild.remove();
            }
            buildDropDown_tahasil(Tahasil_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })

}

function Get_village(params, flag) {
    var Village_child = document.getElementById("menuItems-village");
    Village_List = [];
    Village_List_index = 0;


    //   CurrentSelectedFilter = flag;

    firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").where("dtname", "==", params).get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots

            currentTaluka = doc.id
        });
    }).then(() => {

        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").doc(currentTaluka).collection("Villages")

        docRef.get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots

                Village_List[Village_List_index++] = doc.data().village_name;


            });
        }).then(() => {
            console.log("Village Karyalay", Village_List)
            while (Village_child.childElementCount !== 0) {

                Village_child.firstChild.remove();
            }
            buildDropDown_village(Village_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })

}


//Edits
let search_Vibhag = document.getElementById("searchCoin1")


//Find every item inside the dropdown
let Edit_Vibhag_dropdown_item = document.getElementById("dropdown_Edit_Vibhag_menuItems")

function Edit_Vibhag_buildDropDown(values) {
    let contents = []
    for (let name of values) {
        contents.push(`<input type="button" class="dropdown-item" type="button" value="${name}" onclick="Get_District_For_Edits(this.value)"/>`)
    }
    $('#dropdown_Edit_Vibhag_menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

$('#dropdown_Edit_Vibhag_menuItems').on('click', '.dropdown-item', function () {

    Selected_Place = $(this)[0].value

    $('#dropdown_Edit_Vibhag').text($(this)[0].value)
    $("#dropdown_Edit_Vibhag").dropdown('toggle');

    // document.querySelector('#ResetFilterInModal').style.display = ""
    document.querySelector('#dropdown_Edit_District').disabled = false
})

function Get_Vibhag_Edits(params) {
    var Vibhag_List = [];
    var Vibhag_List_index = 0;

    firestore.collection("SaatBara").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots


            Vibhag_List[Vibhag_List_index++] = doc.data().name;
        });
    }).then(() => {
        Edit_Vibhag_buildDropDown(Vibhag_List);
    })
}
Get_Vibhag_Edits();



//Find the input search box

var search_District = document.getElementById("search_dropdown_Edit_District")
//Find every item inside the dropdown
let Edit_District_dropdown_item = document.getElementById("dropdown_Edit_District_menuItems");

function buildDropDown_dist_Edits(values) {

    let contents = []
    for (let dist of values) {
        contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${dist}" onclick="Get_Tahasil_For_Edits(this.value,'District')"/>`)
    }
    $('#dropdown_Edit_District_menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}
//Capture the event when user types into the search box
search_District.addEventListener('input', function () {

    filter_dist(search_Dist.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_dist_Edits(word) {
    let length = Edit_District_dropdown_item.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
        if (Edit_District_dropdown_item.children[i].value.toLowerCase().startsWith(word)) {
            $(Edit_District_dropdown_item.children[i]).show()
        }
        else {
            $(Edit_District_dropdown_item.children[i]).hide()
            hidden++
        }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
        $('#empty').show()
    }
    else {
        $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#dropdown_Edit_District_menuItems').on('click', '.dropdown-item', function () {

    // alert("District");

    // DistrictFilterSelected = 'district';
    // Selected_District = $(this)[0].value;

    // Selected_Place = $(this)[0].value
    // CurrentSelectedFilter = 'District'
    $('#dropdown_Edit_District').text($(this)[0].value)
    $("#dropdown_Edit_District").dropdown('toggle');

    // WhichFilterSelected = "district";

    document.querySelector('#dropdown_Edit_Taluka').disabled = false
})

function Get_District_For_Edits(params, flag) {

   var  District_List = [];
    var   District_List_index = 0;
    var Dist_child = document.getElementById("dropdown_Edit_District_menuItems");

    

    firestore.collection("SaatBara").where("name", "==", params).get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            currentVibhag = doc.id;
        });
    }).then(() => {
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District");
        docRef.get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                District_List[District_List_index++] = doc.data().name;
            });
        }).then(() => {
            while (Dist_child.childElementCount !== 0) {

                Dist_child.firstChild.remove();
            }
            console.log("Tahasil Karyalay", District_List)
            buildDropDown_dist_Edits(District_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });

    })

}

var search_Tahasil = document.getElementById("search_dropdown_Edit_Taluka")
//Find every item inside the dropdown
var Edit_Tahasil_dropdown_item = document.getElementById("dropdown_Edit_Taluka_menuItems");

function buildDropDown_tahasil_Edits(values) {

    let contents = []
    for (let dist of values) {
        contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${dist}" onclick="Get_Village_For_Edits(this.value)" />`)
    }
    $('#dropdown_Edit_Taluka_menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}
//Capture the event when user types into the search box
search_Tahasil.addEventListener('input', function () {

    filter_tahasil_Edits(search_Tahasil.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_tahasil_Edits(word) {
    let length = Edit_Tahasil_dropdown_item.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
        if (Edit_Tahasil_dropdown_item.children[i].value.toLowerCase().startsWith(word)) {
            $(Edit_Tahasil_dropdown_item.children[i]).show()
        }
        else {
            $(Edit_Tahasil_dropdown_item.children[i]).hide()
            hidden++
        }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
        $('#empty').show()
    }
    else {
        $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#dropdown_Edit_Taluka_menuItems').on('click', '.dropdown-item', function () {

    // alert("Tahasil");

    // TahasilFilterSelected = 'Tahasil';
    // Selected_Tahasil = $(this)[0].value;

    // Selected_Place = $(this)[0].value
    // CurrentSelectedFilter = 'Tahasil'
    $('#dropdown_Edit_Taluka').text($(this)[0].value)
    $("#dropdown_Edit_Taluka").dropdown('toggle');

    // WhichFilterSelected = "district";

    document.querySelector('#dropdown_Edit_Gav').disabled = false
})

function Get_Tahasil_For_Edits(params, flag) {

    var  District_List = [];
     var   District_List_index = 0;
     var Dist_child = document.getElementById("dropdown_Edit_Taluka_menuItems");
 
     
 
     firestore.collection("SaatBara").doc(currentVibhag).collection("District").where("name", "==", params).get().then((querySnapshot) => { 
         querySnapshot.forEach((doc) => {
             // doc.data() is never undefined for query doc snapshots
             currentDistrict = doc.id;
         });
     }).then(() => {
         var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas");
         docRef.get().then((querySnapshot) => {
             querySnapshot.forEach((doc) => {
                 // doc.data() is never undefined for query doc snapshots
                 console.log(" doc.data().name", doc.data().dtname)
                 District_List[District_List_index++] = doc.data().dtname;
             });
         }).then(() => {
             while (Dist_child.childElementCount !== 0) {
 
                 Dist_child.firstChild.remove();
             }
             console.log("Tahasil Karyalay", District_List)
             buildDropDown_tahasil_Edits(District_List);
         }).catch((error) => {
             console.log("Error getting document:", error);
         });
      })
 
 }


 // village

 var search_Village = document.getElementById("search_dropdown_Edit_Gav")
//Find every item inside the dropdown
var Edit_Village_dropdown_item = document.getElementById("dropdown_Edit_Gav_menuItems");

function buildDropDown_Village_Edits(values) {

    let contents = []
    for (let dist of values) {
        contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${dist}" onclick="Get_Tahasil_For_Edits(this.value,'Tahasil')"/>`)
    }
    $('#dropdown_Edit_Gav_menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}
//Capture the event when user types into the search box
search_Village.addEventListener('input', function () {

    filter_village_Edits(search_Village.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_village_Edits(word) {
    let length = Edit_Village_dropdown_item.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
        if (Edit_Village_dropdown_item.children[i].value.toLowerCase().startsWith(word)) {
            $(Edit_Village_dropdown_item.children[i]).show()
        }
        else {
            $(Edit_Village_dropdown_item.children[i]).hide()
            hidden++
        }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
        $('#empty').show()
    }
    else {
        $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#dropdown_Edit_Gav_menuItems').on('click', '.dropdown-item', function () {

    // alert("Tahasil");

    // TahasilFilterSelected = 'Tahasil';
    // Selected_Tahasil = $(this)[0].value;

    // Selected_Place = $(this)[0].value
    // CurrentSelectedFilter = 'Tahasil'
    $('#dropdown_Edit_Gav').text($(this)[0].value)
    $("#dropdown_Edit_Gav").dropdown('toggle');

    // WhichFilterSelected = "district";

    // document.querySelector('#Tahasil').disabled = false
})

function Get_Village_For_Edits(params, flag) {

    var  District_List = [];
    var   District_List_index = 0;
    var Dist_child = document.getElementById("dropdown_Edit_Gav_menuItems");
 
     
 
     firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").where("dtname","==",params).get().then((querySnapshot) => { 
         querySnapshot.forEach((doc) => {
             // doc.data() is never undefined for query doc snapshots
             currentTaluka = doc.id;
         });
     }).then(() => {
         var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").doc(currentTaluka).collection("Villages");
         docRef.get().then((querySnapshot) => {
             querySnapshot.forEach((doc) => {
                 // doc.data() is never undefined for query doc snapshots
                
                 District_List[District_List_index++] = doc.data().village_name;
             });
         }).then(() => {
             while (Dist_child.childElementCount !== 0) {
 
                 Dist_child.firstChild.remove();
             }
             console.log("Tahasil Karyalay", District_List)
             buildDropDown_Village_Edits(District_List);
         }).catch((error) => {
             console.log("Error getting document:", error);
         });
 
     })
 
 }
 //village

function ExportData(params) {

    var csv = 'Product Owner Name,Product Owner Contact ,Product Qty,Product Name,Product Category,Product Price,Product Discounted Price,Unit,Discount(%),District,Taluka,Village,Pincode\n';

    //merge the data with CSV
    ExportDataList.forEach(function (row) {
        //console.log(row)
        csv += row.join(',');
        csv += "\n";
    });

    //display the created CSV data on the web browser 
    //document.write(csv);


    var hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';

    //provide the name for the CSV file to be downloaded
    hiddenElement.download = `Exported data.csv`;

    hiddenElement.click();
}

function ResetFilter(params) {


    Selected_District = ""
    Selected_Taluka = ""
    Selected_Village = ""
    DistrictFilterSelected = undefined;
    TalukaFilterSelected = undefined;
    VillageFilterSlected = undefined;

    $('#village').text('गाव');

    $('#Tahasil').text('तालुका');

    $('#District_Drop_Down').text('जिल्हा')

    All_products();

}