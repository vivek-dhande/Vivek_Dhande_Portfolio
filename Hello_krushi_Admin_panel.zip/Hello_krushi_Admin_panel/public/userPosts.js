

                        var firestore = firebase.firestore();

                        var userdoc = localStorage.getItem('userDocId');
                        var userId = localStorage.getItem('UserId');
                        
                        var lastVisiblePost;
                        
               
                        
                        var docRef = firestore.collection("Userinfo").doc(userdoc);
                        docRef.get().then((doc) => {
                            if (doc.exists) {
                            //    document.getElementById("profile_pic")
                          
                            NO_Profile(doc.data().userProfilePic,doc.data().userName)
                            document.getElementById("User_Name").innerText = doc.data().userName
                        
                            }
                        }).catch((error) => {
                            console.log("Error getting document:", error);
                        });
                        
                        function NO_Profile(params,params1) {
                            if(params!==""){
                              
                                  document.getElementById("profile_pic").src = params;
                             
                              }
                              else{
                                var PriflePic;
                                         
                                var english = /^[A-Za-z0-9]*$/;
                                var check = params1
                                   
                                    if( english.test(check.charAt(0)) == true){
                                        var UserName_Copy = (params1.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                        switch (UserName_Copy.charAt(0).toLowerCase()) {
                        
                                            case 'a':
                                                PriflePic= "/img/a.svg";
                                                break;
                                                
                                            case 'b':
                                                PriflePic= "/img/b.svg";
                                                break;
                                            
                                            case 'c':
                                                PriflePic= "/img/c.svg";
                                                break;
                                                
                                            case 'd':
                                                PriflePic= "/img/d.svg";
                                                break;
                                                
                                            case 'e':
                                                PriflePic= "/img/e.svg";
                                                break;
                                                
                                            case 'f':
                                                PriflePic= "/img/f.svg";
                                                break;
                                                
                                            case 'g':
                                                PriflePic= "/img/g.svg";
                                                break;
                                                
                                            case 'h':
                                                PriflePic= "/img/h.svg";
                                                break;
                                                
                                            case 'i':
                                                PriflePic= "/img/i.svg";
                                                break;
                                                
                                            case 'j':
                                                PriflePic= "/img/j.svg";
                                                break;
                                                
                                            case 'k':
                                                PriflePic= "/img/k.svg";
                                                break;
                                                
                                            case 'l':
                                                PriflePic= "/img/l.svg";
                                                break;
                                                
                                            case 'm':
                                                PriflePic= "/img/m.svg";
                                                break;
                                                
                                            case 'n':
                                                PriflePic= "/img/n.svg";
                                                break;
                                                
                                            case 'o':
                                                PriflePic= "/img/o.svg";
                                                break;
                                                
                                            case 'p':
                                                PriflePic= "/img/p.svg";
                                                break;
                                                
                                            case 'q':
                                                PriflePic= "/img/q.svg";
                                                break;
                                                
                                            case 'r':
                                                PriflePic= "/img/r.svg";
                                                break;
                                                
                                            case 's':
                                                PriflePic= "/img/s.svg";
                                                break;
                                                
                                            case 't':
                                                PriflePic= "/img/t.svg";
                                                break;
                                                
                                            case 'u':
                                                PriflePic= "/img/u.svg";
                                                break;
                                                
                                            case 'v':
                                                PriflePic= "/img/v.svg";
                                                break;
                                            
                                            case 'w':
                                                PriflePic= "/img/w.svg";
                                                break;
                                                
                                            case 'x':
                                                PriflePic= "/img/x.svg";
                                                break;
                                            
                                            case 'y':
                                                PriflePic= "/img/y.svg";
                                                break;
                                            
                                            case 'z':
                                                PriflePic= "/img/z.svg";
                                                break;
                                        
                                    }
                                    }
                                    else{
                                        PriflePic= "/img/person.svg";
                                    }  
                                    document.getElementById("profile_pic").src = PriflePic;
                        
                          } 
                        }
                        function post() {
                            firestore.collection("postFeedData").where("uid", "==", userId)
                            .get()
                            .then((querySnapshot) => {
                                    if(querySnapshot.size == 0) {
                   
                                            document.getElementById("LoadMoreButton").style.display = "none"
                                            
                                    }
                                    else{
                                            document.getElementById("LoadMoreButton").style.display = "flex"
                                    }

                                lastVisiblePost = querySnapshot.docs[querySnapshot.docs.length-1];
                                querySnapshot.forEach((doc) => {
                                    // doc.data() is never undefined for query doc snapshots
                                 
                                    $("#userpostsList").append(`<div id="${doc.id}" class="col" style="display: flex;">
                                    <div class="card h-20" style="width: 20rem;margin-right: 1rem;">
                                        <div class="card-body">
                                        <div id="Product_title" style="display: flex;justify-content: space-between;">
                                        </div>
                                        <span>${moment(doc.data().date.toDate()).format('LL')}</span>
                                        <img src="${doc.data().imgUri}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                        <p> ${doc.data().caption} </p>
                                        <div id="utilities" style="
                                    display: flex;
                                    justify-content: space-evenly;
                                    margin-top: 2rem;
                                    
                                
                                  
                                ">
                                <a id="${doc.id}" class="btn btn-info btn-circle btn-lg" onclick = "openPostInfo(this.id)">
                                <i class="fas fa-info-circle"></i>
                                </a>        
                                <a id="${doc.id}" class="btn btn-danger btn-circle btn-lg" onclick = "deletepost(this.id)" >
                                         <i class="fas fa-trash"></i>
                                </a>
                                    </div>
                                    </div>
                                    </div>
                                    
                                </div>`)
                                });
                            }).then(()=>{
                                document.getElementById("UserPostList").style.display = ""
                                document.getElementById("NoProduct").style.display = "none"
                                if(document.getElementById("userpostsList").childElementCount == 0  ){
                                    $("#userpostsList").append(`<div id="NoProduct" style="width: 200rem;display: flex;justify-content: center;"> <lottie-player src="https://assets10.lottiefiles.com/packages/lf20_y6ilh1zw.json"  background="transparent"  speed="1.5"  style="width: 400px; height: 400px;"  loop autoplay></lottie-player> </div>`)
                                }
                                else{
                                    
                                }

                            })
                            .catch((error) => {
                                console.log("Error getting documents: ", error);
                            });            
                        }
                        post();
        
                        function GetMoreposts() {
                            firestore.collection("postFeedData").where("uid", "==", userId).startAfter(lastVisiblePost).limit(6)
                            .get()
                            .then((querySnapshot) => {
                                console.log("Data", querySnapshot.docs.length)
                                if( querySnapshot.docs.length == 0 ){
                                    document.getElementById("LoadMoreButton").style.display = "none"
                                  }
                                  else{
                                  
                                  }
                                lastVisiblePost = querySnapshot.docs[querySnapshot.docs.length-1];
                                
                                querySnapshot.forEach((doc) => {
                                    // doc.data() is never undefined for query doc snapshots
                                 
                                    $("#userpostsList").append(`<div id="${doc.id}" class="col" style="display: flex;">
                                    <div class="card h-20" style="width: 20rem;margin-right: 1rem;">
                                        <div class="card-body">
                                        <div id="Product_title" style="display: flex;justify-content: space-between;">
                                        </div>
                                        <span>${moment(doc.data().date.toDate()).format('LL')}</span>
                                        <img src="${doc.data().imgUri}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                        <p> ${doc.data().caption} </p>
                                        <div id="utilities" style="
                                    display: flex;
                                    justify-content: space-evenly;
                                    margin-top: 2rem;
                                    
                                
                                  
                                ">
                                <a id="${doc.id}" class="btn btn-info btn-circle btn-lg" onclick = "openPostInfo(this.id)">
                                <i class="fas fa-info-circle"></i>
                                </a>        
                                <a id="${doc.id}" class="btn btn-danger btn-circle btn-lg" onclick = "deletepost(this.id)" >
                                         <i class="fas fa-trash"></i>
                                </a>
                                    </div>
                                    </div>
                                    </div>
                                    
                                </div>`)
                                });
                            })
                            .catch((error) => {
                                console.log("Error getting documents: ", error);
                            });
                        }


                        
                        function openPostInfo(params) {
                            console.log("this is modal fucntiom")
                            var PostDocRef = firestore.collection("postFeedData").doc(params);
                            PostDocRef.get().then((doc) => {
                                if (doc.exists) {
                                    // document.getElementById("modal-date").innerText = moment(doc.data().date.toDate()).format('LL');
                                    document.getElementById("modal-post-img").src = doc.data().imgUri;
                                    document.getElementById("modal-post-caption").innerText = doc.data().caption;
                                    document.getElementById("Post_Date").innerText = moment(doc.data().date.toDate()).format('LL')
                                    $('#viewpost').modal();
                            
                                }
                            }).catch((error) => {
                                console.log("Error getting document:", error);
                            });
                        
                        }
                        
                        deletepost =(id)=>{
                         
                             swal({
                                title: "Are you sure?",
                                text: "Do you want to Delete this Post",
                                icon: "warning",
                                buttons: !0,
                                dangerMode: !0
                            }).then(n => {
                                n && firestore.collection("postFeedData").doc(`${id}`).delete()
                                
                                
                                .then(function() {
                                    let subsWrapper = document.getElementById(`${id}`)
                                    subsWrapper.remove();
                                    swal("Successfull", "Post Deleted ", "success")
                                }).catch(function(e) {
                                    console.error("Error removing document: ", e)
                                })
                            })
                        }