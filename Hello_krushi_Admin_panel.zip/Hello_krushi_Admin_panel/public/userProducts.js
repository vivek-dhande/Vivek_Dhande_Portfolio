
/* <div class="col-xl-3 col-md-6 mb-4">
                            
                        </div> */
var firestore = firebase.firestore();

var userdoc = localStorage.getItem('userDocId');
var userId = localStorage.getItem('UserId');

var lastVisibleProduct;

document.getElementById("LoadMoreButton").style.display = "none";



var docRef = firestore.collection("Userinfo").doc(userdoc);
docRef.get().then((doc) => {
    if (doc.exists) {
    //    document.getElementById("profile_pic")
  
    NO_Profile(doc.data().userProfilePic,doc.data().userName)
    document.getElementById("User_Name").innerText = doc.data().userName

    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

function NO_Profile(params,params1) {
    if(params!==""){
      
          document.getElementById("profile_pic").src = params;
     
      }
      else{
        var PriflePic;
                 
        var english = /^[A-Za-z0-9]*$/;
        var check = params1
           
            if( english.test(check.charAt(0)) == true){
                var UserName_Copy = (params1.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                switch (UserName_Copy.charAt(0).toLowerCase()) {

                    case 'a':
                        PriflePic= "/img/a.svg";
                        break;
                        
                    case 'b':
                        PriflePic= "/img/b.svg";
                        break;
                    
                    case 'c':
                        PriflePic= "/img/c.svg";
                        break;
                        
                    case 'd':
                        PriflePic= "/img/d.svg";
                        break;
                        
                    case 'e':
                        PriflePic= "/img/e.svg";
                        break;
                        
                    case 'f':
                        PriflePic= "/img/f.svg";
                        break;
                        
                    case 'g':
                        PriflePic= "/img/g.svg";
                        break;
                        
                    case 'h':
                        PriflePic= "/img/h.svg";
                        break;
                        
                    case 'i':
                        PriflePic= "/img/i.svg";
                        break;
                        
                    case 'j':
                        PriflePic= "/img/j.svg";
                        break;
                        
                    case 'k':
                        PriflePic= "/img/k.svg";
                        break;
                        
                    case 'l':
                        PriflePic= "/img/l.svg";
                        break;
                        
                    case 'm':
                        PriflePic= "/img/m.svg";
                        break;
                        
                    case 'n':
                        PriflePic= "/img/n.svg";
                        break;
                        
                    case 'o':
                        PriflePic= "/img/o.svg";
                        break;
                        
                    case 'p':
                        PriflePic= "/img/p.svg";
                        break;
                        
                    case 'q':
                        PriflePic= "/img/q.svg";
                        break;
                        
                    case 'r':
                        PriflePic= "/img/r.svg";
                        break;
                        
                    case 's':
                        PriflePic= "/img/s.svg";
                        break;
                        
                    case 't':
                        PriflePic= "/img/t.svg";
                        break;
                        
                    case 'u':
                        PriflePic= "/img/u.svg";
                        break;
                        
                    case 'v':
                        PriflePic= "/img/v.svg";
                        break;
                    
                    case 'w':
                        PriflePic= "/img/w.svg";
                        break;
                        
                    case 'x':
                        PriflePic= "/img/x.svg";
                        break;
                    
                    case 'y':
                        PriflePic= "/img/y.svg";
                        break;
                    
                    case 'z':
                        PriflePic= "/img/z.svg";
                        break;
                
            }
            }
            else{
                PriflePic= "/img/person.svg";
            }  
            document.getElementById("profile_pic").src = PriflePic;

  } 
}
function product(params) {
    firestore.collection("ECommerce").where("ownerId", "==", userId).limit(6)
    .get()
    .then((querySnapshot) => {

        if(querySnapshot.size == 0){
            document.getElementById("LoadMoreButton").style.display = "none"
        }else{
            document.getElementById("LoadMoreButton").style.display = "flex"
        }
       

        lastVisibleProduct = querySnapshot.docs[querySnapshot.docs.length-1];
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots

            
         
            $("#userProductsList").append(`<div id="${doc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
            <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                <div class="card-body">
               
                <div id="Product_title" style="display: flex;justify-content: space-between;">
        
                <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${doc.data().title}</h>
                </div>
                <span>${moment(doc.data().date.toDate()).format('LL')}</span>
                <img src="${doc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height=288px">
            </div>
            <div id="utilities" style="
            display: flex;
            justify-content: space-around;
            margin-bottom: 1rem;
        
          
        ">
                <a  class="btn btn-info btn-icon-split" id="${doc.id}" onclick= "openProductInfo(this.id)" >
                    <span  class="icon text-white-50" >
                        <i class="fas fa-info-circle"></i>
                    </span>
                    <span class="text" style="color: white">View</span>
                </a>
                <a  class="btn btn-danger btn-icon-split" id="${doc.id}" onclick = "deleteproduct(this.id)">
                    <span class="icon text-white-50">
                        <i class="fas fa-trash"></i>
                    </span>
                    <span class="text" style="color: white">Remove</span>
                </a>
            </div>
            </div>
            
        </div>`)
        });
    }).then(()=>{
        
        document.getElementById("NoProduct").style.display = "none";
        document.getElementById("UserProductList").style.display = "";

        if(document.getElementById("userProductsList").childElementCount == 0  ){

            $("#userProductsList").append(`<div id="NoProduct" style="width: 200rem;display: flex;justify-content: center;"> <lottie-player src="https://assets10.lottiefiles.com/packages/lf20_y6ilh1zw.json"  background="transparent"  speed="1.5"  style="width: 400px; height: 400px;"  loop autoplay></lottie-player> </div>
            `)
            
        }
        else{
            
        }
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    
}
product();

function GetMoreproduct() {
    firestore.collection("ECommerce").where("ownerId", "==", userId).startAfter(lastVisibleProduct).limit(6)
    .get()
    .then((querySnapshot) => {
        lastVisibleProduct = querySnapshot.docs[querySnapshot.docs.length-1];
        console.log("In Load More Stop",querySnapshot.docs.length);
        if( querySnapshot.docs.length == 0 ){
            document.getElementById("LoadMoreButton").style.display = "none"
          }
          else{
            document.getElementById("LoadMoreButton").style.display = "flex"
          }
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            

            console.log("Data",doc.data());
         
            $("#userProductsList").append(`<div id="${doc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
            <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                <div class="card-body">
               
                <div id="Product_title" style="display: flex;justify-content: space-between;">
        
                <h5 class="d-flex align-items-center mb-3" style="color:black; font-weight: bold;" >${doc.data().title}</h>
                </div>
                <span>${moment(doc.data().date.toDate()).format('LL')}</span>
                <img src="${doc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height=288px">
            </div>
            <div id="utilities" style="
            display: flex;
            justify-content: space-around;
            margin-bottom: 1rem;
        
          
        ">
                <a  class="btn btn-info btn-icon-split" id="${doc.id}" onclick= "openProductInfo(this.id)" >
                    <span  class="icon text-white-50" >
                        <i class="fas fa-info-circle"></i>
                    </span>
                    <span class="text" style="color: white">View</span>
                </a>
                <a  class="btn btn-danger btn-icon-split" id="${doc.id}" onclick = "deleteproduct(this.id)">
                    <span class="icon text-white-50">
                        <i class="fas fa-trash"></i>
                    </span>
                    <span class="text" style="color: white">Remove</span>
                </a>
            </div>
            </div>
            
        </div>`)
        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
}

function openProductInfo(params) {
    console.log("this is modal fucntiom")
    var ECommerceDocRef = firestore.collection("ECommerce").doc(params);
    ECommerceDocRef.get().then((doc) => {
        if (doc.exists) {
        //    document.getElementById("profile_pic")
        var PriflePic;
                 
        var english = /^[A-Za-z0-9]*$/;
        var check = doc.data().userName
     
        
        if(doc.data().userProfilePic == ""){
           
            if( english.test(check.charAt(0)) == true){
                var UserName_Copy = (doc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                switch (UserName_Copy.charAt(0).toLowerCase()) {

                    case 'a':
                        PriflePic= "/imges/a.svg";
                        break;
                        
                    case 'b':
                        PriflePic= "/imges/b.svg";
                        break;
                    
                    case 'c':
                        PriflePic= "/imges/c.svg";
                        break;
                        
                    case 'd':
                        PriflePic= "/imges/d.svg";
                        break;
                        
                    case 'e':
                        PriflePic= "/imges/e.svg";
                        break;
                        
                    case 'f':
                        PriflePic= "/imges/f.svg";
                        break;
                        
                    case 'g':
                        PriflePic= "/imges/g.svg";
                        break;
                        
                    case 'h':
                        PriflePic= "/imges/h.svg";
                        break;
                        
                    case 'i':
                        PriflePic= "/imges/i.svg";
                        break;
                        
                    case 'j':
                        PriflePic= "/imges/j.svg";
                        break;
                        
                    case 'k':
                        PriflePic= "/imges/k.svg";
                        break;
                        
                    case 'l':
                        PriflePic= "/imges/l.svg";
                        break;
                        
                    case 'm':
                        PriflePic= "/imges/m.svg";
                        break;
                        
                    case 'n':
                        PriflePic= "/imges/n.svg";
                        break;
                        
                    case 'o':
                        PriflePic= "/imges/o.svg";
                        break;
                        
                    case 'p':
                        PriflePic= "/imges/p.svg";
                        break;
                        
                    case 'q':
                        PriflePic= "/imges/q.svg";
                        break;
                        
                    case 'r':
                        PriflePic= "/imges/r.svg";
                        break;
                        
                    case 's':
                        PriflePic= "/imges/s.svg";
                        break;
                        
                    case 't':
                        PriflePic= "/imges/t.svg";
                        break;
                        
                    case 'u':
                        PriflePic= "/imges/u.svg";
                        break;
                        
                    case 'v':
                        PriflePic= "/imges/v.svg";
                        break;
                    
                    case 'w':
                        PriflePic= "/imges/w.svg";
                        break;
                        
                    case 'x':
                        PriflePic= "/imges/x.svg";
                        break;
                    
                    case 'y':
                        PriflePic= "/imges/y.svg";
                        break;
                    
                    case 'z':
                        PriflePic= "/imges/z.svg";
                        break;
                
            }
            }
            else{
                PriflePic= "/imges/person.svg";
            }  
            }
            else{
                PriflePic = doc.data().userProfilePic
               
            } 
        document.getElementById("product_tile").innerText = doc.data().title
        document.getElementById("product-post-img").src = doc.data().image
        document.getElementById("product-discription").innerHTML = doc.data().description
        document.getElementById("product-price").innerText = doc.data().price
        document.getElementById("discount-price").innerHTML = doc.data().discountPrice
        document.getElementById("discount-in-percent").innerText = doc.data().discount
        document.getElementById("quantity").innerText =  doc.data().quantity
    
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
   
    
    $('#viewProductModelPost').modal();


}

deleteproduct =(id)=>{
 
    swal({
       title: "Are you sure?",
       text: "Do you want to Delete this Product",
       icon: "warning",
       buttons: !0,
       dangerMode: !0
   }).then(n => {
       n && firestore.collection("postFeedData").doc(`${id}`).delete()
       
       
       .then(function() {
           let subsWrapper = document.getElementById(`${id}`)
           subsWrapper.remove();
           swal("Successfull", "Product Deleted ", "success")
       }).catch(function(e) {
           console.error("Error removing document: ", e)
       })
   })
}
