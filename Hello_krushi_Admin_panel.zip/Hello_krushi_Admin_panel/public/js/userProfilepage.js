var firestore = firebase.firestore();
const storage = firebase.storage();

var userdoc = localStorage.getItem('userDocId');
var UserID;

var docRef = firestore.collection("Userinfo").doc(userdoc);

var Userid ;
var UserDoc ;
var ShetiIndex = 1;
var currentSheti;
var CropName,CropCategory,CropDate,ShetiArea,ShetiVillage,ShetiTaluka,ShetiDistrict,ShetiType,ShetiUnit ;
var validation_flag = false;
var UserType;

docRef.get().then((doc) => {
    if (doc.exists) {
    //    document.getElementById("profile_pic")
    UserDoc = doc.id ;
    NO_Profile(doc.data().userProfilePic,doc.data().userName)
    document.getElementById("User_Name").innerText = doc.data().userName
    document.getElementById("user_Full_Name").innerText = doc.data().userName
    document.getElementById("user_contact").innerText = doc.data().userContact
    document.getElementById("user_village").innerText = doc.data().village 
    document.getElementById("user_tahsil").innerText = doc.data().tahsil
    document.getElementById("user_district").innerText = doc.data().district
    document.getElementById("user_age").innerText = doc.data().age
    document.getElementById("user_gender").innerText = doc.data().gender
    UserType = doc.data().userType

    Userid =  doc.data().userID;
    localStorage.setItem('UserId', Userid);
    product(Userid);
    post(Userid);

    }
}).then(()=>{

    UserID = localStorage.getItem('UserId');
    var userInfoVari = firestore.collection("Sheti").where("userId","==",UserID).orderBy("date","asc")
userInfoVari.get().then(function(querySnapshot){
    if(querySnapshot.size == 0  ){
        $("#Sheti_list").append(`<div id="NoProduct" style="width: 22rem;display: flex;justify-content: center;"> <lottie-player src="https://assets10.lottiefiles.com/packages/lf20_y6ilh1zw.json"  background="transparent"  speed="1.5"  style="width: 400px; height: 400px;"  loop autoplay></lottie-player> </div>
        `)
    }
    else{
        
    }

    console.log("querySnapshot.size",querySnapshot.size)

    querySnapshot.forEach((e)=>{
 
        console.log("Data",e.data())
        // Sheti_Data[ShetiIndex++] = [e.data().crop,e.data().cropDate,e.data().farmArea,e.data().landTaluka,e.data().landType]
        
        $("#Sheti_list").append(`  <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap" id="${e.id}" onclick="shetiInfo(this.id)">
        <h6 class="mb-0">Sheti${ShetiIndex++}</h6>                      
      </li>
      
`);

        
    })
})
}).catch((error) => {
    console.log("Error getting document:", error);
});



function NO_Profile(params,params1) {
    if(params!==""){
      
          document.getElementById("profile_pic").src = params;
     
      }
      else{
        var PriflePic;
                 
        var english = /^[A-Za-z0-9]*$/;
        var check = params1
           
            if( english.test(check.charAt(0)) == true){
                var UserName_Copy = (params1.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                switch (UserName_Copy.charAt(0).toLowerCase()) {

                    case 'a':
                        PriflePic= "/img/a.svg";
                        break;
                        
                    case 'b':
                        PriflePic= "/img/b.svg";
                        break;
                    
                    case 'c':
                        PriflePic= "/img/c.svg";
                        break;
                        
                    case 'd':
                        PriflePic= "/img/d.svg";
                        break;
                        
                    case 'e':
                        PriflePic= "/img/e.svg";
                        break;
                        
                    case 'f':
                        PriflePic= "/img/f.svg";
                        break;
                        
                    case 'g':
                        PriflePic= "/img/g.svg";
                        break;
                        
                    case 'h':
                        PriflePic= "/img/h.svg";
                        break;
                        
                    case 'i':
                        PriflePic= "/img/i.svg";
                        break;
                        
                    case 'j':
                        PriflePic= "/img/j.svg";
                        break;
                        
                    case 'k':
                        PriflePic= "/img/k.svg";
                        break;
                        
                    case 'l':
                        PriflePic= "/img/l.svg";
                        break;
                        
                    case 'm':
                        PriflePic= "/img/m.svg";
                        break;
                        
                    case 'n':
                        PriflePic= "/img/n.svg";
                        break;
                        
                    case 'o':
                        PriflePic= "/img/o.svg";
                        break;
                        
                    case 'p':
                        PriflePic= "/img/p.svg";
                        break;
                        
                    case 'q':
                        PriflePic= "/img/q.svg";
                        break;
                        
                    case 'r':
                        PriflePic= "/img/r.svg";
                        break;
                        
                    case 's':
                        PriflePic= "/img/s.svg";
                        break;
                        
                    case 't':
                        PriflePic= "/img/t.svg";
                        break;
                        
                    case 'u':
                        PriflePic= "/img/u.svg";
                        break;
                        
                    case 'v':
                        PriflePic= "/img/v.svg";
                        break;
                    
                    case 'w':
                        PriflePic= "/img/w.svg";
                        break;
                        
                    case 'x':
                        PriflePic= "/img/x.svg";
                        break;
                    
                    case 'y':
                        PriflePic= "/img/y.svg";
                        break;
                    
                    case 'z':
                        PriflePic= "/img/z.svg";
                        break;
                
            }
            }
            else{
                PriflePic= "/img/person.svg";
            }  
            document.getElementById("profile_pic").src = PriflePic;

  } 
}

function product(params) {
    // console.log("USer Data",document.getElementById("productList"))
   

    firestore.collection("ECommerce").where("ownerId", "==", params).limit(6)
    .get()
    .then((querySnapshot) => {

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
         
            $("#productList").append(`<div id="${doc.id}" class="col" style="display: flex;">
            <div class="card h-20" style="width: 20rem;margin-right: 1rem;">
                <div class="card-body">
               
                <div id="Product_title" style="display: flex;justify-content: space-between;">
        
                <h6 class="d-flex align-items-center mb-3">${doc.data().title}</h6>
                </div>
                <span>${moment(doc.data().date.toDate()).format('LL')}</span>
                <img src="${doc.data().image}" class="rounded " alt="Responsive image" style="width: 288px;height=288px">
            </div>
            <div id="utilities" style="
            display: flex;
            justify-content: space-around;
            margin-bottom: 1rem;
        
          
        ">
                <a  class="btn btn-info btn-icon-split" id="${doc.id}" onclick= "openProductInfo(this.id)" >
                    <span  class="icon text-white-50" >
                        <i class="fas fa-info-circle"></i>
                    </span>
                    <span class="text" style="color: white">View</span>
                </a>
                <a  class="btn btn-danger btn-icon-split" id="${doc.id}" onclick = "deleteproduct(this.id)">
                    <span class="icon text-white-50">
                        <i class="fas fa-trash"></i>
                    </span>
                    <span class="text" style="color: white">Remove</span>
                </a>
            </div>
            </div>
            
        </div>`)
        });
        
        document.getElementById("LoadingCircle").style.display = "none";
        document.getElementById("profile_pic").style.display = "";
    }).then(()=>{
        if(document.getElementById("productList").childElementCount == 0  ){
            $("#productList").append(`<div id="NoProduct" style="width: 200rem;display: flex;justify-content: center;"> <lottie-player src="https://assets10.lottiefiles.com/packages/lf20_y6ilh1zw.json"  background="transparent"  speed="1.5"  style="width: 400px; height: 400px;"  loop autoplay></lottie-player> </div>
            `)
        }
        else{
            
        }
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
 
    
}
function post(params) {

  
    firestore.collection("postFeedData").where("uid", "==", params).limit(6)
    .get()
    .then((querySnapshot) => {
   
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
         
            $("#postList").append(`<div id="${doc.id}" class="col" style="display: flex;">
            <div class="card h-20" style="width: 20rem;margin-right: 1rem;">
                <div class="card-body">
                <div id="Product_title" style="display: flex;justify-content: space-between;">
                </div>
                <span>${moment(doc.data().date.toDate()).format('LL')}</span>
                <img src="${doc.data().imgUri}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                <p> ${doc.data().caption} </p>
                <div id="utilities" style="
            display: flex;
            justify-content: space-evenly;
            margin-top: 2rem;
            
        
          
        ">
        <a id="${doc.id}" class="btn btn-info btn-circle btn-lg" onclick = "openPostInfo(this.id)">
        <i class="fas fa-info-circle"></i>
        </a>        
        <a id="${doc.id}" class="btn btn-danger btn-circle btn-lg" onclick = "deletepost(this.id)" >
                 <i class="fas fa-trash"></i>
        </a>
            </div>
            </div>
            </div>
            
        </div>`)
        });
    }).then(()=>{
        if(document.getElementById("postList").childElementCount == 0  ){
            $("#postList").append(`<div id="NoProduct" style="width: 200rem;display: flex;justify-content: center;"> <lottie-player src="https://assets10.lottiefiles.com/packages/lf20_y6ilh1zw.json"  background="transparent"  speed="1.5"  style="width: 400px; height: 400px;"  loop autoplay></lottie-player> </div>
            `)
        }
        else{
            
        }
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });


    
}

function openProductInfo(params) {
    console.log("this is modal fucntiom")
    var ECommerceDocRef = firestore.collection("ECommerce").doc(params);
    ECommerceDocRef.get().then((doc) => {
        if (doc.exists) {
        //    document.getElementById("profile_pic")
        var PriflePic;
                 
        var english = /^[A-Za-z0-9]*$/;
        var check = doc.data().userName
     
        
        if(doc.data().userProfilePic == ""){
           
            if( english.test(check.charAt(0)) == true){
                var UserName_Copy = (doc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                switch (UserName_Copy.charAt(0).toLowerCase()) {

                    case 'a':
                        PriflePic= "/imges/a.svg";
                        break;
                        
                    case 'b':
                        PriflePic= "/imges/b.svg";
                        break;
                    
                    case 'c':
                        PriflePic= "/imges/c.svg";
                        break;
                        
                    case 'd':
                        PriflePic= "/imges/d.svg";
                        break;
                        
                    case 'e':
                        PriflePic= "/imges/e.svg";
                        break;
                        
                    case 'f':
                        PriflePic= "/imges/f.svg";
                        break;
                        
                    case 'g':
                        PriflePic= "/imges/g.svg";
                        break;
                        
                    case 'h':
                        PriflePic= "/imges/h.svg";
                        break;
                        
                    case 'i':
                        PriflePic= "/imges/i.svg";
                        break;
                        
                    case 'j':
                        PriflePic= "/imges/j.svg";
                        break;
                        
                    case 'k':
                        PriflePic= "/imges/k.svg";
                        break;
                        
                    case 'l':
                        PriflePic= "/imges/l.svg";
                        break;
                        
                    case 'm':
                        PriflePic= "/imges/m.svg";
                        break;
                        
                    case 'n':
                        PriflePic= "/imges/n.svg";
                        break;
                        
                    case 'o':
                        PriflePic= "/imges/o.svg";
                        break;
                        
                    case 'p':
                        PriflePic= "/imges/p.svg";
                        break;
                        
                    case 'q':
                        PriflePic= "/imges/q.svg";
                        break;
                        
                    case 'r':
                        PriflePic= "/imges/r.svg";
                        break;
                        
                    case 's':
                        PriflePic= "/imges/s.svg";
                        break;
                        
                    case 't':
                        PriflePic= "/imges/t.svg";
                        break;
                        
                    case 'u':
                        PriflePic= "/imges/u.svg";
                        break;
                        
                    case 'v':
                        PriflePic= "/imges/v.svg";
                        break;
                    
                    case 'w':
                        PriflePic= "/imges/w.svg";
                        break;
                        
                    case 'x':
                        PriflePic= "/imges/x.svg";
                        break;
                    
                    case 'y':
                        PriflePic= "/imges/y.svg";
                        break;
                    
                    case 'z':
                        PriflePic= "/imges/z.svg";
                        break;
                
            }
            }
            else{
                PriflePic= "/imges/person.svg";
            }  
            }
            else{
                PriflePic = doc.data().userProfilePic
               
            } 
        document.getElementById("product_tile").innerText = doc.data().title
        document.getElementById("product-post-img").src = doc.data().image
        document.getElementById("product-discription").innerHTML = doc.data().description
        document.getElementById("product-price").innerText = doc.data().price
        document.getElementById("discount-price").innerHTML = doc.data().discountPrice
        document.getElementById("discount-in-percent").innerText = doc.data().discount
        document.getElementById("quantity").innerText =  doc.data().quantity
    
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
   
    
    $('#viewProductModelPost').modal();



}

function openPostInfo(params) {
    console.log("this is modal fucntiom")
    var PostDocRef = firestore.collection("postFeedData").doc(params);
    PostDocRef.get().then((doc) => {
        if (doc.exists) {
            // document.getElementById("modal-date").innerText = moment(doc.data().date.toDate()).format('LL');
            document.getElementById("modal-post-img").src = doc.data().imgUri;
            document.getElementById("modal-post-caption").innerText = doc.data().caption;
            $('#viewpost').modal();
    
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

deletepost =(id)=>{
 
     swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Post",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        n && firestore.collection("postFeedData").doc(`${id}`).delete()
        
        
        .then(function() {
            let subsWrapper = document.getElementById(`${id}`)
            subsWrapper.remove();
            swal("Successfull", "Post Deleted ", "success")
        }).catch(function(e) {
            console.error("Error removing document: ", e)
        })
    })
}
deleteproduct =(id)=>{
 
    swal({
       title: "Are you sure?",
       text: "Do you want to Delete this Product",
       icon: "warning",
       buttons: !0,
       dangerMode: !0
   }).then(n => {
       n && firestore.collection("postFeedData").doc(`${id}`).delete()
       
       
       .then(function() {
           let subsWrapper = document.getElementById(`${id}`)
           subsWrapper.remove();
           swal("Successfull", "Product Deleted ", "success")
       }).catch(function(e) {
           console.error("Error removing document: ", e)
       })
   })
}


function edit_profile() {
    var UA_e = document.getElementById("user_Full_Name").innerText
    var  UC_e = document.getElementById("user_contact").innerText
    var UV_e =  document.getElementById("user_village").innerText
    var UT_e = document.getElementById("user_tahsil").innerText
    var UD_e = document.getElementById("user_district").innerText
    var Uage = document.getElementById("user_age").innerText
    var Ugender = document.getElementById("user_gender").innerText
    console.log("Data",UA_e);

    
    document.getElementById("user_age_gender").style.display = ""; 
    document.getElementById("user_age_update").style.display = ""; 
    document.getElementById("user_gender").style.display = ""; 
    document.getElementById("update_profile_button").style.display = ""; 
    document.getElementById("cancel_update_profile_button").style.display = "";
    document.getElementById("user_Full_Name_update").style.display = "";
    document.getElementById("user_contact_update").style.display = "";
    // document.getElementById("user_village_update").style.display = "";
    // document.getElementById("user_tahsil_update").style.display = "";
    // document.getElementById("user_district_update").style.display = ""; 
    document.getElementById("Vibhag_row").style.display = "";
    document.getElementById("vibhagHR").style.display = ""; 

    document.getElementById("District_Dropdown_button_E").style.display = ""; 
    document.getElementById("Taluka_Dropdown_Button_E").style.display = "";
    document.getElementById("village_Dropdown_button_E").style.display = "";


    document.getElementById("user_Full_Name").style.display = "none";
    document.getElementById("user_contact").style.display = "none";
    document.getElementById("user_village").style.display = "none";
    document.getElementById("user_tahsil").style.display = "none";
    document.getElementById("user_district").style.display = "none";
    document.getElementById("user_age").style.display = "none"
    document.getElementById("user_gender").style.display = "none"
    

    document.getElementById("user_Full_Name_update").value = UA_e;
    document.getElementById("user_contact_update").value = UC_e;
    document.getElementById("District_Dropdown_button_E").innerText = UD_e; 
    document.getElementById("Taluka_Dropdown_Button_E").innerText = UT_e;
    document.getElementById("village_Dropdown_button_E").innerText = UV_e; 
    document.getElementById("user_age_update").value = Uage
    document.getElementById("user_age_gender").innerText = Ugender
    document.getElementById("Vibhag_row").style.display = "";
    document.getElementById("vibhagHR").style.display = ""; 

   

    // document.getElementById("user_village_update").value = UV_e;
    // document.getElementById("user_tahsil_update").value = UT_e;
    // document.getElementById("user_district_update").value = UD_e;

}

$("#gender_Menu").on('click', '.dropdown-item', function(){

    // alert("In gender DropDown",)
console.log("In[0]",this.innerText)

document.getElementById("user_age_gender").innerText = this.innerText

     $("#user_age_gender").dropdown('toggle');

  })

function update_profile() {
  
    
     var UA = document.getElementById("user_Full_Name_update").value
    var  UC = document.getElementById("user_contact_update").value
    var UV =  document.getElementById("village_Dropdown_button_E").innerText
    var UT = document.getElementById("Taluka_Dropdown_Button_E").innerText
    var UD = document.getElementById("District_Dropdown_button_E").innerText
    var UpdateAge = document.getElementById("user_age_update").value
    var updateGender = document.getElementById("user_age_gender").innerText
    console.log("userInfo",updateGender);

    firestore.collection("Userinfo").doc(UserDoc).update({
        userName: UA,
        userContact : UC,
        village: UV,
        tahsil : UT,
        district : UD,
        age:UpdateAge,
        gender:updateGender

    }).then(function() {

    document.getElementById("user_age_update").style.display = "none"    
    document.getElementById("user_age_gender").style.display = "none";
    document.getElementById("user_age").style.display = ""; 
    document.getElementById("user_gender").style.display = "";
    document.getElementById("cancel_update_profile_button").style.display = "none";
    document.getElementById("update_profile_button").style.display = "none"; 
    document.getElementById("user_Full_Name_update").style.display = "none";
    document.getElementById("user_contact_update").style.display = "none";
    document.getElementById("Vibhag_row").style.display = "";
    document.getElementById("vibhagHR").style.display = ""; 
    document.getElementById("District_Dropdown_button_E").style.display = ""; 
    document.getElementById("Taluka_Dropdown_Button_E").style.display = "";
    document.getElementById("village_Dropdown_button_E").style.display = "";
    // document.getElementById("user_village_update").style.display = "none";
    // document.getElementById("user_tahsil_update").style.display = "none";
    // document.getElementById("user_district_update").style.display = "none";
    document.getElementById("user_Full_Name").style.display = "";
    document.getElementById("user_contact").style.display = "";
    document.getElementById("user_village").style.display = "";
    document.getElementById("user_tahsil").style.display = "";
    document.getElementById("user_district").style.display = "";
        swal("Successfull!", "Group Member Updated Successfully", "success")
    }).then(()=>{
        // location.reload();
    }).catch(function(e) {
        console.log("Error:" + e)
    })

}

function cancel(params) {

    document.getElementById("update_profile_button").style.display = "none"; 
    document.getElementById("cancel_update_profile_button").style.display = "none";
    document.getElementById("user_Full_Name_update").style.display = "none";
    document.getElementById("user_contact_update").style.display = "none";
    // document.getElementById("user_village_update").style.display = "none";
    // document.getElementById("user_tahsil_update").style.display = "none";
    // document.getElementById("user_district_update").style.display = "none";
    document.getElementById("user_Full_Name").style.display = "";
    document.getElementById("user_contact").style.display = "";
    document.getElementById("user_village").style.display = "";
    document.getElementById("user_tahsil").style.display = "";
    document.getElementById("user_district").style.display = "";

    document.getElementById("District_Dropdown_button_E").style.display = "none"; 
    document.getElementById("Taluka_Dropdown_Button_E").style.display = "none";
    document.getElementById("village_Dropdown_button_E").style.display = "none";
    document.getElementById("Vibhag_row").style.display = "none";
    document.getElementById("vibhagHR").style.display = "none"; 
}

function shetiInfo(params) {

    currentSheti = params
    var shetiInfo = firestore.collection("Sheti").doc(params);
    // document.getElementById("CropImg_other").style.display = ""
    document.getElementById("CropName_other").style.display = ""
    document.getElementById("CropCategory_other").style.display = ""
    document.getElementById("ShowCropDate_other").style.display = ""
    document.getElementById("FarmArea_other").style.display = ""
    document.getElementById("Village_other").style.display =  ""
    document.getElementById("Taluka_other").style.display =  ""
    document.getElementById("District_other").style.display = ""
    document.getElementById("Landtype_other").style.display = ""
    document.getElementById("Unit_other").style.display = ""
    document.getElementById("exampleFormControlLable_Edit_Sheti_Info").style.display = "none" 
    document.getElementById("exampleFormControlFile1_Edit_Sheti_Info").style.display = "none" 

    document.getElementById("User_Peka_filter").style.display = "none" 
    document.getElementById("User_Peka_Sub_filter").style.display = "none"
    document.getElementById("dropdown_coins").style.display = "none" 
    document.getElementById("Dist_Dist").style.display = "none" 
    document.getElementById("Dist_Tal").style.display = "none"
    document.getElementById("Dist_vill").style.display = "none"

    document.getElementById("E_ShowCropDate").style.display = "none"
    document.getElementById("E_FarmArea").style.display = "none"
    // document.getElementById("E_Village").style.display = "none"  
    // document.getElementById("E_Taluka").style.display = "none"
    // document.getElementById("E_District").style.display = "none"
    document.getElementById("E_Landtype").style.display = "none"
    document.getElementById("E_Unit").style.display = "none" 
   
    shetiInfo.get().then((doc) => {
        if (doc.exists) {
            console.log("Data",doc.data());
            // document.getElementById("modal-date").innerText = moment(doc.data().date.toDate()).format('LL');
            document.getElementById("CropImg_other").src = doc.data().pikImage
            document.getElementById("CropName_other").value = doc.data().crop
            document.getElementById("CropCategory_other").value = doc.data().cropMainCat
            document.getElementById("ShowCropDate_other").value = doc.data().cropDateString
            document.getElementById("FarmArea_other").value =  doc.data().farmArea 
            document.getElementById("Village_other").value =  doc.data().village
            document.getElementById("Taluka_other").value =  doc.data().tahsil
            document.getElementById("District_other").value = doc.data().district
            document.getElementById("Landtype_other").value = doc.data().landType
            document.getElementById("Unit_other").value = doc.data().selectedFarmAreaUnit

                      
            $('#ShetiInfo_Modal').modal();
          
    
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

function Open_Add_SHeti(params) {
    
 
console.log("UserType",UserType)

    $('#Add_ShetiInfo_Modal').modal();
}

function Add_Sheti(params) {

    CropName = document.getElementById("CROP_DROPDOWN_Button").innerText 
    CropCategory = document.getElementById("CROP_CATEGORY_Button").innerText
    CropDate = document.getElementById("AddCropDate").value
    ShetiArea = document.getElementById("AddFarmArea").value  
    ShetiVillage = document.getElementById("village_Dropdown_button").innerText  
    ShetiTaluka = document.getElementById("Taluka_Dropdown_Button").innerText
    ShetiDistrict = document.getElementById("District_Dropdown_button").innerText 
    ShetiType = document.getElementById("landtype").value
    ShetiUnit = document.getElementById("AddUnit").value 
    CropImage =  document.getElementById("exampleFormControlFile1_sub").value  


    console.log("CropName:",CropName.trim()=="पीक","CropCategory:",CropCategory,"CropDate",CropDate,"ShetiArea",ShetiArea,"ShetiVillage",ShetiVillage,"ShetiTaluka",ShetiTaluka,"ShetiDistrict",ShetiDistrict,"ShetiType",ShetiType,"ShetiUnit",ShetiUnit,CropImage)
           
        if(CropName.trim() === "पीक" ){
    
            validation_flag = true;
            document.getElementById("pik").style.display = "";

        }else{
            validation_flag = false;
            document.getElementById("pik").style.display = "none";
        }

        if(CropCategory.trim() === "पीक Category"){
         
            validation_flag = true;
             document.getElementById("CROP_CATEGORY_Span").style.display = ""; 
             
        }else{
            validation_flag = false;
             document.getElementById("CROP_CATEGORY_Span").style.display = "none"; 
        }
        if(CropDate === ""){
            validation_flag = true;
            document.getElementById("cdate").style.display = "";
       
        }else{
            document.getElementById("cdate").style.display = "none";
            validation_flag = false;
        }
        if(ShetiArea === "" || ShetiUnit === "Choose..."){
            validation_flag = true;
            document.getElementById("farmarea").style.display = "";
        }else{
            validation_flag = false;
            document.getElementById("farmarea").style.display = "none";
        }
        if(ShetiVillage.trim() === "गाव"){
            validation_flag = true;
    
            document.getElementById("village_Span").style.display = "";
        }else{
            validation_flag = false;
            document.getElementById("village_Span").style.display = "none";
        }
        if(ShetiTaluka.trim() === "तालुका"){
            validation_flag = true;
            document.getElementById("taluka").style.display = "";
        }else{
            validation_flag = false;
            document.getElementById("taluka").style.display = "none";
        }
        if(ShetiDistrict.trim() === "जिल्हा"){
            validation_flag = true;
            document.getElementById("district").style.display = "";  
        }else{
            validation_flag = false;
            document.getElementById("district").style.display = "none";
        }
        if(ShetiType === "Choose..."){
            validation_flag = true;
            document.getElementById("landtype123").style.display = "";
        }else{
            validation_flag = false;
            document.getElementById("landtype123").style.display = "none";
        }
        if(CropImage === ""){
            validation_flag = true;
            document.getElementById("img_span").style.display = "";
        }else{
            validation_flag = false;
            document.getElementById("img_span").style.display = "none";
        }

        if(validation_flag == false){

            var ImgUrl_Sub;
           
            const ref = firebase.storage().ref();
            const file = document.querySelector('#exampleFormControlFile1_sub').files[0]
            console.log("filename",file);
            const name =  file.name;
            const metadata = {
            contentType: file.type
            };
            const task = ref.child('CommodityImages/' + name).put(file, metadata);
            task
            .then(snapshot => snapshot.ref.getDownloadURL())
            .then((url) => {
            console.log(url);
            ImgUrl_Sub = url
            }).then(()=>{

                firestore.collection('Sheti').add({
                    crop:CropName,
                    cropDate: firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate))),
                    cropDateString: moment(CropDate).format("DD/MM/YYY"), 
                    cropMainCat:CropCategory,
                    landType:ShetiType,
                    farmArea:Number(ShetiArea),
                    village:ShetiVillage,
                    tahsil:ShetiTaluka,
                    district:ShetiDistrict,
                    userId:UserID,
                    pikImage:ImgUrl_Sub,
                    selectedFarmAreaUnit:ShetiUnit,
                    date : firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                    UserType:UserType
    
                }).then(()=>{
    
                    alert("ShetiAdded Sucessfully");
                    document.getElementById("CROP_DROPDOWN_Button").innerText = "पीक" 
                    document.getElementById("CROP_CATEGORY_Button").innerText = "पीक Category"
                    document.getElementById("AddCropDate").value = ""
                    document.getElementById("AddFarmArea").value = "" 
                    document.getElementById("Vibhag_DROPDOWN_button").innerText = "विभाग"  
                    document.getElementById("village_Dropdown_button").innerText = "गाव"  
                    document.getElementById("Taluka_Dropdown_Button").innerText = "तालुका"  
                    document.getElementById("District_Dropdown_button").innerText = "जिल्हा"  
                    document.getElementById("landtype").value = "Choose..."
                    document.getElementById("AddUnit").value = "Choose..." 
                    
                }).then(()=>{
                    location.reload();
                })
    

            })

        
            $('#Add_ShetiInfo_Modal').modal('hide')
            
        }
        
   
    
     
            // var ImgUrl_Sub;
           
            // const ref = firebase.storage().ref();
            // const file = document.querySelector('#exampleFormControlFile1_sub').files[0]
            // console.log("filename",file);
            // const name =  file.name;
            // const metadata = {
            // contentType: file.type
            // };
            // const task = ref.child('CommodityImages/' + name).put(file, metadata);
            // task
            // .then(snapshot => snapshot.ref.getDownloadURL())
            // .then((url) => {
            // console.log(url);
            // ImgUrl_Sub = url
            // }).then(()=>{

            //     firestore.collection('Sheti').add({
            //         crop:CropName,
            //         cropDate: firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate).format("LL"))).toDate(),
            //         cropMainCat:CropCategory,
            //         landType:ShetiType,
            //         farmArea:Number(ShetiArea),
            //         village:ShetiVillage,
            //         tahsil:ShetiTaluka,
            //         district:ShetiDistrict,
            //         userId:UserID,
            //         pikImage:ImgUrl_Sub,
            //         selectedFarmAreaUnit:ShetiUnit,
            //         date : firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
    
            //     }).then(()=>{
    
                    // alert("ShetiAdded Sucessfully");
            //         document.getElementById("AddCropName").value = "" 
            //         document.getElementById("AddCropCategory").value = ""
            //         document.getElementById("AddCropDate").value = ""
            //         document.getElementById("AddFarmArea").value = ""  
            //         document.getElementById("AddVillage").value = ""  
            //         document.getElementById("AddTaluka").value = ""  
            //         document.getElementById("AddDistrict").value = ""  
            //         document.getElementById("AddLandtype").value = ""
            //         document.getElementById("AddUnit").value = "" 
            //     })
    

            // })
            
            
}

function Edit_Sheti(params) {

    document.getElementById("CropName_other").style.display = "none"
    document.getElementById("CropCategory_other").style.display = "none" 
    document.getElementById("ShowCropDate_other").style.display = "none"
    document.getElementById("FarmArea_other").style.display = "none"
    document.getElementById("Village_other").style.display =  "none"
    document.getElementById("Taluka_other").style.display =  "none"
    document.getElementById("District_other").style.display = "none" 
    document.getElementById("Landtype_other").style.display = "none"

    document.getElementById("Update_Sheti_Button").style.display = ""
    document.getElementById("Unit_other").style.display = "none"
    // document.getElementById("E_CropName").style.display = "" 
    // document.getElementById("E_CropCategory").style.display = ""

    document.getElementById("User_Peka_filter").style.display = "" 
    document.getElementById("User_Peka_Sub_filter").style.display = ""   
    document.getElementById("User_Peka").style.display = ""  
    document.getElementById("User_Peka_Sub_Pika").style.display = ""
    document.getElementById("Dist_Dist").style.display = "" 
    document.getElementById("Dist_Tal").style.display = "" 
    document.getElementById("Dist_vill").style.display = ""  
    document.getElementById("Vibhag_group").style.display = "" 
    document.getElementById("dropdown_coins").style.display = "" 
    document.getElementById("E_ShowCropDate").style.display = ""
    document.getElementById("E_FarmArea").style.display = ""
    
    // document.getElementById("E_Village").style.display = ""  
    // document.getElementById("E_Taluka").style.display = ""
    // document.getElementById("E_District").style.display = ""
    document.getElementById("E_Landtype").style.display = ""
    document.getElementById("E_Unit").style.display = "" 
    document.getElementById("exampleFormControlLable_Edit_Sheti_Info").style.display = "" 
    document.getElementById("exampleFormControlFile1_Edit_Sheti_Info").style.display = ""  
 
    document.getElementById("User_Peka_Sub_filter").innerHTML =  document.getElementById("CropName_other").value
    document.getElementById("User_Peka_filter").innerHTML = document.getElementById("CropCategory_other").value
    document.getElementById("AddCropDate_Edit").value = document.getElementById("ShowCropDate_other").value
    document.getElementById("E_FarmArea").value = document.getElementById("FarmArea_other").value
    document.getElementById("village").innerHTML = document.getElementById("Village_other").value
    document.getElementById("Tahasil").innerHTML =  document.getElementById("Taluka_other").value
    document.getElementById("District_Drop_Down").innerHTML =  document.getElementById("District_other").value
    document.getElementById("E_Landtype_1").value = document.getElementById("Landtype_other").value
    document.getElementById("E_Unit").value =  document.getElementById("Unit_other").value



   
      
}

function Update_Sheti_Info(params) {
    var ImgUrl_Sub;

    var CropName = document.getElementById("User_Peka_Sub_Pika").innerText 
   var CropCategory = document.getElementById("User_Peka_filter").innerText
   var CropDate = document.getElementById("AddCropDate_Edit").value
   var ShetiArea = document.getElementById("E_FarmArea").value  
   var ShetiVillage = document.getElementById("village").innerText  
   var ShetiTaluka = document.getElementById("Tahasil").innerText  
   var ShetiDistrict = document.getElementById("District_Drop_Down").innerText  
   var ShetiType = document.getElementById("E_Landtype_1").value
   var ShetiUnit = document.getElementById("E_Unit").value 

   console.log("Local Time",CropDate) 
   console.log("Timestamp",firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate))))
   
    const ref = firebase.storage().ref();
    
    const file = document.querySelector('#exampleFormControlFile1_Edit_Sheti_Info').files[0]
    if(file===undefined){
        // alert("Blank");
       // moment(CropDate).format('DD/MM/YYYY')
        firestore.collection('Sheti').doc(currentSheti).update({
            crop:CropName,
            cropDate: firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate))),
            cropDateString: moment(CropDate).format("DD/MM/YYYY"), 
            landType:ShetiType,
            farmArea:Number(ShetiArea),
            village:ShetiVillage,
            tahsil:ShetiTaluka,
            district:ShetiDistrict,
            userId:UserID,
            selectedFarmAreaUnit:ShetiUnit,
            date : firebase.firestore.Timestamp.fromDate(new Date()).toDate()
        }).then(()=>{

            alert("ShetiUpdatedSucessfully");
            document.getElementById("Update_Sheti_Button").style.display = "none"
            // document.getElementById("AddCropName").value = "" 
            // document.getElementById("AddCropCategory").value = ""
            // document.getElementById("AddCropDate").value = ""
            // document.getElementById("AddFarmArea").value = ""  
            // document.getElementById("AddVillage").value = ""  
            // document.getElementById("AddTaluka").value = ""  
            // document.getElementById("AddDistrict").value = ""  
            // document.getElementById("AddLandtype").value = ""
            // document.getElementById("AddUnit").value = "" 
        })
    }
    else{
        // alert("File");
            const name =  file.name;
            const metadata = {
            contentType: file.type
            };
            const task = ref.child('CommodityImages/' + name).put(file, metadata);
            task
            .then(snapshot => snapshot.ref.getDownloadURL())
            .then((url) => {
            console.log(url);
            ImgUrl_Sub = url
        }).then(()=>{
            firestore.collection('Sheti').doc(currentSheti).update({
                crop:CropName.trim(),
                cropDate: firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate))),
                cropDateString: moment(CropDate).format("DD/MM/YYYY"), 
                cropMainCat:CropCategory.trim(),
                landType:ShetiType.trim(),
                farmArea:ShetiArea,
                village:ShetiVillage.trim(),
                tahsil:ShetiTaluka.trim(),
                district:ShetiDistrict.trim(),
                userId:UserID,
                pikImage:ImgUrl_Sub,
                selectedFarmAreaUnit:ShetiUnit,
                date : firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
    
            }).then(()=>{
    
                alert("ShetiUpdatedSucessfully");
                // document.getElementById("AddCropName").value = "" 
                // document.getElementById("AddCropCategory").value = ""
                // document.getElementById("AddCropDate").value = ""
                // document.getElementById("AddFarmArea").value = ""  
                // document.getElementById("AddVillage").value = ""  
                // document.getElementById("AddTaluka").value = ""  
                // document.getElementById("AddDistrict").value = ""  
                // document.getElementById("AddLandtype").value = ""
                // document.getElementById("AddUnit").value = "" 
            })
        })
    }
  

    
}

$(function () {
  $('#datepicker').datepicker();
  $('#datepicker1').datepicker(); 
  $('#E_ShowCropDate').datepicker(); 
  
});




let search_Main_Category = document.getElementById("searchCoin4")

//Find every item inside the dropdown
let Main_Category_items = document.getElementById("menuItems-MainCatgory");

function buildDropDown_Main_cat(values) {
    let contents = []
    for (let MainCategory of values) {
    contents.push(`<input type="button" id="dropdown-item-MainCategory" class="dropdown-item"  type="button" value="${MainCategory}" onclick="Get_Pika_Sub_Category(this.value,'Main_Cat')" />`)
    }
    $('#menuItems-MainCatgory').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_Main_Category.addEventListener('input', function () {
  
  
  filter_Main_Cat(search_Main_Category.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_Main_Cat(word) {
    let length = Main_Category_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Main_Category_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Main_Category_items.children[i]).show()
    }
    else {
        $(Main_Category_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
  $('#menuItems-MainCatgory').on('click', '.dropdown-item', function(){

      $('#User_Peka_filter').text($(this)[0].value)
      $("#User_Peka_filter").dropdown('toggle');

    })

    let Search_CROP_CATEGORY = document.getElementById("search_CROP_CATEGORY")

    //Find every item inside the dropdown
    let Main_CROP_CATEGORY_items = document.getElementById("menuItems-CROP_CATEGORY");
    
    function buildDropDown_CROP_CATEGORY(values) {
        let contents = []
        for (let CROP_CATEGORY of values) {
        contents.push(`<input type="button" id="dropdown-item-MainCategory" class="dropdown-item"  type="button" value="${CROP_CATEGORY}" onclick="Get_CROP_List(this.value,'Main_Cat')" />`)
        }
        $('#menuItems-CROP_CATEGORY').append(contents.join(""))
    
        //Hide the row that shows no items were found
        $('#empty').hide()
    }
    
    

    var CROP_CATEGORY_list = [];
    var CROP_CATEGORY_list_index = 0;
    var CROP_LIST = [];
    var CROP_LIST_index = 0;
    var VIBHAG_List = [];
    var VIBHAG_List_index = 0;
    var DISTRICT_List = [];
    var DISTRICT_List_index = 0;
    var TALUKA_List = [];
    var TALUKA_List_index = 0;
    var VILLAGE_List = [];
    var VILLAGE_List_index = 0;

    var VIBHAG_List_E = [];
    var VIBHAG_List_index_E = 0;

    var DISTRICT_List_E = [];
    var DISTRICT_List_index_E = 0;

    var VILLAGE_List_E = [];
    var VILLAGE_List_index_E = 0;

    var TALUKA_List_E = [];
    var TALUKA_List_index_E = 0;


    //Capture the event when user types into the search box
    Search_CROP_CATEGORY.addEventListener('input', function () {
      
      
      filter_Main_Cat(Search_CROP_CATEGORY.value.trim().toLowerCase())
    })
    
    //For every word entered by the user, check if the symbol starts with that word
    //If it does show the symbol, else hide it
    function filter_Main_Cat(word) {
        let length = Main_CROP_CATEGORY_items.children.length
        let collection = []
        let hidden = 0
        for (let i = 0; i < length; i++) {
        if (Main_CROP_CATEGORY_items.children[i].value.toLowerCase().startsWith(word)) {
            $(Main_CROP_CATEGORY_items.children[i]).show()
        }
        else {
            $(Main_CROP_CATEGORY_items.children[i]).hide()
            hidden++
        }
        }
    
        //If all items are hidden, show the empty view
        if (hidden === length) {
        $('#empty').show()
        }
        else {
        $('#empty').hide()
        }
    }
    
    //If the user clicks on any item, set the title of the button as the text of the item
      $('#menuItems-CROP_CATEGORY').on('click', '.dropdown-item', function(){
    
          $('#CROP_CATEGORY_Button').text($(this)[0].value)
          $("#CROP_CATEGORY_Button").dropdown('toggle');
    
        })
    

    function Get_CROP_CATEGORY() {

        var docRef = firestore.collection("ShetiPik").get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
    
                CROP_CATEGORY_list[CROP_CATEGORY_list_index++] = doc.data().mainCatName;
    
            });
            }).then(()=>{
    
            
            buildDropDown_CROP_CATEGORY(CROP_CATEGORY_list);
            }).catch((error) => {
                console.log("Error getting document:", error);
            });
    
    }

    Get_CROP_CATEGORY();

    function Get_CROP_List(params,flag) {
        var pik_child = document.getElementById("menuItems-pika");
      
        CROP_LIST = [];
        CROP_LIST_index = 0;
      
        var docRef = firestore.collection("ShetiPik").where("mainCatName","==", params).get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
              Selected_Main_Category_Doc = doc.id
              //  console.log("Vivek Dhande",  doc.data())

              var docRef = firestore.collection("ShetiPik").doc(doc.id).collection("SubCat")
      
              docRef.get().then((querySnapshot) => {
                  
                querySnapshot.forEach(element => {
                  
                    CROP_LIST[CROP_LIST_index++] = element.data().pikName;
             //     console.log("Pika Data",element.data().pikName) 
                });
              }).then(()=>{
                while(pik_child.childElementCount!==0){
                  pik_child.firstChild.remove();
                }
             
                buildDropDown_CROP(CROP_LIST);
        
              }).catch((error) => {
                  console.log("Error getting document:", error);
              });
            
      
          });
        }).then(()=>{

        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    }

    let search_CROP = document.getElementById("search_CROP_DROPDOWN")

    //Find every item inside the dropdown
    let Main_CROP = document.getElementById("menuItems-CROP_DROPDOWN");
    
    function buildDropDown_CROP(values) {
        let contents = []
        for (let CROP of values) {
        contents.push(`<input type="button" id="dropdown-menuItems-pika" class="dropdown-item"  type="button" value="${CROP}"/>`)
        }
        $('#menuItems-CROP_DROPDOWN').append(contents.join(""))
    
        //Hide the row that shows no items were found
        $('#empty').hide()
    }
    
    
    
    //Capture the event when user types into the search box
    search_CROP.addEventListener('input', function () {
      
      
      filter_Main_pik(search_CROP.value.trim().toLowerCase())
    })
    
    //For every word entered by the user, check if the symbol starts with that word
    //If it does show the symbol, else hide it
    function filter_Main_pik(word) {
        let length = Main_CROP.children.length
        let collection = []
        let hidden = 0
        for (let i = 0; i < length; i++) {
        if (Main_CROP.children[i].value.toLowerCase().startsWith(word)) {
            $(Main_CROP.children[i]).show()
        }
        else {
            $(Main_CROP.children[i]).hide()
            hidden++
        }
        }
    
        //If all items are hidden, show the empty view
        if (hidden === length) {
        $('#empty').show()
        }
        else {
        $('#empty').hide()
        }
    }
    
    //If the user clicks on any item, set the title of the button as the text of the item
      $('#menuItems-CROP_DROPDOWN').on('click', '.dropdown-item', function(){
        
        CropSelected = "crop";
        Selected_Crop = $(this)[0].value
          $('#CROP_DROPDOWN_Button').text($(this)[0].value)
          $("#CROP_DROPDOWN_Button").dropdown('toggle');
  
      
      })



    function Get_VIBHAG(params) {

    firestore.collection("SaatBara").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
    
    
            VIBHAG_List [VIBHAG_List_index++] = doc.data().name;
        });
    }).then(()=>{
    
    
        buildDropDown_vibhag(VIBHAG_List);
    })
    
    }
    
    Get_VIBHAG();

//Vibhag
// let items = document.getElementsByClassName("dropdown-item")

function buildDropDown_vibhag(values) {
    let contents = []
    for (let vibhaglist of values) {
    contents.push(`<input type="button" class="dropdown-item" type="button" value=${vibhaglist} onclick="Get_DISTRICT(this.value)"/>`)
    }
    $('#menuItems_Vibhag_DROPDOWN').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box


//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems_Vibhag_DROPDOWN').on('click', '.dropdown-item', function(){

    document.querySelector('#District_Dropdown_button').disabled = false
    $('#Vibhag_DROPDOWN_button').text($(this)[0].value)
    $("#Vibhag_DROPDOWN_button").dropdown('toggle');

  
})


function Get_VIBHAG_E(params) {
  
    firestore.collection("SaatBara").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
    
    
            VIBHAG_List_E [VIBHAG_List_index_E++] = doc.data().name;
        });
    }).then(()=>{
    
    
        buildDropDown_vibhag_E(VIBHAG_List_E);
    })
    
    }

    Get_VIBHAG_E();

//Vibhag
// let items = document.getElementsByClassName("dropdown-item")

function buildDropDown_vibhag_E(values) {
    let contents = []
    for (let vibhaglist of values) {
    contents.push(`<input type="button" class="dropdown-item" type="button" value=${vibhaglist} onclick="Get_DISTRICT_E(this.value)"/>`)
    }
    $('#menuItems_Vibhag_DROPDOWN_E').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box


//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems_Vibhag_DROPDOWN_E').on('click', '.dropdown-item', function(){

    document.querySelector('#District_Dropdown_button_E').disabled = false
    $('#Vibhag_DROPDOWN_button_E').text($(this)[0].value)
    $("#Vibhag_DROPDOWN_button_E").dropdown('toggle');

  
})




function Get_DISTRICT(params,flag) {

   
    var Dist_child_ = document.getElementById("menuItems-District_Dropdown");
  
    
     
    firestore.collection("SaatBara").where("name","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        currentVibhag = doc.id; 
      });
    }).then(()=>{
      var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District");
      docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            DISTRICT_List[DISTRICT_List_index++] = doc.data().name;
        });
      }).then(()=>{
        while(Dist_child_.childElementCount !== 0){
    
            Dist_child_.firstChild.remove();
        }
        console.log("Tahasil Karyalay",District_List)
        buildDropDown_District(DISTRICT_List);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });
  
    })
  
  }

let search_District_Dropdown = document.getElementById("search_District_Dropdown")

//Find every item inside the dropdown
let District_Dropdown_items = document.getElementById("menuItems-District_Dropdown");

function buildDropDown_District(values) {


    let contents = []
    for (let district of values) {
    contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${district}" onclick="Get_TALUKA(this.value,'District')"/>`)
    }
    $('#menuItems-District_Dropdown').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_District_Dropdown.addEventListener('input', function () {
  
  filter_dist_A(search_District_Dropdown.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_dist_A(word) {
    let length = District_Dropdown_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (District_Dropdown_items.children[i].value.toLowerCase().startsWith(word)) {
        $(District_Dropdown_items.children[i]).show()
    }
    else {
        $(District_Dropdown_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-District_Dropdown').on('click', '.dropdown-item', function(){
    
    document.querySelector('#Taluka_Dropdown_Button').disabled = false
    $('#District_Dropdown_button').text($(this)[0].value)
    $("#District_Dropdown_button").dropdown('toggle');

})


function Get_DISTRICT_E(params,flag) {

   
    var Dist_child_ = document.getElementById("menuItems-District_Dropdown_E");
  
    
     
    firestore.collection("SaatBara").where("name","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        currentVibhag = doc.id; 
      });
    }).then(()=>{
      var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District");
      docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            DISTRICT_List_E[DISTRICT_List_index_E++] = doc.data().name;
        });
      }).then(()=>{
        while(Dist_child_.childElementCount !== 0){
    
            Dist_child_.firstChild.remove();
        }
   
        buildDropDown_District_E(DISTRICT_List_E);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });
  
    })
  
  }

let search_District_Dropdown_E = document.getElementById("search_District_Dropdown_E")

//Find every item inside the dropdown
let District_Dropdown_items_E = document.getElementById("menuItems-District_Dropdown_E");

function buildDropDown_District_E(values) {


    let contents = []
    for (let district of values) {
    contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${district}" onclick="Get_TALUKA_E(this.value,'District')"/>`)
    }
    $('#menuItems-District_Dropdown_E').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box
search_District_Dropdown_E.addEventListener('input', function () {
  
  filter_dist_E(search_District_Dropdown_E.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_dist_E(word) {
    let length = District_Dropdown_items_E.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (District_Dropdown_items_E.children[i].value.toLowerCase().startsWith(word)) {
        $(District_Dropdown_items_E.children[i]).show()
    }
    else {
        $(District_Dropdown_items_E.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}


//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-District_Dropdown_E').on('click', '.dropdown-item', function(){
    
    document.querySelector('#Taluka_Dropdown_Button_E').disabled = false
    $('#District_Dropdown_button_E').text($(this)[0].value)
    $("#District_Dropdown_button_E").dropdown('toggle');

})



function Get_TALUKA (params,flag) {

    var Talu_child = document.getElementById("menuItems-Taluka_Dropdown");
  
    TALUKA_List = [];
     TALUKA_List_index = 0;
  
  
    CurrentSelectedFilter = flag;
  
    firestore.collection("SaatBara").doc(currentVibhag).collection("District").where("name","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
       
          currentDistrict = doc.id;
    });
    }).then(()=>{
  
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas")
  
        docRef.get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots

              TALUKA_List[TALUKA_List_index++] = doc.data().dtname;

          });
        }).then(()=>{
          
          while(Talu_child.childElementCount !== 0){
    
            Talu_child.firstChild.remove();

          }
          buildDropDown_Taluka(TALUKA_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })
  
}

  

let search_Taluka_Dropdown = document.getElementById("search_Taluka_Dropdown")

//Find every item inside the dropdown
let Taluka_Dropdown_items = document.getElementById("menuItems-Taluka_Dropdown");

function buildDropDown_Taluka(values) {
    let contents = []
    for (let Taluka  of values) {
    contents.push(`<input type="button" id="dropdown-item-taha" class="dropdown-item"  type="button" value="${Taluka}" onclick="Get_VILLAGE(this.value,'Tahasil')"/>`)
    }
    $('#menuItems-Taluka_Dropdown').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

search_Taluka_Dropdown.addEventListener('input', function () {
  
  
  filter_taha_A(search_Taluka_Dropdown.value.trim().toLowerCase())
})

function filter_taha_A(word) {
    let length = Taluka_Dropdown_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Taluka_Dropdown_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Taluka_Dropdown_items.children[i]).show()
    }
    else {
        $(Taluka_Dropdown_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-Taluka_Dropdown').on('click', '.dropdown-item', function(){

    document.querySelector('#village_Dropdown_button').disabled = false

    $('#Taluka_Dropdown_Button').text($(this)[0].value)
    $("#Taluka_Dropdown_Button").dropdown('toggle');

})




function Get_TALUKA_E (params,flag) {

    var Talu_child = document.getElementById("menuItems-Taluka_Dropdown_E");
  
    TALUKA_List_E = [];
     TALUKA_List_index_E = 0;
  
  
    CurrentSelectedFilter = flag;
  
    firestore.collection("SaatBara").doc(currentVibhag).collection("District").where("name","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
       
          currentDistrict = doc.id;
    });
    }).then(()=>{
  
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas")
  
        docRef.get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots

              TALUKA_List_E[TALUKA_List_index_E++] = doc.data().dtname;

          });
        }).then(()=>{
          
          while(Talu_child.childElementCount !== 0){
    
            Talu_child.firstChild.remove();

          }
          buildDropDown_Taluka_E(TALUKA_List_E);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })
  
}

  

let search_Taluka_Dropdown_E = document.getElementById("search_Taluka_Dropdown_E")

//Find every item inside the dropdown
let Taluka_Dropdown_items_E = document.getElementById("menuItems-Taluka_Dropdown_E");

function buildDropDown_Taluka_E(values) {
    let contents = []
    for (let Taluka  of values) {
    contents.push(`<input type="button" id="dropdown-item-taha" class="dropdown-item"  type="button" value="${Taluka}" onclick="Get_VILLAGE_E(this.value,'Tahasil')"/>`)
    }
    $('#menuItems-Taluka_Dropdown_E').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

search_Taluka_Dropdown_E.addEventListener('input', function () {
  
  
  filter_taha_E(search_Taluka_Dropdown_E.value.trim().toLowerCase())
})

function filter_taha_E(word) {
    let length = Taluka_Dropdown_items_E.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Taluka_Dropdown_items_E.children[i].value.toLowerCase().startsWith(word)) {
        $(Taluka_Dropdown_items_E.children[i]).show()
    }
    else {
        $(Taluka_Dropdown_items_E.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-Taluka_Dropdown_E').on('click', '.dropdown-item', function(){

    document.querySelector('#village_Dropdown_button_E').disabled = false

    $('#Taluka_Dropdown_Button_E').text($(this)[0].value)
    $("#Taluka_Dropdown_Button_E").dropdown('toggle');

})


function Get_VILLAGE (params,flag) {
    var Village_child = document.getElementById("menuItems-village_Dropdown");

     VILLAGE_List = [];
     VILLAGE_List_index = 0;
    CurrentSelectedFilter = flag;
  
    firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").where("dtname","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
       
          currentTaluka = doc.id
    });
    }).then(()=>{
  
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").doc(currentTaluka).collection("Villages")
  
        docRef.get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
       
              VILLAGE_List[VILLAGE_List_index++] = doc.data().village_name;
      
          
          });
        }).then(()=>{
          console.log("Village Karyalay",Village_List)
          while(Village_child.childElementCount !== 0){
    
            Village_child.firstChild.remove();
          }
          buildDropDown_VILLAGE(VILLAGE_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })
  
  }

let Search_VILLAGE = document.getElementById("search_VILLAGE")

//Find every item inside the dropdown
let village_items_village_Dropdown = document.getElementById("menuItems-village_Dropdown");

function buildDropDown_VILLAGE(values) {
    let contents = []
    for (let VILLAGE of values) {
    contents.push(`<input type="button" id="dropdown-item-village" class="dropdown-item"  type="button" value="${VILLAGE}"  />`)
    }
    $('#menuItems-village_Dropdown').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
Search_VILLAGE.addEventListener('input', function () {
  
  
  filter_villa_A(Search_VILLAGE.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_villa_A(word) {
    let length = village_items_village_Dropdown.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (village_items_village_Dropdown.children[i].value.toLowerCase().startsWith(word)) {
        $(village_items_village_Dropdown.children[i]).show()
    }
    else {
        $(village_items_village_Dropdown.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-village_Dropdown').on('click', '.dropdown-item', function(){

    $('#village_Dropdown_button').text($(this)[0].value)
    $("#village_Dropdown_button").dropdown('toggle');

})


function Get_VILLAGE_E (params,flag) {

    var Village_child = document.getElementById("menuItems-village_Dropdown_E");

     VILLAGE_List_E = [];
     VILLAGE_List_index_E = 0;
    CurrentSelectedFilter = flag;
  
    firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").where("dtname","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
       
          currentTaluka = doc.id
    });
    }).then(()=>{
  
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").doc(currentTaluka).collection("Villages")
  
        docRef.get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
       
              VILLAGE_List_E[VILLAGE_List_index_E++] = doc.data().village_name;
        
          });
        }).then(()=>{
          console.log("Village Karyalay",Village_List)
          while(Village_child.childElementCount !== 0){
    
            Village_child.firstChild.remove();
          }
          buildDropDown_VILLAGE_E(VILLAGE_List_E);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })
  
  }

let Search_VILLAGE_E = document.getElementById("search_VILLAGE_E")

let village_items_village_Dropdown_E = document.getElementById("menuItems-village_Dropdown_E");

function buildDropDown_VILLAGE_E(values) {
    let contents = []
    for (let VILLAGE of values) {
    contents.push(`<input type="button" id="dropdown-item-village" class="dropdown-item"  type="button" value="${VILLAGE}"  />`)
    }
    $('#menuItems-village_Dropdown_E').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
Search_VILLAGE_E.addEventListener('input', function () {
  
  
  filter_villa_E(Search_VILLAGE_E.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_villa_E(word) {
    let length = village_items_village_Dropdown_E.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (village_items_village_Dropdown_E.children[i].value.toLowerCase().startsWith(word)) {
        $(village_items_village_Dropdown_E.children[i]).show()
    }
    else {
        $(village_items_village_Dropdown_E.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-village_Dropdown_E').on('click', '.dropdown-item', function(){
    
    $('#village_Dropdown_button_E').text($(this)[0].value)
    $("#village_Dropdown_button_E").dropdown('toggle');

})






  var CropCategory_list = [];
  var CropCategory_list_index = 0;

  var pika_list = [];
  var pika_list_index = 0;

  var Vibhag_List = [] ;
  var Vibhag_List_index = 0; 

let District_List = [];
let District_List_index = 0;

let Tahasil_List = [];
let Tahasil_List_index = 0;

let Village_List = [];
let Village_List_index = 0;

    function Get_Main_Category() {

        var docRef = firestore.collection("ShetiPik").get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
    
                CropCategory_list[CropCategory_list_index++] = doc.data().mainCatName;
    
            });
          }).then(()=>{
    
           
            buildDropDown_Main_cat(CropCategory_list);
          }).catch((error) => {
              console.log("Error getting document:", error);
          });
    
    }

    Get_Main_Category();


    let search_pika = document.getElementById("searchCoin5")

    //Find every item inside the dropdown
    let Main_pika_items = document.getElementById("menuItems-pika");
    
    function buildDropDown_pika(values) {
        let contents = []
        for (let pika of values) {
        contents.push(`<input type="button" id="dropdown-menuItems-pika" class="dropdown-item"  type="button" value="${pika}"/>`)
        }
        $('#menuItems-pika').append(contents.join(""))
    
        //Hide the row that shows no items were found
        $('#empty').hide()
    }
    
    
    
    //Capture the event when user types into the search box
    search_pika.addEventListener('input', function () {
      
      
      filter_Main_pik(search_pika.value.trim().toLowerCase())
    })
    
    //For every word entered by the user, check if the symbol starts with that word
    //If it does show the symbol, else hide it
    function filter_Main_pik(word) {
        let length = Main_pika_items.children.length
        let collection = []
        let hidden = 0
        for (let i = 0; i < length; i++) {
        if (Main_pika_items.children[i].value.toLowerCase().startsWith(word)) {
            $(Main_pika_items.children[i]).show()
        }
        else {
            $(Main_pika_items.children[i]).hide()
            hidden++
        }
        }
    
        //If all items are hidden, show the empty view
        if (hidden === length) {
        $('#empty').show()
        }
        else {
        $('#empty').hide()
        }
    }
    
    //If the user clicks on any item, set the title of the button as the text of the item
      $('#menuItems-pika').on('click', '.dropdown-item', function(){
        
        CropSelected = "crop";
        Selected_Crop = $(this)[0].value
          $('#User_Peka_Sub_filter').text($(this)[0].value)
          $("#User_Peka_Sub_filter").dropdown('toggle');
  
      
      })
  


    function Get_Pika_Sub_Category(params,flag) {
        getpika(params);
    }
      
      function getpika (params) {
      
        var pik_child = document.getElementById("menuItems-pika");
      
        pika_list = [];
        pika_list_index = 0;
      
        var docRef = firestore.collection("ShetiPik").where("mainCatName","==", params).get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
              Selected_Main_Category_Doc = doc.id
              //  console.log("Vivek Dhande",  doc.data())

              var docRef = firestore.collection("ShetiPik").doc(doc.id).collection("SubCat")
      
              docRef.get().then((querySnapshot) => {
                  
                querySnapshot.forEach(element => {
                  
                  pika_list[pika_list_index++] = element.data().pikName;
             //     console.log("Pika Data",element.data().pikName) 
                });
              }).then(()=>{
                while(pik_child.childElementCount!==0){
                  pik_child.firstChild.remove();
                }
                console.log("Pika Data",pika_list); 
                buildDropDown_pika(pika_list);
        
              }).catch((error) => {
                  console.log("Error getting document:", error);
              });
            
      
          });
        }).then(()=>{

      

      
           
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
        
      }

      function Get_Vibhag(params) {
  
        firestore.collection("SaatBara").get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
        
      
              Vibhag_List [Vibhag_List_index++] = doc.data().name;
          });
        }).then(()=>{
        
      
          buildDropDown(Vibhag_List);
        })
      
      }
      
      Get_Vibhag();

//Vibhag
let items = document.getElementsByClassName("dropdown-item")
function buildDropDown(values) {
    let contents = []
    for (let name of values) {
    contents.push(`<input type="button" class="dropdown-item" type="button" value=${name} onclick="Get_District(this.value)"/>`)
    }
    $('#menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box


//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems').on('click', '.dropdown-item', function(){

    document.querySelector('#District_Drop_Down').disabled = false
    $('#dropdown_coins').text($(this)[0].value)
    $("#dropdown_coins").dropdown('toggle');

  
})


function Get_District(params,flag) {

    District_List = [];
    District_List_index = 0;
    var Dist_child = document.getElementById("menuItems-dist");
  
    console.log("menuItems-dist",Dist_child.childElementCount)
     
    firestore.collection("SaatBara").where("name","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        currentVibhag = doc.id; 
      });
    }).then(()=>{
      var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District");
      docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            District_List[District_List_index++] = doc.data().name;
        });
      }).then(()=>{
        while(Dist_child.childElementCount !== 0){
    
          Dist_child.firstChild.remove();
        }
        console.log("Tahasil Karyalay",District_List)
        buildDropDown_dist(District_List);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });
  
    })
  
  }

  let search_Dist = document.getElementById("searchCoin1")

//Find every item inside the dropdown
let Dist_items = document.getElementById("menuItems-dist");

function buildDropDown_dist(values) {


    let contents = []
    for (let dist of values) {
    contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${dist}" onclick="Get_Taluka(this.value,'District')"/>`)
    }
    $('#menuItems-dist').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}


function filter(word) {
  let length = items.length
  let collection = []
  let hidden = 0
  console.log(Dist_items.children[0])
  for (let i = 0; i < length; i++) {
  if (items[i].value.toLowerCase().startsWith(word)) {
      $(items[i]).show()
  }
  else {
      $(items[i]).hide()
      hidden++
  }
  }

  //If all items are hidden, show the empty view
  if (hidden === length) {
  $('#empty').show()
  }
  else {
  $('#empty').hide()
  }
}

//Capture the event when user types into the search box
search_Dist.addEventListener('input', function () {
  
  filter_dist(search_Dist.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_dist(word) {
    let length = Dist_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Dist_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Dist_items.children[i]).show()
    }
    else {
        $(Dist_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-dist').on('click', '.dropdown-item', function(){
    
    document.querySelector('#Tahasil').disabled = false
    $('#District_Drop_Down').text($(this)[0].value)
    $("#District_Drop_Down").dropdown('toggle');

    
  
})
  
  function Get_Taluka (params,flag) {
    var Talu_child = document.getElementById("menuItems-Taluka");
  
    Tahasil_List = [];
    Tahasil_List_index = 0;
  
  
    CurrentSelectedFilter = flag;
  
    firestore.collection("SaatBara").doc(currentVibhag).collection("District").where("name","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
       
          currentDistrict = doc.id;
    });
    }).then(()=>{
  
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas")
  
        docRef.get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
              console.log()
              Tahasil_List[Tahasil_List_index++] = doc.data().dtname;
      
          
          });
        }).then(()=>{
          console.log("Tahasil Karyalay",Tahasil_List)
          while(Talu_child.childElementCount !== 0){
    
            Talu_child.firstChild.remove();
          }
          buildDropDown_tahasil(Tahasil_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })
  
  }

  let search_Taluka = document.getElementById("searchCoin2")

//Find every item inside the dropdown
let Taluka_items = document.getElementById("menuItems-Taluka");

function buildDropDown_tahasil(values) {
    let contents = []
    for (let taluka of values) {
    contents.push(`<input type="button" id="dropdown-item-taha" class="dropdown-item"  type="button" value="${taluka}" onclick="Get_village(this.value,'Tahasil')"/>`)
    }
    $('#menuItems-Taluka').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



search_Taluka.addEventListener('input', function () {
  
  
  filter_taha(search_Taluka.value.trim().toLowerCase())
})


function filter_taha(word) {
    let length = Taluka_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Taluka_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Taluka_items.children[i]).show()
    }
    else {
        $(Taluka_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-Taluka').on('click', '.dropdown-item', function(){


    document.querySelector('#village').disabled = false

    $('#Tahasil').text($(this)[0].value)
    $("#Tahasil").dropdown('toggle');

})
  
  function Get_village (params,flag) {
    var Village_child = document.getElementById("menuItems-village");
    Village_List = [];
    Village_List_index = 0;
    CurrentSelectedFilter = flag;
  
    firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").where("dtname","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
       
          currentTaluka = doc.id
    });
    }).then(()=>{
  
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").doc(currentTaluka).collection("Villages")
  
        docRef.get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
       
              Village_List[Village_List_index++] = doc.data().village_name;
      
          
          });
        }).then(()=>{
          console.log("Village Karyalay",Village_List)
          while(Village_child.childElementCount !== 0){
    
            Village_child.firstChild.remove();
          }
          buildDropDown_village(Village_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })
  
  }
  

let search_village = document.getElementById("searchCoin3")

//Find every item inside the dropdown
let village_items = document.getElementById("menuItems-village");

function buildDropDown_village(values) {
    let contents = []
    for (let village of values) {
    contents.push(`<input type="button" id="dropdown-item-village" class="dropdown-item"  type="button" value="${village}"  />`)
    }
    $('#menuItems-village').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_village.addEventListener('input', function () {
  
  
  filter_villa(search_village.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_villa(word) {
    let length = village_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (village_items.children[i].value.toLowerCase().startsWith(word)) {
        $(village_items.children[i]).show()
    }
    else {
        $(village_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-village').on('click', '.dropdown-item', function(){

    $('#village').text($(this)[0].value)
    $("#village").dropdown('toggle');

})