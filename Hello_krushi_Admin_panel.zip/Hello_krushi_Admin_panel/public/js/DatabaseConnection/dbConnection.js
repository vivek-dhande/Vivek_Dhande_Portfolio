

const firebaseConfig = {
// Firebase Config code
  };
  firebase.initializeApp(firebaseConfig);