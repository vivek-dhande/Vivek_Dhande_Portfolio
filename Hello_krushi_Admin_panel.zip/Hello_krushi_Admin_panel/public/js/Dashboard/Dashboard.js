

var firestore = firebase.firestore();
var exportIndex = 0; 
var ExportDataList = []; 
var Data = [];
var index = 0;
var UserCount = [];
var FilterUser = [];

var UserCountIndex = 0;
var ShetiCount = 0;
var ProductCount = 0;

var Selected_Profession;


// firestore.collection("Userinfo").get().then((querySnapshot) => {
    
//        document.getElementById("userCount").innerText = querySnapshot.size
//        ExportDataList[exportIndex++] = querySnapshot.size

// });

// firestore.collection("postFeedData").get().then((querySnapshot) => {
    
//     document.getElementById("allPostCount").innerText = querySnapshot.size
//        ExportDataList[exportIndex++] = querySnapshot.size

// });

// firestore.collection("ECommerce").get().then((querySnapshot) => {
    
//     document.getElementById("productCount").innerText = querySnapshot.size
     
//       ExportDataList[exportIndex++] =querySnapshot.size
// });

// firestore.collection("postFeedData").where("reported", "==", true)
//     .get()
//     .then((querySnapshot) => {
//         document.getElementById("reportedPostCount").innerText = querySnapshot.size
//         ExportDataList[exportIndex++] = querySnapshot.size
//     })
//     .catch((error) => {
//         console.log("Error getting documents: ", error);
//     });

// firestore.collection("Sheti").get().then((querySnapshot) => {

//     document.getElementById("shetiCount").innerText = querySnapshot.size
//     ExportDataList[exportIndex++] = querySnapshot.size
        

// });



firestore.collection("Userinfo").get().then((Vivek) => {
   ExportDataList = []; 
   index = 0;
    
  document.getElementById("userCount").innerText = Vivek.size
  // ExportDataList[exportIndex++] = querySnapshot.size

  firestore.collection("postFeedData").get().then((Vivek1) => {
    
    document.getElementById("allPostCount").innerText = Vivek1.size
      //  ExportDataList[exportIndex++] = Vivek.size

       firestore.collection("ECommerce").get().then((Vivek2) => {

        document.getElementById("productCount").innerText = Vivek2.size
        
        //  ExportDataList[exportIndex++] =Vivek.size

         
          firestore.collection("postFeedData").where("reported", "==", true)
          .get()
          .then((Vivek3) => {
            document.getElementById("reportedPostCount").innerText = Vivek3.size
            // ExportDataList[exportIndex++] = Vivek.size

            firestore.collection("Sheti").get().then((Vivek4) => {

              document.getElementById("shetiCount").innerText = Vivek4.size
              ExportDataList[exportIndex] = [`${Vivek.size}`,`${Vivek1.size}`,`${Vivek2.size}`,`${Vivek3.size}`,`${Vivek4.size}`,moment()]
                
              
              });
          })
          .catch((error) => {
            console.log("Error getting documents: ", error);

            
     
          });


        });

  });

});







let Vibhag_List = [];
let Vibhag_List_index = 0;

let District_List = [];
let District_List_index = 0;

let Tahasil_List = [];
let Tahasil_List_index = 0;

let Village_List = [];
let Village_List_index = 0;

let CategoryList = [];
let CategoryList_index = 0;

let CropList = [];
let  CropListIndex = 0;

  var CatDocId;
var VibhagSlected;
var DistrictFilterSelected;
var TalukaFilterSelected;
var VillageFilterSlected;


var Selected_District;
var Selected_Village;
var Selected_Taluka;
var Selected_Vibhag;
var Selected_Category;
var Selected_Crop;


//Find the input search box
let search = document.getElementById("searchCoin") 
let search1 = document.getElementById("searchCoin1") 


//Find every item inside the dropdown
let items = document.getElementsByClassName("dropdown-item")
function buildDropDown(values) {
    let contents = []
    for (let name of values) {
    contents.push(`<input type="button" class="dropdown-item" type="button" value=${name} onclick="Get_District(this.value)"/>`)
    }
    $('#menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box
search.addEventListener('input', function () {


    filter(search.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems').on('click', '.dropdown-item', function(){

    Selected_Place = $(this)[0].value
    
    $('#dropdown_coins').text($(this)[0].value)
    $("#dropdown_coins").dropdown('toggle');

    document.querySelector('#ResetFilterInModal').style.display = ""
    document.querySelector('#District_Drop_Down').disabled = false
})


//Find the input search box
let search_Dist = document.getElementById("searchCoin1")

//Find every item inside the dropdown
let Dist_items = document.getElementById("menuItems-dist");

function buildDropDown_dist(values) {


    let contents = []
    for (let dist of values) {
    contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${dist}" onclick="Get_Taluka(this.value,'District')"/>`)
    }
    $('#menuItems-dist').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}


function filter(word) {
  let length = items.length
  let collection = []
  let hidden = 0
  console.log(Dist_items.children[0])
  for (let i = 0; i < length; i++) {
  if (items[i].value.toLowerCase().startsWith(word)) {
      $(items[i]).show()
  }
  else {
      $(items[i]).hide()
      hidden++
  }
  }

  //If all items are hidden, show the empty view
  if (hidden === length) {
  $('#empty').show()
  }
  else {
  $('#empty').hide()
  }
}

//Capture the event when user types into the search box
search1.addEventListener('input', function () {
  
  filter_dist(search_Dist.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_dist(word) {
    let length = Dist_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Dist_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Dist_items.children[i]).show()
    }
    else {
        $(Dist_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-dist').on('click', '.dropdown-item', function(){

    // alert("District");

    DistrictFilterSelected = 'district';
    Selected_District = $(this)[0].value;

    Selected_Place = $(this)[0].value
    CurrentSelectedFilter = 'District'
    $('#District_Drop_Down').text($(this)[0].value)
    $("#District_Drop_Down").dropdown('toggle');

    WhichFilterSelected = "district";

    document.querySelector('#Tahasil').disabled = false
})


let search_Taluka = document.getElementById("searchCoin2")

//Find every item inside the dropdown
let Taluka_items = document.getElementById("menuItems-Taluka");

function buildDropDown_tahasil(values) {
    let contents = []
    for (let taluka of values) {
    contents.push(`<input type="button" id="dropdown-item-taha" class="dropdown-item"  type="button" value="${taluka}" onclick="Get_village(this.value,'Tahasil')"/>`)
    }
    $('#menuItems-Taluka').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_Taluka.addEventListener('input', function () {
  
  
  filter_taha(search_Taluka.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_taha(word) {
    let length = Taluka_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Taluka_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Taluka_items.children[i]).show()
    }
    else {
        $(Taluka_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-Taluka').on('click', '.dropdown-item', function(){


  TalukaFilterSelected = 'tahsil';
  Selected_Taluka =  $(this)[0].value
  CurrentSelectedFilter = 'Tahasil'
  WhichFilterSelected = "tahsil";
  Selected_Place = $(this)[0].value
    $('#Tahasil').text($(this)[0].value)
    $("#Tahasil").dropdown('toggle');
    document.querySelector('#village').disabled = false
})

let search_village = document.getElementById("searchCoin3")

//Find every item inside the dropdown
let village_items = document.getElementById("menuItems-village");

function buildDropDown_village(values) {
    let contents = []
    for (let village of values) {
    contents.push(`<input type="button" id="dropdown-item-village" class="dropdown-item"  type="button" value="${village}"  />`)
    }
    $('#menuItems-village').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_village.addEventListener('input', function () {
  
  
  filter_villa(search_village.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_villa(word) {
    let length = village_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (village_items.children[i].value.toLowerCase().startsWith(word)) {
        $(village_items.children[i]).show()
    }
    else {
        $(village_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-village').on('click', '.dropdown-item', function(){

  VillageFilterSlected = 'village';
  Selected_Village = $(this)[0].value;

  WhichFilterSelected = "village";
  CurrentSelectedFilter = 'Village'
  Selected_Place = $(this)[0].value
    $('#village').text($(this)[0].value)
    $("#village").dropdown('toggle');
})



function Get_Vibhag(params) {
  
    firestore.collection("SaatBara").get().then((querySnapshot) => {
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
          console.log(doc.id, " => ", doc.data().call);
  
          Vibhag_List [Vibhag_List_index++] = doc.data().name;
      });
    }).then(()=>{
    
  
      buildDropDown(Vibhag_List);
    })
  
}
  
  Get_Vibhag();
  
  function Get_District(params,flag) {
  
    District_List = [];
    District_List_index = 0;
    var Dist_child = document.getElementById("menuItems-dist");
  
    console.log("menuItems-dist",Dist_child.childElementCount)
     
    firestore.collection("SaatBara").where("name","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        currentVibhag = doc.id; 
      });
    }).then(()=>{
      var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District");
      docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            District_List[District_List_index++] = doc.data().name;
        });
      }).then(()=>{
        while(Dist_child.childElementCount !== 0){
    
          Dist_child.firstChild.remove();
        }
        console.log("Tahasil Karyalay",District_List)
        buildDropDown_dist(District_List);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });
  
    })
  
  }
  
  
  function Get_Taluka (params,flag) {
    var Talu_child = document.getElementById("menuItems-Taluka");
  
    Tahasil_List = [];
    Tahasil_List_index = 0;
  
  
  //   CurrentSelectedFilter = flag;
  
    firestore.collection("SaatBara").doc(currentVibhag).collection("District").where("name","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
       
          currentDistrict = doc.id;
    });
    }).then(()=>{
  
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas")
  
        docRef.get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
              console.log()
              Tahasil_List[Tahasil_List_index++] = doc.data().dtname;
      
          
          });
        }).then(()=>{
          console.log("Tahasil Karyalay",Tahasil_List)
          while(Talu_child.childElementCount !== 0){
    
            Talu_child.firstChild.remove();
          }
          buildDropDown_tahasil(Tahasil_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })
  
  }
  
  function Get_village (params,flag) {
    var Village_child = document.getElementById("menuItems-village");
    Village_List = [];
    Village_List_index = 0;
  
  
  //   CurrentSelectedFilter = flag;
  
    firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").where("dtname","==",params).get().then((querySnapshot)=>{
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
       
          currentTaluka = doc.id
    });
    }).then(()=>{
  
        var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").doc(currentTaluka).collection("Villages")
  
        docRef.get().then((querySnapshot) => {
          querySnapshot.forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
       
              Village_List[Village_List_index++] = doc.data().village_name;
      
          
          });
        }).then(()=>{
          console.log("Village Karyalay",Village_List)
          while(Village_child.childElementCount !== 0){
    
            Village_child.firstChild.remove();
          }
          buildDropDown_village(Village_List);
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
    })
  
  }
  
  Get_Category();
  function Get_Category(params) {
  
    firestore.collection("ShetiPik").get().then((querySnapshot) => {
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
          console.log(doc.id, " => ", doc.data().call);
  
          CategoryList [CategoryList_index++] = doc.data().mainCatName;
      });
    }).then(()=>{
    
  
      buildDropDown_Catgory(CategoryList);
    })
  
}


let Search_cat = document.getElementById("search_Category_Drop_Down") 


//Find every item inside the dropdown
let CatDropMenu = document.getElementById("Category_menuItems")
function buildDropDown_Catgory(values) {
    let contents = []
    for (let name of values) {
    contents.push(`<input type="button" class="dropdown-item" type="button" value="${name}" onclick="Get_Crop(this.value)"/>`)
    }
    $('#Category_menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box
Search_cat.addEventListener('input', function () {


    filter_cat(Search_cat.value.trim().toLowerCase())
})
function filter_cat(word) {
  let length = CatDropMenu.children.length
  let collection = []
  let hidden = 0
  for (let i = 0; i < length; i++) {
  if (CatDropMenu.children[i].value.toLowerCase().startsWith(word)) {
      $(CatDropMenu.children[i]).show()
  }
  else {
      $(CatDropMenu.children[i]).hide()
      hidden++
  }
  }

  //If all items are hidden, show the empty view
  if (hidden === length) {
  $('#empty').show()
  }
  else {
  $('#empty').hide()
  }
}


$('#Category_menuItems').on('click', '.dropdown-item', function(){

    $('#Category_Drop_Down').text($(this)[0].value)
    $("#Category_Drop_Down").dropdown('toggle');
    Selected_Category = $(this)[0].value;


    document.querySelector('#ResetFilterInModal').style.display = ""
    document.querySelector('#District_Drop_Down').disabled = false
})


// Pika
function Get_Crop(params) {
console.log("params",params)
  firestore.collection("ShetiPik").where("mainCatName","==",params).get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
    
      console.log("नगदी",doc.id,doc.data());
                  CatDocId = doc.id;
    })
    
  }).then(()=>{

    firestore.collection("ShetiPik").doc(CatDocId).collection("SubCat").get().then((querySnapshot) => {
      querySnapshot.forEach((Crop) => {
        console.log("Crop.data().pikName",Crop.data().pikName)
         
            CropList[CropListIndex++] = Crop.data().pikName;
      });

    }).then(()=>{
      buildDropDown_Crop(CropList);
    })

  })

}

let Search_Crop = document.getElementById("search_Crop_Drop_Down") 


//Find every item inside the dropdown
let CropMenu = document.getElementById("Crop_Drop_Down_menuItems")
function buildDropDown_Crop(values) {

  let contents = []
  for (let name of values) {
    console.log("name",name)
  contents.push(`<input type="button" class="dropdown-item" type="button" value="${name}"/>`)
  }
  $('#Crop_Drop_Down_menuItems').append(contents.join(""))

  //Hide the row that shows no items were found
  $('#empty').hide()
}

//Capture the event when user types into the search box
Search_Crop.addEventListener('input', function () {


  filter_crop(Search_Crop.value.trim().toLowerCase())
})
function filter_crop(word) {
let length = CropMenu.children.length
let collection = []
let hidden = 0
for (let i = 0; i < length; i++) {
if (CropMenu.children[i].value.toLowerCase().startsWith(word)) {
    $(CropMenu.children[i]).show()
}
else {
    $(CropMenu.children[i]).hide()
    hidden++
}
}

//If all items are hidden, show the empty view
if (hidden === length) {
$('#empty').show()
}
else {
$('#empty').hide()
}
}


$('#Crop_Drop_Down_menuItems').on('click', '.dropdown-item', function(){



  $('#Crop_Drop_Down').text($(this)[0].value)
  $("#Crop_Drop_Down").dropdown('toggle');
  Selected_Crop = $(this)[0].value;
  document.querySelector('#ResetFilterInModal').style.display = ""
  document.querySelector('#District_Drop_Down').disabled = false
})

// Proffession 

$('#Profession_menuItems').on('click', '.dropdown-item', function(){

  $('#Profession_Drop_Down').text($(this)[0].value)
  $("#Profession_Drop_Down").dropdown('toggle');
  Selected_Profession = $(this)[0].value;


  document.querySelector('#ResetFilterInModal').style.display = ""
 
})


  function ApplyFilter(params) {
                
  
  if(DistrictFilterSelected !== undefined){
    document.getElementById("District_Checked").style.display = "";
  }else{
    document.getElementById("District_Checked").style.display = "none";
  }

  if(TalukaFilterSelected !== undefined){
    document.getElementById("Taluka_Checked").style.display = "";
  }else{
    document.getElementById("Taluka_Checked").style.display = "none";
  }

  if(VillageFilterSlected !== undefined){
    document.getElementById("Village_Checked").style.display = "";
  }else{
    document.getElementById("Village_Checked").style.display = "none";
  }

  if(Selected_Category !== undefined){
    document.getElementById("Category_Checked").style.display = "";
  }else{
    document.getElementById("Category_Checked").style.display = "none";
  }

  if(Selected_Crop !== undefined){
    document.getElementById("Crop_Checked").style.display = "";
  }else{
    document.getElementById("Crop_Checked").style.display = "none";
  }

  if(Selected_Profession !== undefined){
    document.getElementById("Proffesion_Checked").style.display = "";
  }else{
    document.getElementById("Proffesion_Checked").style.display = "none";
  }
  
  
  if(Selected_Profession !== undefined){


    if(Selected_Crop !== undefined){

        if(VillageFilterSlected !== undefined){

            alert("Crop Village")
          filters('crop',Selected_Crop,VillageFilterSlected,Selected_Village,'userType',Selected_Profession)

        }else if(TalukaFilterSelected !== undefined){
            alert("Crop Taluka")
          filters('crop',Selected_Crop,TalukaFilterSelected,Selected_Taluka,'userType',Selected_Profession)

        }else if(DistrictFilterSelected !== undefined){
            alert("Crop District")
          filters('crop',Selected_Crop,DistrictFilterSelected,Selected_District,'userType',Selected_Profession)
        }else{
          alert("Only Crop")
          filters('crop',Selected_Crop,'userType',Selected_Profession)
        }

    }
    else if(Selected_Category!==undefined ){
        
          if(VillageFilterSlected !== undefined){
            alert("Cat Village")
            filters('cropMainCat',Selected_Category,VillageFilterSlected,Selected_Village,'userType',Selected_Profession)

          }else if(TalukaFilterSelected !== undefined){
            alert("Cat Taluka")
            filters('cropMainCat',Selected_Category,TalukaFilterSelected,Selected_Taluka,'userType',Selected_Profession)

          }else if(DistrictFilterSelected !== undefined){
            alert("Cat District")
            filters('cropMainCat',Selected_Category,DistrictFilterSelected,Selected_District,'userType',Selected_Profession)
          }else {
            alert("Only Cat")
            filters('cropMainCat',Selected_Category,'userType',Selected_Profession)

          }
      
    }else{
      if(VillageFilterSlected !== undefined){
        alert("Village")
        filters(VillageFilterSlected,Selected_Village,'userType',Selected_Profession)

      }else if(TalukaFilterSelected !== undefined){
        alert(" Taluka")
        filters(TalukaFilterSelected,Selected_Taluka,'userType',Selected_Profession)

      }else if(DistrictFilterSelected !== undefined){
        alert("District")
        filters(DistrictFilterSelected,Selected_District,'userType',Selected_Profession)
      }else{
        alert("Only UserType")
        filters('userType',Selected_Profession)

      }
    }

    }
    else if(Selected_Category!==undefined || Selected_Crop !== undefined){


      if(Selected_Crop !== undefined){

          if(VillageFilterSlected !== undefined){

              alert("Crop Village")
            filters('crop',Selected_Crop,VillageFilterSlected,Selected_Village)

          }else if(TalukaFilterSelected !== undefined){
              alert("Crop Taluka")
            filters('crop',Selected_Crop,TalukaFilterSelected,Selected_Taluka)

          }else if(DistrictFilterSelected !== undefined){
              alert("Crop District")
            filters('crop',Selected_Crop,DistrictFilterSelected,Selected_District)
          }else{
            alert("Only Crop")
            filters('crop',Selected_Crop)
          }
  
        }
        else if(Selected_Category!==undefined ){
          
            if(VillageFilterSlected !== undefined){
              alert("Cat Village")
              filters('cropMainCat',Selected_Category,VillageFilterSlected,Selected_Village)

            }else if(TalukaFilterSelected !== undefined){
              alert("Cat Taluka")
              filters('cropMainCat',Selected_Category,TalukaFilterSelected,Selected_Taluka)

            }else if(DistrictFilterSelected !== undefined){
              alert("Cat District")
              filters('cropMainCat',Selected_Category,DistrictFilterSelected,Selected_District)
            }else {
              alert("Only Cat")
              filters('cropMainCat',Selected_Category)

            }
        
        }

    }
    else{
       if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined){
        
        // document.getElementById("District_Checked").style.display = "";
  
          //District
          console.log("Vivek Dhande")
          // alert("District");
       //   DistrictFilter(DistrictFilterSelected,Selected_District);
          filters(DistrictFilterSelected,Selected_District)
  
      }
      else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined){
        // document.getElementById("Taluka_Checked").style.display = "";
  
          //Taluka
          // alert("Taluka");
          // DistrictFilter(TalukaFilterSelected,Selected_Taluka);
          console.log(TalukaFilterSelected,Selected_Taluka)
          filters(TalukaFilterSelected,Selected_Taluka)
  
      }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined){
        // document.getElementById("Village_Checked").style.display = "";
              //Village
          // alert("Village");
  
          // DistrictFilter(VillageFilterSlected,Selected_Village);
          filters(VillageFilterSlected,Selected_Village)
              
      }
    }
   

}


function filters(params,params2,params3,params4,params5,params6) {
    
  ExportDataList=[];
  exportIndex = 0;

  if(Selected_Profession !== undefined){

   if(Selected_Category!==undefined || Selected_Crop !== undefined){

    if(params3 == undefined && params4 == undefined){
      firestore.collection("Sheti").where(params,"==",params2).get().then((querySnapshot) => {
      
        document.getElementById("shetiCount").innerText = querySnapshot.size
        console.log("Sheti Count",UserCount)
        ShetiCount = querySnapshot.size;
        
        querySnapshot.forEach((doc)=>{

          UserCount[UserCountIndex++] = doc.data().userId;

        })
      }).then(()=>{

        console.log("UserCount",[...new Set(UserCount)])
         document.getElementById("userCount").innerText = [...new Set(UserCount)].length
      

         ExportDataList[exportIndex++] = [`${params2}`,`${[...new Set(UserCount)].length}`,'filter Disbale','filter Disbale','filter Disbale',`${ShetiCount}`,moment()];

      })
  
    }else if(params3 !== undefined && params4 !== undefined && params5 == undefined && params6 == undefined){

      UserCount = [];
      UserCountIndex = 0;

      firestore.collection("Sheti").where(params,"==",params2).where(params3,"==",params4).get().then((querySnapshot) => {
      
        document.getElementById("shetiCount").innerText = querySnapshot.size
        ShetiCount = querySnapshot.size;
        querySnapshot.forEach((doc)=>{
  
          UserCount[UserCountIndex++] = doc.data().userId;
        
        })
      }).then(()=>{
        document.getElementById("userCount").innerText = [...new Set(UserCount)].length
        firestore.collection("ECommerce").where(params3,"==",params4).get().then((vivek) =>{
            
          document.getElementById("productCount").innerText = vivek.size
          ProductCount = vivek.size;
       }).then(()=>{

        ExportDataList[exportIndex++] = [`${params2}-${params4}`,`${[...new Set(UserCount)].length}`,'filter Disbale',`${ProductCount}`,'filter Disbale',`${ShetiCount}`,moment()];

       })

      })
  
  


    }else if(params3 !== undefined && params4 !== undefined && params5 !== undefined && params6 !== undefined){

      UserCount = [];
      UserCountIndex = 0;

      firestore.collection("Sheti").where(params,"==",params2).where(params3,"==",params4).where(params5,"==",params6).get().then((querySnapshot) => {
      
        document.getElementById("shetiCount").innerText = querySnapshot.size
        ShetiCount = querySnapshot.size;
        querySnapshot.forEach((doc)=>{
  
          UserCount[UserCountIndex++] = doc.data().userId;
        
        })
      }).then(()=>{
        document.getElementById("userCount").innerText = [...new Set(UserCount)].length
        firestore.collection("ECommerce").where(params3,"==",params4).get().then((vivek) =>{
            
          document.getElementById("productCount").innerText = vivek.size
          ProductCount = vivek.size;
       }).then(()=>{

        ExportDataList[exportIndex++] = [`${params2}-${params4}`,`${[...new Set(UserCount)].length}`,'filter Disbale',`${ProductCount}`,'filter Disbale',`${ShetiCount}`,moment()];

       })

      })
  
  


    }
  }else{
    if(params3 !== undefined && params4 !== undefined){
      UserCount = [];
      UserCountIndex = 0;

      firestore.collection("Sheti").where(params,"==",params2).where(params3,"==",params4).get().then((querySnapshot) => {
      
        document.getElementById("shetiCount").innerText = querySnapshot.size
        ShetiCount = querySnapshot.size;
        querySnapshot.forEach((doc)=>{
  
          UserCount[UserCountIndex++] = doc.data().userId;
        
        })
      }).then(()=>{
        document.getElementById("userCount").innerText = [...new Set(UserCount)].length
        firestore.collection("ECommerce").where(params3,"==",params4).get().then((vivek) =>{
            
          document.getElementById("productCount").innerText = vivek.size
          ProductCount = vivek.size;
       }).then(()=>{

        ExportDataList[exportIndex++] = [`${params2}-${params4}`,`${[...new Set(UserCount)].length}`,'filter Disbale',`${ProductCount}`,'filter Disbale',`${ShetiCount}`,moment()];

       })

      })
  
    }else{
      firestore.collection("Sheti").where(params,"==",params2).get().then((querySnapshot) => {
      
        document.getElementById("shetiCount").innerText = querySnapshot.size
        console.log("Sheti Count",UserCount)
        ShetiCount = querySnapshot.size;
        
        querySnapshot.forEach((doc)=>{

          UserCount[UserCountIndex++] = doc.data().userId;

        })
      }).then(()=>{

        console.log("UserCount",[...new Set(UserCount)])
         document.getElementById("userCount").innerText = [...new Set(UserCount)].length
      

         ExportDataList[exportIndex++] = [`${params2}`,`${[...new Set(UserCount)].length}`,'filter Disbale','filter Disbale','filter Disbale',`${ShetiCount}`,moment()];

      })
    }
  }

  }
  else if(Selected_Category!==undefined || Selected_Crop !== undefined){

    if(params3 == undefined && params4 == undefined){
      firestore.collection("Sheti").where(params,"==",params2).get().then((querySnapshot) => {
      
        document.getElementById("shetiCount").innerText = querySnapshot.size
        console.log("Sheti Count",UserCount)
        ShetiCount = querySnapshot.size;
        
        querySnapshot.forEach((doc)=>{

          UserCount[UserCountIndex++] = doc.data().userId;


          // firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) =>{
          //   querySnapshot.forEach((doc)=>{

          //     UserCount[UserCount++] = 
                    
          //   })
               
          // }).then(()=>{
          //   // document.getElementById("userCount").innerText = UserCount
          
    
          //   // document.getElementById("userCount").innerText = UserCount
    
          // })
        })
      }).then(()=>{

        console.log("UserCount",[...new Set(UserCount)])
         document.getElementById("userCount").innerText = [...new Set(UserCount)].length
      

         ExportDataList[exportIndex++] = [`${params2}`,`${[...new Set(UserCount)].length}`,'filter Disbale','filter Disbale','filter Disbale',`${ShetiCount}`,moment()];

      })
  
    }else{

      UserCount = [];
      UserCountIndex = 0;

      firestore.collection("Sheti").where(params,"==",params2).where(params3,"==",params4).get().then((querySnapshot) => {
      
        document.getElementById("shetiCount").innerText = querySnapshot.size
        ShetiCount = querySnapshot.size;
        querySnapshot.forEach((doc)=>{
  
          UserCount[UserCountIndex++] = doc.data().userId;
        
        })
      }).then(()=>{
        document.getElementById("userCount").innerText = [...new Set(UserCount)].length
        firestore.collection("ECommerce").where(params3,"==",params4).get().then((vivek) =>{
            
          document.getElementById("productCount").innerText = vivek.size
          ProductCount = vivek.size;
       }).then(()=>{

        ExportDataList[exportIndex++] = [`${params2}-${params4}`,`${[...new Set(UserCount)].length}`,'filter Disbale',`${ProductCount}`,'filter Disbale',`${ShetiCount}`,moment()];

       })

      })
  
  


    }

  }else{


      firestore.collection("Userinfo").where(params,"==",params2).get().then((vivek) => {
        
        document.getElementById("userCount").innerText = vivek.size   
  
        firestore.collection("ECommerce").where(params,"==",params2).get().then((vivek1) => {
    
          document.getElementById("productCount").innerText = vivek1.size
  
          firestore.collection("Sheti").where(params,"==",params2).get().then((vivek2) => {
    
            document.getElementById("shetiCount").innerText = vivek2.size
          
            ExportDataList[exportIndex] = [`${params2}`,`${vivek.size}`, `Filter Disable`,`${vivek1.size}`,`Filter Disable`,`${vivek2.size}`,moment()]
  
        
        });   
        });
    });
    }

  }
    


function DashBoard_Filter(params) {
         
        
        $('#FilterModal').modal();

    
}


function ResetFilter(params) {

    location.reload();

    document.querySelector('#ResetFilterInModal').style.display = "none"
    document.getElementById("District_Checked").style.display = "none";
    document.getElementById("Taluka_Checked").style.display = "none";
    document.getElementById("Village_Checked").style.display = "none";
    
    
    
    $('#dropdown_coins').text('विभाग')
    $('#District_Drop_Down').text('जिल्हा')
    $('#Tahasil').text('तालुका')
    $('#village').text('गाव')

    DistrictFilterSelected = undefined;
    TalukaFilterSelected = undefined;
    VillageFilterSlected = undefined;

    Selected_District = "";
    Selected_Taluka = "";
    Selected_Village = ""; 

//     firestore.collection("Userinfo").get().then((querySnapshot) => {
    
//         document.getElementById("userCount").innerText = querySnapshot.size
         
 
//  });
 
//  firestore.collection("postFeedData").get().then((querySnapshot) => {
     
//      document.getElementById("allPostCount").innerText = querySnapshot.size
      
 
//  });
 
//  firestore.collection("ECommerce").get().then((querySnapshot) => {
     
//      document.getElementById("productCount").innerText = querySnapshot.size
      
 
//  });
 
//  firestore.collection("postFeedData").where("reported", "==", true)
//      .get()
//      .then((querySnapshot) => {
//          document.getElementById("reportedPostCount").innerText = querySnapshot.size
//      })
//      .catch((error) => {
//          console.log("Error getting documents: ", error);
//      });
 
//  firestore.collection("Sheti").get().then((querySnapshot) => {
 
//      document.getElementById("shetiCount").innerText = querySnapshot.size
         
 
//  });
// firestore.collection("Userinfo").get().then((Vivek) => {
//   ExportDataList = []; 
//   index = 0;
   
//  document.getElementById("userCount").innerText = Vivek.size
//  // ExportDataList[exportIndex++] = querySnapshot.size

//  firestore.collection("postFeedData").get().then((Vivek1) => {
   
//    document.getElementById("allPostCount").innerText = Vivek1.size
//      //  ExportDataList[exportIndex++] = Vivek.size

//       firestore.collection("ECommerce").get().then((Vivek2) => {

//        document.getElementById("productCount").innerText = Vivek2.size
       
//        //  ExportDataList[exportIndex++] =Vivek.size

        
//          firestore.collection("postFeedData").where("reported", "==", true)
//          .get()
//          .then((Vivek3) => {
//            document.getElementById("reportedPostCount").innerText = Vivek3.size
//            // ExportDataList[exportIndex++] = Vivek.size

//            firestore.collection("Sheti").get().then((Vivek4) => {

//              document.getElementById("shetiCount").innerText = Vivek4.size
//              ExportDataList[exportIndex] = [`${Vivek.size}`,`${Vivek1.size}`,`${Vivek2.size}`,`${Vivek3.size}`,`${Vivek4.size}`,moment()]
               
             
//              });
//          })
//          .catch((error) => {
//            console.log("Error getting documents: ", error);

           
    
//          });


//        });

//  });

// });


}


function ExportData_DashBoard(params) {



  var csv = 'Filter Type,User Count,Post Count,Product Count,Reported Post Count ,Sheti Count,Date of Report\n';
  //console.log("ExportDataList",ExportDataList)

  // ExportDataList.forEach(element => {
  //   Data[index++] = [element[0],element[1],element[2],element[3],element[4]]
  // }).then(()=>{
  //   console.log("data",Data)
  // })

 ExportDataList.forEach(function (row) {
    console.log(row)
    csv += row.join(",");
    csv += "\n";
  });

  //display the created CSV data on the web browser 



  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';

  //provide the name for the CSV file to be downloaded
  hiddenElement.download = `Exported data.csv`;

  hiddenElement.click();
}


function Routing(params) {

  if(params == "user"){
    window.location.replace("/users/users.html");
  }else if(params == "products"){

    window.location.replace("/products/products.html");
  }else if(params == "products"){

    window.location.replace("/products/products.html");
  }else if(params == "pika"){

    window.location.replace("/pika/pika.html");
  }else if(params == "post"){

    window.location.replace("/posts/posts.html");
  }else if(params == "report"){

    window.location.replace("/reports/reportedPost.html");
  }else if(params == "sheti"){

    window.location.replace("/sheti/sheti.html");
  }else if(params == "Slider"){

    window.location.replace("/Slider/slider.html");
  }else if(params == "sheti"){

    window.location.replace("/sheti/sheti.html");
  }
  
  
}