var firestore = firebase.firestore();
var lastVisiblePost;
document.getElementById("LoadMoreButton").style.display = "none";

function reports(params) {

    firestore.collection("postFeedData").where("reported","==",true).orderBy("date","desc").limit(3).get().then((querySnapshot) => {
        lastVisiblePost = querySnapshot.docs[querySnapshot.docs.length-1];
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data().uid);
            firestore.collection("Userinfo").where("userID", "==", doc.data().uid)
            .get()
            .then((querySnapshot) => {
                querySnapshot.forEach((userDoc) => {
                    // doc.data() is never undefined for query doc snapshots
                    console.log(userDoc.id, " => ", userDoc.data());
                    var PriflePic;
                                        
                    var english = /^[A-Za-z0-9]*$/;
                    var check = userDoc.data().userName
                    
                    
                    if(userDoc.data().userProfilePic == ""){
                        
                        if( english.test(check.charAt(0)) == true){
                            var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                            switch (UserName_Copy.charAt(0).toLowerCase()) {
            
                                case 'a':
                                    PriflePic= "/img/a.svg";
                                    break;
                                    
                                case 'b':
                                    PriflePic= "/img/b.svg";
                                    break;
                                
                                case 'c':
                                    PriflePic= "/img/c.svg";
                                    break;
                                    
                                case 'd':
                                    PriflePic= "/img/d.svg";
                                    break;
                                    
                                case 'e':
                                    PriflePic= "/img/e.svg";
                                    break;
                                    
                                case 'f':
                                    PriflePic= "/img/f.svg";
                                    break;
                                    
                                case 'g':
                                    PriflePic= "/img/g.svg";
                                    break;
                                    
                                case 'h':
                                    PriflePic= "/img/h.svg";
                                    break;
                                    
                                case 'i':
                                    PriflePic= "/img/i.svg";
                                    break;
                                    
                                case 'j':
                                    PriflePic= "/img/j.svg";
                                    break;
                                    
                                case 'k':
                                    PriflePic= "/img/k.svg";
                                    break;
                                    
                                case 'l':
                                    PriflePic= "/img/l.svg";
                                    break;
                                    
                                case 'm':
                                    PriflePic= "/img/m.svg";
                                    break;
                                    
                                case 'n':
                                    PriflePic= "/img/n.svg";
                                    break;
                                    
                                case 'o':
                                    PriflePic= "/img/o.svg";
                                    break;
                                    
                                case 'p':
                                    PriflePic= "/img/p.svg";
                                    break;
                                    
                                case 'q':
                                    PriflePic= "/img/q.svg";
                                    break;
                                    
                                case 'r':
                                    PriflePic= "/img/r.svg";
                                    break;
                                    
                                case 's':
                                    PriflePic= "/img/s.svg";
                                    break;
                                    
                                case 't':
                                    PriflePic= "/img/t.svg";
                                    break;
                                    
                                case 'u':
                                    PriflePic= "/img/u.svg";
                                    break;
                                    
                                case 'v':
                                    PriflePic= "/img/v.svg";
                                    break;
                                
                                case 'w':
                                    PriflePic= "/img/w.svg";
                                    break;
                                    
                                case 'x':
                                    PriflePic= "/img/x.svg";
                                    break;
                                
                                case 'y':
                                    PriflePic= "/img/y.svg";
                                    break;
                                
                                case 'z':
                                    PriflePic= "/img/z.svg";
                                    break;
                            
                        }
                        }
                        else{
                            PriflePic= "/img/person.svg";
                        }  
                        }
                        else{
                            PriflePic = userDoc.data().userProfilePic
                            
                        } 
                    

                        $("#AllReportedPostList").append(`<div id="${doc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                        <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                            <div class="card-body">
                            <div>
                            <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                            <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                            <span style="display: flex;
                            justify-content: flex-end;">${moment(doc.data().date.toDate()).format('LL')}</span>
                            <hr>
            
                            </div>
                            <div id="Product_title" style="display: flex;justify-content: space-between;">
                            </div>
                            <div>

                            <img src="${doc.data().imgUri}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                            <p style="margin-top: 1rem;  display: inline-block;
                            width: 200px;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;"> ${doc.data().caption} </p>
                            </div>
                            <hr>
                            <div id="utilities" style="
                        display: flex;
                        justify-content: space-evenly;
                        
                        
                    
                      
                    ">
                    <a id="${doc.id}" class="btn btn-info btn-circle btn-lg" onclick = "openPostInfo(this.id,'${PriflePic}','${userDoc.data().userName}')">
                    <i class="fas fa-info-circle"></i>
                    </a>     
                    <a id="${doc.id}" class="btn btn-success btn-circle btn-lg" onclick = "unreportThePost(this.id)" >
                    <i class="fas fa-check"></i>
                     </a>   
                    <a id="${doc.id}" class="btn btn-danger btn-circle btn-lg" onclick = "deletepost(this.id)" >
                             <i class="fas fa-trash"></i>
                    </a>
                   
                        </div>
                        </div>
                        </div>
                        
                    </div>`)
                    document.getElementById("LoadMoreButton").style.display = "flex";
                    document.getElementById("NoProduct").style.display = "none";

                    
                });
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });
                    

            //End
        });
    });
    
   
}
reports();


function GetMoreReportedposts() {
    firestore.collection("postFeedData").where("reported", "==", true).orderBy("date","desc").startAfter(lastVisiblePost).limit(3)
    .get()
    .then((querySnapshot) => {
        lastVisiblePost = querySnapshot.docs[querySnapshot.docs.length-1];
        if( querySnapshot.docs.length == 0 ){
            document.getElementById("LoadMoreButton").style.display = "none"
          }
          else{
          
          }

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
         
            firestore.collection("Userinfo").where("userID", "==", doc.data().uid)
                                    .get()
                                    .then((querySnapshot) => {
                                        querySnapshot.forEach((userDoc) => {
                                            // doc.data() is never undefined for query doc snapshots
                                            var PriflePic;
                                        
                                            var english = /^[A-Za-z0-9]*$/;
                                            var check = userDoc.data().userName
                                            
                                            
                                            if(userDoc.data().userProfilePic == ""){
                                                
                                                if( english.test(check.charAt(0)) == true){
                                                    var UserName_Copy = (userDoc.data().userName.match(/[a-zA-Z]/) || []).pop().toLowerCase();
                                                    switch (UserName_Copy.charAt(0).toLowerCase()) {
                                    
                                                        case 'a':
                                                            PriflePic= "/img/a.svg";
                                                            break;
                                                            
                                                        case 'b':
                                                            PriflePic= "/img/b.svg";
                                                            break;
                                                        
                                                        case 'c':
                                                            PriflePic= "/img/c.svg";
                                                            break;
                                                            
                                                        case 'd':
                                                            PriflePic= "/img/d.svg";
                                                            break;
                                                            
                                                        case 'e':
                                                            PriflePic= "/img/e.svg";
                                                            break;
                                                            
                                                        case 'f':
                                                            PriflePic= "/img/f.svg";
                                                            break;
                                                            
                                                        case 'g':
                                                            PriflePic= "/img/g.svg";
                                                            break;
                                                            
                                                        case 'h':
                                                            PriflePic= "/img/h.svg";
                                                            break;
                                                            
                                                        case 'i':
                                                            PriflePic= "/img/i.svg";
                                                            break;
                                                            
                                                        case 'j':
                                                            PriflePic= "/img/j.svg";
                                                            break;
                                                            
                                                        case 'k':
                                                            PriflePic= "/img/k.svg";
                                                            break;
                                                            
                                                        case 'l':
                                                            PriflePic= "/img/l.svg";
                                                            break;
                                                            
                                                        case 'm':
                                                            PriflePic= "/img/m.svg";
                                                            break;
                                                            
                                                        case 'n':
                                                            PriflePic= "/img/n.svg";
                                                            break;
                                                            
                                                        case 'o':
                                                            PriflePic= "/img/o.svg";
                                                            break;
                                                            
                                                        case 'p':
                                                            PriflePic= "/img/p.svg";
                                                            break;
                                                            
                                                        case 'q':
                                                            PriflePic= "/img/q.svg";
                                                            break;
                                                            
                                                        case 'r':
                                                            PriflePic= "/img/r.svg";
                                                            break;
                                                            
                                                        case 's':
                                                            PriflePic= "/img/s.svg";
                                                            break;
                                                            
                                                        case 't':
                                                            PriflePic= "/img/t.svg";
                                                            break;
                                                            
                                                        case 'u':
                                                            PriflePic= "/img/u.svg";
                                                            break;
                                                            
                                                        case 'v':
                                                            PriflePic= "/img/v.svg";
                                                            break;
                                                        
                                                        case 'w':
                                                            PriflePic= "/img/w.svg";
                                                            break;
                                                            
                                                        case 'x':
                                                            PriflePic= "/img/x.svg";
                                                            break;
                                                        
                                                        case 'y':
                                                            PriflePic= "/img/y.svg";
                                                            break;
                                                        
                                                        case 'z':
                                                            PriflePic= "/img/z.svg";
                                                            break;
                                                    
                                                }
                                                }
                                                else{
                                                    PriflePic= "/img/person.svg";
                                                }  
                                                }
                                                else{
                                                    PriflePic = userDoc.data().userProfilePic
                                                    
                                                } 
                                            
            
                                                $("#AllReportedPostList").append(`<div id="${doc.id}" class="col-xl-3 col-md-6 mb-4" style="display: flex;margin-bottom: 1rem">
                                                <div class="card shadow-sm h-20" style="width: 20rem;margin-right: 1rem;">
                                                    <div class="card-body">
                                                    <div>
                                                    <img src="${PriflePic}" class="rounded " alt="Responsive image" style="width: 50px;height:50px">
                                                    <span style="margin-left:1rem;color: black;font-weight: 700"> ${userDoc.data().userName}</span>
                                                    <span style="display: flex;
                                                    justify-content: flex-end;">${moment(doc.data().date.toDate()).format('LL')}</span>
                                                    <hr>
                                    
                                                    </div>
                                                    <div id="Product_title" style="display: flex;justify-content: space-between;">
                                                    </div>
                                                    <div>
                                                 
                                                    <img src="${doc.data().imgUri}" class="rounded " alt="Responsive image" style="width: 288px;height:288px">
                                                    <p style="margin-top: 1rem;  display: inline-block;
                                                    width: 200px;
                                                    white-space: nowrap;
                                                    overflow: hidden;
                                                    text-overflow: ellipsis;"> ${doc.data().caption} </p>
                                                    </div>
                                                    <hr>
                                                    <div id="utilities" style="
                                                display: flex;
                                                justify-content: space-evenly;
                                                
                                                
                                            
                                              
                                            ">
                                            <a id="${doc.id}" class="btn btn-info btn-circle btn-lg" onclick = "openPostInfo(this.id,'${PriflePic}','${userDoc.data().userName}')">
                                            <i class="fas fa-info-circle"></i>
                                            </a>     
                                            <a id="${doc.id}" class="btn btn-success btn-circle btn-lg" onclick = "unreportThePost(this.id)" >
                                            <i class="fas fa-check"></i>
                                             </a> 
                                            <a id="${doc.id}" class="btn btn-danger btn-circle btn-lg" onclick = "deletepost(this.id)" >
                                                     <i class="fas fa-trash"></i>
                                            </a>
                                        
                                                </div>
                                                </div>
                                                </div>
                                                
                                            </div>`)
                                        });
                                    })
                                    .catch((error) => {
                                        console.log("Error getting documents: ", error);
                                    });
          
        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });  
}

function openPostInfo(params,userImg,userName) {
    console.log("this is modal fucntiom")
    var PostDocRef = firestore.collection("postFeedData").doc(params);
    PostDocRef.get().then((doc) => {
        if (doc.exists) {
            // document.getElementById("modal-date").innerText = moment(doc.data().date.toDate()).format('LL');
            document.getElementById("modal-post-img").src = doc.data().imgUri;
            document.getElementById("modal-post-caption").innerText = doc.data().caption;
            document.getElementById("Post_Date").innerText = moment(doc.data().date.toDate()).format('LL');
            document.getElementById("modal-img").src = userImg;
            document.getElementById("modal-name").innerText = userName;
            $('#viewpost').modal();
    
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

deletepost =(id)=>{
                         
    swal({
       title: "Are you sure?",
       text: "Do you want to Delete this Post",
       icon: "warning",
       buttons: !0,
       dangerMode: !0
   }).then(n => {
       n && firestore.collection("postFeedData").doc(`${id}`).delete()
       
       
       .then(function() {
           let subsWrapper = document.getElementById(`${id}`)
           subsWrapper.remove();
           swal("Successfull", "Post Deleted ", "success")
       }).catch(function(e) {
           console.error("Error removing document: ", e)
       })
   })
}

function unreportThePost(params) {

          
        swal({
            title: "Are you sure?",
            text: "Do you want to Un-Report this Post",
            icon: "warning",
            buttons: !0,
            dangerMode: !0
        }).then(n => {
            n &&  firestore.collection("postFeedData").doc(params).update({
                reported: false
            }).then(function() {
                let subsWrapper = document.getElementById(`${params}`)
                subsWrapper.remove();    
                swal("Successfull", "Post Un-Reported ", "success")
            }).catch(function(e) {
                console.error("Error removing document: ", e)
            })
        })
        
      

}