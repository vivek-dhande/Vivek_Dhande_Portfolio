var firestore = firebase.firestore();
var database = firebase.database();
const storage = firebase.storage();
var storageRef = storage.ref();

var SliderDoc;


function ShowImage(params) {
    document.getElementById("blah").style.display = ""
    if (params.files && params.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah')
                .attr('src', e.target.result)
                .width(300)
                .height(350);
        };

        reader.readAsDataURL(params.files[0]);
    }
}
function ShowEditSliderImage(params) {
    document.getElementById("Slider_Image").style.display = ""
    if (params.files && params.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#Slider_Image')
                .attr('src', e.target.result)
                .width(300)
                .height(350);
        };

        reader.readAsDataURL(params.files[0]);
    }
}

function SaveSlider(params) {

    var SliderFlag = document.getElementById("SliderFlag").value;
    var SliderLink = document.getElementById("SliderLink").value;
    var SliderImage = document.getElementById("InserSliderImg").value;  


    if(SliderFlag!=="Choose..." && SliderLink!=="" && SliderImage!==""){

        const ref = firebase.storage().ref();
        const file = document.querySelector('#InserSliderImg').files[0]
        const name =  file.name;
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('CommodityImages/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
        console.log(url);
        firestore.collection("Slider").add({
            date: firebase.firestore.Timestamp.fromDate(new Date()).toDate() ,
            image:url,
            flag :SliderFlag,
            link :SliderLink,
        })
        
        }).then(()=>{
            document.getElementById("SliderFlag").value = undefined;
            document.getElementById("SliderLink").value = undefined;
             ocument.getElementById("InserSliderImg").value = undefined;  
            swal("successful", "Slider Added successfully ", "success")
  
        })

        document.getElementById("flagSpan").style.display = "none"
        document.getElementById("linkSpan").style.display = "none"
        document.getElementById("imgspan").style.display = "none"

    }else{

        if(SliderFlag == "Choose..."){

            document.getElementById("flagSpan").style.display = ""
        }else{
            document.getElementById("flagSpan").style.display = "none"
        }

        if(SliderLink == ""){

            document.getElementById("linkSpan").style.display = ""
        }else{

            document.getElementById("linkSpan").style.display = "none"
        }
        if(SliderImage == ""){

          
            document.getElementById("imgspan").style.display = ""
        }else{

            document.getElementById("imgspan").style.display = "none"

        }
    }



}


function showSlider(params) {
   var Get_slider_Child = document.getElementById("Show_slider");
   while(Get_slider_Child.childElementCount !== 0){
    Get_slider_Child.firstChild.remove();
   }

    firestore.collection("Slider").limit(5).get().then((querySnapshot) => {
        lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data());


            $("#Show_slider").append(`<div id="${doc.id}-div" class="card mb-3" style="max-width: 700px;">
            <div class="row no-gutters">
              <div class="col-md-4" style=" display: flex;
              align-items: center;" id="${doc.id}" onclick="Edit_Slider(this.id)">

                <img src="${doc.data().image}" alt="..." style="width: 20rem;
                height: 15rem;">

                </div>
              <div class="col-md-8">
                <div class="card-body" style="margin-left: 5rem">
                <div style="display:flex;margin-bottom:1rem">
                  <h5>Flag:</h5>
                  <span style="margin-left: 1rem; word-break: break-all;"> ${doc.data().flag} </span> 
                </div>
                <div style="display:flex;margin-bottom:1rem"">
                  <h5>Link:</h5>
                  <span style="margin-left: 1rem; word-break: break-all;">${doc.data().link} </span>
                </div>
                <div style="display:flex;margin-bottom:1rem"">
                  <h5>Date:</h5>
                  <span style="margin-left: 1rem; word-break: break-all;">${moment(doc.data().date.toDate()).format("LL")} </span>
                </div>
                <div style="display:flex;justify-content: flex-end;">
               
                <button type="button" class="btn btn-link" id="${doc.id}" onclick="Edit_Slider(this.id)" >Edit Slider</button>
                <button type="button" class="btn btn-danger" id="${doc.id}" onclick="deletepost(this.id)" >Delete</button>
                </div>
                </div>
              </div>
            </div>
          </div>`);
        
        });
    }).then(()=>{

        document.getElementById("MoreSlider").style.display = "";
    })


}

function GetMoreSlider(params) {
    firestore.collection("Slider").startAfter(lastUser).limit(5).get().then((querySnapshot) => {
        lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
        if( querySnapshot.docs.length == 0 ){
            document.getElementById("MoreSlider").style.display = "none";
             swal("There is no Record Found")
        
          }else{
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                console.log(doc.id, " => ", doc.data());
    
    
                $("#Show_slider").append(`<div id="${doc.id}-div" class="card mb-3" style="max-width: 700px;">
                <div class="row no-gutters">
                  <div class="col-md-4" style=" display: flex;
                  align-items: center;" id="${doc.id}" onclick="Edit_Slider(this.id)">
    
                    <img src="${doc.data().image}" alt="..." style="width: 20rem;
                    height: 15rem;">
    
                    </div>
                  <div class="col-md-8">
                    <div class="card-body" style="margin-left: 5rem">
                    <div style="display:flex;margin-bottom:1rem">
                      <h5>Flag:</h5>
                      <span style="margin-left: 1rem; word-break: break-all;"> ${doc.data().flag} </span> 
                    </div>
                    <div style="display:flex;margin-bottom:1rem"">
                      <h5>Link:</h5>
                      <span style="margin-left: 1rem; word-break: break-all;">${doc.data().link} </span>
                    </div>
                    <div style="display:flex;margin-bottom:1rem"">
                      <h5>Date:</h5>
                      <span style="margin-left: 1rem; word-break: break-all;">${moment(doc.data().date.toDate()).format("LL")} </span>
                    </div>
                    <div style="display:flex;justify-content: flex-end;">
                    <button type="button" class="btn btn-link" id=${doc.id} onclick="Edit_Slider(this.id)" >Edit Slider</button>
                    <button type="button" class="btn btn-danger" id="${doc.id}" onclick="deletepost(this.id)" >Delete</button>
    
                    </div>
                    </div>
                  </div>
                </div>
              </div>`);
              document.getElementById("MoreSlider").style.display = "";
            });
          }
       
    })
    
}

function Edit_Slider(params) {
    SliderDoc = params;
    // firestore.collection("Slider").doc(params).get().then((querySnapshot) => {
    //     querySnapshot.forEach((doc) => {
    //         // doc.data() is never undefined for query doc snapshots
    //         console.log(doc.id, " => ", doc.data());

            // document.getElementById("Slider_Image").src = doc.data().image;
      
    //     });
    // });


    var docRef = firestore.collection("Slider").doc(params);


    docRef.get().then((doc) => {
        if (doc.exists) {
            // console.log("Document data:", doc.data());
            document.getElementById("Slider_Image").src = doc.data().image;
            document.getElementById("Slider_Flag_Edit").value = doc.data().flag;
            document.getElementById("SliderLinkEdit").value = doc.data().link;
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });



   
    $('#EditSliderModal').modal();
}

function UpdateSlider(params) {

    var Slider_Image_Update = document.getElementById("exampleFormControlFile1_sub").value
    var Slider_Flag_Update = document.getElementById("Slider_Flag_Edit").value 
     var Slider_Link_Update = document.getElementById("SliderLinkEdit").value 
    

    if(Slider_Image_Update!=""){
        const ref = firebase.storage().ref();
        const file = document.querySelector('#exampleFormControlFile1_sub').files[0]
        const name =  file.name;
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('CommodityImages/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
        console.log(url);
        firestore.collection("Slider").doc(SliderDoc).update({
            flag: Slider_Flag_Update,
            link:Slider_Link_Update,
            image:url,
            date:firebase.firestore.Timestamp.fromDate(new Date()).toDate()
           
        })
        }).then(function() {
            swal("Successfull!", "Slider Updated Successfully", "success")
        }).then(()=>{
            location.reload();
        })
    }else{
        
        firestore.collection("Slider").doc(SliderDoc).update({
            flag: Slider_Flag_Update,
            link:Slider_Link_Update,
            date:firebase.firestore.Timestamp.fromDate(new Date()).toDate()
           
        }).then(function() {
            swal("Successfull!", "Slider Updated Successfully", "success")

            
        }).then(()=>{
            location.reload();
        })


    }

    
}

function Slider_Show_Insert(params) {

    if(params == "Show"){

        document.getElementById("Show_slider").style.display = "";
        document.getElementById("Input_Slider").style.display = "none";
        
        showSlider();
    }else if(params == "Add"){

        document.getElementById("Show_slider").style.display = "none";
        document.getElementById("Input_Slider").style.display = "";
        document.getElementById("MoreSlider").style.display = "none";
        

    }
    
} 

deletepost =(id)=>{
                         
    swal({
       title: "Are you sure?",
       text: "Do you want to Delete this Slider",
       icon: "warning",
       buttons: !0,
       dangerMode: !0
   }).then(n => {
       n && firestore.collection("Slider").doc(`${id}`).delete()
       
       
       .then(function() {
           let subsWrapper = document.getElementById(`${id}-div`)
           subsWrapper.remove();
           swal("Successfull", "Slider Deleted ", "success")
       }).catch(function(e) {
           console.error("Error removing document: ", e)
       })
   })
}

var dummy = 0;
// function TestFun(params) {

// //     var washingtonRef = firestore.collection("TrailOne").doc("uF6gPtuoofEfJWCiI194");

// // // Set the "capital" field of the city 'DC'
// // return washingtonRef.update({
// //     field1:  10
// // })
// // .then(() => {
// //     console.log("Document successfully updated!");
// // })
// // .catch((error) => {
// //     // The document probably doesn't exist.
// //     console.error("Error updating document: ", error);
// // });



// // firestore.collection("TrailOne").add({
// //     USERID : `Vivek${dummy++}`
// // })
// // .then((docRef) => {

// //     dummy < 5 ? TestFun() : ""
 
// //     console.log("Document written with ID: ", docRef.id);
  
// // })
// // .catch((error) => {
// //     console.error("Error adding document: ", error);
// // });

// firestore.collection("TrailTwo").add({
//     USERID : `Vivek${dummy++}`
// })
// .then((docRef) => {

//     dummy < 5 ? TestFun() : ""
 
//     console.log("Document written with ID: ", docRef.id);
  
// })
// .catch((error) => {
//     console.error("Error adding document: ", error);
// });

// }

function TestFun(params) {

    //     var washingtonRef = firestore.collection("TrailOne").doc("uF6gPtuoofEfJWCiI194");
    
    // // Set the "capital" field of the city 'DC'
    // return washingtonRef.update({
    //     field1:  10
    // })
    // .then(() => {
    //     console.log("Document successfully updated!");
    // })
    // .catch((error) => {
    //     // The document probably doesn't exist.
    //     console.error("Error updating document: ", error);
    // });


     
        firestore.collection("Sheti").orderBy("date","desc").get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots

                // console.log("My User Type",doc.data().userType)

                if(doc.data().userType!==undefined){
                    console.log("My User Type",doc.data().userType)
                }
        
        });
            
    })



}


