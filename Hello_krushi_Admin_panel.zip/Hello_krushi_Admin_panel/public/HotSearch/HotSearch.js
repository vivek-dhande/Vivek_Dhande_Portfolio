var firestore = firebase.firestore();
var database = firebase.database();
const storage = firebase.storage();
var storageRef = storage.ref();
var tobeHotSearchEdit ; 

var paginationindex = 0;
var CurrentPage = 0;
var HotSearchList = [];
var HotSearchListIndex = 0;
var data = [];
var index = 0 ;
var ResetSearchCount = 0;
var lastHotSearchDoc;

var MainDropDownCategory = ["Yojana","शेतमाल","खत दुकान / कृषी सेवा केंद्र","भाडेतत्वावर सेवा","रोपवाटीका","खते","अवजारे व वाहने","जमीन खरेदी विक्री","पशू खरेदी विक्री","बी-बियाणे खरेदी विक्री","शेतीपूरक व्यवसाय","कृषी पर्यटन केंद्र","मजूर/कामगार/चिटबाॅय","मजूर/कामगार/चिटबाॅय","प्लंबर/वायरमन","पशू चिकित्सक","पोल्ट्री फार्म","शेळी/मेंढीपालन","दुग्धव्यवसाय","शेतीविषयक सेवा","कृषी प्रक्रीया उद्योग","इतर व्यवसाय"];

function getAllSubstrings(str) {
    var result = [],i;
	for (let j = 1 ; j < str.length + 1; j++) {
	  result.push(str.slice(i, j));

	}
	for (let j = str.indexOf(" ")+2 ; j < str.length + 1; j++) {
	  result.push(str.slice(str.indexOf(" ")+1, j));
  }
return result;
}


Rendercategory();
function Rendercategory(params) {

    MainDropDownCategory.forEach((e)=>{

        $("#Category_HotSearch").append(`<option>${e}</option>`)

    })
    
}

function Rendercategory_Edit(params) {

    MainDropDownCategory.forEach((e)=>{

        $("#Category_HotSearch_Edit").append(`<option>${e}</option>`)

    })
    
}

var SliderDoc;


function SaveHotSearch(params) {

    var hotSearchCat = document.getElementById("Category_HotSearch").value;
    var hotSearchText = document.getElementById("texttobesearch").value;
    var KeywordsTobeSearch = getAllSubstrings(hotSearchText.toLowerCase());
    var WhereToSearch = document.getElementById("Category_HotSearch_where").value;
    if(hotSearchCat!=="Choose..." && hotSearchText!=="" && WhereToSearch!=="Choose..." ){


        firestore.collection("HotSearch").add({
            category : hotSearchCat,
            searchText : hotSearchText,
            date: firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
            keywords : KeywordsTobeSearch,
            whereToShow : WhereToSearch
        }).then(()=>{

            alert("Keyword Added")
        })
        document.getElementById("Category_HotSearch").value = ""
        document.getElementById("texttobesearch").value ="";
        document.getElementById("Category_HotSearch_where").value = "Choose...";

        document.getElementById("Cat_Span").style.display = "none"
        document.getElementById("Text_Span").style.display = "none"
        document.getElementById("wheretoshow_Span").style.display = "none"
    }
    else{

        if(hotSearchCat == "Choose..."){

            document.getElementById("Cat_Span").style.display = ""
        }else{
            document.getElementById("Cat_Span").style.display = "none"
        }

        if(hotSearchText == ""){

            document.getElementById("Text_Span").style.display = ""
        }else{

            document.getElementById("Text_Span").style.display = "none"
        }
        if(WhereToSearch == "Choose..."){

            document.getElementById("wheretoshow_Span").style.display = ""
        }else{

            document.getElementById("wheretoshow_Span").style.display = "none"
        }
        
    }

}


function HotSearchBody(params) {
   var Get_slider_Child = document.getElementById("HotSearchBody");
   while(Get_slider_Child.childElementCount !== 0){
    Get_slider_Child.firstChild.remove();
   }

     HotSearchList = [];
     HotSearchListIndex = 0;
     data = [];
     index = 0 ;
     paginationindex = 0;
     CurrentPage = 0;

    firestore.collection("HotSearch").orderBy("date","desc").limit(5).get().then((querySnapshot) => {
        lastHotSearchDoc = querySnapshot.docs[querySnapshot.docs.length-1];
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            data[index++] = [`${doc.id}`,`${doc.data().category}`,`${doc.data().searchText}`,`${doc.data().whereToShow}`]
            $('#HotSearchBody').append(`<tr id="${doc.id}-Delete">
            <th>${doc.data().category}</th>
            <th>${doc.data().searchText}</th>
            <th>${doc.data().whereToShow}</th>
            <th>
            <button class="btn btn-primary" id="${doc.id}" onclick="EditHotSearchOpen(this.id)" ><i class="fa fa-pencil-square" aria-hidden="true"></i>Edit</button> 
            <button class="btn btn-danger" id=${doc.id} onclick="DeleteHotSearch(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
            </th>
         
            </tr>
            `)
        });
    }).then(()=>{

        HotSearchList[HotSearchListIndex++] = data;
        paginationindex++;
        CurrentPage++;
    })


}
function nextPage(params) {
    
    CurrentPage >0 ? document.querySelector('#previous').disabled = false : document.querySelector('#previous').disabled = true

    
      if(CurrentPage==paginationindex){
  
      
        paginationindex++;
      
    
        firestore.collection("HotSearch").orderBy("date","desc").startAfter(lastHotSearchDoc).limit(5).get().then((querySnapshot) => {
            console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
            document.querySelector('#next').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             swal("There is no Record Found")
          }
          else{
            data = [];
            index = 0;
        
            while(document.getElementById("HotSearchBody").childElementCount!==0){
              document.getElementById("HotSearchBody").firstChild.remove();
            }

            lastHotSearchDoc = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
              //   console.log(doc.data().userName);
                 // doc.data() is never undefined for query doc snapshots
                 data[index++] = [`${doc.id}`,`${doc.data().category}`,`${doc.data().searchText}`,`${doc.data().whereToShow}`]
                 $('#HotSearchBody').append(`<tr id="${doc.id}-Delete">
                 <th>${doc.data().category}</th>
                 <th>${doc.data().searchText}</th>
                 <th>${doc.data().whereToShow}</th>
                 <th>
                 <button class="btn btn-primary" id="${doc.id}" onclick="EditHotSearchOpen(this.id)" ><i class="fa fa-pencil-square" aria-hidden="true"></i>Edit</button> 
                 <button class="btn btn-danger" id=${doc.id} onclick="DeleteHotSearch(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
                 </th>
              
                 </tr>
                 `)
            //  document.getElementById("NoProduct").style.display = "none"
              })
              
             
          }

         
      }).then(()=>{

        HotSearchList[HotSearchListIndex++] = data;
        CurrentPage++;
      })
       
      }
      else{  

        while(document.getElementById("HotSearchBody").childElementCount!==0){
          document.getElementById("HotSearchBody").firstChild.remove();
        }
        HotSearchList[CurrentPage].forEach(doc => {
         
         // console.log("demo Array",element)
      
         $('#HotSearchBody').append(`<tr id="${doc[0]}-Delete">
         <th>${doc[1]}</th>
         <th>${doc[2]}</th>
         <th>${doc[3]}</th>
         <th>
         <button class="btn btn-primary" id="${doc[0]}" onclick="EditHotSearchOpen(this.id)" ><i class="fa fa-pencil-square" aria-hidden="true"></i>Edit</button> 
         <button class="btn btn-danger" id=${doc[0]} onclick="DeleteHotSearch(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
         </th>
      
         </tr>
         `)
        });
        CurrentPage++;
      }
  
}

function previousPage(params) {

  document.querySelector('#next').disabled = false;

 
  CurrentPage--;


  if(CurrentPage > 0){
    

    while(document.getElementById("HotSearchBody").childElementCount!==0){
        document.getElementById("HotSearchBody").firstChild.remove();
    }
  
    
    HotSearchList[CurrentPage-1].forEach(doc => {
       
        $('#HotSearchBody').append(`<tr id="${doc[0]}-Delete">
        <th>${doc[1]}</th>
        <th>${doc[2]}</th>
        <th>${doc[3]}</th>
        <th>
        <button class="btn btn-primary" id="${doc[0]}" onclick="EditHotSearchOpen(this.id)" ><i class="fa fa-pencil-square" aria-hidden="true"></i>Edit</button> 
        <button class="btn btn-danger" id=${doc[0]} onclick="DeleteHotSearch(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
        </th>
     
        </tr>
        `)
      });
      // <th><button type="button" id= ${element[0]} class="btn btn-danger" onclick = "DeleteUser(this.id)">Delete</button></th>
  }
  else{
    CurrentPage = 1
    console.log("Current-Page",CurrentPage)
    document.querySelector('#previous').disabled = true;

  }

}

function HotSearch_Show_Insert(params) {

    if(params == "Show"){

        document.getElementById("Show_slider").style.display = "";
        document.getElementById("Input_Slider").style.display = "none";
        
        HotSearchBody();
    }else if(params == "Add"){

        document.getElementById("Show_slider").style.display = "none";
        document.getElementById("Input_Slider").style.display = "flex";
        document.getElementById("MoreSlider").style.display = "none";
        

    }
    
} 

function EditHotSearchOpen(params) {

    tobeHotSearchEdit = params;

    Rendercategory_Edit();
    var docRef = firestore.collection("HotSearch").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {
        
            document.getElementById("Category_HotSearch_Edit").value = doc.data().category;
            document.getElementById("texttobesearch_Edit").value = doc.data().searchText;
            document.getElementById("whereto_Edit").value = doc.data().whereToShow;  
            $("#EditHotSearchModal").modal();

        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
    
}

function UpdateHotSearch(params) {

    var hotSearchCat = document.getElementById("Category_HotSearch_Edit").value;
    var hotSearchText = document.getElementById("texttobesearch_Edit").value;
    var WhereToShow =  document.getElementById("whereto_Edit").value
    var KeywordsTobeSearch_Update = getAllSubstrings(hotSearchText.toLowerCase())
     
    if(hotSearchCat!=="Choose..." && hotSearchText!==""){


        firestore.collection("HotSearch").doc(tobeHotSearchEdit).update({
            category : hotSearchCat,
            searchText : hotSearchText,
            keywords :KeywordsTobeSearch_Update,
            whereToShow :WhereToShow
        }).then(()=>{

            swal("Hot Search Edited")
            $('#EditHotSearchModal').modal('hide');
        }).then(()=>{
            location.reload();
        })
        document.getElementById("Category_HotSearch_Edit").value = ""
        document.getElementById("whereto_Edit").value ="";

        document.getElementById("Cat_Span_Edit").style.display = "none"
        document.getElementById("Text_Span_edit").style.display = "none"

    }else{

        if(hotSearchCat == "Choose..."){

            document.getElementById("Cat_Span_Edit").style.display = ""
        }else{
            document.getElementById("Cat_Span_Edit").style.display = "none"
        }

        if(hotSearchText == ""){

            document.getElementById("Text_Span_edit").style.display = ""
        }else{

            document.getElementById("Text_Span_edit").style.display = "none"
        }

    }

    
}

var DeleteHotSearch = (id) => {

    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Hot Search",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        n && firestore.collection("HotSearch").doc(id).delete()


            .then(function () {
                let subsWrapper = document.getElementById(`${id}-Delete`)
                subsWrapper.remove();
                swal("Successfull", "Hot Search Deleted ", "success")
            }).catch(function (e) {
                console.error("Error removing document: ", e)
            })
    })
}

function searchHotKeyword(params) {

    var TobeSearch = document.getElementById("MySearch").value.toLowerCase();;
    if(TobeSearch!==""){
        firestore.collection("HotSearch").where("keywords", "array-contains", TobeSearch)
        .get()
        .then((querySnapshot) => {
            while (document.getElementById("HotSearchBody").childElementCount != 0) {

                document.getElementById("HotSearchBody").firstChild.remove();
        
            }
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                $('#HotSearchBody').append(`<tr id="${doc.id}-Delete">
                <th>${doc.data().category}</th>
                <th>${doc.data().searchText}</th>
                <th>
                <button class="btn btn-primary" id="${doc.id}" onclick="EditHotSearchOpen(this.id)" ><i class="fa fa-pencil-square" aria-hidden="true"></i>Edit</button> 
                <button class="btn btn-danger" id=${doc.id} onclick="DeleteHotSearch(this.id)"><i class="fa fa-trash" aria-hidden="true"></i> Delete</button>
                </th>
             
                </tr>
                `)
            });
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });

    }
        

}


function ResetYojanaSearch(params) {
    

    if(document.getElementById("MySearch").value == "" ){
      
        if(ResetSearchCount<1){
            while (document.getElementById("HotSearchBody").childElementCount != 0) {
 
                document.getElementById("HotSearchBody").firstChild.remove();
        
            }
            ResetSearchCount++;
            HotSearchBody();
        }
        
     }else{
         ResetSearchCount = 0;
     }

}






// Add a new document with a generated id.
