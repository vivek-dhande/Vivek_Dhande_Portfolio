

// Call the dataTables jQuery plugin
var firestore = firebase.firestore();
var userdoc = localStorage.getItem('userDocId');
const storage = firebase.storage();
// $(document).ready(function() {
//   $('#dataTable').DataTable();

// });

const Acre_Guntha =  40.00000001;
const Acre_Hector = 0.4046856422;

const Guntha_Acre = 0.02499999999;
const Guntha_Hector = 0.01011714105;

const Hector_Acre = 2.471053815;
const Hector_Guntha = 98.84215262;

let toalLandSum = 0;
var index = 0;
var exportIndex = 0; 
var data = [];
var ExportDataList = []; 
var lastUser;
var OnlyDateLastDoc;
var userID;
var WhichFilterSelected;
var Pagination_Filter_Flag;
var Pagination_Filter_Value;
var Pagination_Filter_Both ;
var Pagination_Filter_Both_Value ;

var VibhagSlected;
var DistrictFilterSelected;
var TalukaFilterSelected;
var VillageFilterSlected;
var MainCategorySelected;
var CropSelected;

var Selected_District;
var Selected_Taluka;
var Selected_Village;
var Selected_Category;
var Selected_Crop;
var Selected_Land_Unit;

var Date_Selected_To;
var Date_Selected_From;

var Pagination_Cat_Type ;
var  Pagination_Cat_Value ;


var UserList = [];
var index1= 0;
paginationindex = 0;


let Vibhag_List = [];
let Vibhag_List_index = 0;

let District_List = [];
let District_List_index = 0;

let Tahasil_List = [];
let Tahasil_List_index = 0;

let Village_List = [];
let Village_List_index = 0;

let CropCategory_list = [];
let CropCategory_list_index = 0;

let CropCategory_User_list = [];
let CropCategory_User_list_index = 0;

let pika_list = [];
let pika_list_index = 0;

let Product_List = [];
let Product_List_index = 0;

//Find the input search box
let search = document.getElementById("searchCoin") 
let search1 = document.getElementById("searchCoin1") 


// ------------------------------------------------------------ Sheti Without Filter ------------------------------------------------------- 

function getUserlist(params) {

  lastUser = "";
  data = [];
  index = 0;
  UserList = [];
  index1= 0;
  paginationindex = 0;
  CurrentPage = 0;

//   first = firestore.collection("Sheti").orderBy("date","desc").get().then((querySnapshot) => {

//     querySnapshot.forEach((doc) => {

//    firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

//     querySnapshot.forEach((userdoc) => {

//       ExportDataList[exportIndex++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
//     })
//   })
// })

// }).then(()=>{

//     console.log("ExportDataList",ExportDataList)
// })


  firestore.collection("Sheti").orderBy("date","desc").limit(10).get().then((querySnapshot) => {
    while(document.getElementById("tbody").childElementCount!==0){
      document.getElementById("tbody").firstChild.remove();
    }

    lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
    querySnapshot.forEach((doc) => { 
      firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

        querySnapshot.forEach((userdoc) => {
          data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

          // doc.data() is never undefined for query doc snapshots
          $("#tbody").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
          <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
          <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
          <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
          <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
          <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
          <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
          <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
          <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
          <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
          <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
          <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
        
      </tr>`);
    
          document.getElementById("ShetiListTable").style.display = "";
          document.getElementById("NoProduct").style.display = "none";
    
        })
      })


    })
   
  
  //   querySnapshot.forEach((doc) => {
   
  //     data[index++] = [`${doc.id}`,`${doc.data().cropDateString}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

  //     // doc.data() is never undefined for query doc snapshots
  //     $("#tbody").append(`<tr>
  //     <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
  //     <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
  // </tr>`);

  //     document.getElementById("ShetiListTable").style.display = "";
  //     document.getElementById("NoProduct").style.display = "none";

  //  });
   
}).then(()=>{
  UserList[index1++] = data;
  paginationindex++;
  CurrentPage++;
  console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
  console.log("Data Puted Sucessfully",UserList);
})
  
}
getUserlist();

function nextPage(params) {

  CurrentPage >0 ? document.querySelector('#previous').disabled = false : document.querySelector('#previous').disabled = true
  
  
  // CurrentPage++;
  

    console.log("  ",lastUser)
  if(CurrentPage==paginationindex){

    
    paginationindex++;
  

    firestore.collection("Sheti").orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
      console.log("Get New Data");
      if( querySnapshot.docs.length == 0 ){
        document.querySelector('#next').disabled = true;
        
         CurrentPage--;
        paginationindex--;
         (swal("There is no Record Found"))
        console.log("At the End",UserList);
      }
      else{
        data = [];
        index = 0;
        while(document.getElementById("tbody").childElementCount!==0){
          document.getElementById("tbody").firstChild.remove();
        }
        lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
        querySnapshot.forEach((doc) => {
          //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
             // doc.data() is never undefined for query doc snapshots

             firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

              querySnapshot.forEach((userdoc) => {
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                // doc.data() is never undefined for query doc snapshots
                $("#tbody").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              
            </tr>`);
          
                document.getElementById("ShetiListTable").style.display = "";
                document.getElementById("NoProduct").style.display = "none";
          
              })
            })
       
        //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

        //      // doc.data() is never undefined for query doc snapshots
        //      $("#tbody").append(`<tr>
        //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
        //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
        //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
        //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
        //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
        //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
        //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
        //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
        //  </tr>`);
       
        //      document.getElementById("ShetiListTable").style.display = "";
        //      document.getElementById("NoProduct").style.display = "none";
          })
          
         
      }

     
  }).then(()=>{
    console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
    UserList[index1++] = data;
    console.log("Data Puted Sucessfully",UserList);
  })
   
  }
  else{

    console.log("  ",lastUser)
    while(document.getElementById("tbody").childElementCount!==0){
      document.getElementById("tbody").firstChild.remove();
    }
    UserList[CurrentPage].forEach(element => {
     
     // console.log("demo Array",element)
  
      $("#tbody").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      <th>${element[10]}</th>
      <th>${element[11]}</th>
      </tr>`);
    });
    console.log("Data from local",UserList);
  }

  
  CurrentPage++;

}
function previousPage(params) {

  document.querySelector('#next').disabled = false;

 
  CurrentPage--;
  console.log("demo Array",CurrentPage)

  if(CurrentPage > 0){
    

    console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
    while(document.getElementById("tbody").childElementCount!==0){
      document.getElementById("tbody").firstChild.remove();
    }
  
    
      UserList[CurrentPage-1].forEach(element => {
       
        $("#tbody").append(`<tr>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
        <th>${element[8]}</th>
        <th>${element[9]}</th>
        <th>${element[10]}</th>
        </tr>`);
      });
       
  }
  else{
    CurrentPage = 1
    document.querySelector('#previous').disabled = true;

  }
}

// ------------------------------------------------------------ Sheti Without Filter ------------------------------------------------------- 


// ------------------------------------------------------------ Sheti With Filter ------------------------------------------------------- 

let items = document.getElementsByClassName("dropdown-item")
function buildDropDown(values) {
    let contents = []
    for (let name of values) {
    contents.push(`<input type="button" class="dropdown-item" type="button" value=${name} onclick="Get_District(this.value)"/>`)
    }
    $('#menuItems').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}

//Capture the event when user types into the search box
search.addEventListener('input', function () {


    filter(search.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems').on('click', '.dropdown-item', function(){

  
  if(VibhagSlected!==undefined){

    DistrictFilterSelected = undefined ; 
    Selected_District = undefined;
    $('#District_Drop_Down').text('जिल्हा')

    TalukaFilterSelected = undefined;
    Selected_Taluka =undefined;
    $('#Tahasil').text('तालुका')
 
    VillageFilterSlected = undefined ;
    Selected_Village = undefined;
    $('#village').text('गाव')
    
   }
   VibhagSlected = "0";


    
    $('#dropdown_coins').text($(this)[0].value)
    $("#dropdown_coins").dropdown('toggle');

    document.querySelector('#ResetFilterInModal').style.display = ""
    document.querySelector('#District_Drop_Down').disabled = false
})


//Find the input search box
let search_Dist = document.getElementById("searchCoin1")

//Find every item inside the dropdown
let Dist_items = document.getElementById("menuItems-dist");

function buildDropDown_dist(values) {


    let contents = []
    for (let dist of values) {
    contents.push(`<input type="button" id="dropdown-item-dist" class="dropdown-item"  type="button" value="${dist}" onclick="Get_Taluka(this.value,'District')"/>`)
    }
    $('#menuItems-dist').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}


function filter(word) {
  let length = items.length
  let collection = []
  let hidden = 0
  console.log(Dist_items.children[0])
  for (let i = 0; i < length; i++) {
  if (items[i].value.toLowerCase().startsWith(word)) {
      $(items[i]).show()
  }
  else {
      $(items[i]).hide()
      hidden++
  }
  }

  //If all items are hidden, show the empty view
  if (hidden === length) {
  $('#empty').show()
  }
  else {
  $('#empty').hide()
  }
}

//Capture the event when user types into the search box
search1.addEventListener('input', function () {
  
  filter_dist(search_Dist.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_dist(word) {
    let length = Dist_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Dist_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Dist_items.children[i]).show()
    }
    else {
        $(Dist_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-dist').on('click', '.dropdown-item', function(){


  if(DistrictFilterSelected!==undefined){

   TalukaFilterSelected = undefined;
   Selected_Taluka = undefined ;
   $('#Tahasil').text('तालुका')

   VillageFilterSlected = undefined ;
   Selected_Village = undefined;
   $('#village').text('गाव')

  }

  DistrictFilterSelected = "district"
    Selected_District = $(this)[0].value
    $('#District_Drop_Down').text($(this)[0].value)
    $("#District_Drop_Down").dropdown('toggle');
    

    WhichFilterSelected = "district";

    document.querySelector('#Tahasil').disabled = false
    document.querySelector('#next_withFilter').disabled = false;
    document.querySelector('#previous_withFilter').disabled = false
   
})


let search_Taluka = document.getElementById("searchCoin2")

//Find every item inside the dropdown
let Taluka_items = document.getElementById("menuItems-Taluka");

function buildDropDown_tahasil(values) {
    let contents = []
    for (let taluka of values) {
    contents.push(`<input type="button" id="dropdown-item-taha" class="dropdown-item"  type="button" value="${taluka}" onclick="Get_village(this.value,'Tahasil')"/>`)
    }
    $('#menuItems-Taluka').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_Taluka.addEventListener('input', function () {
  
  
  filter_taha(search_Taluka.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_taha(word) {
    let length = Taluka_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Taluka_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Taluka_items.children[i]).show()
    }
    else {
        $(Taluka_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-Taluka').on('click', '.dropdown-item', function(){

  if(TalukaFilterSelected!==undefined){

    VillageFilterSlected = undefined ;
    $('#village').text('गाव')
    
   }

    TalukaFilterSelected = "tahsil";
    WhichFilterSelected = "tahsil";
    Selected_Taluka = $(this)[0].value
    $('#Tahasil').text($(this)[0].value)
    $("#Tahasil").dropdown('toggle');
    document.querySelector('#village').disabled = false
    document.querySelector('#next_withFilter').disabled = false;
    document.querySelector('#previous_withFilter').disabled = false
})

let search_village = document.getElementById("searchCoin3")

//Find every item inside the dropdown
let village_items = document.getElementById("menuItems-village");

function buildDropDown_village(values) {
    let contents = []
    for (let village of values) {
    contents.push(`<input type="button" id="dropdown-item-village" class="dropdown-item"  type="button" value="${village}"  />`)
    }
    $('#menuItems-village').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_village.addEventListener('input', function () {
  
  
  filter_villa(search_village.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_villa(word) {
    let length = village_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (village_items.children[i].value.toLowerCase().startsWith(word)) {
        $(village_items.children[i]).show()
    }
    else {
        $(village_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
$('#menuItems-village').on('click', '.dropdown-item', function(){
  VillageFilterSlected = "village";
  WhichFilterSelected = "village";
  Selected_Village = $(this)[0].value
    $('#village').text($(this)[0].value)
    $("#village").dropdown('toggle');

    document.querySelector('#next_withFilter').disabled = false;
    document.querySelector('#previous_withFilter').disabled = false
})


let search_Main_Category = document.getElementById("searchCoin4")

//Find every item inside the dropdown
let Main_Category_items = document.getElementById("menuItems-MainCatgory");

function buildDropDown_Main_cat(values) {
    let contents = []
    for (let MainCategory of values) {
    contents.push(`<input type="button" id="dropdown-item-MainCategory" class="dropdown-item"  type="button" value="${MainCategory}" onclick="Get_Pika_Sub_Category(this.value,'Main_Cat')" />`)
    }
    $('#menuItems-MainCatgory').append(contents.join(""))

    //Hide the row that shows no items were found
    $('#empty').hide()
}



//Capture the event when user types into the search box
search_Main_Category.addEventListener('input', function () {
  
  
  filter_Main_Cat(search_Main_Category.value.trim().toLowerCase())
})

//For every word entered by the user, check if the symbol starts with that word
//If it does show the symbol, else hide it
function filter_Main_Cat(word) {
    let length = Main_Category_items.children.length
    let collection = []
    let hidden = 0
    for (let i = 0; i < length; i++) {
    if (Main_Category_items.children[i].value.toLowerCase().startsWith(word)) {
        $(Main_Category_items.children[i]).show()
    }
    else {
        $(Main_Category_items.children[i]).hide()
        hidden++
    }
    }

    //If all items are hidden, show the empty view
    if (hidden === length) {
    $('#empty').show()
    }
    else {
    $('#empty').hide()
    }
}

//If the user clicks on any item, set the title of the button as the text of the item
  $('#menuItems-MainCatgory').on('click', '.dropdown-item', function(){
    document.querySelector('#ResetFilterInModal').style.display = ""

    if(MainCategorySelected !== undefined){

      CropSelected = undefined ;
      Selected_Crop = undefined ;
      $('#User_Peka_Sub_filter').text('पीक')
      
    }

    MainCategorySelected = "cropMainCat";
    Selected_Category = $(this)[0].value
      $('#User_Peka_filter').text($(this)[0].value)
      $("#User_Peka_filter").dropdown('toggle');
      document.querySelector('#User_Peka_Sub_filter').disabled = false
      document.querySelector('#next_withFilter').disabled = false;
      document.querySelector('#previous_withFilter').disabled = false
    })

  let search_pika = document.getElementById("searchCoin5")

  //Find every item inside the dropdown
  let Main_pika_items = document.getElementById("menuItems-pika");
  
  function buildDropDown_pika(values) {
      let contents = []
      for (let pika of values) {
      contents.push(`<input type="button" id="dropdown-menuItems-pika" class="dropdown-item"  type="button" value="${pika}"/>`)
      }
      $('#menuItems-pika').append(contents.join(""))
  
      //Hide the row that shows no items were found
      $('#empty').hide()
  }
  
  
  
  //Capture the event when user types into the search box
  search_pika.addEventListener('input', function () {
    
    
    filter_Main_pik(search_pika.value.trim().toLowerCase())
  })
  
  //For every word entered by the user, check if the symbol starts with that word
  //If it does show the symbol, else hide it
  function filter_Main_pik(word) {
      let length = Main_pika_items.children.length
      let collection = []
      let hidden = 0
      for (let i = 0; i < length; i++) {
      if (Main_pika_items.children[i].value.toLowerCase().startsWith(word)) {
          $(Main_pika_items.children[i]).show()
      }
      else {
          $(Main_pika_items.children[i]).hide()
          hidden++
      }
      }
  
      //If all items are hidden, show the empty view
      if (hidden === length) {
      $('#empty').show()
      }
      else {
      $('#empty').hide()
      }
  }
  
  //If the user clicks on any item, set the title of the button as the text of the item
    $('#menuItems-pika').on('click', '.dropdown-item', function(){
      
      CropSelected = "crop";
      Selected_Crop = $(this)[0].value
        $('#User_Peka_Sub_filter').text($(this)[0].value)
        $("#User_Peka_Sub_filter").dropdown('toggle');

        document.querySelector('#next_withFilter').disabled = false;
        document.querySelector('#previous_withFilter').disabled = false
    })

  

    $('#Total_Land_Filter').on('click', '.dropdown-item' , function(){
      document.querySelector('#ResetFilterInModal').style.display = ""
        Selected_Land_Unit = $(this)[0].innerText ;
        console.log("Selected_Land_Unit",Selected_Land_Unit)
        $('#TotalLandFilter').text($(this)[0].innerText)
        $("#TotalLandFilter").dropdown('toggle');

        document.querySelector('#next_withFilter').disabled = false;
        document.querySelector('#previous_withFilter').disabled = false
    })


    $('#datepicker_from').on('change', function(){
      // //alert("From",$(this)[0].value)
      document.querySelector('#ResetFilterInModal').style.display = ""

      // if(MainCategorySelected !== undefined){
  
      //   CropSelected = undefined ;
      //   Selected_Crop = undefined ;
      //   $('#User_Peka_Sub_filter').text('पीक')
        
      // }
      // MainCategorySelected = "cropMainCat";
      Date_Selected_From = moment($(this)[0].value,"DD/MM/YYYY").toDate()

      // var myDate = firebase.firestore.Timestamp.fromDate(new Date());
      console.log("myDate",)
        // document.querySelector('#User_Peka_Sub_filter').disabled = false
    })

    $('#datepicker_to').on('change', function(){

      // //alert("TO",$(this)[0].value)
      document.querySelector('#ResetFilterInModal').style.display = ""

      // if(MainCategorySelected !== undefined){
  
      //   CropSelected = undefined ;
      //   Selected_Crop = undefined ;
      //   $('#User_Peka_Sub_filter').text('पीक')
        
      // }
      // MainCategorySelected = "cropMainCat";
      Date_Selected_To  = moment($(this)[0].value,"DD/MM/YYYY").add(1, 'days').toDate()
      
      // var myDate = firebase.firestore.Timestamp.fromDate(new Date());
      console.log("myDate",Date_Selected_To)
        // document.querySelector('#User_Peka_Sub_filter').disabled = false
      })


function Get_Vibhag(params) {
  
  firestore.collection("SaatBara").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        console.log(doc.id, " => ", doc.data().call);

        Vibhag_List [Vibhag_List_index++] = doc.data().name;
    });
  }).then(()=>{
  

    buildDropDown(Vibhag_List);
  })

}

Get_Vibhag();

function Get_District(params,flag) {

  District_List = [];
  District_List_index = 0;
  var Dist_child = document.getElementById("menuItems-dist");

  console.log("menuItems-dist",Dist_child.childElementCount)
   
  firestore.collection("SaatBara").where("name","==",params).get().then((querySnapshot)=>{
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      currentVibhag = doc.id; 
    });
  }).then(()=>{
    var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District");
    docRef.get().then((querySnapshot) => {
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
          District_List[District_List_index++] = doc.data().name;
      });
    }).then(()=>{
      while(Dist_child.childElementCount !== 0){
  
        Dist_child.firstChild.remove();
      }
      console.log("Tahasil Karyalay",District_List)
      buildDropDown_dist(District_List);
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

  })

}


function Get_Taluka (params,flag) {
  var Talu_child = document.getElementById("menuItems-Taluka");

  Tahasil_List = [];
  Tahasil_List_index = 0;


  CurrentSelectedFilter = flag;

  firestore.collection("SaatBara").doc(currentVibhag).collection("District").where("name","==",params).get().then((querySnapshot)=>{
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
     
        currentDistrict = doc.id;
  });
  }).then(()=>{

      var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas")

      docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log()
            Tahasil_List[Tahasil_List_index++] = doc.data().dtname;
    
        
        });
      }).then(()=>{
        console.log("Tahasil Karyalay",Tahasil_List)
        while(Talu_child.childElementCount !== 0){
  
          Talu_child.firstChild.remove();
        }
        buildDropDown_tahasil(Tahasil_List);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });
  })

}

function Get_village (params,flag) {
  var Village_child = document.getElementById("menuItems-village");
  Village_List = [];
  Village_List_index = 0;
  CurrentSelectedFilter = flag;

  firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").where("dtname","==",params).get().then((querySnapshot)=>{
    querySnapshot.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
     
        currentTaluka = doc.id
  });
  }).then(()=>{

      var docRef = firestore.collection("SaatBara").doc(currentVibhag).collection("District").doc(currentDistrict).collection("Talukas").doc(currentTaluka).collection("Villages")

      docRef.get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
     
            Village_List[Village_List_index++] = doc.data().village_name;
    
        
        });
      }).then(()=>{
        console.log("Village Karyalay",Village_List)
        while(Village_child.childElementCount !== 0){
  
          Village_child.firstChild.remove();
        }
        buildDropDown_village(Village_List);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });
  })

}


function Get_Main_Category() {



    var docRef = firestore.collection("ShetiPik").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots

            CropCategory_list[CropCategory_list_index++] = doc.data().mainCatName;

        });
      }).then(()=>{

        console.log("Village Karyalay",Village_List)
        buildDropDown_Main_cat(CropCategory_list);
      }).catch((error) => {
          console.log("Error getting document:", error);
      });

}

Get_Main_Category();


function getpika (params) {


  var pik_child = document.getElementById("menuItems-pika");

  pika_list = [];
  pika_list_index = 0;

  var docRef = firestore.collection("ShetiPik").where("mainCatName","==", params).get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        Selected_Main_Category_Doc = doc.id
        //  console.log("Vivek Dhande",  doc.data())
      

    });
  }).then(()=>{
  // console.log("Village Karyalay",Village_List)
  // var docRef = firestore.collection("ShetiPik").doc(Selected_Main_Category_Doc).get().then((querySnapshot) => {
  //   querySnapshot.forEach((e) => {
  //       // doc.data() is never undefined for query doc snapshots

  //       console.log("Vivek Dhande",  e.data())
        
  //       //pika_list[pika_list_index++] = doc.data().mainCatName;

  //   })
  // })

  var docRef = firestore.collection("ShetiPik").doc(Selected_Main_Category_Doc).collection("SubCat")

      docRef.get().then((querySnapshot) => {
          
        querySnapshot.forEach(element => {
          
          pika_list[pika_list_index++] = element.data().pikName;
     //     console.log("Pika Data",element.data().pikName) 
        });
      }).then(()=>{
        while(pik_child.childElementCount!==0){
          pik_child.firstChild.remove();
        }
        console.log("Pika Data",pika_list); 
        buildDropDown_pika(pika_list);

      }).catch((error) => {
          console.log("Error getting document:", error);
      });

     
  }).catch((error) => {
      console.log("Error getting document:", error);
  });
  
}

function Get_Pika_Sub_Category(params,flag) {

  Get_UserDoc_For_Main_cat = [];
  Get_UserDoc_For_Main_cat_index = 0 ; 
  Filtered_User_Data = [] ;
  Filtered_User_Data_index = 0;


  UserList = [];
  Special_Index = 0;

console.log("Pagination_Filter_Flag",WhichFilterSelected===undefined)


  Selected_pika_Db_Reffrence = 'cropMainCat';
    CurrentSelectedFilter = flag;
    // Selected_Main_Category_Title = params
    getpika(params);

    // where(`${WhichFilterSelected}`,"==",Selected_District)
    // where("cropMainCat","==",params)
    if(WhichFilterSelected!==undefined){

      firestore.collection("Sheti").where(WhichFilterSelected,"==",Selected_District).where("cropMainCat","==",params).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
        lastUser_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
          console.log("UserData",doc.data());
          Get_UserDoc_For_Main_cat[Get_UserDoc_For_Main_cat_index++] = [doc.data().userId,doc.data().cropMainCat,doc.data().crop]
       
      })
  }).then(()=>{
  
    // ForProcessing = [...new Set(Get_UserDoc_For_Main_cat)]
  
    Get_UserDoc_For_Main_cat.forEach(element => {
  
      console.log("element",element[0])
      
      firestore.collection("Userinfo").where("userID","==",element[0]).get().then((querySnapshot) => {
   
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
  
            Filtered_User_Data[Filtered_User_Data_index++] = [`${doc.id}`,`${doc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,element[0],element[1],element[2]]
  
        })
      })
    });
  
  }).then(()=>{
  
            console.log("Vivek Dhande :   ",Filtered_User_Data)
            UserList[Special_Index++] = Filtered_User_Data;
            Filtered_User_Data.forEach(element => {
              console.log("Filtered_Data",element)
            });
  })
      
    }
    else{
      firestore.collection("Sheti").where("cropMainCat","==",params).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
        lastUser_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
  
          Get_UserDoc_For_Main_cat[Get_UserDoc_For_Main_cat_index++] = [doc.data().userId,doc.data().cropMainCat,doc.data().crop]
       
      })
  }).then(()=>{
  
    // ForProcessing = [...new Set(Get_UserDoc_For_Main_cat)]
  
    Get_UserDoc_For_Main_cat.forEach(element => {
  
      console.log("element",element[0])
      
      firestore.collection("Userinfo").where("userID","==",element[0]).get().then((querySnapshot) => {
   
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
  
            Filtered_User_Data[Filtered_User_Data_index++] = [`${doc.id}`,`${doc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,element[0],element[1],element[2]]
  
        })
      })
    });
  
  }).then(()=>{
  
            console.log("Vivek Dhande :   ",Filtered_User_Data)
            UserList[Special_Index++] = Filtered_User_Data;
            Filtered_User_Data.forEach(element => {
              console.log("Filtered_Data",element)
            });
  })

  }

}

// ------------------------------------------------------------ Sheti With Filter ------------------------------------------------------- 


function ApplyFilter(params) {

  
document.getElementById("previous").disabled = false
document.getElementById("next").disabled = false 

document.getElementById("previous_withFilter").disabled = false
document.getElementById("next_withFilter").disabled = false 

  if(Selected_Land_Unit !== undefined){
    document.getElementById("TotalLandTitlewithFilter").style.display = "";
  }else{
    document.getElementById("TotalLandTitlewithFilter").style.display = "none";
  }

  if(DistrictFilterSelected !== undefined){
    document.getElementById("District_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("District_Checked_Only_Region").style.display = "none";
  }

  if(TalukaFilterSelected !== undefined){
    document.getElementById("Taluka_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("Taluka_Checked_Only_Region").style.display = "none";
  }

  if(VillageFilterSlected !== undefined){
    document.getElementById("Village_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("Village_Checked_Only_Region").style.display = "none";
  }

  if(MainCategorySelected !== undefined){
    document.getElementById("Category_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("Category_Checked_Only_Region").style.display = "none";
  }

  if(CropSelected !== undefined){
    document.getElementById("Crop_Checked_Only_Region").style.display = "";
  }else{
    document.getElementById("Crop_Checked_Only_Region").style.display = "none";
  }
      // if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined ){

      //     //Disctrict // Maincat
      //     // //alert("Disctrict - Maincat");

      //     DistrictFilter(MainCategorySelected,Selected_Category,DistrictFilterSelected,Selected_District);

      // }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined){
          
      //     //Disctrict // Crop
      //     // //alert("Disctrict - CROP");
      //     DistrictFilter(CropSelected,Selected_Crop,DistrictFilterSelected,Selected_District);
      // }
      // else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined ){

      //     //Taluka // Mincat
      //     // //alert("Taluka - Mincat");
      //     DistrictFilter(MainCategorySelected,Selected_Category,TalukaFilterSelected,Selected_Taluka);
      // }
      // else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined ){

      //   //Taluka // CROP
      //     //alert("Taluka - CROP");
      //     DistrictFilter(CropSelected,Selected_Crop,TalukaFilterSelected,Selected_Taluka);

      // }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined ){

      //   //Village // main cat
      //   // //alert("Village -  main cat");
      //   DistrictFilter(MainCategorySelected,Selected_Category,VillageFilterSlected,Selected_Village);

      // }
      // else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined ){

      //   //Village // main cat
      //   // //alert("Village - CROP");
      //   DistrictFilter(CropSelected,Selected_Crop,VillageFilterSlected,Selected_Village);
        
      // }else if(DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined ){

      //   //Village // main cat
      //   // //alert("Only Main Category");
      //   DistrictFilter(MainCategorySelected,Selected_Category);
        
      // }
      // else if(DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined ){

      //   //Village // main cat
      //   // //alert("Only Main CROP");
      //   DistrictFilter(CropSelected,Selected_Crop);
        
      // }
      // else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined){
        
      //   //District
      //   //alert("District");
      //   DistrictFilter(DistrictFilterSelected,Selected_District);
      // }

      // else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined){

      //     //Taluka
      //     // //alert("Taluka");
      //   DistrictFilter(TalukaFilterSelected,Selected_Taluka);

      // }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined){

      //       //Village
      //     // //alert("Village");

      //   DistrictFilter(VillageFilterSlected,Selected_Village);
            
      // }
      //
     if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

        //Disctrict // Maincat
         //alert("Disctrict - Maincat");
  
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Category_Checked").style.display = "";
        DistrictFilter(MainCategorySelected,Selected_Category,DistrictFilterSelected,Selected_District);
  
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
        
        //Disctrict // Crop
        //alert("Disctrict - CROP");
        // document.getElementById("District_Checked_P").style.display = "";
        // document.getElementById("Crop_Checked").style.display = "";
        DistrictFilter(CropSelected,Selected_Crop,DistrictFilterSelected,Selected_District);
    }
    else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
  
        //Taluka // Mincat
         //alert("Taluka - Mincat");
        // document.getElementById("Category_Checked").style.display = "";
        // document.getElementById("Taluka_Checked_P").style.display = "";
        // document.getElementById("District_Checked_P").style.display = "";
        DistrictFilter(MainCategorySelected,Selected_Category,TalukaFilterSelected,Selected_Taluka);
    }
    else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined ) ){
  
      //Taluka // CROP
         //alert("Taluka - CROP");
        // document.getElementById("Crop_Checked").style.display = "";
        // document.getElementById("Taluka_Checked_P").style.display = "";
        // document.getElementById("District_Checked_P").style.display = "";
        DistrictFilter(CropSelected,Selected_Crop,TalukaFilterSelected,Selected_Taluka);
  
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined ) ){
  
      //Village // main cat
       //alert("Village -  main cat");
      // document.getElementById("Category_Checked").style.display = "";
      // document.getElementById("Village_Checked_P").style.display = "";
      // document.getElementById("Taluka_Checked_P").style.display = "";
      // document.getElementById("District_Checked_P").style.display = "";
      DistrictFilter(MainCategorySelected,Selected_Category,VillageFilterSlected,Selected_Village);
  
    }
    else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
  
      //Village // main cat
       //alert("Village - CROP");
      // document.getElementById("Crop_Checked").style.display = "";
      // document.getElementById("Village_Checked_P").style.display = "";
      // document.getElementById("Taluka_Checked_P").style.display = "";
      // document.getElementById("District_Checked_P").style.display = "";
      DistrictFilter(CropSelected,Selected_Crop,VillageFilterSlected,Selected_Village);
      
    }else if(DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
  
      //Village // main cat
       //alert("Only Main Category");
      // document.getElementById("Category_Checked").style.display = "";
      DistrictFilter(MainCategorySelected,Selected_Category);
      
    }
    else if(DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined ) ){
  
  
       //alert("Only Main CROP");
      // document.getElementById("Crop_Checked").style.display = "";
      DistrictFilter(CropSelected,Selected_Crop);
      
    }
    else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
      //District
       //alert("District only");
      // document.getElementById("District_Checked_Only_Region").style.display = "";
      DistrictFilter(DistrictFilterSelected,Selected_District);
    }
    else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
  
        //Taluka
         //alert("Taluka");
        // document.getElementById("District_Checked_Only_Region").style.display = "";
        // document.getElementById("Taluka_Checked_Only_Region").style.display = "";
      DistrictFilter(TalukaFilterSelected,Selected_Taluka);
  
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){
  
          //Village
        //alert("Village");
        // document.getElementById("District_Checked_Only_Region").style.display = "";
        // document.getElementById("Taluka_Checked_Only_Region").style.display = "";
        // document.getElementById("Village_Checked_Only_Region").style.display = "";
      DistrictFilter(VillageFilterSlected,Selected_Village);
          
    }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected === undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
  
      //alert("With Only Date")
      DistrictFilter(Date_Selected_From,Date_Selected_To);
      
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined  && MainCategorySelected === undefined && CropSelected === undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
      
      //District
       //alert("District with Date");
      // document.getElementById("District_Checked_Only_Region").style.display = "";
  
      console.log("Before Actul Filter",DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To)
      DistrictFilter(DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To);
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected === undefined && CropSelected === undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined  ){
      
      //District
       //alert("Taluka with Date");
      // document.getElementById("District_Checked_Only_Region").style.display = "";
      
      console.log("Before Actul Filter",DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To)
      DistrictFilter(TalukaFilterSelected,Selected_Taluka,Date_Selected_From,Date_Selected_To);
    }
    else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
      
      //District
       //alert("Village with Date");
  
       DistrictFilter(VillageFilterSlected,Selected_Village,Date_Selected_From,Date_Selected_To);
      // document.getElementById("District_Checked_Only_Region").style.display = "";
      
      // console.log("Before Actul Filter",DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To)
   }
   else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
              //alert("Vivek Dhande")
              DistrictFilter(DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To,MainCategorySelected,Selected_Category);
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
      //alert("Taluka Filter Data")
             DistrictFilter(TalukaFilterSelected,Selected_Taluka,Date_Selected_From,Date_Selected_To,MainCategorySelected,Selected_Category);
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
      //alert("village Filter Data")
             DistrictFilter(VillageFilterSlected,Selected_Village,Date_Selected_From,Date_Selected_To,MainCategorySelected,Selected_Category);
    }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected == undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
      //alert("Only Main-Cat Date")
             DistrictFilter(MainCategorySelected,Selected_Category,Date_Selected_From,Date_Selected_To);
    }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
      //alert("Only Crop Date")
            
        DistrictFilter(CropSelected,Selected_Crop,Date_Selected_From,Date_Selected_To);
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
      //alert("District Crop Date")
            
        DistrictFilter(DistrictFilterSelected,Selected_District,Date_Selected_From,Date_Selected_To,CropSelected,Selected_Crop);
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
      //alert("Taluka Crop Date")
            
        DistrictFilter(TalukaFilterSelected,Selected_Taluka,Date_Selected_From,Date_Selected_To,CropSelected,Selected_Crop);
    }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
      //alert("village Crop Date")
            
        DistrictFilter(VillageFilterSlected,Selected_Village,Date_Selected_From,Date_Selected_To,CropSelected,Selected_Crop);
    }
    if(DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected === undefined && CropSelected === undefined ){
      GetTotalLandFilter();
    }

      

}

function DistrictFilter(params,params2,params3,params4,params5,params6) {

  ExportDataList = [];
  exportIndex = 0;
  toalLandSum = 0;

  document.getElementById("WithoutFilter").style.display = "none";
  document.getElementById("WithFilter").style.display = ""; 

  Pagination_Filter_Flag = params;
  Pagination_Filter_Value =params2;

  Pagination_Filter_Both = params3;
  Pagination_Filter_Both_Value = params4

   Pagination_Cat_Type = params5;
   Pagination_Cat_Value =params6

  data = [];
  UserList = [];
  index1 = 0;
  index = 0;
  CurrentPage=0;
  paginationindex=0;
  while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
  


          // if(params3 !== undefined && params4 !== undefined){


          //   firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").get().then((querySnapshot) => {
          
    
          //     querySnapshot.forEach((doc) => {

          //       if(Selected_Land_Unit === "एकर"){


          //         if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
    
          //           toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
    
          //             console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
    
          //         }
          //         else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
    
          //             toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
    
          //         }
          //         else{
    
          //           toalLandSum = toalLandSum + doc.data().farmArea
          
          //         }
    
    
          //       }
          //       else if(Selected_Land_Unit === "हेक्टर"){
        
          //         if(doc.data().selectedFarmAreaUnit === 'एकर'){
        
          //           toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
        
                    
        
          //         }
          //         else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
        
          //             toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
        
          //         }
          //         else{
        
          //           toalLandSum = toalLandSum + doc.data().farmArea
                    
          //         }
        
        
          //       }
          //       else if(Selected_Land_Unit === "गुंठा"){
        
          //         if(doc.data().selectedFarmAreaUnit === 'एकर'){
        
          //           toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
        
                    
        
          //       }
          //       else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
        
          //           toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
        
          //       }
          //       else{
        
          //         toalLandSum = toalLandSum + doc.data().farmArea
                  
          //       }
        
        
          //       }

          //    });
         
          // }).then(()=>{
          //   // //alert("In the Filter mode")
          //   if(Selected_Land_Unit !== undefined){

          //     document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
          //     document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
            
          //   }
           

          // })
          // }
          // else{
          //   first = firestore.collection("Sheti").where(`${params}`,"==",params2).orderBy("date","desc").get().then((querySnapshot) => {
        
          //     querySnapshot.forEach((doc) => {

          //       if(Selected_Land_Unit === "एकर"){


          //         if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
    
          //           toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
    
          //             console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
    
          //         }
          //         else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
    
          //             toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
    
          //         }
          //         else{
    
          //           toalLandSum = toalLandSum + doc.data().farmArea
          
          //         }
    
    
          //       }
          //       else if(Selected_Land_Unit === "हेक्टर"){
        
          //         if(doc.data().selectedFarmAreaUnit === 'एकर'){
        
          //           toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
        
                    
        
          //         }
          //         else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
        
          //             toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
        
          //         }
          //         else{
        
          //           toalLandSum = toalLandSum + doc.data().farmArea
                    
          //         }
        
        
          //       }
          //       else if(Selected_Land_Unit === "गुंठा"){
        
          //         if(doc.data().selectedFarmAreaUnit === 'एकर'){
        
          //           toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
        
                    
        
          //       }
          //       else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
        
          //           toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
        
          //       }
          //       else{
        
          //         toalLandSum = toalLandSum + doc.data().farmArea
                  
          //       }
        
        
          //       }
         
              
          //   });
            
          // }).then(()=>{

          //   if(Selected_Land_Unit !== undefined){
          //     // //alert("In the Filter mode")
          //     document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
          //     document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
            
          //   }
 
          // })
          
          
          // }


          if(params5 !== undefined && params6 !== undefined && params3 !== undefined && params4 !== undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){

            //alert("District with Date Render with cat"); 
            
            document.querySelector('#next_Main_cat').disabled = false;
            // //alert("In Special Case");

            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }

          if(params == "village"){
    
            firestore.collection("Sheti").where("date",">=",params3).where("date","<=",params4).where(params,"==",params2).where(params5,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];

          

              querySnapshot.forEach((doc) => {
            // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
            console.log("Filtered data",doc.data())
            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((userdoc)=>{
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                         // doc.data() is never undefined for query doc snapshots
                         $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                         <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                         <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                         <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                         <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                       
                     </tr>`);
                         document.getElementById("NoProduct").style.display = "none"
                         // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

            });
            


            }).then(()=>{
              UserList[index1++] = data;
              paginationindex++;
              CurrentPage++;
              console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
              console.log("Data Puted Sucessfully",UserList);
            })          

            firestore.collection("Sheti").where("date",">=",params3).where("date","<=",params4).where(params,"==",params2).where(params5,"==",params6).orderBy("date","desc").get().then((querySnapshot) => {

            querySnapshot.forEach((doc) => {
              if(Selected_Land_Unit === "एकर"){


                if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
  
                  toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
  
                    console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
  
                }
                else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
  
                    toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
  
                }
                else{
  
                  toalLandSum = toalLandSum + doc.data().farmArea
        
                }
  
  
              }
              else if(Selected_Land_Unit === "हेक्टर"){
      
                if(doc.data().selectedFarmAreaUnit === 'एकर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
      
                  
      
                }
                else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                    toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
      
                }
                else{
      
                  toalLandSum = toalLandSum + doc.data().farmArea
                  
                }
      
      
              }
              else if(Selected_Land_Unit === "गुंठा"){
      
                if(doc.data().selectedFarmAreaUnit === 'एकर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
      
                  
      
              }
              else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
      
              }
              else{
      
                toalLandSum = toalLandSum + doc.data().farmArea
                
              }
      
      
              }
        
          firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {

            querySnapshot.forEach((userdoc)=>{

              ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ').replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
                    
            })

          })

          });

            }).then(()=>{
              console.log("User Data",ExportDataList)
              if(Selected_Land_Unit !== undefined){
      

                document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
                document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
              
              }
            })

          }else{
            firestore.collection("Sheti").where("date",">=",params3).where("date","<=",params4).where(params,"==",params2).where(params5,"==",params6).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];

          

              querySnapshot.forEach((doc) => {
            // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
            console.log("Filtered data",doc.data())
            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((userdoc)=>{
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                         // doc.data() is never undefined for query doc snapshots
                         $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                         <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                         <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                         <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                         <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                       
                     </tr>`);
                         document.getElementById("NoProduct").style.display = "none"
                         // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

            });
            


            }).then(()=>{
              UserList[index1++] = data;
              paginationindex++;
              CurrentPage++;
              console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
              console.log("Data Puted Sucessfully",UserList);
            })          

            firestore.collection("Sheti").where("date",">=",params3).where("date","<=",params4).where(params,"==",params2).where(params5,"==",params6).orderBy("date","desc").get().then((querySnapshot) => {

            querySnapshot.forEach((doc) => {
              if(Selected_Land_Unit === "एकर"){


                if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
  
                  toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
  
                    console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
  
                }
                else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
  
                    toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
  
                }
                else{
  
                  toalLandSum = toalLandSum + doc.data().farmArea
        
                }
  
  
              }
              else if(Selected_Land_Unit === "हेक्टर"){
      
                if(doc.data().selectedFarmAreaUnit === 'एकर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
      
                  
      
                }
                else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                    toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
      
                }
                else{
      
                  toalLandSum = toalLandSum + doc.data().farmArea
                  
                }
      
      
              }
              else if(Selected_Land_Unit === "गुंठा"){
      
                if(doc.data().selectedFarmAreaUnit === 'एकर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
      
                  
      
              }
              else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
      
              }
              else{
      
                toalLandSum = toalLandSum + doc.data().farmArea
                
              }
      
      
              }
        
          firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {

            querySnapshot.forEach((userdoc)=>{

              ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ').replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
                    
            })

          })

          });

            }).then(()=>{
              console.log("User Data",ExportDataList)
              if(Selected_Land_Unit !== undefined){
      

                document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
                document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
              
              }
            })
          }
            
            
          }
          else if(params3 !== undefined && params4 !== undefined && (Date_Selected_From == undefined && Date_Selected_To == undefined )){

            //alert("In WithOut Date")

            if(params3== "village"){
              first = firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).where("tahsil","==",Selected_Taluka).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
  
                querySnapshot.forEach((doc) => {
              // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
              // data[index++] = [`${doc.id}`,`${doc.data().cropDateString}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
              
              //     // doc.data() is never undefined for query doc snapshots
              //     $("#tbody_filter").append(`<tr>
              //     <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              // </tr>`);
              //     document.getElementById("NoProduct").style.display = "none"
              //     // document.getElementById("UserListTable").style.display = ""
  
  
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
                    querySnapshot.forEach((userdoc) => {
                      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                      // doc.data() is never undefined for query doc snapshots
                      $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                      <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                      <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                      <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                      <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                    
                  </tr>`);
                
                  document.getElementById("NoProduct").style.display = "none"
                
                    })
                  })
              
              });
              
  
  
              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })
  
  
              first = firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).where("tahsil","==",Selected_Taluka).orderBy("date","desc").get().then((querySnapshot) => {
  
                querySnapshot.forEach((doc) => {
                  if(Selected_Land_Unit === "एकर"){
  
  
                    if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
      
                        console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
      
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
      
                    }
                    else{
      
                      toalLandSum = toalLandSum + doc.data().farmArea
            
                    }
      
      
                  }
                  else if(Selected_Land_Unit === "हेक्टर"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
          
                      
          
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
          
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
          
                    }
                    else{
          
                      toalLandSum = toalLandSum + doc.data().farmArea
                      
                    }
          
          
                  }
                  else if(Selected_Land_Unit === "गुंठा"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
          
                      
          
                  }
                  else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
          
                  }
                  else{
          
                    toalLandSum = toalLandSum + doc.data().farmArea
                    
                  }
          
          
                  }
            
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).where("tahsil","==",Selected_Taluka).orderBy("date","desc").get().then((querySnapshot) => {
  
                querySnapshot.forEach((userdoc)=>{
  
                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ').replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
                        
                })
  
              })
  
              });
  
              }).then(()=>{
                console.log("User Data",ExportDataList)
                if(Selected_Land_Unit !== undefined){
                
  
                  document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
                  document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
                
                }
              })
            }else{
              first = firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
  
                querySnapshot.forEach((doc) => {
              // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
              // data[index++] = [`${doc.id}`,`${doc.data().cropDateString}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
              
              //     // doc.data() is never undefined for query doc snapshots
              //     $("#tbody_filter").append(`<tr>
              //     <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              // </tr>`);
              //     document.getElementById("NoProduct").style.display = "none"
              //     // document.getElementById("UserListTable").style.display = ""
  
  
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
                    querySnapshot.forEach((userdoc) => {
                      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                      // doc.data() is never undefined for query doc snapshots
                      $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                      <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                      <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                      <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                      <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                    
                  </tr>`);
                
                  document.getElementById("NoProduct").style.display = "none"
                
                    })
                  })
              
              });
              
  
  
              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })
  
  
              first = firestore.collection("Sheti").where(`${params}`,"==",params2).where(`${params3}`,"==",params4).orderBy("date","desc").get().then((querySnapshot) => {
  
                querySnapshot.forEach((doc) => {
                  if(Selected_Land_Unit === "एकर"){
  
  
                    if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
      
                        console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
      
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
      
                    }
                    else{
      
                      toalLandSum = toalLandSum + doc.data().farmArea
            
                    }
      
      
                  }
                  else if(Selected_Land_Unit === "हेक्टर"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
          
                      
          
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
          
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
          
                    }
                    else{
          
                      toalLandSum = toalLandSum + doc.data().farmArea
                      
                    }
          
          
                  }
                  else if(Selected_Land_Unit === "गुंठा"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
          
                      
          
                  }
                  else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
          
                  }
                  else{
          
                    toalLandSum = toalLandSum + doc.data().farmArea
                    
                  }
          
          
                  }
            
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
  
                querySnapshot.forEach((userdoc)=>{
  
                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ').replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
                        
                })
  
              })
  
              });
  
              }).then(()=>{
                console.log("User Data",ExportDataList)
                if(Selected_Land_Unit !== undefined){
                
  
                  document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
                  document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
                
                }
              })
            }
           


          }else if(params3 !== undefined && params4 !== undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){

            //alert("District with Date Render");
            document.getElementById("WithFilter_pikar").style.display = "none";   
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";   
            
            document.querySelector('#next_Main_cat').disabled = false;
            // //alert("In Special Case");

            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }

            if(params == "village"){
                       alert("In Special Case");
              firestore.collection("Sheti").where("date",">=",params3).where("date","<=",params4).where(params,"==",params2).where("tahsil","==",Selected_Taluka).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];

                querySnapshot.forEach((doc) => {
              // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
              // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                querySnapshot.forEach((userdoc)=>{
                  data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                          <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                          <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                        
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""

                        
                })

              })

              });
              


              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })


              firestore.collection("Sheti").where("date",">=",params3).where("date","<=",params4).where(params,"==",params2).where("tahsil","==",Selected_Taluka).orderBy("date","desc").get().then((querySnapshot) => {

                querySnapshot.forEach((doc) => {
                  if(Selected_Land_Unit === "एकर"){


                    if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
      
                        console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
      
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
      
                    }
                    else{
      
                      toalLandSum = toalLandSum + doc.data().farmArea
            
                    }
      
      
                  }
                  else if(Selected_Land_Unit === "हेक्टर"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
          
                      
          
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
          
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
          
                    }
                    else{
          
                      toalLandSum = toalLandSum + doc.data().farmArea
                      
                    }
          
          
                  }
                  else if(Selected_Land_Unit === "गुंठा"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
          
                      
          
                  }
                  else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
          
                  }
                  else{
          
                    toalLandSum = toalLandSum + doc.data().farmArea
                    
                  }
          
          
                  }
            
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).where("tahsil","==",Selected_Taluka).orderBy("date","desc").get().then((querySnapshot) => {

                querySnapshot.forEach((userdoc)=>{

                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ').replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
                        
                })

              })

              });

              }).then(()=>{
                console.log("User Data",ExportDataList)
                if(Selected_Land_Unit !== undefined){
                

                  document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
                  document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
                
                }
              })
            }else{
              firestore.collection("Sheti").where("date",">=",params3).where("date","<=",params4).where(params,"==",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];

                querySnapshot.forEach((doc) => {
              // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
              // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                querySnapshot.forEach((userdoc)=>{
                  data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                          <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                          <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                          <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                        
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""

                        
                })

              })

              });
              


              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })


              firestore.collection("Sheti").where("date",">=",params3).where("date","<=",params4).where(params,"==",params2).orderBy("date","desc").get().then((querySnapshot) => {

                querySnapshot.forEach((doc) => {
                  if(Selected_Land_Unit === "एकर"){


                    if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
      
                        console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
      
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
      
                    }
                    else{
      
                      toalLandSum = toalLandSum + doc.data().farmArea
            
                    }
      
      
                  }
                  else if(Selected_Land_Unit === "हेक्टर"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
          
                      
          
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
          
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
          
                    }
                    else{
          
                      toalLandSum = toalLandSum + doc.data().farmArea
                      
                    }
          
          
                  }
                  else if(Selected_Land_Unit === "गुंठा"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
          
                      
          
                  }
                  else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
          
                  }
                  else{
          
                    toalLandSum = toalLandSum + doc.data().farmArea
                    
                  }
          
          
                  }
            
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {

                querySnapshot.forEach((userdoc)=>{

                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ').replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
                        
                })

              })

              });

              }).then(()=>{
                console.log("User Data",ExportDataList)
                if(Selected_Land_Unit !== undefined){
                

                  document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
                  document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
                
                }
              })
            }  
              
            
          }
          else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected === undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
           
           //alert("In Date")
            document.getElementById("WithFilter_pikar").style.display = "none";   
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";   
            
            document.querySelector('#next_Main_cat').disabled = false;
            // //alert("In Special Case");

            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }

      
            firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
            // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((userdoc)=>{
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                         // doc.data() is never undefined for query doc snapshots
                         $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                         <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                         <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                         <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                         <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                       
                     </tr>`);
                         document.getElementById("NoProduct").style.display = "none"
                         // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })

          // Land Mesument and Export Data

          firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).orderBy("date","desc").get().then((querySnapshot) => {

            querySnapshot.forEach((doc) => {
              if(Selected_Land_Unit === "एकर"){


                if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
  
                  toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
  
                    console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
  
                }
                else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
  
                    toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
  
                }
                else{
  
                  toalLandSum = toalLandSum + doc.data().farmArea
        
                }
  
  
              }
              else if(Selected_Land_Unit === "हेक्टर"){
      
                if(doc.data().selectedFarmAreaUnit === 'एकर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
      
                  
      
                }
                else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                    toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
      
                }
                else{
      
                  toalLandSum = toalLandSum + doc.data().farmArea
                  
                }
      
      
              }
              else if(Selected_Land_Unit === "गुंठा"){
      
                if(doc.data().selectedFarmAreaUnit === 'एकर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
      
                  
      
              }
              else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                  toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
      
              }
              else{
      
                toalLandSum = toalLandSum + doc.data().farmArea
                
              }
      
      
              }

          firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

            querySnapshot.forEach((userdoc)=>{

              console.log("Sheti Download",[`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`])

              ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

           
            })

          })

          });

        }).then(()=>{
        if(Selected_Land_Unit!== undefined){

          document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
          document.getElementById("DemotextFilter").innerText = `${toalLandSum} ${Selected_Land_Unit}`
        }
    
        })
      
           
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){

            document.getElementById("WithFilter_pikar").style.display = "none";   
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";   
            
            document.querySelector('#next_Main_cat').disabled = false;
            // //alert("In Special Case");

            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }

      
            firestore.collection("Sheti").where("date",">=",params).where("date","<=",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
            // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((userdoc)=>{
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

                         // doc.data() is never undefined for query doc snapshots
                         $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                         <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                         <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                         <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                         <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                         <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                       
                     </tr>`);
                         document.getElementById("NoProduct").style.display = "none"
                         // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined &&  MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
             
            //alert("In Taluka Date")
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";
            document.getElementById("WithFilter_pikar").style.display = "none";  
            
            document.querySelector('#next_withFilter').disabled = false;

            first = firestore.collection("Userinfo").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
              

              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
              console.log()
            // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
            data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

            

                // doc.data() is never undefined for query doc snapshots
                $("#tbody_filter").append(`<tr>
                <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                <th>${doc.data().userName.replace(/[\.\,\n\r]/g,' ')}</th>
                <th>${doc.data().village}</th>
                <th>${doc.data().tahsil}</th>
                <th>${doc.data().district}</th>
                <th>${doc.data().userContact}</th>
            </tr>`);
                document.getElementById("NoProduct").style.display = "none"
                // document.getElementById("UserListTable").style.display = ""
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })    
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined &&  MainCategorySelected == undefined && CropSelected == undefined && (Date_Selected_From !== undefined && Date_Selected_To !== undefined ) ){
             
            //alert("In Village Date")
            document.getElementById("WithFilter").style.display = "";
            document.getElementById("WithoutFilter").style.display = "none";
            document.getElementById("WithFilter_pikar").style.display = "none";  
            
            document.querySelector('#next_withFilter').disabled = false;

            first = firestore.collection("Userinfo").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
              

              lastUser = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
             
            // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
            data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,]

            

                // doc.data() is never undefined for query doc snapshots
                $("#tbody_filter").append(`<tr>
                <th style="cursor:pointer"><a id ="${doc.id}" onclick="showprofile(this.id)">${moment(doc.data().date.toDate()).format("DD/MM/YYYY") }</a> </th>
                <th>${doc.data().userName.replace(/[\.\,\n\r]/g,' ')}</th>
                <th>${doc.data().village}</th>
                <th>${doc.data().tahsil}</th>
                <th>${doc.data().district}</th>
                <th>${doc.data().userContact}</th>
            </tr>`);
                document.getElementById("NoProduct").style.display = "none"
                // document.getElementById("UserListTable").style.display = ""
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })    
          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
           //alert("In Special Filter")
            document.querySelector('#next_Main_cat').disabled = false;
          
            
            while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
              document.getElementById("tbody_filter_Pika").firstChild.remove();
            }

             firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).limit(10).get().then((querySnapshot) => {

              lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];

              querySnapshot.forEach((doc) => {
            // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
            // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

            firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

              querySnapshot.forEach((docI)=>{
                data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]

                         // doc.data() is never undefined for query doc snapshots
                         $("#tbody_filter_Pika").append(`<tr>
                         <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                         <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                         <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                         <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                     </tr>`);
                         document.getElementById("NoProduct").style.display = "none"
                         // document.getElementById("UserListTable").style.display = ""

                      
              })

            })

               
            
            });
            


          }).then(()=>{
            UserList[index1++] = data;
            paginationindex++;
            CurrentPage++;
            console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
            console.log("Data Puted Sucessfully",UserList);
          })
          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
            //alert("In Taluka Filter")
             document.querySelector('#next_Main_cat').disabled = false;
           
             
             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).limit(10).get().then((querySnapshot) => {
 
               lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if((DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
            //alert("In Village Filter")
             document.querySelector('#next_Main_cat').disabled = false;
           
             
             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(MainCategorySelected,"==",Selected_Category).limit(10).get().then((querySnapshot) => {
 
               lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if((DistrictFilterSelected === undefined && TalukaFilterSelected === undefined &&  VillageFilterSlected === undefined && MainCategorySelected !== undefined && CropSelected === undefined) && (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){
            
            //alert("In Only Main-Cat Date")
             document.querySelector('#next_Main_cat').disabled = false;
           
             
             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).limit(10).get().then((querySnapshot) => {
 
               lastUser_Date_with_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if(DistrictFilterSelected == undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
            //alert("In Only Crop Date")
             document.querySelector('#next_Main_cat').disabled = false;
           
             
             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
                lastUser_Date_with_Crop = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected == undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
            //alert("District - Crop  - Date")
             document.querySelector('#next_Main_cat').disabled = false;

             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
                lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected == undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
            //alert("Taluka - Crop  - Date")
             document.querySelector('#next_Main_cat').disabled = false;

             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
                lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }else if(DistrictFilterSelected !== undefined && TalukaFilterSelected !== undefined &&  VillageFilterSlected !== undefined && MainCategorySelected !== undefined && CropSelected !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined ){
            
            //alert("Village - Crop  - Date")
             document.querySelector('#next_Main_cat').disabled = false;

             while(document.getElementById("tbody_filter_Pika").childElementCount!==0){
               document.getElementById("tbody_filter_Pika").firstChild.remove();
             }
 
              firestore.collection("Sheti").where(`${params}`,"==",params2).where("date",">=",params3).where("date","<=",params4).where(CropSelected,"==",Selected_Crop).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
                lastUser_Date_with_Crop_Dist = querySnapshot.docs[querySnapshot.docs.length-1];
 
               querySnapshot.forEach((doc) => {
             // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
             // data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
 
             firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
 
               querySnapshot.forEach((docI)=>{
                 data[index++] = [`${docI.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${docI.data().district}`,`${docI.data().tahsil}`,`${docI.data().village}` ,`${docI.data().userContact}`]
 
                          // doc.data() is never undefined for query doc snapshots
                          $("#tbody_filter_Pika").append(`<tr>
                          <th  id=${docI.id} onclick ="showprofile(this.id)"><a id ="${docI.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().crop}</a> </th>
                          <th><a id ="${docI.id}" >${doc.data().cropMainCat}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().district}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().tahsil}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().village}</a> </th>
                          <th><a id ="${docI.id}" >${docI.data().userContact}</a> </th>
                      </tr>`);
                          document.getElementById("NoProduct").style.display = "none"
                          // document.getElementById("UserListTable").style.display = ""
 
                       
               })
 
             })
 
                
             
             });
             
 
 
           }).then(()=>{
             UserList[index1++] = data;
             paginationindex++;
             CurrentPage++;
             console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
             console.log("Data Puted Sucessfully",UserList);
           })
          }
          else{
            //alert("In Filter 2 mode")
         
            if(params == "village"){
              first = firestore.collection("Sheti").where(`${params}`,"==",params2).where("tahsil","==",Selected_Taluka).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
  
                querySnapshot.forEach((doc) => {
              // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
              // data[index++] = [`${doc.id}`,`${doc.data().cropDateString}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
              
  
                  // doc.data() is never undefined for query doc snapshots
              //     $("#tbody_filter").append(`<tr>
              //     <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              // </tr>`);
              //     document.getElementById("NoProduct").style.display = "none"
                  // document.getElementById("UserListTable").style.display = ""
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
                    querySnapshot.forEach((userdoc) => {
                      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                      // doc.data() is never undefined for query doc snapshots
                      $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                      <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                      <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                      <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                      <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                  </tr>`);
                
                  document.getElementById("NoProduct").style.display = "none"
                
                    })
                  })
              });
              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })
  
  
              first = firestore.collection("Sheti").where(`${params}`,"==",params2).where("tahsil","==",Selected_Taluka).orderBy("date","desc").get().then((querySnapshot) => {
  
                querySnapshot.forEach((doc) => {
                  if(Selected_Land_Unit === "एकर"){
  
  
                    if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
      
                        console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
      
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
      
                    }
                    else{
      
                      toalLandSum = toalLandSum + doc.data().farmArea
            
                    }
      
      
                  }
                  else if(Selected_Land_Unit === "हेक्टर"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
          
                      
          
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
          
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
          
                    }
                    else{
          
                      toalLandSum = toalLandSum + doc.data().farmArea
                      
                    }
          
          
                  }
                  else if(Selected_Land_Unit === "गुंठा"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
          
                      
          
                  }
                  else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
          
                  }
                  else{
          
                    toalLandSum = toalLandSum + doc.data().farmArea
                    
                  }
          
          
                  }
            
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).where("tahsil","==",Selected_Taluka).orderBy("date","desc").get().then((querySnapshot) => {
  
                querySnapshot.forEach((userdoc)=>{
  
                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ').replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
                        
                })
  
              })
  
              });
  
              }).then(()=>{
                // console.log("User Data",ExportDataList)
                if(Selected_Land_Unit !== undefined){
                
  
                  document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
                  document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
                
                }
              })
            }else{
              first = firestore.collection("Sheti").where(`${params}`,"==",params2).orderBy("date","desc").limit(10).get().then((querySnapshot) => {

                lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
  
                querySnapshot.forEach((doc) => {
              // console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' ')); 
              // data[index++] = [`${doc.id}`,`${doc.data().cropDateString}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
              
  
                  // doc.data() is never undefined for query doc snapshots
              //     $("#tbody_filter").append(`<tr>
              //     <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              //     <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              // </tr>`);
              //     document.getElementById("NoProduct").style.display = "none"
                  // document.getElementById("UserListTable").style.display = ""
                  firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
                    querySnapshot.forEach((userdoc) => {
                      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                      // doc.data() is never undefined for query doc snapshots
                      $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                      <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                      <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                      <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                      <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                  </tr>`);
                
                  document.getElementById("NoProduct").style.display = "none"
                
                    })
                  })
              });
              }).then(()=>{
                UserList[index1++] = data;
                paginationindex++;
                CurrentPage++;
                console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
                console.log("Data Puted Sucessfully",UserList);
              })
  
  
              first = firestore.collection("Sheti").where(`${params}`,"==",params2).orderBy("date","desc").get().then((querySnapshot) => {
  
                querySnapshot.forEach((doc) => {
                  if(Selected_Land_Unit === "एकर"){
  
  
                    if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
      
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Acre ) 
      
                        console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)
      
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
      
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Acre )
      
                    }
                    else{
      
                      toalLandSum = toalLandSum + doc.data().farmArea
            
                    }
      
      
                  }
                  else if(Selected_Land_Unit === "हेक्टर"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Hector ) 
          
                      
          
                    }
                    else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){
          
                        toalLandSum = toalLandSum + (doc.data().farmArea * Guntha_Hector )
          
                    }
                    else{
          
                      toalLandSum = toalLandSum + doc.data().farmArea
                      
                    }
          
          
                  }
                  else if(Selected_Land_Unit === "गुंठा"){
          
                    if(doc.data().selectedFarmAreaUnit === 'एकर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Acre_Guntha ) 
          
                      
          
                  }
                  else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){
          
                      toalLandSum = toalLandSum + (doc.data().farmArea * Hector_Guntha )
          
                  }
                  else{
          
                    toalLandSum = toalLandSum + doc.data().farmArea
                    
                  }
          
          
                  }
            
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).orderBy("date","desc").get().then((querySnapshot) => {
  
                querySnapshot.forEach((userdoc)=>{
  
                  ExportDataList[exportIndex++] = [`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ').replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
                        
                })
  
              })
  
              });
  
              }).then(()=>{
                // console.log("User Data",ExportDataList)
                if(Selected_Land_Unit !== undefined){
                
  
                  document.getElementById("TotalLandTitlewithFilter").style.display = "flex"
                  document.getElementById("DemotextFilter").innerText = `${toalLandSum.toFixed(2)} ${Selected_Land_Unit}`
                
                }
              })
            }
            


          }

  
}


function nextPage_Filter(params) {



CurrentPage >0 ? document.querySelector('#previous_withFilter').disabled = false : document.querySelector('#previous_withFilter').disabled = true


// CurrentPage++;
if(Pagination_Cat_Type!== undefined && Pagination_Cat_Value !== undefined ){
      if(Pagination_Filter_Flag == "village"){
        alert("Date with Cat")
        if(CurrentPage==paginationindex){

          paginationindex++;
          
          firestore.collection("Sheti").where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(Pagination_Filter_Flag,"==",Pagination_Filter_Value).where("tahsil","==",Selected_Taluka).where(Pagination_Cat_Type,"==",Pagination_Cat_Value).orderBy("date","desc").startAfter(OnlyDateLastDoc).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
            
              document.querySelector('#next_withFilter').disabled = true
              
              CurrentPage--;
              paginationindex--;
              
              (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter").childElementCount!==0){
                document.getElementById("tbody_filter").firstChild.remove();
              }
              OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
                //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
                  // doc.data() is never undefined for query doc snapshots
              //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
          
              //      $("#tbody_filter").append(`<tr>
              //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              //  </tr>`);
              //  document.getElementById("NoProduct").style.display = "none"
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
                querySnapshot.forEach((userdoc) => {
                  data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                  // doc.data() is never undefined for query doc snapshots
                  $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                  <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                  <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                  <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                  <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                
              </tr>`);
            
              document.getElementById("NoProduct").style.display = "none"
            
                })
              })
                })
                
              
            }
          
          
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
          
          // console.log("demo Array",element)
          
            $("#tbody_filter").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>
            <th>${element[8]}</th>
            <th>${element[9]}</th>
            <th>${element[10]}</th>
            <th>${element[11]}</th>
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          CurrentPage++;
      }else{
        if(CurrentPage==paginationindex){

          paginationindex++;
          
          firestore.collection("Sheti").where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(Pagination_Filter_Flag,"==",Pagination_Filter_Value).where(Pagination_Cat_Type,"==",Pagination_Cat_Value).orderBy("date","desc").startAfter(OnlyDateLastDoc).limit(10).get().then((querySnapshot) => {
            console.log("Get New Data");
            if( querySnapshot.docs.length == 0 ){
            
              document.querySelector('#next_withFilter').disabled = true
              
              CurrentPage--;
              paginationindex--;
              
              (swal("There is no Record Found"))
              console.log("At the End",UserList);
            }
            else{
              
              data = [];
              index = 0;
              while(document.getElementById("tbody_filter").childElementCount!==0){
                document.getElementById("tbody_filter").firstChild.remove();
              }
              OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];
              querySnapshot.forEach((doc) => {
                //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
                  // doc.data() is never undefined for query doc snapshots
              //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
          
              //      $("#tbody_filter").append(`<tr>
              //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              //  </tr>`);
              //  document.getElementById("NoProduct").style.display = "none"
              firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
                querySnapshot.forEach((userdoc) => {
                  data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                  // doc.data() is never undefined for query doc snapshots
                  $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                  <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                  <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                  <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                  <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                  <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
                
              </tr>`);
            
              document.getElementById("NoProduct").style.display = "none"
            
                })
              })
                })
                
              
            }
          
          
          }).then(()=>{
          console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
          UserList[index1++] = data;
          console.log("Data Puted Sucessfully",UserList);
          })
          
          }
          else{
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          UserList[CurrentPage].forEach(element => {
          
          // console.log("demo Array",element)
          
            $("#tbody_filter").append(`<tr>
            <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
            <th>${element[2]}</th>
            <th>${element[3]}</th>
            <th>${element[4]}</th>
            <th>${element[5]}</th>
            <th>${element[6]}</th>
            <th>${element[7]}</th>
            <th>${element[8]}</th>
            <th>${element[9]}</th>
            <th>${element[10]}</th>
            <th>${element[11]}</th>
            </tr>`);
          });
          console.log("Data from local",UserList);
          }
          CurrentPage++;
      }
    


}
else if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && Date_Selected_From == undefined && Date_Selected_To == undefined){
 
  
  console.log(Pagination_Filter_Flag,Pagination_Filter_Both);
  if(Pagination_Filter_Both == "village"){
    // alert("With out date")
    if(CurrentPage==paginationindex){

      paginationindex++;
      
      firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).where("tahsil","==",Selected_Taluka).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
         
          document.querySelector('#next_withFilter').disabled = true
          
           CurrentPage--;
          paginationindex--;
          
           (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          
          data = [];
          index = 0;
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
               // doc.data() is never undefined for query doc snapshots
          //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
      
          //      $("#tbody_filter").append(`<tr>
          //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
          //  </tr>`);
          //  document.getElementById("NoProduct").style.display = "none"
          firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
            querySnapshot.forEach((userdoc) => {
              data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
              // doc.data() is never undefined for query doc snapshots
              $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
              <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
              <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            
          </tr>`);
          
        
          document.getElementById("NoProduct").style.display = "none"
        
            })
          })
      
            })
            
           
        }
      
       
      }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      console.log("Data Puted Sucessfully",UserList);
      })
      
      }
      else{
      while(document.getElementById("tbody_filter").childElementCount!==0){
        document.getElementById("tbody_filter").firstChild.remove();
      }
      UserList[CurrentPage].forEach(element => {
       
       // console.log("demo Array",element)
      
        $("#tbody_filter").append(`<tr>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
        <th>${element[8]}</th>
        <th>${element[9]}</th>
        <th>${element[10]}</th>
        <th>${element[11]}</th>
        </tr>`);
      });
      console.log("Data from local",UserList);
      }
      
      CurrentPage++;
  }else{
    if(CurrentPage==paginationindex){

      paginationindex++;
      
      firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where(`${Pagination_Filter_Both}`,"==",Pagination_Filter_Both_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
         
          document.querySelector('#next_withFilter').disabled = true
          
           CurrentPage--;
          paginationindex--;
          
           (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          
          data = [];
          index = 0;
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
               // doc.data() is never undefined for query doc snapshots
          //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
      
          //      $("#tbody_filter").append(`<tr>
          //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
          //  </tr>`);
          //  document.getElementById("NoProduct").style.display = "none"
          firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
            querySnapshot.forEach((userdoc) => {
              data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
              // doc.data() is never undefined for query doc snapshots
              $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
              <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
              <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            
          </tr>`);
          
        
          document.getElementById("NoProduct").style.display = "none"
        
            })
          })
      
            })
            
           
        }
      
       
      }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      console.log("Data Puted Sucessfully",UserList);
      })
      
      }
      else{
      while(document.getElementById("tbody_filter").childElementCount!==0){
        document.getElementById("tbody_filter").firstChild.remove();
      }
      UserList[CurrentPage].forEach(element => {
       
       // console.log("demo Array",element)
      
        $("#tbody_filter").append(`<tr>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
        <th>${element[8]}</th>
        <th>${element[9]}</th>
        <th>${element[10]}</th>
        <th>${element[11]}</th>
        </tr>`);
      });
      console.log("Data from local",UserList);
      }
      
      CurrentPage++;
  }
 

}else if(Pagination_Filter_Both !== undefined && Pagination_Filter_Both_Value !== undefined && Date_Selected_From !== undefined && Date_Selected_To !== undefined){
      
  if(Pagination_Filter_Flag == "village"){

    // alert("Date with village")
    if(CurrentPage==paginationindex){

      paginationindex++;
      
      firestore.collection("Sheti").where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(Pagination_Filter_Flag,"==",Pagination_Filter_Value).where("tahsil","==",Selected_Taluka).orderBy("date","desc").startAfter(OnlyDateLastDoc).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
        
          document.querySelector('#next_withFilter').disabled = true
          
          CurrentPage--;
          paginationindex--;
          
          (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          
          data = [];
          index = 0;
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
              // doc.data() is never undefined for query doc snapshots
          //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
      
          //      $("#tbody_filter").append(`<tr>
          //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
          //  </tr>`);
          //  document.getElementById("NoProduct").style.display = "none"
          firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

            querySnapshot.forEach((userdoc) => {
              data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              // doc.data() is never undefined for query doc snapshots
              $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
              <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
              <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            
          </tr>`);
        
          document.getElementById("NoProduct").style.display = "none"
        
            })
          })
            })
            
          
        }
      
      
      }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      console.log("Data Puted Sucessfully",UserList);
      })
      
    }
    else{
    while(document.getElementById("tbody_filter").childElementCount!==0){
      document.getElementById("tbody_filter").firstChild.remove();
    }
    UserList[CurrentPage].forEach(element => {
    
    // console.log("demo Array",element)
    
      $("#tbody_filter").append(`<tr>
      <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
      <th>${element[2]}</th>
      <th>${element[3]}</th>
      <th>${element[4]}</th>
      <th>${element[5]}</th>
      <th>${element[6]}</th>
      <th>${element[7]}</th>
      <th>${element[8]}</th>
      <th>${element[9]}</th>
      <th>${element[10]}</th>
      <th>${element[11]}</th>
      </tr>`);
    });
    console.log("Data from local",UserList);
    }
    CurrentPage++;

  }else{
    if(CurrentPage==paginationindex){

      paginationindex++;
      
      firestore.collection("Sheti").where("date",">=",Pagination_Filter_Both).where("date","<=",Pagination_Filter_Both_Value).where(Pagination_Filter_Flag,"==",Pagination_Filter_Value).orderBy("date","desc").startAfter(OnlyDateLastDoc).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
        
          document.querySelector('#next_withFilter').disabled = true
          
          CurrentPage--;
          paginationindex--;
          
          (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          
          data = [];
          index = 0;
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
              // doc.data() is never undefined for query doc snapshots
          //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
      
          //      $("#tbody_filter").append(`<tr>
          //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
          //  </tr>`);
          //  document.getElementById("NoProduct").style.display = "none"
          firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

            querySnapshot.forEach((userdoc) => {
              data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              // doc.data() is never undefined for query doc snapshots
              $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
              <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
              <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            
          </tr>`);
        
          document.getElementById("NoProduct").style.display = "none"
        
            })
          })
            })
            
          
        }
      
      
      }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      console.log("Data Puted Sucessfully",UserList);
      })
      
      }
      else{
      while(document.getElementById("tbody_filter").childElementCount!==0){
        document.getElementById("tbody_filter").firstChild.remove();
      }
      UserList[CurrentPage].forEach(element => {
      
      // console.log("demo Array",element)
      
        $("#tbody_filter").append(`<tr>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
        <th>${element[8]}</th>
        <th>${element[9]}</th>
        <th>${element[10]}</th>
        <th>${element[11]}</th>
        </tr>`);
      });
      console.log("Data from local",UserList);
      }
      CurrentPage++;
  }
      

}

else{

  //alert("In Single Filed")

  if( (Date_Selected_From !== undefined && Date_Selected_To !== undefined )){

        if(CurrentPage==paginationindex){

      paginationindex++;
      
      firestore.collection("Sheti").where("date",">=",Pagination_Filter_Flag).where("date","<=",Pagination_Filter_Value).orderBy("date","desc").startAfter(OnlyDateLastDoc).limit(10).get().then((querySnapshot) => {
        console.log("Get New Data");
        if( querySnapshot.docs.length == 0 ){
         
          document.querySelector('#next_withFilter').disabled = true
          
           CurrentPage--;
          paginationindex--;
          
           (swal("There is no Record Found"))
          console.log("At the End",UserList);
        }
        else{
          
          data = [];
          index = 0;
          while(document.getElementById("tbody_filter").childElementCount!==0){
            document.getElementById("tbody_filter").firstChild.remove();
          }
          OnlyDateLastDoc = querySnapshot.docs[querySnapshot.docs.length-1];
          querySnapshot.forEach((doc) => {
            //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
               // doc.data() is never undefined for query doc snapshots
          //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
      
          //      $("#tbody_filter").append(`<tr>
          //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
          //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
          //  </tr>`);
          //  document.getElementById("NoProduct").style.display = "none"
          firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
  
            querySnapshot.forEach((userdoc) => {
              data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

              // doc.data() is never undefined for query doc snapshots
              $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
              <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
              <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
              <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
              <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            
          </tr>`);
        
          document.getElementById("NoProduct").style.display = "none"
        
            })
          })
            })
            
           
        }
      
       
      }).then(()=>{
      console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
      UserList[index1++] = data;
      console.log("Data Puted Sucessfully",UserList);
      })
      
      }
      else{
      while(document.getElementById("tbody_filter").childElementCount!==0){
        document.getElementById("tbody_filter").firstChild.remove();
      }
      UserList[CurrentPage].forEach(element => {
       
       // console.log("demo Array",element)
      
        $("#tbody_filter").append(`<tr>
        <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
        <th>${element[2]}</th>
        <th>${element[3]}</th>
        <th>${element[4]}</th>
        <th>${element[5]}</th>
        <th>${element[6]}</th>
        <th>${element[7]}</th>
        <th>${element[8]}</th>
        <th>${element[9]}</th>
        <th>${element[10]}</th>
        <th>${element[11]}</th>
        </tr>`);
      });
      console.log("Data from local",UserList);
      }
      CurrentPage++;

  }else{
   
    if(Pagination_Filter_Flag == "village"){
      if(CurrentPage==paginationindex){

        paginationindex++;
        
        firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).where("tahsil","==",Selected_Taluka).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
           
            document.querySelector('#next_withFilter').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
              //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
                 // doc.data() is never undefined for query doc snapshots
            //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
        
            //      $("#tbody_filter").append(`<tr>
            //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            //  </tr>`);
            //  document.getElementById("NoProduct").style.display = "none"
            firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
    
              querySnapshot.forEach((userdoc) => {
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                // doc.data() is never undefined for query doc snapshots
                $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              
            </tr>`);
          
            document.getElementById("NoProduct").style.display = "none"
          
              })
            })
              })
              
             
          }
        
         
        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter").childElementCount!==0){
          document.getElementById("tbody_filter").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
         
         // console.log("demo Array",element)
        
          $("#tbody_filter").append(`<tr id ="${element[0]}" onclick="shetiInfo(this.id)">
          <th style="cursor:pointer"><a >${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>
          <th>${element[8]}</th>
          <th>${element[9]}</th>
          <th>${element[10]}</th>
          <th>${element[11]}</th>
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        CurrentPage++
    }else{
      if(CurrentPage==paginationindex){

        paginationindex++;
        
        firestore.collection("Sheti").where(`${Pagination_Filter_Flag}`,"==",Pagination_Filter_Value).orderBy("date","desc").startAfter(lastUser).limit(10).get().then((querySnapshot) => {
          console.log("Get New Data");
          if( querySnapshot.docs.length == 0 ){
           
            document.querySelector('#next_withFilter').disabled = true
            
             CurrentPage--;
            paginationindex--;
            
             (swal("There is no Record Found"))
            console.log("At the End",UserList);
          }
          else{
            
            data = [];
            index = 0;
            while(document.getElementById("tbody_filter").childElementCount!==0){
              document.getElementById("tbody_filter").firstChild.remove();
            }
            lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
            querySnapshot.forEach((doc) => {
              //   console.log(doc.data().userName.replace(/[\.\,\n\r]/g,' '));
                 // doc.data() is never undefined for query doc snapshots
            //      data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format('DD/MM/YYYY')}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
        
            //      $("#tbody_filter").append(`<tr>
            //      <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
            //      <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
            //  </tr>`);
            //  document.getElementById("NoProduct").style.display = "none"
            firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {
    
              querySnapshot.forEach((userdoc) => {
                data[index++] = [`${doc.id}`,`${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
                // doc.data() is never undefined for query doc snapshots
                $("#tbody_filter").append(`<tr  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;">
                <th ><a id ="${doc.id}" >${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</a> </th>
                <th ><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
                <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
                <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
                <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
              
            </tr>`);
          
            document.getElementById("NoProduct").style.display = "none"
          
              })
            })
              })
              
             
          }
        
         
        }).then(()=>{
        console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
        UserList[index1++] = data;
        console.log("Data Puted Sucessfully",UserList);
        })
        
        }
        else{
        while(document.getElementById("tbody_filter").childElementCount!==0){
          document.getElementById("tbody_filter").firstChild.remove();
        }
        UserList[CurrentPage].forEach(element => {
         
         // console.log("demo Array",element)
        
          $("#tbody_filter").append(`<tr id ="${element[0]}" onclick="shetiInfo(this.id)">
          <th style="cursor:pointer"><a >${element[1]}</a> </th>
          <th>${element[2]}</th>
          <th>${element[3]}</th>
          <th>${element[4]}</th>
          <th>${element[5]}</th>
          <th>${element[6]}</th>
          <th>${element[7]}</th>
          <th>${element[8]}</th>
          <th>${element[9]}</th>
          <th>${element[10]}</th>
          <th>${element[11]}</th>
          </tr>`);
        });
        console.log("Data from local",UserList);
        }
        CurrentPage++;
    }
 

  }

}



}

function Previous_Page_filter(params) {


document.querySelector('#next_withFilter').disabled = false;


CurrentPage--;
console.log("demo Array",UserList)

if(CurrentPage > 0){


console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
while(document.getElementById("tbody_filter").childElementCount!==0){
  document.getElementById("tbody_filter").firstChild.remove();
}


  UserList[CurrentPage-1].forEach(element => {
   
    $("#tbody_filter").append(`<tr>
    <th style="cursor:pointer"><a id ="${element[0]}" onclick="shetiInfo(this.id)">${element[1]}</a> </th>
    <th>${element[2]}</th>
    <th>${element[3]}</th>
    <th>${element[4]}</th>
    <th>${element[5]}</th>
    <th>${element[6]}</th>
    <th>${element[7]}</th>
    <th>${element[8]}</th>
    <th>${element[9]}</th>
    <th>${element[10]}</th>
    <th>${element[11]}</th>
    </tr>`);
  });
   
}
else{
CurrentPage = 1
document.querySelector('#previous_withFilter').disabled = true;

} 

}


// -----------------------------------------------------------Land Filter------------------------------------------------------------------ //


let sum = 0;


function GetTotalLandFilter(params) {

  // //alert("In the Without Filter mode");
  sum = 0;

firestore.collection("Sheti").get().then((querySnapshot) => {


  querySnapshot.forEach((doc)=>{

        if(Selected_Land_Unit === "एकर"){


              if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){

                  sum = sum + (doc.data().farmArea * Hector_Acre ) 

                  console.log(`${doc.data().farmArea} * ${Hector_Acre } "==" ${sum} `)

              }
              else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){

                  sum = sum + (doc.data().farmArea * Guntha_Acre )

              }
              else{

                sum = sum + doc.data().farmArea
                console.log(`${sum} * ${Hector_Acre } "==" ${doc.data().farmArea} `)
              }


        }
        else if(Selected_Land_Unit === "हेक्टर"){

          if(doc.data().selectedFarmAreaUnit === 'एकर'){

            sum = sum + (doc.data().farmArea * Acre_Hector ) 

            

          }
          else if(doc.data().selectedFarmAreaUnit === 'गुंठा'){

              sum = sum + (doc.data().farmArea * Guntha_Hector )

          }
          else{

            sum = sum + doc.data().farmArea
            
          }


        }
        else if(Selected_Land_Unit === "गुंठा"){

          if(doc.data().selectedFarmAreaUnit === 'एकर'){

            sum = sum + (doc.data().farmArea * Acre_Guntha ) 

            

        }
        else if(doc.data().selectedFarmAreaUnit === 'हेक्टर'){

            sum = sum + (doc.data().farmArea * Hector_Guntha )

        }
        else{

          sum = sum + doc.data().farmArea
          
        }


        }

  })

}).then(()=>{

    
   document.getElementById("TotalLandTitle").style.display = "flex"
  document.getElementById("Demotext").innerText = `${sum} ${Selected_Land_Unit}`
})


}



// Export Data 

function ExportData(params) {
  var csv = 'Reg Date,Crop Date,Sheti Owner,Sheti Contact,Crop Name,Crop Category,Faram Area,Land Type,District,Taluka,Village\n';

  //merge the data with CSV
  ExportDataList.forEach(function (row) {
    //console.log(row)
    csv += row.join(',');
    csv += "\n";
  });

  //display the created CSV data on the web browser 
  


  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';

  //provide the name for the CSV file to be downloaded
  hiddenElement.download = `Exported data.csv`;

  hiddenElement.click();
}

 
function OpenFilter(params) {
  
  $('#FilterModal').modal();
}





//-------------------------------------------------------------------------Sheti Opeartions----------------------------------------------------



// function shetiInfo(params) {

//     currentSheti = params
//     var shetiInfo = firestore.collection("Sheti").doc(params);
//     // document.getElementById("CropImg_other").style.display = ""
//     document.getElementById("CropName_other").style.display = ""
//     document.getElementById("CropCategory_other").style.display = ""
//     document.getElementById("ShowCropDate_other").style.display = ""
//     document.getElementById("FarmArea_other").style.display = ""
//     document.getElementById("Village_other").style.display =  ""
//     document.getElementById("Taluka_other").style.display =  ""
//     document.getElementById("District_other").style.display = ""
//     document.getElementById("Landtype_other").style.display = ""
//     document.getElementById("Unit_other").style.display = ""
//     document.getElementById("exampleFormControlLable_Edit_Sheti_Info").style.display = "none" 
//     document.getElementById("exampleFormControlFile1_Edit_Sheti_Info").style.display = "none" 

//     document.getElementById("E_CropName").style.display = "none" 
//     document.getElementById("E_CropCategory").style.display = "none"
//     document.getElementById("E_ShowCropDate").style.display = "none"
//     document.getElementById("E_FarmArea").style.display = "none"
//     document.getElementById("E_Village").style.display = "none"  
//     document.getElementById("E_Taluka").style.display = "none"
//     document.getElementById("E_District").style.display = "none"
//     document.getElementById("E_Landtype").style.display = "none"
//     document.getElementById("E_Unit").style.display = "none" 
   
//     shetiInfo.get().then((doc) => {
//         if (doc.exists) {
           
//             // var Date = doc.data().cropDate
          
//             // document.getElementById("modal-date").innerText = moment(doc.data().date.toDate()).format('LL');
//             document.getElementById("CropImg_other").src = doc.data().pikImage
//             document.getElementById("CropName_other").value = doc.data().crop
//             document.getElementById("CropCategory_other").value = doc.data().cropMainCat
//             document.getElementById("ShowCropDate_other").value =  doc.data().cropDateString
//             document.getElementById("FarmArea_other").value =  doc.data().farmArea 
//             document.getElementById("Village_other").value =  doc.data().village
//             document.getElementById("Taluka_other").value =  doc.data().tahsil
//             document.getElementById("District_other").value = doc.data().district
//             document.getElementById("Landtype_other").value = doc.data().landType
//             document.getElementById("Unit_other").value = doc.data().selectedFarmAreaUnit

//             userID = doc.data().userId;

           
            
//             $('#ShetiInfo_Modal').modal();
          
    
//         }
//     }).catch((error) => {
//         console.log("Error getting document:", error);
//     });

// }
function shetiInfo(params) {

  currentSheti = params
  var shetiInfo = firestore.collection("Sheti").doc(params);
  // document.getElementById("CropImg_other").style.display = ""
  document.getElementById("CropName_other").style.display = ""
  document.getElementById("CropCategory_other").style.display = ""
  document.getElementById("ShowCropDate_other").style.display = ""
  document.getElementById("FarmArea_other").style.display = ""
  document.getElementById("Village_other").style.display =  ""
  document.getElementById("Taluka_other").style.display =  ""
  document.getElementById("District_other").style.display = ""
  document.getElementById("Landtype_other").style.display = ""
  document.getElementById("Unit_other").style.display = ""
  document.getElementById("exampleFormControlLable_Edit_Sheti_Info").style.display = "none" 
  document.getElementById("exampleFormControlFile1_Edit_Sheti_Info").style.display = "none" 

  // document.getElementById("User_Peka").style.display = "none" 
  // document.getElementById("User_Peka_Sub_Pika").style.display = "none"
  // document.getElementById("Dist_Dist").style.display = "none" 
  // document.getElementById("Dist_Tal").style.display = "none" 
  // document.getElementById("Dist_vill").style.display = "none"  
  // document.getElementById("Vibhag_group").style.display = "none" 

  document.getElementById("E_CropName").style.display = "none" 
  document.getElementById("E_CropCategory").style.display = "none"
  document.getElementById("E_ShowCropDate").style.display = "none"
  document.getElementById("E_FarmArea").style.display = "none"
  document.getElementById("E_Village").style.display = "none"  
  document.getElementById("E_Taluka").style.display = "none"
  document.getElementById("E_District").style.display = "none"
  document.getElementById("E_Landtype").style.display = "none"
  document.getElementById("E_Unit").style.display = "none" 
 
  shetiInfo.get().then((doc) => {
      if (doc.exists) {
          console.log("Data",doc.data());
          // document.getElementById("modal-date").innerText = moment(doc.data().date.toDate()).format('LL');
          document.getElementById("CropImg_other").src = doc.data().pikImage
          document.getElementById("CropName_other").value = doc.data().crop
          document.getElementById("CropCategory_other").value = doc.data().cropMainCat
          document.getElementById("ShowCropDate_other").value = doc.data().cropDateString
          document.getElementById("FarmArea_other").value =  doc.data().farmArea 
          document.getElementById("Village_other").value =  doc.data().village
          document.getElementById("Taluka_other").value =  doc.data().tahsil
          document.getElementById("District_other").value = doc.data().district
          document.getElementById("Landtype_other").value = doc.data().landType
          document.getElementById("Unit_other").value = doc.data().selectedFarmAreaUnit

         
          
          $('#ShetiInfo_Modal').modal();
        
  
      }
  }).catch((error) => {
      console.log("Error getting document:", error);
  });

}

// function Edit_Sheti(params) {

// document.getElementById("CropName_other").style.display = "none"
// document.getElementById("CropCategory_other").style.display = "none"
// document.getElementById("ShowCropDate_other").style.display = "none"
// document.getElementById("FarmArea_other").style.display = "none"
// document.getElementById("Village_other").style.display =  "none"
// document.getElementById("Taluka_other").style.display =  "none"
// document.getElementById("District_other").style.display = "none"
// document.getElementById("Landtype_other").style.display = "none"

// document.getElementById("Update_Sheti_Button").style.display = ""
// document.getElementById("Unit_other").style.display = "none"
// document.getElementById("E_CropName").style.display = "" 
// document.getElementById("E_CropCategory").style.display = ""
// document.getElementById("E_ShowCropDate").style.display = ""
// document.getElementById("E_FarmArea").style.display = ""
// document.getElementById("E_Village").style.display = ""  
// document.getElementById("E_Taluka").style.display = ""
// document.getElementById("E_District").style.display = ""
// document.getElementById("E_Landtype").style.display = ""
// document.getElementById("E_Unit").style.display = "" 
// document.getElementById("exampleFormControlLable_Edit_Sheti_Info").style.display = "" 
// document.getElementById("exampleFormControlFile1_Edit_Sheti_Info").style.display = "" 

// document.getElementById("E_CropName").value =  document.getElementById("CropName_other").value
// document.getElementById("E_CropCategory").value = document.getElementById("CropCategory_other").value
// document.getElementById("AddCropDate_Edit").value = document.getElementById("ShowCropDate_other").value
// document.getElementById("E_FarmArea").value = document.getElementById("FarmArea_other").value
// document.getElementById("E_Village").value = document.getElementById("Village_other").value
// document.getElementById("E_Taluka").value =  document.getElementById("Taluka_other").value
// document.getElementById("E_District").value =  document.getElementById("District_other").value
// document.getElementById("E_Landtype").value = document.getElementById("Landtype_other").value
// document.getElementById("E_Unit").value =  document.getElementById("Unit_other").value



// }

// function Update_Sheti_Info(params) {
// var ImgUrl_Sub;

// var CropName = document.getElementById("E_CropName").value 
// var CropCategory = document.getElementById("E_CropCategory").value
// var CropDate = document.getElementById("AddCropDate_Edit").value
// var ShetiArea = document.getElementById("E_FarmArea").value  
// var ShetiVillage = document.getElementById("E_Village").value  
// var ShetiTaluka = document.getElementById("E_Taluka").value  
// var ShetiDistrict = document.getElementById("E_District").value  
// var ShetiType = document.getElementById("E_Landtype").value
// var ShetiUnit = document.getElementById("E_Unit").value 


// const ref = firebase.storage().ref();
// console.log("USER_ID",userID)
// const file = document.querySelector('#exampleFormControlFile1_Edit_Sheti_Info').files[0]
// if(file===undefined){
// //alert("Blank");

// firestore.collection('Sheti').doc(currentSheti).update({
//   crop:CropName,
//   cropDate: firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate).format("LL"))).toDate(),
//   cropMainCat:CropCategory,
//   landType:ShetiType,
//   farmArea:ShetiArea,
//   village:ShetiVillage,
//   tahsil:ShetiTaluka,
//   district:ShetiDistrict,
//   userId:userID,
//   selectedFarmAreaUnit:ShetiUnit,
//   date : firebase.firestore.Timestamp.fromDate(new Date()).toDate(),

// }).then(()=>{

//   //alert("ShetiUpdatedSucessfully");
//   document.getElementById("Update_Sheti_Button").style.display = "none"
//   // document.getElementById("AddCropName").value = "" 
//   // document.getElementById("AddCropCategory").value = ""
//   // document.getElementById("AddCropDate").value = ""
//   // document.getElementById("AddFarmArea").value = ""  
//   // document.getElementById("AddVillage").value = ""  
//   // document.getElementById("AddTaluka").value = ""  
//   // document.getElementById("AddDistrict").value = ""  
//   // document.getElementById("AddLandtype").value = ""
//   // document.getElementById("AddUnit").value = "" 
// })
// }
// else{
// //alert("File");
//   const name =  file.name;
//   const metadata = {
//   contentType: file.type
//   };
//   const task = ref.child('CommodityImages/' + name).put(file, metadata);
//   task
//   .then(snapshot => snapshot.ref.getDownloadURL())
//   .then((url) => {
//   console.log(url);
//   ImgUrl_Sub = url
// }).then(()=>{
//   firestore.collection('Sheti').doc(currentSheti).update({
//       crop:CropName,
//       cropDate: firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate).format("LL"))).toDate(),
//       cropMainCat:CropCategory,
//       landType:ShetiType,
//       farmArea:ShetiArea,
//       village:ShetiVillage,
//       tahsil:ShetiTaluka,
//       district:ShetiDistrict,
//       userId:userID,
//       pikImage:ImgUrl_Sub,
//       selectedFarmAreaUnit:ShetiUnit,
//       date : firebase.firestore.Timestamp.fromDate(new Date()).toDate(),

//   }).then(()=>{

//       //alert("ShetiUpdatedSucessfully");
//       // document.getElementById("AddCropName").value = "" 
//       // document.getElementById("AddCropCategory").value = ""
//       // document.getElementById("AddCropDate").value = ""
//       // document.getElementById("AddFarmArea").value = ""  
//       // document.getElementById("AddVillage").value = ""  
//       // document.getElementById("AddTaluka").value = ""  
//       // document.getElementById("AddDistrict").value = ""  
//       // document.getElementById("AddLandtype").value = ""
//       // document.getElementById("AddUnit").value = "" 
//   })
// })
// }



// }

function Edit_Sheti(params) {

  document.getElementById("CropName_other").style.display = "none"
  document.getElementById("CropCategory_other").style.display = "none" 
  document.getElementById("ShowCropDate_other").style.display = "none"
  document.getElementById("FarmArea_other").style.display = "none"
  document.getElementById("Village_other").style.display =  "none"
  document.getElementById("Taluka_other").style.display =  "none"
  document.getElementById("District_other").style.display = "none"
  document.getElementById("Landtype_other").style.display = "none"

  document.getElementById("Update_Sheti_Button").style.display = ""
  document.getElementById("Unit_other").style.display = "none"
  // document.getElementById("E_CropName").style.display = "" 
  // document.getElementById("E_CropCategory").style.display = ""
  document.getElementById("User_Peka").style.display = "" 
  document.getElementById("User_Peka_Sub_Pika").style.display = ""
  document.getElementById("Dist_Dist").style.display = "" 
  document.getElementById("Dist_Tal").style.display = "" 
  document.getElementById("Dist_vill").style.display = "" 
  document.getElementById("E_ShowCropDate").style.display = ""
  document.getElementById("E_FarmArea").style.display = ""
  document.getElementById("Dist_Vibhag").style.display = "" 
  // document.getElementById("E_Village").style.display = ""  
  // document.getElementById("E_Taluka").style.display = ""
  // document.getElementById("E_District").style.display = ""
  document.getElementById("Vibhag_group").style.display = "" 
  document.getElementById("E_Landtype").style.display = ""
  document.getElementById("E_Unit").style.display = "" 
  document.getElementById("exampleFormControlLable_Edit_Sheti_Info").style.display = "" 
  document.getElementById("exampleFormControlFile1_Edit_Sheti_Info").style.display = ""  

  document.getElementById("User_Peka_Sub_filter").innerHTML =  document.getElementById("CropName_other").value
  document.getElementById("User_Peka_filter").innerHTML = document.getElementById("CropCategory_other").value
  document.getElementById("AddCropDate_Edit").value = document.getElementById("ShowCropDate_other").value
  document.getElementById("E_FarmArea").value = document.getElementById("FarmArea_other").value
  document.getElementById("village").innerHTML = document.getElementById("Village_other").value
  document.getElementById("Tahasil").innerHTML =  document.getElementById("Taluka_other").value
  document.getElementById("District_Drop_Down").innerHTML =  document.getElementById("District_other").value
  document.getElementById("E_Landtype").value = document.getElementById("Landtype_other").value
  document.getElementById("E_Unit").value =  document.getElementById("Unit_other").value



 
    
}

function Update_Sheti_Info(params) {
  var ImgUrl_Sub;

  var CropName = document.getElementById("User_Peka_Sub_Pika").innerText 
 var CropCategory = document.getElementById("User_Peka_filter").innerText
 var CropDate = document.getElementById("AddCropDate_Edit").value
 var ShetiArea = document.getElementById("E_FarmArea").value  
 var ShetiVillage = document.getElementById("village").innerText  
 var ShetiTaluka = document.getElementById("Tahasil").innerText  
 var ShetiDistrict = document.getElementById("District_Drop_Down").innerText  
 var ShetiType = document.getElementById("E_Landtype_1").value
 var ShetiUnit = document.getElementById("E_Unit").value 

 console.log("Local Time",CropDate)

 
  const ref = firebase.storage().ref();
  
  const file = document.querySelector('#exampleFormControlFile1_Edit_Sheti_Info').files[0]
  if(file===undefined){
      // //alert("Blank");
     // moment(CropDate).format('DD/MM/YYYY')
      firestore.collection('Sheti').doc(currentSheti).update({
          crop:CropName,
          cropDate: firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate))),
          cropDateString: CropDate, 
          landType:ShetiType,
          farmArea:Number(ShetiArea),
          village:ShetiVillage,
          tahsil:ShetiTaluka,
          district:ShetiDistrict,
       
          selectedFarmAreaUnit:ShetiUnit,
          date : firebase.firestore.Timestamp.fromDate(new Date()).toDate()
      }).then(()=>{

          //alert("ShetiUpdatedSucessfully");
          document.getElementById("Update_Sheti_Button").style.display = "none"
          // document.getElementById("AddCropName").value = "" 
          // document.getElementById("AddCropCategory").value = ""
          // document.getElementById("AddCropDate").value = ""
          // document.getElementById("AddFarmArea").value = ""  
          // document.getElementById("AddVillage").value = ""  
          // document.getElementById("AddTaluka").value = ""  
          // document.getElementById("AddDistrict").value = ""  
          // document.getElementById("AddLandtype").value = ""
          // document.getElementById("AddUnit").value = "" 
      })
  }
  else{
      //alert("File");
          const name =  file.name;
          const metadata = {
          contentType: file.type
          };
          const task = ref.child('CommodityImages/' + name).put(file, metadata);
          task
          .then(snapshot => snapshot.ref.getDownloadURL())
          .then((url) => {
          console.log(url);
          ImgUrl_Sub = url
      }).then(()=>{
          firestore.collection('Sheti').doc(currentSheti).update({
              crop:CropName.trim(),
              cropDate: firebase.firestore.Timestamp.fromDate(new Date(moment(CropDate).format('DD/MM/YYYY'))),
              cropDateString: CropDate, 
              cropMainCat:CropCategory.trim(),
              landType:ShetiType.trim(),
              farmArea:ShetiArea,
              village:ShetiVillage.trim(),
              tahsil:ShetiTaluka.trim(),
              district:ShetiDistrict.trim(),
              pikImage:ImgUrl_Sub,
              selectedFarmAreaUnit:ShetiUnit,
              date : firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
  
          }).then(()=>{
  
              //alert("ShetiUpdatedSucessfully");
              // document.getElementById("AddCropName").value = "" 
              // document.getElementById("AddCropCategory").value = ""
              // document.getElementById("AddCropDate").value = ""
              // document.getElementById("AddFarmArea").value = ""  
              // document.getElementById("AddVillage").value = ""  
              // document.getElementById("AddTaluka").value = ""  
              // document.getElementById("AddDistrict").value = ""  
              // document.getElementById("AddLandtype").value = ""
              // document.getElementById("AddUnit").value = "" 
          })
      })
  }


  
}

$(function () {
// $('#datepicker').datepicker();
$('#E_ShowCropDate_id').datepicker(); 
$('#E_ShowCropDate').datepicker(); 
$('#datepicker_from').datepicker({  format: 'dd/mm/yyyy'})
$('#datepicker_to').datepicker({  format: 'dd/mm/yyyy'})
});



function ResetFilter(params) {
  document.querySelector('#ResetFilterInModal').style.display = "none"

  document.getElementById("WithoutFilter").style.display = "";
  document.getElementById("WithFilter").style.display = "none";
  
  
  
  $('#dropdown_coins').text('विभाग')
  $('#District_Drop_Down').text('जिल्हा')
  $('#Tahasil').text('तालुका')
  $('#village').text('गाव')
  $('#User_Peka_filter').text('पीक Category');
  $('#User_Peka_Sub_filter').text('पीक');
  $('#TotalLandFilter').text('TotalLandFilter'); 

  document.getElementById("District_Drop_Down").disabled = true;
  document.getElementById("Tahasil").disabled = true;
  document.getElementById("District_Drop_Down").disabled = true;
  document.getElementById("village").disabled = true;
  document.getElementById("User_Peka_Sub_filter").disabled = true;
  
  document.getElementById("previous").disabled = false;
  document.getElementById("next").disabled = false;
  
  document.getElementById("datepicker_from").value = "";
  document.getElementById("datepicker_to").value = "";
  CropSelected = undefined
  MainCategorySelected = undefined;
  DistrictFilterSelected = undefined;
  TalukaFilterSelected = undefined;
  VillageFilterSlected = undefined;

  Selected_Category = "";
  Selected_Crop = "";
  Selected_Land_Unit = "";
  Selected_Category = "";
  Selected_Crop = ""
  
  lastUser = "";
  data = [];
  index = 0;
  UserList = [];
  index1= 0;
  paginationindex = 0;
  CurrentPage = 0;

//   first = firestore.collection("Sheti").orderBy("date","desc").get().then((querySnapshot) => {

//     querySnapshot.forEach((doc) => {

//    firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

//     querySnapshot.forEach((userdoc) => {

//       ExportDataList[exportIndex++] = [userdoc.data().userName.replace(/[\.\,\n\r]/g,' '),userdoc.data().userContact,doc.data().cropDateString,doc.data().crop,doc.data().cropMainCat,doc.data().farmArea,doc.data().selectedFarmAreaUnit,doc.data().landType,doc.data().district,doc.data().tahsil,doc.data().village]
//     })
//   })
// })

// }).then(()=>{

//     console.log("ExportDataList",ExportDataList)
// })


//   firestore.collection("Sheti").orderBy("date","desc").limit(10).get().then((querySnapshot) => {

//     lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
//     querySnapshot.forEach((doc) => { 
//       firestore.collection("Userinfo").where("userID","==",doc.data().userId).get().then((querySnapshot) => {

//         querySnapshot.forEach((userdoc) => {
//           data[index++] = [`${doc.id}`,`${doc.data().cropDateString}`,`${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${userdoc.data().userContact}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]
  
//           // doc.data() is never undefined for query doc snapshots
//           $("#tbody").append(`<tr>
//           <th  id=${doc.id} onclick ="shetiInfo(this.id)" style="cursor: pointer;"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
//           <th><a id ="${doc.id}" >${userdoc.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
//           <th><a id ="${doc.id}" >${userdoc.data().userContact}</a> </th>
//           <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
//           <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
//           <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
//           <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
//           <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
//           <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
//           <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
//       </tr>`);
    
//           document.getElementById("ShetiListTable").style.display = "";
//           document.getElementById("NoProduct").style.display = "none";
    
//         })
//       })


//     })
   
  
//   //   querySnapshot.forEach((doc) => {
   
//   //     data[index++] = [`${doc.id}`,`${doc.data().cropDateString}`,`${doc.data().crop}`,`${doc.data().cropMainCat}`,`${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}`,`${doc.data().landType}`,`${doc.data().district}`,`${doc.data().tahsil}`,`${doc.data().village}`]

//   //     // doc.data() is never undefined for query doc snapshots
//   //     $("#tbody").append(`<tr>
//   //     <th  id=${doc.id} onclick ="shetiInfo(this.id)"><a id ="${doc.id}" >${doc.data().cropDateString}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().cropMainCat}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().farmArea} ${doc.data().selectedFarmAreaUnit}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().landType}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().district}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().tahsil}</a> </th>
//   //     <th><a id ="${doc.id}" >${doc.data().village}</a> </th>
//   // </tr>`);

//   //     document.getElementById("ShetiListTable").style.display = "";
//   //     document.getElementById("NoProduct").style.display = "none";

//   //  });
   
// }).then(()=>{
//   UserList[index1++] = data;
//   paginationindex++;
//   CurrentPage++;
//   console.log("Current Page ",CurrentPage,"paginationindex",paginationindex)
//   console.log("Data Puted Sucessfully",UserList);
// })

getUserlist();
  
  
}











//-------------------------------------------------------------------------Sheti Opeartions----------------------------------------------------


// CropCategory_list_o = [];
// CropCategory_list_index_o = 0;

// let search_Main_Category_o = document.getElementById("searchCoin4")

// //Find every item inside the dropdown
// let Main_Category_items_o = document.getElementById("menuItems-MainCatgory");

// function buildDropDown_Main_cat_o(values) {
//     let contents = []
//     for (let MainCategory of values) {
//     contents.push(`<input type="button" id="dropdown-item-MainCategory_o" class="dropdown-item"  type="button" value="${MainCategory}" onclick="Get_Pika_Sub_Category_o(this.value,'Main_Cat')" />`)
//     }
//     $('#menuItems-MainCatgory_o').append(contents.join(""))

//     //Hide the row that shows no items were found
//     $('#empty').hide()
// }



// //Capture the event when user types into the search box
// search_Main_Category_o.addEventListener('input', function () {
  
//   filter_Main_Cat(search_Main_Category_o.value.trim().toLowerCase())
// })

// //For every word entered by the user, check if the symbol starts with that word
// //If it does show the symbol, else hide it
// function filter_Main_Cat(word) {
//     let length = Main_Category_items_o.children.length
//     let collection = []
//     let hidden = 0
//     for (let i = 0; i < length; i++) {
//     if (Main_Category_items_o.children[i].value.toLowerCase().startsWith(word)) {
//         $(Main_Category_items_o.children[i]).show()
//     }
//     else {
//         $(Main_Category_items_o.children[i]).hide()
//         hidden++
//     }
//     }

//     //If all items are hidden, show the empty view
//     if (hidden === length) {
//     $('#empty').show()
//     }
//     else {
//     $('#empty').hide()
//     }
// }

// //If the user clicks on any item, set the title of the button as the text of the item
//   $('#menuItems-MainCatgory_0').on('click', '.dropdown-item', function(){
//     document.querySelector('#ResetFilterInModal').style.display = ""


//       $('#User_Peka_filter_o').text($(this)[0].value)
//       $("#User_Peka_filter_o").dropdown('toggle');

//     })


//     function Get_Pika_Sub_Category_o(params,flag) {

//       Get_UserDoc_For_Main_cat = [];
//       Get_UserDoc_For_Main_cat_index = 0 ; 
//       Filtered_User_Data = [] ;
//       Filtered_User_Data_index = 0;
    
    
//       UserList = [];
//       Special_Index = 0;
    
//     console.log("Pagination_Filter_Flag",WhichFilterSelected===undefined)
    
    

//         Selected_Main_Category_Title = params
//         getpika_(params);
    
//         where(`${WhichFilterSelected}`,"==",Selected_District)
//         where("cropMainCat","==",params)
//         if(WhichFilterSelected!==undefined){
    
//           firestore.collection("Sheti").where(WhichFilterSelected,"==",Selected_District).where("cropMainCat","==",params).orderBy("userId").limit(10).get().then((querySnapshot) => {
//             lastUser_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
//           querySnapshot.forEach((doc) => {
//               // doc.data() is never undefined for query doc snapshots
//               console.log("UserData",doc.data());
//               Get_UserDoc_For_Main_cat[Get_UserDoc_For_Main_cat_index++] = [doc.data().userId,doc.data().cropMainCat,doc.data().crop]
           
//           })
//       }).then(()=>{
      
//         // ForProcessing = [...new Set(Get_UserDoc_For_Main_cat)]
      
//         Get_UserDoc_For_Main_cat.forEach(element => {
      
//           console.log("element",element[0])
          
//           firestore.collection("Userinfo").where("userID","==",element[0]).get().then((querySnapshot) => {
       
//             querySnapshot.forEach((doc) => {
//                 // doc.data() is never undefined for query doc snapshots
      
//                 Filtered_User_Data[Filtered_User_Data_index++] = [`${doc.id}`,`${doc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,element[0],element[1],element[2]]
      
//             })
//           })
//         });
      
//       }).then(()=>{
      
//                 console.log("Vivek Dhande :   ",Filtered_User_Data)
//                 UserList[Special_Index++] = Filtered_User_Data;
//                 Filtered_User_Data.forEach(element => {
//                   console.log("Filtered_Data",element)
//                 });
//       })
          
//         }
//         else{
//           firestore.collection("Sheti").where("cropMainCat","==",params).orderBy("userId").limit(10).get().then((querySnapshot) => {
//             lastUser_Main_Cat = querySnapshot.docs[querySnapshot.docs.length-1];
//           querySnapshot.forEach((doc) => {
//               // doc.data() is never undefined for query doc snapshots
      
//               Get_UserDoc_For_Main_cat[Get_UserDoc_For_Main_cat_index++] = [doc.data().userId,doc.data().cropMainCat,doc.data().crop]
           
//           })
//       }).then(()=>{
      
//         // ForProcessing = [...new Set(Get_UserDoc_For_Main_cat)]
      
//         Get_UserDoc_For_Main_cat.forEach(element => {
      
//           console.log("element",element[0])
          
//           firestore.collection("Userinfo").where("userID","==",element[0]).get().then((querySnapshot) => {
       
//             querySnapshot.forEach((doc) => {
//                 // doc.data() is never undefined for query doc snapshots
      
//                 Filtered_User_Data[Filtered_User_Data_index++] = [`${doc.id}`,`${doc.data().userName.replace(/[\.\,\n\r]/g,' ')}`,`${doc.data().village}`,`${doc.data().tahsil}`,`${doc.data().district}`,`${doc.data().userContact}`,element[0],element[1],element[2]]
      
//             })
//           })
//         });
      
//       }).then(()=>{
      
//                 console.log("Vivek Dhande :   ",Filtered_User_Data)
//                 UserList[Special_Index++] = Filtered_User_Data;
//                 Filtered_User_Data.forEach(element => {
//                   console.log("Filtered_Data",element)
//                 });
//       })
    
//       }
    
//     }


//     function Get_Main_Category_o() {



//       var docRef = firestore.collection("ShetiPik").get().then((querySnapshot) => {
//           querySnapshot.forEach((doc) => {
//               // doc.data() is never undefined for query doc snapshots
  
//               CropCategory_list[CropCategory_list_index++] = doc.data().mainCatName;
  
//           });
//         }).then(()=>{
  
//           console.log("Village Karyalay",Village_List)
//           buildDropDown_Main_cat_0(CropCategory_list);
//         }).catch((error) => {
//             console.log("Error getting document:", error);
//         });
  
//   }
  
//     Get_Main_Category_o();



 //  ------------------------------------------------------RAW DATA ----------------------------------------------------------------------------                                                                     

// function shetiInfo(params) {
//   console.log("Insheti modal",params)
//   // var docRef = firestore.collection("Userinfo").doc(userdoc);
//       var shetiInfo = firestore.collection("Sheti").doc(params);
     
//       shetiInfo.get().then((doc) => {
//           if (doc.exists) {
//               console.log("Data",doc.data());
//               // document.getElementById("modal-date").innerText = moment(doc.data().date.toDate()).format('LL');
//               document.getElementById("shetiugName").value =  doc.data().crop
//               document.getElementById("shetiDate").value = doc.data().cropDate
//               document.getElementById("shetiArea").value = doc.data().farmArea
//               document.getElementById("shetiLandTaluka").value = doc.data().landTaluka
//               document.getElementById("shetiType").value = doc.data().landType
//               $('#ShetiInfo_Modal').modal();
            
      
//           }
//       }).catch((error) => {
//           console.log("Error getting document:", error);
//       });
  
//   }


// const myDiv = document.querySelector('#onlyTable')  

// myDiv.addEventListener('scroll', () => {  
//   var searchboxtext = document.getElementById("MySearch");


//       if(searchboxtext.value==""){
//           if (myDiv.offsetHeight + myDiv.scrollTop + 1>= myDiv.scrollHeight) {  
        
//             console.log('scrolled to bottom');  
//             myDiv.scrollTop = myDiv.scrollTop - 50
//             var no = getMoreUserlist(lastUser);
          
//           }  
//       }
      
// })



// function showprofile(params) {

//   localStorage.setItem('userDocId', params);
//   console.log("UserdocID",localStorage.getItem('userDocId'));


//   window.location.href = "/userProfile.html";

// // var docRef = firestore.collection("Userinfo").doc(params);

// // docRef.get().then((doc) => {
// //     if (doc.exists) {
// //       if(doc.data().userProfilePic!==""){
// //         console.log("doc_id",doc.data());
// //           document.getElementById("profilepic").src = doc.data().userProfilePic;
// //           $('#exampleModal').modal('show')
// //       }
// //       else{
// //         var PriflePic;
                 
// //         var english = /^[A-Za-z0-9]*$/;
// //         var check = doc.data().userName.replace(/[\.\,\n\r]/g,' ')
           
// //             if( english.test(check.charAt(0)) == true){
// //                 var UserName.replace(/[\.\,\n\r]/g,' ')_Copy = (doc.data().userName.replace(/[\.\,\n\r]/g,' ').match(/[a-zA-Z]/) || []).pop().toLowerCase();
// //                 switch (UserName.replace(/[\.\,\n\r]/g,' ')_Copy.charAt(0).toLowerCase()) {

// //                     case 'a':
// //                         PriflePic= "/img/a.svg";
// //                         break;
                        
// //                     case 'b':
// //                         PriflePic= "/img/b.svg";
// //                         break;
                    
// //                     case 'c':
// //                         PriflePic= "/img/c.svg";
// //                         break;
                        
// //                     case 'd':
// //                         PriflePic= "/img/d.svg";
// //                         break;
                        
// //                     case 'e':
// //                         PriflePic= "/img/e.svg";
// //                         break;
                        
// //                     case 'f':
// //                         PriflePic= "/img/f.svg";
// //                         break;
                        
// //                     case 'g':
// //                         PriflePic= "/img/g.svg";
// //                         break;
                        
// //                     case 'h':
// //                         PriflePic= "/img/h.svg";
// //                         break;
                        
// //                     case 'i':
// //                         PriflePic= "/img/i.svg";
// //                         break;
                        
// //                     case 'j':
// //                         PriflePic= "/img/j.svg";
// //                         break;
                        
// //                     case 'k':
// //                         PriflePic= "/img/k.svg";
// //                         break;
                        
// //                     case 'l':
// //                         PriflePic= "/img/l.svg";
// //                         break;
                        
// //                     case 'm':
// //                         PriflePic= "/img/m.svg";
// //                         break;
                        
// //                     case 'n':
// //                         PriflePic= "/img/n.svg";
// //                         break;
                        
// //                     case 'o':
// //                         PriflePic= "/img/o.svg";
// //                         break;
                        
// //                     case 'p':
// //                         PriflePic= "/img/p.svg";
// //                         break;
                        
// //                     case 'q':
// //                         PriflePic= "/img/q.svg";
// //                         break;
                        
// //                     case 'r':
// //                         PriflePic= "/img/r.svg";
// //                         break;
                        
// //                     case 's':
// //                         PriflePic= "/img/s.svg";
// //                         break;
                        
// //                     case 't':
// //                         PriflePic= "/img/t.svg";
// //                         break;
                        
// //                     case 'u':
// //                         PriflePic= "/img/u.svg";
// //                         break;
                        
// //                     case 'v':
// //                         PriflePic= "/img/v.svg";
// //                         break;
                    
// //                     case 'w':
// //                         PriflePic= "/img/w.svg";
// //                         break;
                        
// //                     case 'x':
// //                         PriflePic= "/img/x.svg";
// //                         break;
                    
// //                     case 'y':
// //                         PriflePic= "/img/y.svg";
// //                         break;
                    
// //                     case 'z':
// //                         PriflePic= "/img/z.svg";
// //                         break;
                
// //             }
// //             }
// //             else{
// //                 PriflePic= "/img/person.svg";
// //             }  
// //             document.getElementById("profilepic").src = PriflePic;
// //             $('#exampleModal').modal('show')
// //       }
    
// //     } else {
// //         // doc.data() will be undefined in this case
// //         console.log("No such document!");
// //     }
// // }).catch((error) => {
// //     console.log("Error getting document:", error);
// // });

  
  
// }






// function getMoreUserlist(params) {
//   firestore.collection("Sheti").startAfter(params).limit(10).get().then((querySnapshot) => {
//     if( querySnapshot.docs.length == 0 ){
//       (swal("There is no Record Found"))
//       return 0;
//     }
//     else{
    
//     }
 
//     lastUser = querySnapshot.docs[querySnapshot.docs.length-1];
//     querySnapshot.forEach((doc) => {
//       console.log(doc.data().crop);
//       // doc.data() is never undefined for query doc snapshots
//       $("#tbody").append(`<tr>
//       <th><a id ="${doc.id}" >${doc.data().crop}</a> </th>
   
//   </tr>`);
//    });

           
   
// })
  
// }





// function searchUser(params) {



//   var USERLISTCHILD = document.getElementById("tbody");
//   var searchboxtext = document.getElementById('MySearch').value
//   //console.log(searchboxtext);
//   if(searchboxtext!==""){
//      while( USERLISTCHILD.childElementCount !== 0){
//       USERLISTCHILD.firstChild.remove();
//      }
//     //  document.getElementById("load").style.display = "none"
      
//   }else{
//     getUserlist();
//       while( USERLISTCHILD.childElementCount !== 0){
//           USERLISTCHILD.firstChild.remove();
//          }
         
//       // document.getElementById("load").style.display = ""
//   }

  

//   firestore.collection("Userinfo").where("keywords", "array-contains", params).orderBy("date").get().then(function(querySnapshot){
//       var index = 0;
//        querySnapshot.forEach((SearchUser)=>{
         
//           // searchData[index++]= [e.id,e.data().date.toDate(),e.data().userName.replace(/[\.\,\n\r]/g,' '),e.data().userProfilePic]  

//           $("#tbody").append(`<tr>
//           <th id=${SearchUser.id} onclick ="shetiInfo(this.id)"><a id ="${SearchUser.id}" onclick="showprofile(this.id)">${SearchUser.data().userName.replace(/[\.\,\n\r]/g,' ')}</a> </th>
//           <th>${SearchUser.data().village}</th>
//           <th>${SearchUser.data().tahsil}</th>
//           <th>${SearchUser.data().district}</th>
//           <th>${SearchUser.data().userContact}</th>
    
//       </tr>`);
//        })
//       // creatTable(searchData[0])
//    })

 
// }
