var check;
firebase.auth().onAuthStateChanged(function(e){if(e){console.log("User Login"); 
var o,t=document.getElementsByClassName("hideLink");

logEmail=e.email,
    firestore.collection("Editer").where("email","==",e.email).get().then(n=>{n.forEach(e=>{
    if(check=e.id,"admin"==e.data().role)
        for(o=0;o<t.length;o++)t[o].classList.remove("d-none")

}),null==check&&(console.log("in delete function")
                   ,e.delete().then(function(){
    console.log(" User deleted. successful")}).catch(function(e){
    console.log(e),signOut()}))
        })
}
 else window.location.href="login.html"});

var developerInfo={Name:"Lalit Jagdish Vispute", Contact:"8329040477",Visit:"https://m.facebook.com/lalitsoftcreation" };function signOut(){firebase.auth().signOut(),setTimeout(function(){window.location.href="login.html"},2e3)}