var firestore = firebase.firestore(),
    table = document.getElementById("recordTable"),
    tbody = document.getElementById("tableBody"),
    loadBtn = document.getElementById("load"),
    loadingBtn = document.getElementById("loading"),
    searchKey = document.getElementById("searchKey"),
    spinner = document.getElementById("spinner"),
    dataContainer = [],
    getType = "get",
    first = firestore.collection("Groups").orderBy("date").limit(10);

function getSearchResult(e) {
   // alert("In GetSearchResult"); 
   
    "load" == e ? (loadBtn.classList.add("d-none"), loadingBtn.classList.remove("d-none")) : (loadBtn.classList.add("d-none"), loadingBtn.classList.add("d-none")), first.get().then(function(e) {
        var t = e.docs[e.docs.length - 1];
        console.log(t);
        0 == e.docs.length ? (swal("There is no Record Found"), document.getElementById("spinner").classList.add("d-none"), loadBtn.classList.add("d-none"), loadingBtn.classList.add("d-none")) : (spinner.classList.add("d-none"), table.classList.remove("d-none"), first = "get" == getType ? firestore.collection("Groups").orderBy("date").startAfter(t).limit(10) : firestore.collection("Groups").where("keyword", "array-contains", searchKey.value).orderBy("date").startAfter(t).limit(10), e.forEach(function(e) {
            dataContainer[e.id] = e.data(), setDate(e.id, e.data().date.toDate(), e.data().groupName, e.data().count)
        }), loadBtn.classList.remove("d-none"), loadingBtn.classList.add("d-none"))
       
    })
    
}

function getSearch() {
    "" == searchKey.value ? swal("Please Enter Group Name") : (spinner.classList.remove("d-none"), table.classList.add("d-none"), first = firestore.collection("Groups").where("keyword", "array-contains", searchKey.value).orderBy("date").limit(10), removeChild(), getType = "filter", loadBtn.classList.remove("d-none"), loadingBtn.classList.add("d-none"), getSearchResult())
}

function setDate(e, t, n, a) {
    //alert("Set Date");
    
    var o, d;
    d = t.getFullYear(), o = ("0" + (t.getMonth() + 1)).slice(-2), creatTable([e, ("0" + t.getDate()).slice(-2) + "/" + o + "/" + d, n, a])

}

function creatTable(e) {
  //  alert("Create Table");
    var t = document.createElement("TR");
    tbody.appendChild(t);
    for (var n = 0; n < 5; n++) {
        var a = document.createElement("TD");
        if (t.appendChild(a), 3 == n) {
            var o = document.createElement("BUTTON");
            o.classList.add("btn", "btn-info"), o.innerHTML = "<i class='fa fa-pencil'></i>", o.setAttribute("id", "e" + e[0]), o.setAttribute("onclick", "groupEdit(this.id,this)"), o.setAttribute("data-toggle", "modal"), o.setAttribute("data-target", "#viewInfo"), a.appendChild(o)
        } else if (4 == n) {
            var d = document.createElement("Button");
            d.classList.add("btn", "btn-danger"), d.setAttribute("id", e[0]), d.setAttribute("onclick", "deleteGroup(this,this.id)");
            var r = document.createElement("I");
            r.classList.add("fa", "fa-trash"), d.appendChild(r), a.appendChild(d)
        } else a.innerText = e[n + 1]
    }
}

function groupEdit(e, t) {
    var n = e.slice(-20),
        a = t.parentNode.parentNode.rowIndex;
    document.getElementById("ugname").value = dataContainer[n].groupName, document.getElementById("uglink").value = dataContainer[n].groupLink, document.getElementById("ugmem").value = dataContainer[n].count, document.getElementById("updateId").value = n, document.getElementById("ri").value = a
}

function deleteGroup(e, t) {
    swal({
        title: "Are you sure?",
        text: "Once Deleted, You Will Not Be Able To Recover This Group Record!",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        n && firestore.collection("Groups").doc(t).delete().then(function() {
            var t = e.parentNode.parentNode.rowIndex;
            table.deleteRow(t)
        }).then(function() {
            swal("Successfull", "Group Deleted Successfully From Record", "success")
        }).catch(function(e) {
            console.error("Error removing document: ", e)
        })
    })
}

function verifyData() {
    var e = document.getElementById("ugmem").value;
    "" == e ? swal("Group Member Can Not Be Blank") : isNaN(e) ? swal("Group Member Must Be In Digit") : parseInt(e) > 512 || parseInt(e) < 0 ? swal("Enter Valid Member No.") : parseInt(e) < 512 ? updateData(parseInt(e), !0) : updateData(parseInt(e), !1)
}

function updateData(e, t) {
    var n = document.getElementById("updateId").value,
        a = parseInt(document.getElementById("ri").value);
    firestore.collection("Groups").doc(n).update({
        count: e,
        allow: t
    }).then(function() {
        $("#viewInfo").modal("hide"), dataContainer[n].count = e, dataContainer[n].allow = t, table.rows[a].cells[2].innerText = e, swal("Successfull!", "Group Member Updated Successfully", "success")
    }).catch(function(e) {
        console.log("Error:" + e)
    })
}

function removeChild() {
    for (var e = document.getElementById("tableBody"); e.firstChild;) e.removeChild(e.firstChild);
    rc = 1
}

getSearchResult();