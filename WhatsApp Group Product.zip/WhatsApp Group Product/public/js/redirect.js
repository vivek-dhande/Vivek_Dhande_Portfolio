var firestore = firebase.firestore();
function getGroupLink() {
    
    var keys = Object.keys(localStorage);
 
    firestore.collection("Groups").where("allow", "==", !0).orderBy("date").limit(1).get().then(function(e) {
        e.forEach(function(e) {
            500 == e.data().count && sendTeligramMsg(e.data()), console.log(e.data().groupLink)// updateCount(e.id, e.data().count, e.data().groupLink)
            
            if(!keys.find((a)=> a === "appdroid")){
                localStorage.setItem("appdroid", e.data().groupLink);
                updateCount(e.id, e.data().count, e.data().groupLink)
            }
            else if(keys.find((a)=> a === "appdroid")){
                const link = localStorage.getItem("appdroid")
                window.open(link, "_self")
            }
        
        })
        
    })
    
}

function updateCount(e, o, t) {
    
    var n;
    n = o + 1 != 512, firestore.collection("Groups").doc(e).update({
        count: o + 1,
        allow: n
    }).then(function() {
        window.open(t, "_self")
    })
}

function sendTeligramMsg(e) {
    var o = "https://api.telegram.org/bot1855829665:AAHMd6RxbJFSIwnR6oVAa2XeaLwYgoF6ZOY/sendMessage?chat_id=@missionmpscwgm&text=" + ("Group Name : " + e.groupName + "%0AGroup Members : " + (e.count + 1) + "%0AAdmin Panel : http://whatsapp.missionmpsc.org/login.html");
    const t = new XMLHttpRequest;
    t.open("GET", o), t.send(), t.onload = (() => {
        200 === t.status ? console.log("Message Send") : console.log("Message not send")
    })
}
getGroupLink();