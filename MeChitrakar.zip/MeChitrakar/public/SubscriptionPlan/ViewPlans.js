firestore = firebase.firestore();
GetSubscriptions();
function GetSubscriptions(params) {
    firestore.collection("SubsciptionPlans").orderBy("date","desc").get().then((querySnapshot) => {

        querySnapshot.forEach((doc) => {
            console.log("User Data",doc.data())
            // document.getElementById(`${doc.id}`).checked = doc.data().status
            // doc.data() is never undefined for query doc snapshots
            $("#UsersTableBody").append(`<tr id="${doc.id}-col">
            <td>${doc.data().category}</td>
            <td>${doc.data().plan}</td>            
            <td>${doc.data().validity}</td>
            <td>${doc.data().price}</td>
            <td>${doc.data().discountedPrice}</td> 
            <td>${doc.data().jpgCount}</td> 
            <td>${doc.data().psdCount}</td> 
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="OpenSubScriptionModal(this.id)" >Edit</button>
                <button type="button" class="btn rounded-pill btn-danger" id="${doc.id}" onclick="Deleteplan(this.id)">Delete</button>
                </div>
            </td>
          </tr>`)
    
        });
    }).then(()=>{

        document.getElementById("SubadminBody").style.display = "flex" 
        document.getElementById("SubAdminBodyAnimation").style.display = "none"
    })
}

function OpenSubScriptionModal(params) {
    
    var docRef = firestore.collection("SubsciptionPlans").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {
            document.getElementById("categoryId").value = doc.data().category
            document.getElementById("Plan").value = doc.data().plan
            document.getElementById("PlanValidity").value = doc.data().validity
            document.getElementById("Price").value = doc.data().price
            document.getElementById("DPrice").value = doc.data().discountedPrice
            document.getElementById("JPGCount").value = doc.data().jpgCount
            document.getElementById("PSDCount").value = doc.data().psdCount
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
}

function SaveSubscriptionPlan(params) {
    var PTitle = document.getElementById("categoryId").value;
    var Plan = document.getElementById("Plan").value;
    var PValidity = document.getElementById("PlanValidity").value;
    var Price = document.getElementById("Price").value;
    var DPrice = document.getElementById("DPrice").value;
    var JPGCount = document.getElementById("JPGCount").value;
    var PSDCount = document.getElementById("PSDCount").value;
    
    // Add a new document with a generated id.
    
        if(PTitle !=="Select Category" && Plan!=="" && PValidity!=="" && Price!=="" && DPrice!=="" && JPGCount!=="" && PSDCount!=="" ){
    
                if(Number(DPrice) <= Number(Price)){
                    document.getElementById("PlanTitlevalidation").style.display = "none";
                    document.getElementById("Planvalidation").style.display = "none";
                    document.getElementById("PlanValvalidation").style.display = "none";
                    document.getElementById("Pricevalidation").style.display = "none";
                    document.getElementById("DPricevalidation").style.display = "none";
                    document.getElementById("jcountvalidation").style.display = "none";
                    document.getElementById("PSDvalidation").style.display = "none";
    
                    firestore.collection("SubsciptionPlans").add({
                        date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                        plan: Plan,
                        category:PTitle,
                        validity: Number(PValidity),
                        price: Number(Price),
                        discountedPrice:Number(DPrice),
                        jpgCount: Number(JPGCount),
                        jpgTxt: `${JPGCount} JPEG Files`,
                        psdCount: Number(PSDCount) ,
                        psdTxt: `${PSDCount} PSD Files`
                    })
                    .then((docRef) => {
                
                        swal("Subscrption Plan Added")
                        var myModalEl = document.getElementById("EditSubAdmin");
                        var modal = bootstrap.Modal.getInstance(myModalEl)
                        modal.hide();

                        location.reload();
                        
                    })
                    .catch((error) => {
                    });
                }else{
                    if(Number(DPrice) >= Number(Price)){
                        console.log("Invalid",Price,DPrice)
                         document.getElementById("DPricevalidation").style.display = ""
                    }else{
                         console.log("Valid",Price,DPrice)
                         document.getElementById("DPricevalidation").style.display = "none"
                    }
               
                }
    
        }else{
            if(PTitle == ""){
                document.getElementById("PlanTitlevalidation").style.display = "";
            }else{
                document.getElementById("PlanTitlevalidation").style.display = "none";
    
            }
    
            if(Plan == ""){
                document.getElementById("Planvalidation").style.display = "";
            }else{
                document.getElementById("Planvalidation").style.display = "none";
    
            }
    
            if(PValidity == ""){
                document.getElementById("PlanValvalidation").style.display = "";
            }else{
                document.getElementById("PlanValvalidation").style.display = "none";
    
            }
    
            if(Price == ""){
                document.getElementById("Pricevalidation").style.display = "";
            }else{
                document.getElementById("Pricevalidation").style.display = "none";
    
            }
    
            if(DPrice == ""){
                document.getElementById("DPricevalidation").style.display = "";
            }else{
                document.getElementById("DPricevalidation").style.display = "none";
    
            }
    
            if(JPGCount == ""){
                document.getElementById("jcountvalidation").style.display = "";
            }else{
                document.getElementById("jcountvalidation").style.display = "none";
    
            }
    
            if(PSDCount == ""){
                document.getElementById("PSDvalidation").style.display = "";
            }else{
                document.getElementById("PSDvalidation").style.display = "none";
    
            }
        }
    
    }


   function Deleteplan(id) {
    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Post",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        

        n && firestore.collection("SubsciptionPlans").doc(id).delete()

            .then(function () {
                let subsWrapper = document.getElementById(`${id}-col`)
                subsWrapper.remove();
                swal("Successfull", "Plan Deleted ", "success")
                // location.reload();
            }).catch(function (e) {
                console.error("Error removing document: ", e)
            })

    })
   } 