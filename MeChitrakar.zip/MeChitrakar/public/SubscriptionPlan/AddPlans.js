firestore = firebase.firestore();

var CategoryInput = document.getElementById('categoryId')
var category;

CategoryInput.addEventListener("change",function(params) {
    category = params.target.value
})

function SaveSubscriptionPlan(params) {
var PTitle = document.getElementById("categoryId").value;
var Plan = document.getElementById("Plan").value;
var PValidity = document.getElementById("PlanValidity").value;
var Price = document.getElementById("Price").value;
var DPrice = document.getElementById("DPrice").value;
var JPGCount = document.getElementById("JPGCount").value;
var PSDCount = document.getElementById("PSDCount").value;

// Add a new document with a generated id.

    if(PTitle !=="Select Category" && Plan!=="" && PValidity!=="" && Price!=="" && DPrice!=="" && JPGCount!=="" && PSDCount!=="" ){

            if(Number(DPrice) <= Number(Price)){
                alert("Valid")
                document.getElementById("PlanTitlevalidation").style.display = "none";
                document.getElementById("Planvalidation").style.display = "none";
                document.getElementById("PlanValvalidation").style.display = "none";
                document.getElementById("Pricevalidation").style.display = "none";
                document.getElementById("DPricevalidation").style.display = "none";
                document.getElementById("jcountvalidation").style.display = "none";
                document.getElementById("PSDvalidation").style.display = "none";

                firestore.collection("SubsciptionPlans").add({
                    date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                    // titleImage: PTitle,
                    plan: Plan,
                    category : category,
                    validity: Number(PValidity),
                    price: Number(Price),
                    discountedPrice: Number(DPrice),
                    jpgCount: Number(JPGCount),
                    jpgTxt: `${JPGCount} JPEG Files`,
                    psdCount: Number(PSDCount) ,
                    psdTxt: `${PSDCount} PSD Files`
                })
                .then((docRef) => {
                    document.getElementById("categoryId").value = "Select Category"
                    document.getElementById("Plan").value = ""
                    document.getElementById("PlanValidity").value = ""
                    document.getElementById("Price").value = ""
                    document.getElementById("DPrice").value = ""
                    document.getElementById("JPGCount").value =""
                    document.getElementById("PSDCount").value = ""
                    swal("Subscrption Plan Added")
        
                    
                })
                .catch((error) => {
                });
            }else{
                alert("Invalid")
                if(Number(DPrice) >= Number(Price)){
                    console.log("Invalid",Price,DPrice)
                     document.getElementById("DPricevalidation").style.display = ""
                }else{
                     console.log("Valid",Price,DPrice)
                     document.getElementById("DPricevalidation").style.display = "none"
                }
           
            }

    }else{
        if(PTitle == ""){
            document.getElementById("PlanTitlevalidation").style.display = "";
        }else{
            document.getElementById("PlanTitlevalidation").style.display = "none";

        }

        if(Plan == ""){
            document.getElementById("Planvalidation").style.display = "";
        }else{
            document.getElementById("Planvalidation").style.display = "none";

        }

        if(PValidity == ""){
            document.getElementById("PlanValvalidation").style.display = "";
        }else{
            document.getElementById("PlanValvalidation").style.display = "none";

        }

        if(Price == ""){
            document.getElementById("Pricevalidation").style.display = "";
        }else{
            document.getElementById("Pricevalidation").style.display = "none";

        }

        if(DPrice == ""){
            document.getElementById("DPricevalidation").style.display = "";
        }else{
            document.getElementById("DPricevalidation").style.display = "none";

        }

        if(JPGCount == ""){
            document.getElementById("jcountvalidation").style.display = "";
        }else{
            document.getElementById("jcountvalidation").style.display = "none";

        }

        if(PSDCount == ""){
            document.getElementById("PSDvalidation").style.display = "";
        }else{
            document.getElementById("PSDvalidation").style.display = "none";

        }
    }

}


// function PriceValidation(params) {
//     var Price = document.getElementById("Price").value;
//     var DPrice = document.getElementById("DPrice").value;

//     if(params == 'reset' ){

//         document.getElementById("DPrice").value = Number(0);

//     }else{

//         if(DPrice >= Price){
//             console.log("Invalid",Price,DPrice)
//              document.getElementById("DPricevalidation").style.display = "flex"
//         }else if(DPrice <= Price){
//              console.log("Valid",Price,DPrice)
//              document.getElementById("DPricevalidation").style.display = "none"
//         }
//     }

// }