const firebaseConfig = {
    apiKey: "AIzaSyDH30YBSOlZST5KekcLQO_Z2d6m2JvUxiU",
    authDomain: "me-chitrakar.firebaseapp.com",
    projectId: "me-chitrakar",
    storageBucket: "me-chitrakar.appspot.com",
    messagingSenderId: "945981303388",
    appId: "1:945981303388:web:855b5a68e293791a94d499",
    measurementId: "G-3WZNVPXF7C"
  };

firebase.initializeApp(firebaseConfig);