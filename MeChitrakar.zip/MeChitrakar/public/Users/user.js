
firestore = firebase.firestore();


var LastUserListDoc;
var UserList = [] ;
var UserList_index = 0;
var data = [];
var dataindex = 0;
var paginationindex=0
var CurrentPage=0;
var SelectPlanFlag;
var SelectProfessionflag;
var docToBeUpdate;
var FilterFlag;
var LastUserByplan;
var LastUserByProfession;
var LastUserByImageType;
var LastUserByImageTypebyplan;
var selected_Image_type ;
var selected_Filter_Type ;
var Selected_Plan;
var Selected_Plan_ForFilter;
var DataTObeExport = [];
var DataTObeExportIndex = 0;
var SearchDataTObeExport = [];
var SearchDataTObeExportIndex = 0;
var ExportUserName;
var search;
var tobeFilter;
var Sr = 1;
var Sr_plan = 1;
var Sr_Proff = 1;
var Sr_image_typehigher = 1;
var Sr_img_plan = 1;
var Sr_Search = 1;
var planlistArray = [];
var planlistArray_index = 0;
getPlanList();
function getPlanList(params) {
  firestore.collection("SubsciptionPlans").orderBy("date","asc").get().then((querySnapshot) => {

    querySnapshot.forEach((doc) => {
    planlistArray[planlistArray_index++] = 
      $("#planlist").append(` <option value="${doc.data().plan}"></option>`)
      $("#SelectuserPlan").append(` <li><a class="dropdown-item" href="javascript:void(0);">${doc.data().plan}</a></li>
      `)
      
    });
  })
}


GetUserList();
function GetUserList(params) {
  var count = 1;
  FilterFlag = "Default"
  search = 'default';
    UserList = [] ;
    UserList_index = 0;
    data = [];
    dataindex = 0;
    paginationindex=0
    CurrentPage=0;
    DataTObeExport = [];
    DataTObeExportIndex = 0;
    Sr = 1
    // Build Report 
firestore.collection("UserInfo").orderBy("freeTryStartDate","desc").get().then((querySnapshot) => {
  LastUserByplan = querySnapshot.docs[querySnapshot.docs.length-1]
  querySnapshot.forEach((doc) => {
 


      ExportUserName = 'All_Users'; 
      DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`];
      // document.getElementById(`${doc.id}`).checked = doc.data().status
      // doc.data() is never undefined for query doc snapshots


      // if(doc.data().status === true){
          
      //     document.getElementById(`${doc.id}Switch`).checked = true
      // }else{
      //     document.getElementById(`${doc.id}Switch`).checked = false
      // }
  });
}).then(()=>{
  document.getElementById("SubadminBody").style.display = "";
  document.getElementById("SubAdminBodyAnimation").style.display = "none";
})  

// Build Report 
    
    firestore.collection("UserInfo").orderBy("freeTryStartDate","desc").limit(10).get().then((querySnapshot) => {
        LastUserListDoc = querySnapshot.docs[querySnapshot.docs.length-1]
        querySnapshot.forEach((doc) => {
          var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')
     
            data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"), `${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :""})`];
            // document.getElementById(`${doc.id}`).checked = doc.data().status
            // doc.data() is never undefined for query doc snapshots
          

            $("#UsersTableBody").append(`<tr>
          
            <td>${Sr++}</td> 
            <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
            <td>${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""}) </td>
            <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
            <td id="SubAdminPassword">${doc.data().plan}</td>
            <td id="SubAdminPassword">${doc.data().flag}</td>
            <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
            <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)

            // if(doc.data().status === true){
                
            //     document.getElementById(`${doc.id}Switch`).checked = true
            // }else{
            //     document.getElementById(`${doc.id}Switch`).checked = false
            // }
        });
    }).then(()=>{
         UserList[UserList_index++] = data;
         paginationindex++;
         CurrentPage++;
   
    })    
}

function SearchUser(params) {

   SearchDataTObeExport = [];
   SearchDataTObeExportIndex = 0;

 var tobeSearch =  document.getElementById("SearchPost").value;

 if(search == "default"){
Sr_Search = 1;
  firestore.collection("UserInfo").where("keywords","array-contains",tobeSearch).get()
  .then((querySnapshot) => {

    if( querySnapshot.docs.length == 0 ){
     
      document.getElementById("SubAdminTbodyAnimation").style.display = "flex"
      document.getElementById("SubadminBody").style.display = "none"
  }

    while(document.getElementById("UsersTableBody").childElementCount!==0){

      document.getElementById("UsersTableBody").firstChild.remove();
    }

    querySnapshot.forEach((doc)=>{
      var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')

      $("#UsersTableBody").append(`<tr id="${doc.id}-postcol">
      <td>${Sr_Search++} </td>
      <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
      <td>${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""}) </td>
      <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
        <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
      </td>
      <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
      <td id="SubAdminPassword">${doc.data().plan}</td>
      <td id="SubAdminPassword">${doc.data().flag}</td>
      <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
      <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>

      <td>
        <div style="display: flex;justify-content: space-evenly;">
        
          <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
          <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>

        </div>
      </td>
    </tr>`)

    })
  }).then(()=>{

  })

 }else if(search == "plan"){
//alert("Vivek Dhande")

Sr_Search = 1;
  firestore.collection("UserInfo").where("plan","==",Selected_Plan).where("keywords","array-contains",tobeSearch).get()
  .then((querySnapshot) => {

    if( querySnapshot.docs.length == 0 ){
     
      document.getElementById("SubAdminTbodyAnimation").style.display = "flex"
      document.getElementById("SubadminBody").style.display = "none"
  }

    while(document.getElementById("UsersTableBody").childElementCount!==0){

      document.getElementById("UsersTableBody").firstChild.remove();
    }

    querySnapshot.forEach((doc)=>{
      var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')

      $("#UsersTableBody").append(`<tr>
      <td>${Sr_Search++} </td>
      <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
      <td>${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""}) </td>
      <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
        <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
      </td>
      <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
      <td id="SubAdminPassword">${doc.data().plan}</td>
      <td id="SubAdminPassword">${doc.data().flag}</td>
      <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
      <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>

      <td>
        <div style="display: flex;justify-content: space-evenly;">
          <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
          

        </div>
      </td>
    </tr>`)

    })
  })


 }else if(search == "profession"){
  //alert("profession")

  Sr_Search = 1;
    firestore.collection("UserInfo").where("flag","==",SelectProfessionflag).where("keywords","array-contains",tobeSearch).get()
    .then((querySnapshot) => {

      if( querySnapshot.docs.length == 0 ){
     
        document.getElementById("SubAdminTbodyAnimation").style.display = "flex"
        document.getElementById("SubadminBody").style.display = "none"
    }
  
      while(document.getElementById("UsersTableBody").childElementCount!==0){
  
        document.getElementById("UsersTableBody").firstChild.remove();
    }
  
      querySnapshot.forEach((doc)=>{
        var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')

        $("#UsersTableBody").append(`<tr>
        <td>${Sr_Search++} </td>
        <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
        <td>${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""}) </td>
        <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
        </td>
        <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
        <td id="SubAdminPassword">${doc.data().plan}</td>
        <td id="SubAdminPassword">${doc.data().flag}</td>
        <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
        <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
  
        <td>
          <div style="display: flex;justify-content: space-evenly;">
            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
            
  
          </div>
        </td>
      </tr>`)
  
      })
    })
  
  
 }
  else if(document.getElementById("planlistinput").value !=="" && document.getElementById("ProfessionListinput").value !==""){
    //alert("Both")
    Sr_Search = 1;
      firestore.collection("UserInfo").where("flag","==",SelectProfessionflag).where("plan","==",Selected_Plan).where("keywords","array-contains",tobeSearch).get()
      .then((querySnapshot) => {
    
        while(document.getElementById("UsersTableBody").childElementCount!==0){
    
          document.getElementById("UsersTableBody").firstChild.remove();
      }
    
        querySnapshot.forEach((doc)=>{
          var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')

          $("#UsersTableBody").append(`<tr>
          <td> ${Sr_Search++}</td>
          <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
          <td>${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""}) </td>

          <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
            <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
          </td>
          <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
          <td id="SubAdminPassword">${doc.data().plan}</td>
          <td id="SubAdminPassword">${doc.data().flag}</td>
          <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
          <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
    
          <td>
            <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
              
    
            </div>
          </td>
        </tr>`)
    
        })
      })
    
    
 }

}

DeleteUser = (id) => {

  swal({
      title: "Are you sure?",
      text: "Do you want to Delete this Post",
      icon: "warning",
      buttons: !0,
      dangerMode: !0
  }).then(n => {
      

      n &&  firestore
      .collection('UserInfo')
      .doc(id)
      .collection("DownloadedPosts")
      .get()
      .then((querySnapshot) => {
        if(querySnapshot.size !==0){
          querySnapshot.forEach(element => {
            console.log("",element.data())
            firestore.collection('UserInfo')
            .doc(id)
            .collection("DownloadedPosts").doc(element.id).delete()
        });
        }else{
            console.log("0 DownloadPost")
        }
      


      }).then(()=>{
        console.log("Post Deleted")
        firestore.collection("Businesses").where("userPhoneNumber", "==", id)
        .get()
        .then((querySnapshot) => {
          if(querySnapshot.size !==0){
            querySnapshot.forEach(element => {
            
              firestore.collection("Businesses").doc(element.id).delete()
          });
          }else{
              console.log("0 Business")
          }
        
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        }).then(()=>{

          console.log("Business Deleted")
     
            firestore.collection("UserInfo").doc(id).delete()
  
  
                .then(function () {
                    let subsWrapper = document.getElementById(`${id}-postcol`)
                    subsWrapper.remove();
                    swal("Successfull", "Product Deleted ", "success")
                }).catch(function (e) {
                    console.error("Error removing document: ", e)
                })
  
            console.log("Deletion Done!!!!")
  
        })
        })
        
        
      
      // n && firestore.collection("Post").doc(id).delete()


      //     .then(function () {
      //         let subsWrapper = document.getElementById(`${id}-postcol`)
      //         subsWrapper.remove();
      //         swal("Successfull", "Product Deleted ", "success")
      //     }).catch(function (e) {
      //         console.error("Error removing document: ", e)
      //     })

          // firestore()
          // .collection('Post')
          // .doc(id)
          // .get()
          // .then((snapshot) => {
          //   storage()
          //     .refFromURL(snapshot.data().image.url)
          //     .delete()
          // })
  })
}

function resetSearch(params) {
  Sr = 1;
  document.getElementById("SubAdminTbodyAnimation").style.display = "none"
  document.getElementById("SubadminBody").style.display = ""

    if(search == "default" && document.getElementById("SearchPost").value ==""){
      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
      
      }
      GetUserList();

    }else if(search == "plan" && document.getElementById("SearchPost").value ==""){
      
      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
      
      }
      GetUSerListByPlan(tobeFilter)
    }else if(search == "profession" && document.getElementById("SearchPost").value ==""){
      
      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
      
      }
      GetUSerListByProfession(tobeFilter)
    }

}

function NextAdminList(params) {
   

  if(FilterFlag == "plan"){

    document.getElementById("previousButton").disabled = false; 

    data = [];
    dataindex = 0;
 
    if(paginationindex == CurrentPage ){


        firestore.collection("UserInfo").where("plan","==",Selected_Plan).orderBy("freeTryStartDate","desc").startAfter(LastUserByplan).limit(10).get().then((querySnapshot) => {

        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
        }else{

            while(document.getElementById("UsersTableBody").childElementCount!==0){

                document.getElementById("UsersTableBody").firstChild.remove();
            }
    
            LastUserByplan = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
                  var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')

                 data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"), `${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"})`];
    
                $("#UsersTableBody").append(`<tr>
                <td>${Sr_plan++}</td>
                <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
                <td>${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"}) </td>
                <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
            <td id="SubAdminPassword">${doc.data().plan}</td>
            <td id="SubAdminPassword">${doc.data().flag}</td>
            <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
            <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)">Edit</button>
                <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
            });
            
        }

        }).then(()=>{
            UserList[UserList_index++] = data;
            paginationindex++;
            CurrentPage++;
        })

    }else{

      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
    }

        UserList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

     
    
            $("#UsersTableBody").append(`<tr>
            <td>${doc[7]}</td>
            <td>${doc[8]}</td>
            <td>${doc[9]}</td>
            <td id=${doc[0]} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
            </td>
            <td id="SubAdminEmail">${doc[2]}</td> 
            <td id="SubAdminPassword">${doc[3]}</td>
            <td id="SubAdminPassword">${doc[4]}</td>
            <td id="SubAdminPassword">${doc[5]}</td>
            <td id="SubAdminPassword">${doc[6]}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
              <button type="button" class="btn rounded-pill btn-danger"id="${doc[0]}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
        });

        CurrentPage++;


    }
  
  }else if(FilterFlag == "profession"){

    document.getElementById("previousButton").disabled = false; 

    data = [];
    dataindex = 0;
 
    if(paginationindex == CurrentPage ){


        firestore.collection("UserInfo").where("flag","==",SelectProfessionflag).orderBy("freeTryStartDate","desc").startAfter(LastUserByProfession).limit(10).get().then((querySnapshot) => {

        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
        }else{

            while(document.getElementById("UsersTableBody").childElementCount!==0){

                document.getElementById("UsersTableBody").firstChild.remove();
            }
    
            LastUserByProfession = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
                var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')

                data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"), `${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"})`];
    
                $("#UsersTableBody").append(`<tr>
                <td>${Sr_Proff++}</td>
                <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
                <td>${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"}) </td>

                <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
            <td id="SubAdminPassword">${doc.data().plan}</td>
            <td id="SubAdminPassword">${doc.data().flag}</td>
            <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
            <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)">Edit</button>
                <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
            });
            
        }

        }).then(()=>{
            UserList[UserList_index++] = data;
            paginationindex++;
            CurrentPage++;
        })

    }else{


      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
    }
        UserList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

    
            $("#UsersTableBody").append(`<tr>
            <td>${doc[7]}</td>
            <td>${doc[8]}</td>
            <td>${doc[9]}</td>
            <td id=${doc[0]} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
            </td>
            <td id="SubAdminEmail">${doc[2]}</td> 
            <td id="SubAdminPassword">${doc[3]}</td>
            <td id="SubAdminPassword">${doc[4]}</td>
            <td id="SubAdminPassword">${doc[5]}</td>
            <td id="SubAdminPassword">${doc[6]}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
              <button type="button" class="btn rounded-pill btn-danger"id="${doc[0]}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
        });

        CurrentPage++;


    }
  
  }else if(FilterFlag == "ImageTypeHigher"){

    document.getElementById("previousButton").disabled = false; 

    data = [];
    dataindex = 0;
 
    if(paginationindex == CurrentPage ){


        firestore.collection("UserInfo").orderBy(`${selected_Image_type}`,`${selected_Filter_Type}`).startAfter(LastUserByImageType).limit(10).get().then((querySnapshot) => {

        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
        }else{

            while(document.getElementById("UsersTableBody").childElementCount!==0){

                document.getElementById("UsersTableBody").firstChild.remove();
            }
    
            LastUserByImageType = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
              var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')
              data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"), `${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"})`];

                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
    
                $("#UsersTableBody").append(`<tr>
                <td>${Sr_image_typehigher++}</td>
                <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
                <td>${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"}) </td>

                <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
            <td id="SubAdminPassword">${doc.data().plan}</td>
            <td id="SubAdminPassword">${doc.data().flag}</td>
            <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
            <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)">Edit</button>
                <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
            });
            
        }

        }).then(()=>{
            UserList[UserList_index++] = data;
            paginationindex++;
            CurrentPage++;
        })

    }else{

      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
    }
        UserList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

           
    
            $("#UsersTableBody").append(`<tr>
            <td>${doc[7]} </td>
            <td>${doc[8]}</td>
            <td>${doc[9]}</td>
            <td id=${doc[0]} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
            </td>
            <td id="SubAdminEmail">${doc[2]}</td> 
            <td id="SubAdminPassword">${doc[3]}</td>
            <td id="SubAdminPassword">${doc[4]}</td>
            <td id="SubAdminPassword">${doc[5]}</td>
            <td id="SubAdminPassword">${doc[6]}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
              <button type="button" class="btn rounded-pill btn-danger"id="${doc[0]}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
        });

        CurrentPage++;


    }

  }else if(FilterFlag == "ImageTypebyPlan"){

    document.getElementById("previousButton").disabled = false; 

    data = [];
    dataindex = 0;
 
    if(paginationindex == CurrentPage ){


        firestore.collection("UserInfo").where("plan","==",Selected_Plan_ForFilter).orderBy(`${selected_Image_type}`,`${selected_Filter_Type}`).startAfter(LastUserByImageTypebyplan).limit(10).get().then((querySnapshot) => {

        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
        }else{

            while(document.getElementById("UsersTableBody").childElementCount!==0){

                document.getElementById("UsersTableBody").firstChild.remove();
            }
    
            LastUserByImageTypebyplan = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
                
                var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')
                data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr_image_typehigher}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"),`${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""})`];
      
                $("#UsersTableBody").append(`<tr>
                <td>${Sr_img_plan++}</td>
                <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
                <td>${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""}) </td>

                <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
            <td id="SubAdminPassword">${doc.data().plan}</td>
            <td id="SubAdminPassword">${doc.data().flag}</td>
            <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
            <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)">Edit</button>
                <button type="button" class="btn rounded-pill btn-danger"id="${doc[0]}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
            });
            
        }

        }).then(()=>{
            UserList[UserList_index++] = data;
            paginationindex++;
            CurrentPage++;
        })

    }else{
      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
    }

        UserList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

        
    
            $("#UsersTableBody").append(`<tr>
            <td>${doc[7]} </td>
            <td>${doc[8]}</td>
            <td>${doc[9]}</td>
            <td id=${doc[0]} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
            </td>
            <td id="SubAdminEmail">${doc[2]}</td> 
            <td id="SubAdminPassword">${doc[3]}</td>
            <td id="SubAdminPassword">${doc[4]}</td>
            <td id="SubAdminPassword">${doc[5]}</td>
            <td id="SubAdminPassword">${doc[6]}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
              <button type="button" class="btn rounded-pill btn-danger"id="${doc[0]}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
        });

        CurrentPage++;


    }

  }
  else{
    document.getElementById("previousButton").disabled = false; 

    data = [];
    dataindex = 0;
 
    
    if(paginationindex == CurrentPage ){

        firestore.collection("UserInfo").orderBy("freeTryStartDate","desc").startAfter(LastUserListDoc).limit(10).get().then((querySnapshot) => {

        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
        }else{

            while(document.getElementById("UsersTableBody").childElementCount!==0){

                document.getElementById("UsersTableBody").firstChild.remove();
            }
    
            LastUserListDoc = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
                var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')
                // data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr_image_typehigher}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"),`${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""})`];    
                data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"), `${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"})`];
             
                $("#UsersTableBody").append(`<tr>
                <td>${Sr++}</td>
                <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
                <td>${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"}) </td>

                <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
            <td id="SubAdminPassword">${doc.data().plan}</td>
            <td id="SubAdminPassword">${doc.data().flag}</td>
            <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
            <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)">Edit</button>
                <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
            });
            
        }

        }).then(()=>{
            UserList[UserList_index++] = data;
            paginationindex++;
            CurrentPage++;
        })

    }else{

      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
    }
        UserList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

             
    
            $("#UsersTableBody").append(`<tr>
            <td >${doc[7]}</td>
            <td>${doc[8]}</td>
            <td>${doc[9]}</td>
            <td id=${doc[0]} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
            </td>
            <td id="SubAdminEmail">${doc[2]}</td> 
            <td id="SubAdminPassword">${doc[3]}</td>
            <td id="SubAdminPassword">${doc[4]}</td>
            <td id="SubAdminPassword">${doc[5]}</td>
            <td id="SubAdminPassword">${doc[6]}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
              <button type="button" class="btn rounded-pill btn-danger"id="${doc[0]}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
        });

        CurrentPage++;


    }
  }
   
}

function Previous_NextAdminList(params) {

    document.getElementById("nextButton").disabled = false; 

    if(CurrentPage!==1){

        while(document.getElementById("UsersTableBody").childElementCount!==0){ 
            
            document.getElementById("UsersTableBody").firstChild.remove();
        }
    
        CurrentPage--;
        console.log("Data",CurrentPage,paginationindex);
        UserList[CurrentPage-1].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());
    
            $("#UsersTableBody").append(`<tr>
            <td >${doc[7]}</td>
            <td>${doc[8]}</td>
            <td>${doc[9]}</td>
            <td id=${doc[0]} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
            </td>
            <td id="SubAdminEmail">${doc[2]}</td> 
            <td id="SubAdminPassword">${doc[3]}</td>
            <td id="SubAdminPassword">${doc[4]}</td>
            <td id="SubAdminPassword">${doc[5]}</td>
            <td id="SubAdminPassword">${doc[6]}</td>
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
                <button type="button" class="btn rounded-pill btn-danger"id="${doc[0]}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)
        });
        
    }else{
        document.getElementById("previousButton").disabled = true; 
    }


    
}

function openUserModal(params) {

    docToBeUpdate = params;
    
    var docRef = firestore.collection("UserInfo").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {
            
            document.getElementById("userNameModal").value = doc.data().userName 
            document.getElementById("usermobnoModal").value = doc.data().mobNumber
            document.getElementById("userPlan").innerText = doc.data().plan
            document.getElementById("userProfession").innerText = doc.data().flag
            document.getElementById("userpngjpegmodal").value = doc.data().jpg
            document.getElementById("userpsdmodal").value = doc.data().psd
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
}

function SaveEditSliderModal(params) {
    
var userName = document.getElementById("userNameModal").value;
var userMob = document.getElementById("usermobnoModal").value
var userPlan = document.getElementById("userPlan").innerText;
var userProfessionvar = document.getElementById("userProfession").innerText;
var userpngorjpeg = document.getElementById("userpngjpegmodal").value;
var userpsdvar = document.getElementById("userpsdmodal").value

var washingtonRef = firestore.collection("UserInfo").doc(docToBeUpdate);

    // Set the "capital" field of the city 'DC'
    return washingtonRef.update({
        plan : userPlan,
        flag :  userProfessionvar,
        jpg : Number(userpngorjpeg),
        psd : Number(userpsdvar)
    })
    .then(() => {
        swal("User Edited Successfully");

    }).then(()=>{

        location.reload();
    })
    .catch((error) => {
        // The document probably doesn't exist.
        console.error("Error updating document: ", error);
    });


}



$('#SelectuserPlan').on('click', '.dropdown-item', function(){

    SelectPlanFlag = $(this).text();
    $('#userPlan').html($(this).text());   
})

$('#SelectuserProfession').on('click', '.dropdown-item', function(){

    SelectProfessionflag = $(this).text();
    $('#userProfession').html($(this).text());   
})


function redirectToUserProfile(params) {
    
    localStorage.setItem("userDoc", params);
    window.open('userprofile.html', '_blank');
}


$("#planlistinput").change(()=>{

  document.getElementById("nextButton").disabled = false
  document.getElementById("previousButton").disabled = false
  tobeFilter = document.getElementById("planlistinput").value;

  GetUSerListByPlan(tobeFilter);
  
})

$("#ProfessionListinput").change(()=>{

  
  tobeFilter = document.getElementById("ProfessionListinput").value;

  GetUSerListByProfession(tobeFilter);
  
})



function GetUSerListByPlan(params) {
  Selected_Plan = params;
  FilterFlag = "plan";
  search = "plan";
  UserList = [] ;
  UserList_index = 0;
  data = [];
  dataindex = 0;
  paginationindex=0
  CurrentPage=0;
  DataTObeExport = [];
  DataTObeExportIndex = 0;
  Sr_plan = 1;
  
  while(document.getElementById("UsersTableBody").childElementCount!==0){

    document.getElementById("UsersTableBody").firstChild.remove();
}
  


  if(params !== "ALL"){
  // Build Report 
      firestore.collection("UserInfo").where("plan","==",params).orderBy("freeTryStartDate","desc").get().then((querySnapshot) => {
        LastUserByplan = querySnapshot.docs[querySnapshot.docs.length-1]
        querySnapshot.forEach((doc) => {
            console.log("doc.data()",doc.data())
            ExportUserName = 'Filter By Plan'; 
            DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,];
            // document.getElementById(`${doc.id}`).checked = doc.data().status
            // doc.data() is never undefined for query doc snapshots


            // if(doc.data().status === true){
                
            //     document.getElementById(`${doc.id}Switch`).checked = true
            // }else{
            //     document.getElementById(`${doc.id}Switch`).checked = false
            // }
        });
      }).then(()=>{

      })  

  // Build Report 

      firestore.collection("UserInfo").where("plan","==",params).orderBy("freeTryStartDate","desc").limit(10).get().then((querySnapshot) => {
        LastUserByplan = querySnapshot.docs[querySnapshot.docs.length-1]
        querySnapshot.forEach((doc) => {
    
          var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')
          data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"), `${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"})`];
          // document.getElementById(`${doc.id}`).checked = doc.data().status
            // doc.data() is never undefined for query doc snapshots
            $("#UsersTableBody").append(`<tr>
            <td>${Sr_plan++}</td>
            <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
            <td>${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"}) </td>

            <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
            <td id="SubAdminPassword">${doc.data().plan}</td>
            <td id="SubAdminPassword">${doc.data().flag}</td>
            <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
            <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>

            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


              </div>
            </td>
          </tr>`)

            // if(doc.data().status === true){
                
            //     document.getElementById(`${doc.id}Switch`).checked = true
            // }else{
            //     document.getElementById(`${doc.id}Switch`).checked = false
            // }
        });
    }).then(()=>{
        UserList[UserList_index++] = data;
        paginationindex++;
        CurrentPage++;

    })    
  }else{

    GetUserList();

  }

      


}

function GetUSerListByProfession(params) {

  SelectProfessionflag = params;
  FilterFlag = "profession";
  search = "profession"
  UserList = [] ;
  UserList_index = 0;
  data = [];
  dataindex = 0;
  paginationindex=0
  CurrentPage=0;

  DataTObeExport = [];
  DataTObeExportIndex = 0;

  Sr_Proff = 1;
  while(document.getElementById("UsersTableBody").childElementCount!==0){

    document.getElementById("UsersTableBody").firstChild.remove();
}
    // Build Report 
    firestore.collection("UserInfo").where("flag","==",params).orderBy("freeTryStartDate","desc").get().then((querySnapshot) => {
      LastUserByplan = querySnapshot.docs[querySnapshot.docs.length-1]
      querySnapshot.forEach((doc) => {
          console.log("doc.data()",doc.data())
          ExportUserName = 'Filter By Profession'; 
          DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,];
          // document.getElementById(`${doc.id}`).checked = doc.data().status
          // doc.data() is never undefined for query doc snapshots
    
    
          // if(doc.data().status === true){
              
          //     document.getElementById(`${doc.id}Switch`).checked = true
          // }else{
          //     document.getElementById(`${doc.id}Switch`).checked = false
          // }
      });
    }).then(()=>{
    
    })  
    
    // Build Report 

  firestore.collection("UserInfo").where("flag","==",params).orderBy("freeTryStartDate","desc").limit(10).get().then((querySnapshot) => {
    LastUserByProfession = querySnapshot.docs[querySnapshot.docs.length-1]
      querySnapshot.forEach((doc) => {
        var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')
        data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr_image_typehigher}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"),`${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""})`];    
          // document.getElementById(`${doc.id}`).checked = doc.data().status
          // doc.data() is never undefined for query doc snapshots
          $("#UsersTableBody").append(`<tr>
          <td>${Sr_Proff++} </td>
          <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
          <td>${moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY")} (${isNaN(days)!== true ? Math.abs(days)+1 :""}) </td>

          <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
            <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
          </td>
          <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
          <td id="SubAdminPassword">${doc.data().plan}</td>
          <td id="SubAdminPassword">${doc.data().flag}</td>
          <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
          <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
 
          <td>
            <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
              <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


            </div>
          </td>
        </tr>`)

          // if(doc.data().status === true){
              
          //     document.getElementById(`${doc.id}Switch`).checked = true
          // }else{
          //     document.getElementById(`${doc.id}Switch`).checked = false
          // }
      });
  }).then(()=>{
       UserList[UserList_index++] = data;
       paginationindex++;
       CurrentPage++;
 
  })    
}

function GetUSerListByImageTypeHigh(params,params1) {

  SelectImageTypeflag = params;
  FilterFlag = "ImageTypeHigher";
  UserList = [] ;
  UserList_index = 0;
  data = [];
  dataindex = 0;
  paginationindex=0
  CurrentPage=0;
  DataTObeExport = [];
  DataTObeExportIndex = 0;
  Sr_image_typehigher = 1;
  while(document.getElementById("UsersTableBody").childElementCount!==0){

    document.getElementById("UsersTableBody").firstChild.remove();
}
  
firestore.collection("UserInfo").orderBy(`${params}`,`${params1}`).get().then((querySnapshot) => {
  LastUserByplan = querySnapshot.docs[querySnapshot.docs.length-1]
      querySnapshot.forEach((doc) => {
          console.log("doc.data()",)
          ExportUserName = 'Filter By ImageType'; 
          DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`];
          // document.getElementById(`${doc.id}`).checked = doc.data().status
          // doc.data() is never undefined for query doc snapshots
    
    
          // if(doc.data().status === true){
              
          //     document.getElementById(`${doc.id}Switch`).checked = true
          // }else{
          //     document.getElementById(`${doc.id}Switch`).checked = false
          // }
      });
    }).then(()=>{
    
    })  
    

  firestore.collection("UserInfo").orderBy(`${params}`,`${params1}`).limit(10).get().then((querySnapshot) => {
    LastUserByImageType = querySnapshot.docs[querySnapshot.docs.length-1]
      querySnapshot.forEach((doc) => {
          console.log("doc.data()",doc.data())
          var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')
          data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"), `${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"})`];
          // doc.data() is never undefined for query doc snapshots
          $("#UsersTableBody").append(`<tr>
          <td>${Sr_image_typehigher++}</td>
          <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
          <td>${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"}) </td>

          <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
            <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
          </td>
          <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
          <td id="SubAdminPassword">${doc.data().plan}</td>
          <td id="SubAdminPassword">${doc.data().flag}</td>
          <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
          <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
 
          <td>
            <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
              <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


            </div>
          </td>
        </tr>`)

          // if(doc.data().status === true){
              
          //     document.getElementById(`${doc.id}Switch`).checked = true
          // }else{
          //     document.getElementById(`${doc.id}Switch`).checked = false
          // }
      });
  }).then(()=>{
       UserList[UserList_index++] = data;
       paginationindex++;
       CurrentPage++;
 
  })    
}

function GetUSerListByImageTypeWithPlan(params,params1,params2) {

  SelectImageTypeflag = params;
  selected_Filter_Type
  FilterFlag = "ImageTypebyPlan";
  UserList = [] ;
  UserList_index = 0;
  data = [];
  dataindex = 0;
  paginationindex=0
  CurrentPage=0;
  DataTObeExport = [];
  DataTObeExportIndex = 0;

  
  while(document.getElementById("UsersTableBody").childElementCount!==0){

    document.getElementById("UsersTableBody").firstChild.remove();
}

firestore.collection("UserInfo").where("plan","==",params2).orderBy(`${params}`,`${params1}`).get().then((querySnapshot) => {
  LastUserByplan = querySnapshot.docs[querySnapshot.docs.length-1]
      querySnapshot.forEach((doc) => {
          console.log("doc.data()",doc.data())
          ExportUserName = 'Filter By Plan & Image Type'; 

          DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`];
          // document.getElementById(`${doc.id}`).checked = doc.data().status
          // doc.data() is never undefined for query doc snapshots
    
    
          // if(doc.data().status === true){
              
          //     document.getElementById(`${doc.id}Switch`).checked = true
          // }else{
          //     document.getElementById(`${doc.id}Switch`).checked = false
          // }
      });
    }).then(()=>{
    
    })  

  firestore.collection("UserInfo").where("plan","==",params2).orderBy(`${params}`,`${params1}`).limit(5).get().then((querySnapshot) => {
    LastUserByImageTypebyplan = querySnapshot.docs[querySnapshot.docs.length-1]
      querySnapshot.forEach((doc) => {
        var days = moment(moment()).diff(doc.data().expiryDate!==undefined ? moment(doc.data().expiryDate.toDate()).format("LL") : "", 'days')
        data[dataindex++] = [doc.id,doc.data().userName,doc.data().mobNumber,doc.data().plan,doc.data().flag,`${doc.data().jpg !== undefined ? doc.data().jpg : 0 }`,`${doc.data().psd !== undefined ? doc.data().psd : 0}`,`${Sr}`,moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY"), `${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"})`];
        // document.getElementById(`${doc.id}`).checked = doc.data().status
          // doc.data() is never undefined for query doc snapshots
          $("#UsersTableBody").append(`<tr>
          <td>${Sr_img_plan++} </td>
          <td>${moment(doc.data().freeTryStartDate.toDate()).format("DD/MM/YYYY")}</td>
          <td>${doc.data().expiryDate!==undefined? moment(doc.data().expiryDate.toDate()).format("DD/MM/YYYY"):""} (${isNaN(days)!== true ? Math.abs(days)+1 :"Old User"}) </td>

          <td id=${doc.id} onclick="redirectToUserProfile(this.id)">
            <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
          </td>
          <td id="SubAdminEmail">${doc.data().mobNumber}</td> 
          <td id="SubAdminPassword">${doc.data().plan}</td>
          <td id="SubAdminPassword">${doc.data().flag}</td>
          <td id="SubAdminPassword">${doc.data().jpg !== undefined ? doc.data().jpg : 0 }</td>
          <td id="SubAdminPassword">${doc.data().psd !== undefined ? doc.data().psd : 0}</td>
 
          <td>
            <div style="display: flex;justify-content: space-evenly;">
            
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
              <button type="button" class="btn rounded-pill btn-danger"id="${doc.id}" onclick="DeleteUser(this.id)">Delete</button>


            </div>
          </td>
        </tr>`)

          // if(doc.data().status === true){
              
          //     document.getElementById(`${doc.id}Switch`).checked = true
          // }else{
          //     document.getElementById(`${doc.id}Switch`).checked = false
          // }
      });
  }).then(()=>{
       UserList[UserList_index++] = data;
       paginationindex++;
       CurrentPage++;
 
  })    
}

function higherFilter(params) {
  
  if(document.getElementById("ImageTypeInput").value !== "" && document.getElementById("planlistinput").value == ""){
   
        if(document.getElementById("ImageTypeInput").value == "PNG/JPEG" ){

          selected_Image_type = 'jpg';
          selected_Filter_Type = 'desc';
              GetUSerListByImageTypeHigh('jpg','desc')
        }else if(document.getElementById("ImageTypeInput").value == "PSD" ){
          selected_Image_type = 'psd';
          selected_Filter_Type = 'desc';
              GetUSerListByImageTypeHigh('psd','psd')
        }
  }else if(document.getElementById("ImageTypeInput").value !== "" && document.getElementById("planlistinput").value !== ""){
    //alert("Vivek Dhande")
    if(document.getElementById("ImageTypeInput").value == "PNG/JPEG" ){
      selected_Image_type = 'jpg';
      selected_Filter_Type = 'desc';
      Selected_Plan_ForFilter = document.getElementById("planlistinput").value;
      GetUSerListByImageTypeWithPlan('jpg','desc',`${Selected_Plan_ForFilter}`)

    }else if(document.getElementById("ImageTypeInput").value == "PSD" ){
      selected_Image_type = 'psd';
      selected_Filter_Type = 'desc';
      Selected_Plan_ForFilter = document.getElementById("planlistinput").value;
      GetUSerListByImageTypeWithPlan('psd','desc',`${Selected_Plan_ForFilter}`)
    }
  }
}
function lowerFilter(params) {
  
  if(document.getElementById("ImageTypeInput").value !== "" &&  document.getElementById("planlistinput").value == ""){
   
        if(document.getElementById("ImageTypeInput").value == "PNG/JPEG" ){
          selected_Image_type = 'jpg';
          selected_Filter_Type = 'asc';
              GetUSerListByImageTypeHigh('jpg','asc')
        }else if(document.getElementById("ImageTypeInput").value == "PSD" ){
          selected_Image_type = 'psd';
          selected_Filter_Type = 'asc';
              GetUSerListByImageTypeHigh('psd','asc')
        }
  }else if(document.getElementById("ImageTypeInput").value !== "" && document.getElementById("planlistinput").value !== ""){
    //alert("Vivek Dhande")
    if(document.getElementById("ImageTypeInput").value == "PNG/JPEG" ){
      selected_Image_type = 'jpg';
      selected_Filter_Type = 'asc';
      Selected_Plan_ForFilter = document.getElementById("planlistinput").value;
      GetUSerListByImageTypeWithPlan('jpg','asc',`${Selected_Plan_ForFilter}`)

    }else if(document.getElementById("ImageTypeInput").value == "PSD" ){
      selected_Image_type = 'psd';
      selected_Filter_Type = 'asc';
      Selected_Plan_ForFilter = document.getElementById("planlistinput").value;
      GetUSerListByImageTypeWithPlan('psd','asc',`${Selected_Plan_ForFilter}`)
    }
  }
}


document.getElementById('planlistinput').addEventListener('click', (e) => {
  e.target.value = ''
})

document.getElementById('ProfessionListinput').addEventListener('click', (e) => {
  e.target.value = ''
})


function ExportData(params) {
  var csv = `${ExportUserName},${moment().toDate()}\nUSER NAME,MOBILE NUMBER,PLAN,PROFESSION,PNG/JPEG,PSD\n`;

  console.log("DataTObeExport",DataTObeExport)
  //merge the data with CSV
  DataTObeExport.forEach(function (row) {
    //console.log(row)
    csv += row.join(',');
    csv += "\n";
  });

  //display the created CSV data on the web browser 
  


  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';

  //provide the name for the CSV file to be downloaded
  hiddenElement.download = `${ExportUserName}.csv`;

  hiddenElement.click();
}



document.getElementById("userActivation").addEventListener("change", function(e){ 
  
  var UserActiovation= firestore.collection("UserInfo").doc(docToBeUpdate);

  // Set the "capital" field of the city 'DC'
  return UserActiovation.update({
      userActive : e.target.checked
  })
  .then(() => {
      console.log("Document successfully updated!");
  })
  .catch((error) => {
      // The document probably doesn't exist.
      console.error("Error updating document: ", error);
  });

});
