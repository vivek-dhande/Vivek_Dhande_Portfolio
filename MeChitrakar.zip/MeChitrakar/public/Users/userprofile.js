firestore = firebase.firestore();



var getUserDoc = localStorage.getItem("userDoc");

    console.log(getUserDoc);
var docRef = firestore.collection("UserInfo").doc(getUserDoc);

    docRef.get().then((doc) => {
        if (doc.exists) {
            
            document.getElementById("user_Full_Name").innerText = doc.data().userName 
            document.getElementById("user_contact").innerText = doc.data().mobNumber
            document.getElementById("user_plan").innerText = doc.data().plan
            document.getElementById("user_profession").innerText = doc.data().flag
            document.getElementById("user_jpg").innerText = doc.data().jpg
            document.getElementById("user_psd").innerText = doc.data().psd

            console.log("User",doc.data())
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });


    var docRefOfUserPost = firestore.collection("UserInfo").doc(getUserDoc).collection("DownloadedPosts").orderBy("date","desc").limit(3);

    docRefOfUserPost.get().then((querySnapshot) => {

            
            // document.getElementById("user_Full_Name").innerText = doc.data().userName 
            // document.getElementById("user_contact").innerText = doc.data().mobNumber
            // document.getElementById("user_plan").innerText = doc.data().plan
            // document.getElementById("user_profession").innerText = doc.data().flag
            // document.getElementById("user_jpg").innerText = doc.data().jpg
            // document.getElementById("user_psd").innerText = doc.data().psd

            PostLastDocReff = querySnapshot.docs[querySnapshot.docs.length-1]
           
            querySnapshot.forEach(doc => {
              
                $('#viewPostOfUser').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
                <div class="card h-100">
             <div>
             </div>
                  <div class="card-body">
     
                    <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().img}" alt="Card image cap" style="width:311.550px;height:311.550px">
                    <div style="display:flex;margin-top:1rem" >
                         <img class="img-fluid" src="${doc.data().imageFlag == 'jpg' ? '/assets/img/jpg.png' : doc.data().imageFlag == 'psd' ? '/assets/img/psd.png' : "" }" alt="Card image cap" style="width:2rem;height:2rem"><div style="display:flex;align-items: center;"><span> ${ doc.data().imageFlag == 'jpg' ? doc.data().imageFlag.toUpperCase() :  doc.data().imageFlag == 'psd' ? doc.data().imageFlag.toUpperCase() : ""  } </span> </div>

                    <div>
                  </div>
                </div>
              </div>`)
    
                
            })
            // ${doc.data().imageFlag.toUpperCase()}
            if(querySnapshot.docs.length !==0){
                document.getElementById("LoadmoreButtondiv").style.display = "flex";
            }else{
                document.getElementById("LoadmoreButtondiv").style.display = "none";
            }
          
       

    }).then(()=>{
    
     

    }).catch((error) => {
        console.log("Error getting document:", error);
    });

    function LoadMorePost(params) {
        var docRefOfUserPost = firestore.collection("UserInfo").doc(getUserDoc).collection("DownloadedPosts").orderBy("date","desc").startAfter(PostLastDocReff).limit(3);

        docRefOfUserPost.get().then((querySnapshot) => {
    
                
                // document.getElementById("user_Full_Name").innerText = doc.data().userName 
                // document.getElementById("user_contact").innerText = doc.data().mobNumber
                // document.getElementById("user_plan").innerText = doc.data().plan
                // document.getElementById("user_profession").innerText = doc.data().flag
                // document.getElementById("user_jpg").innerText = doc.data().jpg
                // document.getElementById("user_psd").innerText = doc.data().psd
    
                PostLastDocReff = querySnapshot.docs[querySnapshot.docs.length-1]
               
                querySnapshot.forEach(doc => {
                  
                    $('#viewPostOfUser').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
                    <div class="card h-100">
                 <div>
                 </div>
                      <div class="card-body">
         
                        <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().img}" alt="Card image cap" style="width:311.550px;height:311.550px">
                        <div style="display:flex;margin-top:1rem" >
                        <img class="img-fluid" src="${doc.data().imageFlag == 'jpg' ? '/assets/img/jpg.png' : c.data().imageFlag == 'psd' ? '/assets/img/psd.png' : "" }" alt="Card image cap" style="width:2rem;height:2rem"><div style="display:flex;align-items: center;"><span> ${ doc.data().imageFlag == 'jpg' ? doc.data().imageFlag.toUpperCase() :  doc.data().imageFlag == 'psd' ? doc.data().imageFlag.toUpperCase() : ""  } </span> </div>
                        <div>
                      </div>
                    </div>
                  </div>`)
        
                    
                })

                if(querySnapshot.docs.length !==0){
                    document.getElementById("LoadmoreButtondiv").style.display = "flex";
                }else{
                    document.getElementById("LoadmoreButtondiv").style.display = "none";
                    swal("No More Post available")
                }
              
            })
        
    }