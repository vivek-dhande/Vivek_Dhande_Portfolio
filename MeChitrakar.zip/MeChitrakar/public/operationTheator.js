var firestore = firebase.firestore();
alert("Alert")
var subcatDoc;

function GetData(params) {
    firestore.collection("SubCat").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            if(doc.data().mainCatname == undefined){
                $("#ParaentDiv").append(` <div style="display:flex">
                <span>${doc.data().subCatName} </span> <button class="btn btn-primary" id="${doc.id}-${doc.data().mainCat}"  onclick="updateCat(this.id)">Update</button></div>`)
            }

        });
    });
}

GetData();

function updateCat(params,params1) {

        var SubCatTobeUpdate = params.slice(0 ,params.indexOf("-"))
        var mainCatDocID = params.slice(params.indexOf("-")+1 ,params.length)
        var maincatName;
        var docRef = firestore.collection("Category").doc(mainCatDocID);

        docRef.get().then((doc) => {
            if (doc.exists) {
                maincatName = doc.data().catName
                var washingtonRef = firestore.collection("SubCat").doc(SubCatTobeUpdate);

                // Set the "capital" field of the city 'DC'
                return washingtonRef.update({
                    mainCatname: maincatName
                })
                .then(() => {
                 location.reload();
                })
                .catch((error) => {
                    // The document probably doesn't exist.
                    console.error("Error updating document: ", error);
                });
                console.log("Document data:", doc.data());
            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
            }
        }).catch((error) => {
            console.log("Error getting document:", error);
        });
}