var firestore = firebase.firestore();
var Frame_Category;
var FrameLink;
var BusinessCategoryInEnglish = ['Accounting Gst','Ad Blue','Advertising Consultancy','Advocate','Agriculture','Agriculture Pipe Fittings','Air Conditioner','Aluminium Section','Ambulance','Animal / Pet','APMC Traders','Architecture Work','Art & Design','Astrologer','Autoclave areated concrete','Automobile','Ayurvedic','Bag','Bakery & Cake','Bathroom Accessories','Bearing','Beverages','Book Store','Brass Sheet']
getCategories();
function getCategories(params) {
    firestore.collection("FrameCategory").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
           $("#SelectCatForFrame").append(`<li><a class="dropdown-item" href="javascript:void(0);">${doc.data().frameCatName}</a></li>`)
        });
    });
}

$('.dropdown-menu').on('click', '.dropdown-item', function(){
    
    Frame_Category = $(this).text();
    $('#AddframeCat').html($(this).text());
})


function saveFrame(params) {

    var FrameTitle = document.getElementById("AddFrameTitle").value 
    var FrameCode = document.getElementById("FrameCode").value 
    var FrameIamge = document.getElementById("AddFramerImg").value 
    console.log("Frame_Category",Frame_Category)
    if(FrameTitle!== "" && FrameCode !=="" && FrameIamge!=="" && Frame_Category!== undefined){
        
       document.getElementById("UpaloadSliderImg").style.display = "flex"
       document.getElementById("AddSliderIMG").style.display = "none"

        const ref = firebase.storage().ref();
        const file = document.querySelector('#AddFramerImg').files[0]
        const file2 = document.querySelector('#FrameCode').files[0]
        const name =  file.name;
        const name2 = file2.name;
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('meChitrakar/' + name).put(file, metadata);
        const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
        task2
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
            FrameLink = url;
        }).then(()=>{
            task
            .then(snapshot => snapshot.ref.getDownloadURL())
            .then((url) => {
                firestore.collection("Frames").add({
                  frameCategory: Frame_Category,
                  title : FrameTitle,
                  code : FrameLink,
                  thumbnail : url,
                  type:"business",
                  premium:"0",
                  date : firebase.firestore.Timestamp.fromDate(new Date()).toDate()
                })
                .then((docRef) => {
                     document.getElementById("AddFrameTitle").value = ""
                     document.getElementById("FrameCode").value = ""
                     document.getElementById("AddFramerImg").value= "" 
                     document.getElementById("AddSliderIMG").src =  "../assets/img/photo.png"
                     document.getElementById("UpaloadSliderImg").style.display = "none"
                     document.getElementById("AddSliderIMG").style.display = "flex"
                    swal("Frame Added Successfully")
                })
                .catch((error) => {
                    console.error("Error adding document: ", error);
                });
    
            })
        })
        
       
       
      


    }else{
        if(Frame_Category == undefined ){
            document.getElementById("sliderflag").style.display = ""
        }else{
            document.getElementById("sliderflag").style.display = "none"
        } 

        if(FrameTitle == "" ){
            document.getElementById("AddFramespan").style.display = ""
        }else{
            document.getElementById("AddFramespan").style.display = "none"
        } 

        if(FrameCode == "" ){
            document.getElementById("codeOfFrameSpan").style.display = ""
        }else{
            document.getElementById("codeOfFrameSpan").style.display = "none"
        } 

        if(FrameIamge == "" ){
            document.getElementById("pngjpegvalidation").style.display = ""
        }else{
            document.getElementById("pngjpegvalidation").style.display = "none"
        } 
    }
}

function AddImgForSLider(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#AddSliderIMG')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}