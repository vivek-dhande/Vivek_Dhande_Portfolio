
var firestore = firebase.firestore();

// firestore.collection("Sliders").get().then((querySnapshot) => {
//     querySnapshot.forEach((doc) => {
//         // doc.data() is never undefined for query doc snapshots
//         console.log(doc.id, " => ", doc.data());
//     });
// });


function AddFrameCategory(params) {


    var frameCatName = document.getElementById("FrameCatName").value
    var Name = document.getElementById("Name").value 


    if(frameCatName!== "" && Name!=="" ){

        

        
        var docRef = firestore.collection("FrameCategory")
    
        return docRef.add({
            
            frameCatName : frameCatName,
            name : Name,
            date : firebase.firestore.Timestamp.fromDate(new Date()).toDate()

        })
        .then(() => {
            document.getElementById("FrameCatName").value =""
            document.getElementById("Name").value =" "
            // document.getElementById("FrameCatName").value = ""
            document.getElementById("FrameCatNamespan2").style.display = "none"
            document.getElementById("FrameCatNamespan").value = "none"
            
            swal(" Frame Category successfully Added!");
  
           

        }).then(()=>{


        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });
    
     

    }else{
        
        if(frameCatName == ""){
            document.getElementById("FrameCatNamespan").style.display = ""
    
        }else{
            document.getElementById("FrameCatNamespan").style.display = "none"
        }
    
        if(Name == ""){
            document.getElementById("FrameCatNamespan2").style.display = ""
    
        }else{
            document.getElementById("FrameCatNamespan2").style.display = "none"
        }
    }
    

}