
firestore = firebase.firestore();
var docToBeUpdate;
var Sr = 1
var businessTypeEnglishInput;
var businessTypeMarathiInput;
var userBusinessType;
var bydefaultLastDoc;
var BusinessByproff;
const businessTypeEnglish = [  "All",  "Small Business Owner",  "Politician",  "Mobile Shop",  "Gym",  "Beauty Parlor",  "Electronics Shop",  "LIC Agent",  "Cosmetic Shop",  "Builder",  "Men's Salon",  "Lawyer",  "Jewellers",  "Bank",  "Cloths Shop",  "Furniture Shop",  "Restaurant",  "Dry Cleaners",  "Food Center",  "Day Care",  "Fruit Seller",  "Pre Primary School",  "School Colleges",  "Bakery",  "Dairy",  "Coaching Classes",  "Grocery Shop",  "Book Shop",  "Supermarket",  "Two Wheeler Garage",  "Doctors",  "Medical",  "Women Entrepreneur",  "Women Home Business",  "Taxi Driver",  "Yoga Classes",  "Organizations",  "Home Business",  "NGO",  "Painter",  "Electrician",  "Snack Center",  "Tea Center",  "Carpenter",  "Computer Hardware",  "Mobile Repair Shop",  "Cycle Shop",  "IT Services",  "Utensil Shop",  "Chicken & Mutton Shop",  "Surveillance & Security",  "Water Supply",  "Sweet Mart",  "Tiles Dealers",  "Other"]
const businessTypemarathi = [ "All", "छोटे व्यावसायिक", "राजकीय व्यक्ति", "मोबाइल दुकानदार", "जिम", "ब्युटिपार्लर", "इलेक्ट्रोनिक दुकानदार", "एलआयसी एजेंट", "कॉस्मेटिक शॉप", "बिल्डर", "मेन्स सलून", "वकील", "ज्वेलर्स", "बँक", "कापड दुकानदार", "फर्निचर शॉप", "रेस्टोरंट", "ड्रायक्लीनर", "मेस/खानावळ", "डे केअर", "फळविक्रेता", "प्री प्रायमरी स्कूल", "शाळा-कॉलेज", "बेकरी", "दूध डेयरी", "कोचिंग क्लासेस", "किराणा दुकानदार", "बूकशॉप", "सुपरमार्केट", "टू व्हीलर", "डॉक्टर", "मेडिकल", "महिला उद्योजक", "महिला गृह उद्योग", "टॅक्सी ड्रायवर", "योगा क्लासेस", "संघटना", "गृह उद्योग", "एन. जी. ओ.", "पेंटर", "इलेक्ट्रिशियन", "स्नॅक्स सेंटर", "टी सेंटर", "सुतार", "कम्प्युटर हार्डवेअर", "मोबईल दुरुस्ती शॉप", "सायकल शॉप", "आय टी सर्विसेस", "भांडी दुकान", "चिकन आणि मटन शॉप", "सर्वल्हेअन्स आणि सेक्युरिटी", "वॉटर सप्लाय", "मिठाई दुकान", "टाइल्स डीलर", "इतर" ] 
var result = [];
var i=0;


function getAllSubstrings(str) {

    // 	for (let j = 1 ; j < str.length + 1; j++) {
    // 	  result.push(str.slice(i, j));
    
    // 	}
    // 	for (let j = str.indexOf(" ")+2 ; j < str.length + 1; j++) {
    // 	  result.push(str.slice(str.indexOf(" ")+1, j));
    //   }
    // result.push(str);
    for (let j = 1 ; j < str.length + 1; j++) {
        result.push(str.slice(i, j));
    }
    for(let i = 0 ; i<str.length ;i++){
     
        if(str[i] == " "){
    
        for (let j = i+2 ; j < str.length + 1; j++) {
            result.push(str.slice(i+1, j));
        }
    
        }
    }
    return result;
    
}



getProffList();
function getProffList(params) {
    businessTypeEnglish.forEach((doc) => {

        $("#planlist").append(`<option value="${doc}">${doc}</option>
        `)
    })
}


GetUserList();
function GetUserList(params) {
  FilterFlag = "Default"
  search = 'default';
    UserList = [] ;
    UserList_index = 0;
    data = [];
    dataindex = 0;
    paginationindex=0
    CurrentPage=0;
    DataTObeExport = [];
    DataTObeExportIndex = 0;
    Sr = 1;

    // Build Report 
firestore.collection("Businesses").orderBy("userName","asc").get().then((querySnapshot) => {

  querySnapshot.forEach((doc) => {
      ExportUserName = 'All_Users'; 

      // USER NAME,USER CONTACT,ADDRESS,BUSINESS TYPE,BUSINESS NAME,BUSINESS CONATCT,LOGO,WEBSITE,
      DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().userPhoneNumber,doc.data().userBusinessType,doc.data().address,doc.data().businessTypeEnglish,doc.data().businessName,doc.data().mobNumber, `${doc.data().haveLogo== true ? "Yes":"No" }`,`${doc.data().haveWebsite== true ? "Yes":"No" }`];

  });
}).then(()=>{
  document.getElementById("SubadminBody").style.display = "";
  document.getElementById("SubAdminBodyAnimation").style.display = "none";

  document.getElementById("SubAdminTbodyAnimation").style.display = "none";
})  

// Build Report 
    
    firestore.collection("Businesses").orderBy("date","desc").limit(10).get().then((querySnapshot) => {

      bydefaultLastDoc = querySnapshot.docs[querySnapshot.docs.length-1]
      if( querySnapshot.docs.length == 0 ){
        document.querySelector('#nextButton').disabled = true;

        document.getElementById("SubadminBody").style.display = "none";
        document.getElementById("SubAdminTbodyAnimation").style.display = "flex";
        
         CurrentPage--;
        paginationindex--;
         (swal("There is no Record Found"))
      
      }else{
        while(document.getElementById("UsersTableBody").childElementCount!==0){
          document.getElementById("UsersTableBody").firstChild.remove();
      }   
      querySnapshot.forEach((doc) => {
          console.log("doc.data()",doc.data())
          data[dataindex++] = [doc.id,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
          // document.getElementById(`${doc.id}`).checked = doc.data().status
          // doc.data() is never undefined for query doc snapshots
          $("#UsersTableBody").append(`<tr>

          <td>${Sr++}</td>
          <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
            <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
          </td>
          <td id="SubAdminEmail">${doc.data().businessName}</td> 
          <td id="SubAdminPassword">${doc.data().email}</td>
          <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
          <td id="SubAdminPassword">${doc.data().mobNumber}</td>
          
 
          <td>
            <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
              

            </div>
          </td>
        </tr>`)

          // if(doc.data().status === true){
              
          //     document.getElementById(`${doc.id}Switch`).checked = true
          // }else{
          //     document.getElementById(`${doc.id}Switch`).checked = false
          // }
      });
      }
 

        
       
    }).then(()=>{
         UserList[UserList_index++] = data;
         paginationindex++;
         CurrentPage++;
   
    })    
}

function NextBusinessList(params) {
    
     if(FilterFlag == "logo"){

        document.getElementById("previousButton").disabled = false; 
    
        data = [];
        dataindex = 0;
     
        if(paginationindex == CurrentPage ){
    
    
            firestore.collection("Businesses").where("haveLogo","==",Selected_Plan == "Yes"? true : false).orderBy("date","desc").startAfter(BusinessByproff).limit(10).get().then((querySnapshot) => {
                // BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
    
                if( querySnapshot.docs.length == 0 ){
                    document.querySelector('#nextButton').disabled = true;
                    
                     CurrentPage--;
                    paginationindex--;
                     (swal("There is no Record Found"))
                  
                }else{
                    while(document.getElementById("UsersTableBody").childElementCount!==0){
      
                        document.getElementById("UsersTableBody").firstChild.remove();
                    }
                    BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
                    querySnapshot.forEach((doc) => {
                        console.log("doc.data()",doc.data())
                        data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
                        // document.getElementById(`${doc.id}`).checked = doc.data().status
                        // doc.data() is never undefined for query doc snapshots
                        $("#UsersTableBody").append(`<tr>

                        <td>${Sr++}</td>
                        <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
                        </td>
                        <td id="SubAdminEmail">${doc.data().businessName}</td> 
                        <td id="SubAdminPassword">${doc.data().email}</td>
                        <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
                        <td id="SubAdminPassword">${doc.data().mobNumber}</td>
                        
               
                        <td>
                          <div style="display: flex;justify-content: space-evenly;">
                            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                            
              
                          </div>
                        </td>
                      </tr>`)
            
                        // if(doc.data().status === true){
                            
                        //     document.getElementById(`${doc.id}Switch`).checked = true
                        // }else{
                        //     document.getElementById(`${doc.id}Switch`).checked = false
                        // }
                    });
                }
             
            }).then(()=>{
                UserList[UserList_index++] = data;
                paginationindex++;
                CurrentPage++;
        console.log(UserList);
            })    
    
        }else{
    
            while(document.getElementById("UsersTableBody").childElementCount!==0){
      
              document.getElementById("UsersTableBody").firstChild.remove();
          }
              UserList[CurrentPage].forEach((doc) => {
                  // doc.data() is never undefined for query doc snapshots
                  //console.log(doc.id, " => ", doc.data());
      
                  $("#UsersTableBody").append(`<tr>
                  <td >${doc[6]}</td>
                  <td id=${doc[4]} onclick="redirectToUserProfile(this.id)">
                    <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
                  </td>
                  <td id="SubAdminEmail">${doc[2]}</td> 
                  <td id="SubAdminPassword">${doc[3]}</td>
                  <td id="SubAdminPassword">${doc[4]}</td>
                  <td id="SubAdminPassword">${doc[5]}</td>
                  <td>
                    <div style="display: flex;justify-content: space-evenly;">
                    <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
      
                    </div>
                  </td>
                </tr>`)
              });
      
              CurrentPage++;
      
      
          }
      
      }else if(FilterFlag == "profession"){

    document.getElementById("previousButton").disabled = false; 

    data = [];
    dataindex = 0;
 
    if(paginationindex == CurrentPage ){


        firestore.collection("Businesses").where("businessTypeEnglish","==",Selected_Plan).orderBy("date","desc").startAfter(BusinessByproff).limit(10).get().then((querySnapshot) => {
            // BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]

            if( querySnapshot.docs.length == 0 ){
                document.querySelector('#nextButton').disabled = true;
                
                 CurrentPage--;
                paginationindex--;
                 (swal("There is no Record Found"))
              
            }else{
                while(document.getElementById("UsersTableBody").childElementCount!==0){
  
                    document.getElementById("UsersTableBody").firstChild.remove();
                }
                BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
                querySnapshot.forEach((doc) => {
                    console.log("doc.data()",doc.data())
                    data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
                    // document.getElementById(`${doc.id}`).checked = doc.data().status
                    // doc.data() is never undefined for query doc snapshots
                    $("#UsersTableBody").append(`<tr>

                        <td>${Sr++}</td>
                        <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
                        </td>
                        <td id="SubAdminEmail">${doc.data().businessName}</td> 
                        <td id="SubAdminPassword">${doc.data().email}</td>
                        <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
                        <td id="SubAdminPassword">${doc.data().mobNumber}</td>
                        
               
                        <td>
                          <div style="display: flex;justify-content: space-evenly;">
                            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                            
              
                          </div>
                        </td>
                      </tr>`)
        
                    // if(doc.data().status === true){
                        
                    //     document.getElementById(`${doc.id}Switch`).checked = true
                    // }else{
                    //     document.getElementById(`${doc.id}Switch`).checked = false
                    // }
                });
            }
         
        }).then(()=>{
            UserList[UserList_index++] = data;
            paginationindex++;
            CurrentPage++;
    console.log(UserList);
        })    

    }else{

        while(document.getElementById("UsersTableBody").childElementCount!==0){
  
          document.getElementById("UsersTableBody").firstChild.remove();
      }
          UserList[CurrentPage].forEach((doc) => {
              // doc.data() is never undefined for query doc snapshots
              //console.log(doc.id, " => ", doc.data());
  
              $("#UsersTableBody").append(`<tr>
              <td >${doc[6]}</td>
              <td id=${doc[4]} onclick="redirectToUserProfile(this.id)">
                <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
              </td>
              <td id="SubAdminEmail">${doc[2]}</td> 
              <td id="SubAdminPassword">${doc[3]}</td>
              <td id="SubAdminPassword">${doc[4]}</td>
              <td id="SubAdminPassword">${doc[5]}</td>
              <td>
                <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
  
                </div>
              </td>
            </tr>`)
          });
  
          CurrentPage++;
  
  
      }
  
      }else if(FilterFlag == "website"){

          document.getElementById("previousButton").disabled = false; 
      
          data = [];
          dataindex = 0;
      
          if(paginationindex == CurrentPage ){
      
      
              firestore.collection("Businesses").where("haveWebsite","==",Selected_Plan == "Yes"? true : false).orderBy("date","desc").startAfter(BusinessByproff).limit(10).get().then((querySnapshot) => {
                  // BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
      
                  if( querySnapshot.docs.length == 0 ){
                      document.querySelector('#nextButton').disabled = true;
                      
                      CurrentPage--;
                      paginationindex--;
                      (swal("There is no Record Found"))
                    
                  }else{
                      while(document.getElementById("UsersTableBody").childElementCount!==0){
        
                          document.getElementById("UsersTableBody").firstChild.remove();
                      }
                      BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
                      querySnapshot.forEach((doc) => {
                          console.log("doc.data()",doc.data())
                          data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
                          // document.getElementById(`${doc.id}`).checked = doc.data().status
                          // doc.data() is never undefined for query doc snapshots
                          $("#UsersTableBody").append(`<tr>

                          <td>${Sr++}</td>
                          <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                            <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
                          </td>
                          <td id="SubAdminEmail">${doc.data().businessName}</td> 
                          <td id="SubAdminPassword">${doc.data().email}</td>
                          <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
                          <td id="SubAdminPassword">${doc.data().mobNumber}</td>
                          
                 
                          <td>
                            <div style="display: flex;justify-content: space-evenly;">
                              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                              
                
                            </div>
                          </td>
                        </tr>`)
              
                          // if(doc.data().status === true){
                              
                          //     document.getElementById(`${doc.id}Switch`).checked = true
                          // }else{
                          //     document.getElementById(`${doc.id}Switch`).checked = false
                          // }
                      });
                  }
              
              }).then(()=>{
                  UserList[UserList_index++] = data;
                  paginationindex++;
                  CurrentPage++;
          console.log(UserList);
              })    
      
          }else{
      
              while(document.getElementById("UsersTableBody").childElementCount!==0){
        
                document.getElementById("UsersTableBody").firstChild.remove();
            }
                UserList[CurrentPage].forEach((doc) => {
                    // doc.data() is never undefined for query doc snapshots
                    //console.log(doc.id, " => ", doc.data());
        
                    $("#UsersTableBody").append(`<tr>
                    <td >${doc[6]}</td>
                    <td id=${doc[4]} onclick="redirectToUserProfile(this.id)">
                      <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
                    </td>
                    <td id="SubAdminEmail">${doc[2]}</td> 
                    <td id="SubAdminPassword">${doc[3]}</td>
                    <td id="SubAdminPassword">${doc[4]}</td>
                    <td id="SubAdminPassword">${doc[5]}</td>
                    <td>
                      <div style="display: flex;justify-content: space-evenly;">
                      <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
        
                      </div>
                    </td>
                  </tr>`)
                });
        
                CurrentPage++;
        
        
            }
        
      }else if(FilterFlag == "proff_Logo"){

        document.getElementById("previousButton").disabled = false; 
    
        data = [];
        dataindex = 0;
    
        if(paginationindex == CurrentPage ){
    
    
            firestore.collection("Businesses").where("businessTypeEnglish","==",Selected_Plan1).where("haveLogo","==",Selected_Plan2).orderBy("date","desc").startAfter(BusinessByproff).limit(1).get().then((querySnapshot) => {
                // BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
    
                if( querySnapshot.docs.length == 0 ){
                    document.querySelector('#nextButton').disabled = true;
                    
                    CurrentPage--;
                    paginationindex--;
                    (swal("There is no Record Found"))
                  
                }else{
                    while(document.getElementById("UsersTableBody").childElementCount!==0){
      
                        document.getElementById("UsersTableBody").firstChild.remove();
                    }
                    BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
                    querySnapshot.forEach((doc) => {
                        console.log("doc.data()",doc.data())
                        data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
                        // document.getElementById(`${doc.id}`).checked = doc.data().status
                        // doc.data() is never undefined for query doc snapshots
                        $("#UsersTableBody").append(`<tr>

                        <td>${Sr++}</td>
                        <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
                        </td>
                        <td id="SubAdminEmail">${doc.data().businessName}</td> 
                        <td id="SubAdminPassword">${doc.data().email}</td>
                        <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
                        <td id="SubAdminPassword">${doc.data().mobNumber}</td>
                        
               
                        <td>
                          <div style="display: flex;justify-content: space-evenly;">
                            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                            
              
                          </div>
                        </td>
                      </tr>`)
            
                        // if(doc.data().status === true){
                            
                        //     document.getElementById(`${doc.id}Switch`).checked = true
                        // }else{
                        //     document.getElementById(`${doc.id}Switch`).checked = false
                        // }
                    });
                }
            
            }).then(()=>{
                UserList[UserList_index++] = data;
                paginationindex++;
                CurrentPage++;
        console.log(UserList);
            })    
    
        }else{
    
            while(document.getElementById("UsersTableBody").childElementCount!==0){
      
              document.getElementById("UsersTableBody").firstChild.remove();
          }
              UserList[CurrentPage].forEach((doc) => {
                  // doc.data() is never undefined for query doc snapshots
                  //console.log(doc.id, " => ", doc.data());
      
                  $("#UsersTableBody").append(`<tr>
                  <td >${doc[6]}</td>
                  <td id=${doc[4]} onclick="redirectToUserProfile(this.id)">
                    <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
                  </td>
                  <td id="SubAdminEmail">${doc[2]}</td> 
                  <td id="SubAdminPassword">${doc[3]}</td>
                  <td id="SubAdminPassword">${doc[4]}</td>
                  <td id="SubAdminPassword">${doc[5]}</td>
                  <td>
                    <div style="display: flex;justify-content: space-evenly;">
                    <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
      
                    </div>
                  </td>
                </tr>`)
              });
      
              CurrentPage++;
      
      
          }
      
      }else if(FilterFlag == "proff_Web"){

        document.getElementById("previousButton").disabled = false; 
    
        data = [];
        dataindex = 0;
    
        if(paginationindex == CurrentPage ){
    
    
            firestore.collection("Businesses").where("businessTypeEnglish","==",Selected_Plan1).where("haveWebsite","==",Selected_Plan2).orderBy("date","desc").startAfter(BusinessByproff).limit(1).get().then((querySnapshot) => {
                // BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
    
                if( querySnapshot.docs.length == 0 ){
                    document.querySelector('#nextButton').disabled = true;
                    
                    CurrentPage--;
                    paginationindex--;
                    (swal("There is no Record Found"))
                  
                }else{
                    while(document.getElementById("UsersTableBody").childElementCount!==0){
      
                        document.getElementById("UsersTableBody").firstChild.remove();
                    }
                    BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
                    querySnapshot.forEach((doc) => {
                        console.log("doc.data()",doc.data())
                        data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
                        // document.getElementById(`${doc.id}`).checked = doc.data().status
                        // doc.data() is never undefined for query doc snapshots
                        $("#UsersTableBody").append(`<tr>

                        <td>${Sr++}</td>
                        <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
                        </td>
                        <td id="SubAdminEmail">${doc.data().businessName}</td> 
                        <td id="SubAdminPassword">${doc.data().email}</td>
                        <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
                        <td id="SubAdminPassword">${doc.data().mobNumber}</td>
                        
               
                        <td>
                          <div style="display: flex;justify-content: space-evenly;">
                            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                            
              
                          </div>
                        </td>
                      </tr>`)
            
                        // if(doc.data().status === true){
                            
                        //     document.getElementById(`${doc.id}Switch`).checked = true
                        // }else{
                        //     document.getElementById(`${doc.id}Switch`).checked = false
                        // }
                    });
                }
            
            }).then(()=>{
                UserList[UserList_index++] = data;
                paginationindex++;
                CurrentPage++;
        console.log(UserList);
            })    
    
        }else{
    
            while(document.getElementById("UsersTableBody").childElementCount!==0){
      
              document.getElementById("UsersTableBody").firstChild.remove();
          }
              UserList[CurrentPage].forEach((doc) => {
                  // doc.data() is never undefined for query doc snapshots
                  //console.log(doc.id, " => ", doc.data());
      
                  $("#UsersTableBody").append(`<tr>
                  <td >${doc[6]}</td>
                  <td id=${doc[4]} onclick="redirectToUserProfile(this.id)">
                    <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
                  </td>
                  <td id="SubAdminEmail">${doc[2]}</td> 
                  <td id="SubAdminPassword">${doc[3]}</td>
                  <td id="SubAdminPassword">${doc[4]}</td>
                  <td id="SubAdminPassword">${doc[5]}</td>
                  <td>
                    <div style="display: flex;justify-content: space-evenly;">
                    <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
      
                    </div>
                  </td>
                </tr>`)
              });
      
              CurrentPage++;
      
      
          }
      
      }else if(FilterFlag == "proff_logo_Web"){

        document.getElementById("previousButton").disabled = false; 
    
        data = [];
        dataindex = 0;
    
        if(paginationindex == CurrentPage ){
    
    
            firestore.collection("Businesses").where("businessTypeEnglish","==",Selected_Plan1).where("haveWebsite","==",Selected_Plan2).where("haveLogo","==",Selected_Plan3).orderBy("date","desc").startAfter(BusinessByproff).limit(1).get().then((querySnapshot) => {
                // BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
    
                if( querySnapshot.docs.length == 0 ){
                    document.querySelector('#nextButton').disabled = true;
                    
                    CurrentPage--;
                    paginationindex--;
                    (swal("There is no Record Found"))
                  
                }else{
                    while(document.getElementById("UsersTableBody").childElementCount!==0){
      
                        document.getElementById("UsersTableBody").firstChild.remove();
                    }
                    BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
                    querySnapshot.forEach((doc) => {
                        console.log("doc.data()",doc.data())
                        data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
                        // document.getElementById(`${doc.id}`).checked = doc.data().status
                        // doc.data() is never undefined for query doc snapshots
                        $("#UsersTableBody").append(`<tr>

                        <td>${Sr++}</td>
                        <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
                        </td>
                        <td id="SubAdminEmail">${doc.data().businessName}</td> 
                        <td id="SubAdminPassword">${doc.data().email}</td>
                        <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
                        <td id="SubAdminPassword">${doc.data().mobNumber}</td>
                        
               
                        <td>
                          <div style="display: flex;justify-content: space-evenly;">
                            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                            
              
                          </div>
                        </td>
                      </tr>`)
            
                        // if(doc.data().status === true){
                            
                        //     document.getElementById(`${doc.id}Switch`).checked = true
                        // }else{
                        //     document.getElementById(`${doc.id}Switch`).checked = false
                        // }
                    });
                }
            
            }).then(()=>{
                UserList[UserList_index++] = data;
                paginationindex++;
                CurrentPage++;
        console.log(UserList);
            })    
    
        }else{
    
            while(document.getElementById("UsersTableBody").childElementCount!==0){
      
              document.getElementById("UsersTableBody").firstChild.remove();
          }
              UserList[CurrentPage].forEach((doc) => {
                  // doc.data() is never undefined for query doc snapshots
                  //console.log(doc.id, " => ", doc.data());
      
                  $("#UsersTableBody").append(`<tr>
                  <td >${doc[6]}</td>
                  <td id=${doc[4]} onclick="redirectToUserProfile(this.id)">
                    <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
                  </td>
                  <td id="SubAdminEmail">${doc[2]}</td> 
                  <td id="SubAdminPassword">${doc[3]}</td>
                  <td id="SubAdminPassword">${doc[4]}</td>
                  <td id="SubAdminPassword">${doc[5]}</td>
                  <td>
                    <div style="display: flex;justify-content: space-evenly;">
                    <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
      
                    </div>
                  </td>
                </tr>`)
              });
      
              CurrentPage++;
      
      
          }
      
    }
  else{
    document.getElementById("previousButton").disabled = false; 

    data = [];
    dataindex = 0;
 
    
    if(paginationindex == CurrentPage ){

        firestore.collection("Businesses").orderBy("date","desc").startAfter(bydefaultLastDoc).limit(10).get().then((querySnapshot) => {

        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
        }else{

            while(document.getElementById("UsersTableBody").childElementCount!==0){

                document.getElementById("UsersTableBody").firstChild.remove();
            }
    
            bydefaultLastDoc = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
                data[dataindex++] = [doc.id,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
    
                $("#UsersTableBody").append(`<tr>

                <td>${Sr++}</td>
                <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                  <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
                </td>
                <td id="SubAdminEmail">${doc.data().businessName}</td> 
                <td id="SubAdminPassword">${doc.data().email}</td>
                <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
                <td id="SubAdminPassword">${doc.data().mobNumber}</td>
                
       
                <td>
                  <div style="display: flex;justify-content: space-evenly;">
                    <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                    
      
                  </div>
                </td>
              </tr>`)
            });
            
        }

        }).then(()=>{
            UserList[UserList_index++] = data;
            paginationindex++;
            CurrentPage++;
        })

    }else{

      while(document.getElementById("UsersTableBody").childElementCount!==0){

        document.getElementById("UsersTableBody").firstChild.remove();
    }
        UserList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

       
    
            $("#UsersTableBody").append(`<tr>
                  <td >${doc[6]}</td>
                  <td id=${doc[4]} onclick="redirectToUserProfile(this.id)">
                    <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
                  </td>
                  <td id="SubAdminEmail">${doc[2]}</td> 
                  <td id="SubAdminPassword">${doc[3]}</td>
                  <td id="SubAdminPassword">${doc[4]}</td>
                  <td id="SubAdminPassword">${doc[5]}</td>
                  <td>
                    <div style="display: flex;justify-content: space-evenly;">
                    <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>
      
                    </div>
                  </td>
                </tr>`)
        });

        CurrentPage++;


    }
  }
   
}

function Previous_NextAdminList(params) {

    document.getElementById("nextButton").disabled = false; 

    if(CurrentPage!==1){

        while(document.getElementById("UsersTableBody").childElementCount!==0){ 
            
            document.getElementById("UsersTableBody").firstChild.remove();
        }
    
        CurrentPage--;
        console.log("Data",CurrentPage,paginationindex);
        UserList[CurrentPage-1].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());
    
            $("#UsersTableBody").append(`<tr>
            <td >${doc[6]}</td>
            <td id=${doc[4]} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc[1]}</strong>
            </td>
            <td id="SubAdminEmail">${doc[2]}</td> 
            <td id="SubAdminPassword">${doc[3]}</td>
            <td id="SubAdminPassword">${doc[4]}</td>
            <td id="SubAdminPassword">${doc[5]}</td>
            <td>
              <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc[0]}" onclick="openUserModal(this.id)" >Edit</button>

              </div>
            </td>
          </tr>`)
        });
        
    }else{
        document.getElementById("previousButton").disabled = true; 
    }


    
}


function GetUSerListByproff(params) {
    Selected_Plan = params;
    FilterFlag = "profession";
    search = "profession";
    UserList = [] ;
    UserList_index = 0;
    data = [];
    dataindex = 0;
    paginationindex=0
    CurrentPage=0;
    DataTObeExport = [];
    DataTObeExportIndex = 0;
    Sr = 1;
    document.getElementById("nextButton").disabled = false
    document.getElementById("previousButton").disabled = false
    while(document.getElementById("UsersTableBody").childElementCount!==0){
  
      document.getElementById("UsersTableBody").firstChild.remove();
  }

    if(params !== "All"){
    // Build Report 
    firestore.collection("Businesses").where("businessTypeEnglish","==",params).orderBy("userName","asc").get().then((querySnapshot) => {
      
   
      querySnapshot.forEach((doc) => {
          ExportUserName = 'By_Profession'; 
    
          // USER NAME,USER CONTACT,ADDRESS,BUSINESS TYPE,BUSINESS NAME,BUSINESS CONATCT,LOGO,WEBSITE,
          DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().userPhoneNumber,doc.data().userBusinessType,doc.data().address,doc.data().businessTypeEnglish,doc.data().businessName,doc.data().mobNumber, `${doc.data().haveLogo== true ? "Yes":"No" }`,`${doc.data().haveWebsite== true ? "Yes":"No" }`];
    
      });
    }).then(()=>{
      console.log("DataTObeExport",DataTObeExport)
      document.getElementById("SubadminBody").style.display = "";
      document.getElementById("SubAdminBodyAnimation").style.display = "none";
    }) 
    
  
    // Build Report 


        firestore.collection("Businesses").where("businessTypeEnglish","==",params).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
          BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
          if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;

            document.getElementById("SubadminBody").style.display = "none";
            document.getElementById("SubAdminTbodyAnimation").style.display = "flex";
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
          }else{
            document.getElementById("SubadminBody").style.display = "";
            document.getElementById("SubAdminTbodyAnimation").style.display = "none";
              querySnapshot.forEach((doc) => {
    
                data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
                // document.getElementById(`${doc.id}`).checked = doc.data().status
                // doc.data() is never undefined for query doc snapshots
                $("#UsersTableBody").append(`<tr>

                <td>${Sr++}</td>
                <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                  <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
                </td>
                <td id="SubAdminEmail">${doc.data().businessName}</td> 
                <td id="SubAdminPassword">${doc.data().email}</td>
                <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
                <td id="SubAdminPassword">${doc.data().mobNumber}</td>
                
       
                <td>
                  <div style="display: flex;justify-content: space-evenly;">
                    <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                    
      
                  </div>
                </td>
              </tr>`)
        
                // if(doc.data().status === true){
                    
                //     document.getElementById(`${doc.id}Switch`).checked = true
                // }else{
                //     document.getElementById(`${doc.id}Switch`).checked = false
                // }
            });
          }
          
      }).then(()=>{
          UserList[UserList_index++] = data;
          paginationindex++;
          CurrentPage++;
          console.log(UserList);

      })    
    }else{
  
      GetUserList();
  
    }
  
        
  
  

}


function GetUSerListBylogo(params) {
    Selected_Plan = params;
    FilterFlag = "logo";
    search = "logo";
    UserList = [] ;
    UserList_index = 0;
    data = [];
    dataindex = 0;
    paginationindex=0
    CurrentPage=0;
    DataTObeExport = [];
    DataTObeExportIndex = 0;
    Sr = 1;
    
    document.getElementById("nextButton").disabled = false
    document.getElementById("previousButton").disabled = false
    
  
  
    if(params !== "ALL"){
    // Build Report 
    firestore.collection("Businesses").where("haveLogo","==",params == "Yes"? true : false).orderBy("userName","asc").get().then((querySnapshot) => {
      
      querySnapshot.forEach((doc) => {
          ExportUserName = 'By_Logo'; 
    
          // USER NAME,USER CONTACT,ADDRESS,BUSINESS TYPE,BUSINESS NAME,BUSINESS CONATCT,LOGO,WEBSITE,
          DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().userPhoneNumber,doc.data().userBusinessType,doc.data().address,doc.data().businessTypeEnglish,doc.data().businessName,doc.data().mobNumber, `${doc.data().haveLogo== true ? "Yes":"No" }`,`${doc.data().haveWebsite== true ? "Yes":"No" }`];
    
      });
    }).then(()=>{
      document.getElementById("SubadminBody").style.display = "";
      document.getElementById("SubAdminBodyAnimation").style.display = "none";
    }) 
  
    // Build Report 

        firestore.collection("Businesses").where("haveLogo","==",params == "Yes"? true : false).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
          BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]

          if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;

            document.getElementById("SubadminBody").style.display = "none";
            document.getElementById("SubAdminTbodyAnimation").style.display = "flex";
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
          }else{
            while(document.getElementById("UsersTableBody").childElementCount!==0){
  
              document.getElementById("UsersTableBody").firstChild.remove();
          }
            querySnapshot.forEach((doc) => {
          
              data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
              // document.getElementById(`${doc.id}`).checked = doc.data().status
              // doc.data() is never undefined for query doc snapshots
              $("#UsersTableBody").append(`<tr>

              <td>${Sr++}</td>
              <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
              </td>
              <td id="SubAdminEmail">${doc.data().businessName}</td> 
              <td id="SubAdminPassword">${doc.data().email}</td>
              <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
              <td id="SubAdminPassword">${doc.data().mobNumber}</td>
              
     
              <td>
                <div style="display: flex;justify-content: space-evenly;">
                  <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                  
    
                </div>
              </td>
            </tr>`)
  
              // if(doc.data().status === true){
                  
              //     document.getElementById(`${doc.id}Switch`).checked = true
              // }else{
              //     document.getElementById(`${doc.id}Switch`).checked = false
              // }
          });
          }
         
      }).then(()=>{
          UserList[UserList_index++] = data;
          paginationindex++;
          CurrentPage++;
          console.log(UserList);
      })    
    }else{
  
      GetUserList();
  
    }
  
        
  
  

}

function GetUSerListByWeb(params) {
    Selected_Plan = params;
    FilterFlag = "website";
    search = "website";
    UserList = [] ;
    UserList_index = 0;
    data = [];
    dataindex = 0;
    paginationindex=0
    CurrentPage=0;
    DataTObeExport = [];
    DataTObeExportIndex = 0;
    Sr = 1;
    document.getElementById("nextButton").disabled = false
    document.getElementById("previousButton").disabled = false
    while(document.getElementById("UsersTableBody").childElementCount!==0){
  
      document.getElementById("UsersTableBody").firstChild.remove();
  }
    
  
  
    if(params !== "ALL"){
    // Build Report 
    firestore.collection("Businesses").where("haveWebsite","==",params == "Yes"? true : false).orderBy("date","desc").orderBy("userName","asc").get().then((querySnapshot) => {
     
      querySnapshot.forEach((doc) => {
          ExportUserName = 'By_Website'; 
    
          // USER NAME,USER CONTACT,ADDRESS,BUSINESS TYPE,BUSINESS NAME,BUSINESS CONATCT,LOGO,WEBSITE,
          DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().userPhoneNumber,doc.data().userBusinessType,doc.data().address,doc.data().businessTypeEnglish,doc.data().businessName,doc.data().mobNumber, `${doc.data().haveLogo== true ? "Yes":"No" }`,`${doc.data().haveWebsite== true ? "Yes":"No" }`];
    
      });
    }).then(()=>{
      document.getElementById("SubadminBody").style.display = "";
      document.getElementById("SubAdminBodyAnimation").style.display = "none";
    }) 
  
    // Build Report 
  console.log(params)
        firestore.collection("Businesses").where("haveWebsite","==",params == "Yes"? true : false).orderBy("date","desc").limit(10).get().then((querySnapshot) => {
          BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
          if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;

            document.getElementById("SubadminBody").style.display = "none";
            document.getElementById("SubAdminTbodyAnimation").style.display = "flex";
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
          }else{
            querySnapshot.forEach((doc) => {
              console.log("doc.data()",doc.data())
              data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
              // document.getElementById(`${doc.id}`).checked = doc.data().status
              // doc.data() is never undefined for query doc snapshots
              $("#UsersTableBody").append(`<tr>

              <td>${Sr++}</td>
              <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
                <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
              </td>
              <td id="SubAdminEmail">${doc.data().businessName}</td> 
              <td id="SubAdminPassword">${doc.data().email}</td>
              <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
              <td id="SubAdminPassword">${doc.data().mobNumber}</td>
              
     
              <td>
                <div style="display: flex;justify-content: space-evenly;">
                  <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                  
    
                </div>
              </td>
            </tr>`)
  
              // if(doc.data().status === true){
                  
              //     document.getElementById(`${doc.id}Switch`).checked = true
              // }else{
              //     document.getElementById(`${doc.id}Switch`).checked = false
              // }
          });
          }
        
        
      }).then(()=>{
          UserList[UserList_index++] = data;
          paginationindex++;
          CurrentPage++;
          console.log(UserList);
      })    
    }else{
  
      GetUserList();
  
    }
  
        
  
  

}

function proff_Logo(params,params2) {
  var proffInput = document.getElementById("planlistinput").value;
  var logoInput = document.getElementById("logoFilter").value; 
  Selected_Plan1 = proffInput;
  Selected_Plan2 = logoInput == "Yes" ? true : false
  FilterFlag = "proff_Logo";
  search = "proff_Logo";
  UserList = [] ;
  UserList_index = 0;
  data = [];
  dataindex = 0;
  paginationindex=0
  CurrentPage=0;
  DataTObeExport = [];
  DataTObeExportIndex = 0;
  Sr = 1;
  document.getElementById("nextButton").disabled = false
  document.getElementById("previousButton").disabled = false

  
  while(document.getElementById("UsersTableBody").childElementCount!==0){

    document.getElementById("UsersTableBody").firstChild.remove();
  }

  if(params !== "ALL"){
  // Build Report 
  firestore.collection("Businesses").where("businessTypeEnglish","==",proffInput).where("haveLogo","==",logoInput == "Yes" ? true : false).orderBy("date","desc").orderBy("userName","asc").get().then((querySnapshot) => {
   
    querySnapshot.forEach((doc) => {
        ExportUserName = 'Profession with Logo'; 
  
        // USER NAME,USER CONTACT,ADDRESS,BUSINESS TYPE,BUSINESS NAME,BUSINESS CONATCT,LOGO,WEBSITE,
        DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().userPhoneNumber,doc.data().userBusinessType,doc.data().address,doc.data().businessTypeEnglish,doc.data().businessName,doc.data().mobNumber, `${doc.data().haveLogo== true ? "Yes":"No" }`,`${doc.data().haveWebsite== true ? "Yes":"No" }`];
  
    });
  }).then(()=>{
    document.getElementById("SubadminBody").style.display = "";
    document.getElementById("SubAdminBodyAnimation").style.display = "none";
  }) 

  // Build Report 

    firestore.collection("Businesses").where("businessTypeEnglish","==",proffInput).where("haveLogo","==",logoInput == "Yes" ? true : false).orderBy("date","desc").limit(1).get().then((querySnapshot) => {
        BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]

        if( querySnapshot.docs.length == 0 ){
          document.querySelector('#nextButton').disabled = true;

          document.getElementById("SubadminBody").style.display = "none";
          document.getElementById("SubAdminTbodyAnimation").style.display = "flex";
          
           CurrentPage--;
          paginationindex--;
           (swal("There is no Record Found"))
        
        }{
          querySnapshot.forEach((doc) => {
            console.log("doc.data()",doc.data())
            data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
            // document.getElementById(`${doc.id}`).checked = doc.data().status
            // doc.data() is never undefined for query doc snapshots
            $("#UsersTableBody").append(`<tr>

            <td>${Sr++}</td>
            <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().businessName}</td> 
            <td id="SubAdminPassword">${doc.data().email}</td>
            <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
            <td id="SubAdminPassword">${doc.data().mobNumber}</td>
            
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                
  
              </div>
            </td>
          </tr>`)

            // if(doc.data().status === true){
                
            //     document.getElementById(`${doc.id}Switch`).checked = true
            // }else{
            //     document.getElementById(`${doc.id}Switch`).checked = false
            // }
        });
        }
       
    }).then(()=>{
        UserList[UserList_index++] = data;
        paginationindex++;
        CurrentPage++;
        console.log(UserList);
    })  
  }else{

    GetUserList();

  }

}

function proff_Web(params,params2) {
  var proffInput = document.getElementById("planlistinput").value;
  var webInput = document.getElementById("webFilter").value; 
  Selected_Plan1 = proffInput;
  Selected_Plan2 = webInput == "Yes" ? true : false
  FilterFlag = "proff_Web";
  search = "proff_Web";
  UserList = [] ;
  UserList_index = 0;
  data = [];
  dataindex = 0;
  paginationindex=0
  CurrentPage=0;
  DataTObeExport = [];
  DataTObeExportIndex = 0;
  Sr = 1;
  document.getElementById("nextButton").disabled = false
  document.getElementById("previousButton").disabled = false
  
  while(document.getElementById("UsersTableBody").childElementCount!==0){

    document.getElementById("UsersTableBody").firstChild.remove();
  }

  if(params !== "ALL"){
  // Build Report 
  firestore.collection("Businesses").where("businessTypeEnglish","==",proffInput).where("haveWebsite","==",webInput == "Yes" ? true : false).orderBy("userName","asc").get().then((querySnapshot) => {
    ExportUserName = 'Profession with Web'; 
    querySnapshot.forEach((doc) => {
     
  
        // USER NAME,USER CONTACT,ADDRESS,BUSINESS TYPE,BUSINESS NAME,BUSINESS CONATCT,LOGO,WEBSITE,
        DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().userPhoneNumber,doc.data().userBusinessType,doc.data().address,doc.data().businessTypeEnglish,doc.data().businessName,doc.data().mobNumber, `${doc.data().haveLogo== true ? "Yes":"No" }`,`${doc.data().haveWebsite== true ? "Yes":"No" }`];
  
    });
  }).then(()=>{
    document.getElementById("SubadminBody").style.display = "";
    document.getElementById("SubAdminBodyAnimation").style.display = "none";
  }) 

  // Build Report 

    firestore.collection("Businesses").where("businessTypeEnglish","==",proffInput).where("haveWebsite","==",webInput == "Yes" ? true : false).orderBy("date","desc").limit(1).get().then((querySnapshot) => {
        BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
        if( querySnapshot.docs.length == 0 ){
          document.querySelector('#nextButton').disabled = true;

          document.getElementById("SubadminBody").style.display = "none";
          document.getElementById("SubAdminTbodyAnimation").style.display = "flex";
          
           CurrentPage--;
          paginationindex--;
           (swal("There is no Record Found"))
        
        }else{
          querySnapshot.forEach((doc) => {
       
            data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
            // document.getElementById(`${doc.id}`).checked = doc.data().status
            // doc.data() is never undefined for query doc snapshots
            $("#UsersTableBody").append(`<tr>

            <td>${Sr++}</td>
            <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().businessName}</td> 
            <td id="SubAdminPassword">${doc.data().email}</td>
            <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
            <td id="SubAdminPassword">${doc.data().mobNumber}</td>
            
   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                
  
              </div>
            </td>
          </tr>`)

            // if(doc.data().status === true){
                
            //     document.getElementById(`${doc.id}Switch`).checked = true
            // }else{
            //     document.getElementById(`${doc.id}Switch`).checked = false
            // }
        });
        }
       
    }).then(()=>{
        UserList[UserList_index++] = data;
        paginationindex++;
        CurrentPage++;
        console.log(UserList);
    })  
  }else{

    GetUserList();

  }

      



}

function proff_logo_Web(params,params2) {
  var proffInput = document.getElementById("planlistinput").value;
  var webInput = document.getElementById("webFilter").value; 
  var logoInput = document.getElementById("logoFilter").value;
  Selected_Plan1 = proffInput;
  Selected_Plan2 = webInput == "Yes" ? true : false
  Selected_Plan3 = logoInput == "Yes" ? true : false
  FilterFlag = "proff_logo_Web";
  search = "proff_logo_Web";
  UserList = [] ;
  UserList_index = 0;
  data = [];
  dataindex = 0;
  paginationindex=0
  CurrentPage=0;
  DataTObeExport = [];
  DataTObeExportIndex = 0;
  Sr = 1;

  document.getElementById("nextButton").disabled = false
  document.getElementById("previousButton").disabled = false
  
  while(document.getElementById("UsersTableBody").childElementCount!==0){

    document.getElementById("UsersTableBody").firstChild.remove();
  }

  if(params !== "ALL"){
  // Build Report 
  firestore.collection("Businesses").where("businessTypeEnglish","==",proffInput).where("haveWebsite","==",webInput == "Yes" ? true : false).where("haveLogo","==",logoInput == "Yes" ? true : false).orderBy("userName","asc").get().then((querySnapshot) => {
    
    querySnapshot.forEach((doc) => {
        ExportUserName = 'Profession with Logo &Website'; 
  
        // USER NAME,USER CONTACT,ADDRESS,BUSINESS TYPE,BUSINESS NAME,BUSINESS CONATCT,LOGO,WEBSITE,
        DataTObeExport[DataTObeExportIndex++] = [doc.data().userName,doc.data().userPhoneNumber,doc.data().userBusinessType,doc.data().address,doc.data().businessTypeEnglish,doc.data().businessName,doc.data().mobNumber, `${doc.data().haveLogo== true ? "Yes":"No" }`,`${doc.data().haveWebsite== true ? "Yes":"No" }`];
  
    });
  }).then(()=>{
    document.getElementById("SubadminBody").style.display = "";
    document.getElementById("SubAdminBodyAnimation").style.display = "none";
  }) 

  // Build Report 

    firestore.collection("Businesses").where("businessTypeEnglish","==",proffInput).where("haveWebsite","==",webInput == "Yes" ? true : false).where("haveLogo","==",logoInput == "Yes" ? true : false).orderBy("date","desc").limit(1).get().then((querySnapshot) => {
      BusinessByproff = querySnapshot.docs[querySnapshot.docs.length-1]
      if( querySnapshot.docs.length == 0 ){
        document.querySelector('#nextButton').disabled = true;

        document.getElementById("SubadminBody").style.display = "none";
        document.getElementById("SubAdminTbodyAnimation").style.display = "flex";
        
         CurrentPage--;
        paginationindex--;
         (swal("There is no Record Found"))
      
      }else{
        querySnapshot.forEach((doc) => {
          console.log("doc.data()",doc.data())
          data[dataindex++] = [doc.id,doc.data().userName,doc.data().businessName,doc.data().email,doc.data().mobNumber,`${Sr}`];
          // document.getElementById(`${doc.id}`).checked = doc.data().status
          // doc.data() is never undefined for query doc snapshots
          $("#UsersTableBody").append(`<tr>

          <td>${Sr++}</td>
          <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
            <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
          </td>
          <td id="SubAdminEmail">${doc.data().businessName}</td> 
          <td id="SubAdminPassword">${doc.data().email}</td>
          <td id="SubAdminPassword">${doc.data().userPhoneNumber}</td>
          <td id="SubAdminPassword">${doc.data().mobNumber}</td>
          
 
          <td>
            <div style="display: flex;justify-content: space-evenly;">
              <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
              

            </div>
          </td>
        </tr>`)

          // if(doc.data().status === true){
              
          //     document.getElementById(`${doc.id}Switch`).checked = true
          // }else{
          //     document.getElementById(`${doc.id}Switch`).checked = false
          // }
      });
      }
     
  }).then(()=>{
      UserList[UserList_index++] = data;
      paginationindex++;
      CurrentPage++;
      console.log(UserList);
  })

     
  }else{

    GetUserList();

  }

      



}



function resetBusinessList(params) {
    
}

function Image1Modal1(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#Previewforlogo')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}
function activeBusinessField(params) {
    
    if(params !== "Business"){
        userBusinessType = "Business"
        document.getElementById("bnameModalParent").style.display = "none"
        document.getElementById("BusinessTypeIdParent").style.display = "none"
        document.getElementById("bcontactParent").style.display = "none"
        document.getElementById("WebsiteSelectParent").style.display = "none"
        document.getElementById("taglineidParent").style.display = "none"
        // document.getElementById("userBusinessType").style.display = "none" 
    }else{
        userBusinessType = "Individual"
        document.getElementById("inlineRadio2").checked = true
        document.getElementById("bnameModalParent").style.display = ""
        document.getElementById("BusinessTypeIdParent").style.display = ""
        document.getElementById("bcontactParent").style.display = ""
        document.getElementById("WebsiteSelectParent").style.display = ""
        document.getElementById("taglineidParent").style.display = ""
        // document.getElementById("userBusinessType").style.display = "" 
    }
}

function openUserModal(params) {

    docToBeUpdate = params;
    
    var docRef = firestore.collection("Businesses").doc(params);

    docRef.get().then((doc) => {
       
        if (doc.exists) {
            if(doc.data().userBusinessType !== "Business"){
                document.getElementById("bnameModalParent").style.display = ""
                document.getElementById("BusinessTypeIdParent").style.display = "none"
                document.getElementById("bcontactParent").style.display = ""
                document.getElementById("WebsiteSelectParent").style.display = "none"
                document.getElementById("taglineidParent").style.display = "none"
                // document.getElementById("userBusinessType").style.display = "none" 
            }else if(doc.data().userBusinessType == "Business"){
                userBusinessType = doc.data().userBusinessType
                document.getElementById("inlineRadio2").checked = true
                document.getElementById("bnameModalParent").style.display = ""
                document.getElementById("BusinessTypeIdParent").style.display = ""
                document.getElementById("bcontactParent").style.display = ""
                document.getElementById("WebsiteSelectParent").style.display = ""
                document.getElementById("taglineidParent").style.display = ""
                // document.getElementById("userBusinessType").style.display = "" 
            }
            document.getElementById("userNameModal").value = doc.data().userName 
            document.getElementById("bnameModal").value = doc.data().businessName
            document.getElementById("BusinessTypeId").value = doc.data().businessTypeEnglish
            document.getElementById("userBusinessTypeId").value = doc.data().userBusinessType
            
            // document.getElementById("BusinessTypeId").value = doc.data().businessTypeEnglish
            document.getElementById("mobileNoid").value = doc.data().userPhoneNumber
            document.getElementById("bcontact").value = doc.data().mobNumber

            document.getElementById("EmailModal").value = doc.data().email
            document.getElementById("logoSelect").value = doc.data().haveLogo == true ? "Yes" : "No"
            document.getElementById("WebsiteSelect").value = doc.data().haveWebsite == true ? "Yes" : "No"
            document.getElementById("taglineid").value = doc.data().talgile
            document.getElementById("PreviewforSliderModal").src = doc.data().logo
            document.getElementById("addressId").value = doc.data().address

        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
}

function SaveEditedBusinessInfo(params) {

            var userName = document.getElementById("userNameModal").value  
             userBusinessType = document.getElementById("userBusinessTypeId").value  
            var businessName  = document.getElementById("bnameModal").value
            var businesstype = document.getElementById("BusinessTypeId").value 
            var userContact = document.getElementById("mobileNoid").value 
            var BusinessContact = document.getElementById("bcontact").value 
            var useraddress = document.getElementById("addressId").value 
            var email = document.getElementById("EmailModal").value
            var logoavl =  document.getElementById("logoSelect").value == "Yes" ? true : false
            var websiteavl = document.getElementById("WebsiteSelect").value == "Yes" ? true : false
            var tagline  = document.getElementById("taglineid").value 
    
            var logo = document.getElementById("logoId").value;
            getBusinessTypeAsPerL(businesstype);
            
            var keywords = getAllSubstrings(`${businessName.toLowerCase()} ${BusinessContact} ${userContact.substring(3)} `)
            
    var washingtonRef = firestore.collection("Businesses").doc(docToBeUpdate)
    
        // Set the "capital" field of the city 'DC'

        if(userBusinessType == "Business"){
         
            if(userName!== "" && businessName!=="" && businesstype!=="" && email!=="" && userContact!=="" && BusinessContact!=="" && useraddress!=="" && tagline!=="" && logo=="" ){
      
                return washingtonRef.update({
                    userName : userName,
                    businessName : businessName,
                    userPhoneNumber : userContact,
                    mobNumber : BusinessContact,
                    address : useraddress,
                    businessTypeEnglish : businessTypeEnglishInput,
                    businessTypeMarathi : businessTypeMarathiInput,
                    haveLogo  :logoavl,
                    haveWebsite : websiteavl,
                    email:email,
                    talgile : tagline,
                    userBusinessType : "Business",
                    keywords :  keywords
                })
                .then(() => {
                

                    swal("User Edited Successfully");
            
                }).then(()=>{
            
                    location.reload();
                })
                .catch((error) => {
                    // The document probably doesn't exist.
                    console.error("Error updating document: ", error);
                });
            }else if(userName!== "" && businessName!=="" && businesstype!=="" && email!=="" && userContact!=="" && BusinessContact!=="" && useraddress!=="" && tagline!=="" && logo!==""){
                
                document.getElementById("EditPostUploading2").style.display = "flex";
                document.getElementById("Previewforlogo").style.display = "none";
                const ref = firebase.storage().ref();
                const file = document.querySelector('#logoId').files[0]

                const name =  file.name;

                const metadata = {
                contentType: file.type
                };
                const task = ref.child('meChitrakar/' + name).put(file, metadata);

                task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
                    return washingtonRef.update({
                        // userName : userName,
                        businessName : businessName,
                        // userPhoneNumber : userContact,
                        mobNumber : BusinessContact,
                        address : useraddress,
                        businessTypeEnglish : businessTypeEnglishInput,
                        businessTypeMarathi : businessTypeMarathiInput,
                        haveLogo  :logoavl,
                        haveWebsite : websiteavl,
                        email:email,
                        talgile : tagline,
                        userBusinessType : "Business",
                        logo : url
                    })
                    .then(() => {

                        document.getElementById("EditPostUploading2").style.display = "none";
                        document.getElementById("Previewforlogo").style.display = "";
                        document.getElementById("Previewforlogo").src = "../assets/img/photo.png";
                        swal("User Edited Successfully");
                
                    }).then(()=>{
                
                        location.reload();
                    })
                    .catch((error) => {
                        // The document probably doesn't exist.
                        console.error("Error updating document: ", error);
                    });
                })
            }else{
                if(userName == ""){
                    document.getElementById("userNameModalVal").style.display = ""
                }else{

                    document.getElementById("userNameModalVal").style.display = "none"
                }

                if(businessName == ""){
                    document.getElementById("bnameModalval").style.display = ""
                }else{

                    document.getElementById("bnameModalval").style.display = "none"
                }

                if(businesstype == ""){
                    document.getElementById("btype").style.display = ""
                }else{

                    document.getElementById("btype").style.display = "none"
                }

                
                if(email == ""){
                    document.getElementById("eamilVal").style.display = ""
                }else{

                    document.getElementById("eamilVal").style.display = "none"
                } 
                
                if(userContact == ""){
                    document.getElementById("pmobileNoidval").style.display = ""
                }else{

                    document.getElementById("pmobileNoidval").style.display = "none"
                }
                

                if(BusinessContact == ""){
                    document.getElementById("bcontact").style.display = ""
                }else{

                    document.getElementById("bcontact").style.display = "none"
                }

                if(useraddress == ""){
                    document.getElementById("addressid").style.display = ""
                }else{
                    document.getElementById("addressid").style.display = "none"
                }

                if(tagline == ""){
                    document.getElementById("taglineidVal").style.display = ""
                }else{
                    document.getElementById("taglineidVal").style.display = "none"
                }

                
            }
        
        }else if(userBusinessType == "Individual"){
           
            if(userName!== "" && email!=="" && userContact!=="" && BusinessContact!=="" &&  useraddress!==""  && logo==""){
                console.log("In Individual1")
                return washingtonRef.update({
                    // userName : userName,
          
                    businessName : businessName,
                    mobNumber : BusinessContact,
                    // userPhoneNumber : userContact,
                    address : useraddress,
    
                    haveLogo  :logoavl,
    
                    email:email,

                    // userBusinessType : "Individual",
        
                    keywords : keywords
                })
                .then(() => {
                    swal("User Edited Successfully");
            
                }).then(()=>{
            
                    location.reload();
                })
                .catch((error) => {
                    // The document probably doesn't exist.
                    console.error("Error updating document: ", error);
                });
            }else if(userName!== "" && email!=="" && userContact!=="" &&  useraddress!==""  && logo!==""){ 
                console.log("In Individual2")
                document.getElementById("Previewforlogo").style.display = "none";
                document.getElementById("EditPostUploading2").style.display = "flex";
          
                const ref = firebase.storage().ref();
                const file = document.querySelector('#logoId').files[0]

                const name =  file.name;

                const metadata = {
                contentType: file.type
                };
                const task = ref.child('meChitrakar/' + name).put(file, metadata);

                task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
            
                    return washingtonRef.update({

                        logo :url,
                        userName : userName,
              
                        userPhoneNumber : userContact,
                    
                        address : useraddress,
        
                        haveLogo  :logoavl,
        
                        email:email,
    
                        userBusinessType : "Individual",
            
                        keywords : keywords
                    })
                    .then(() => {
                        document.getElementById("EditPostUploading2").style.display = "none";
                        document.getElementById("Previewforlogo").style.display = "";
                        document.getElementById("Previewforlogo").src = "../assets/img/photo.png";
                        swal("User Edited Successfully");
                
                    }).then(()=>{
                
                        location.reload();
                    })
                    .catch((error) => {
                        // The document probably doesn't exist.
                        console.error("Error updating document: ", error);
                    });
            
                })

            
            }else{

                console.log("In Individual2")
                if(userName == ""){
                    document.getElementById("userNameModalVal").style.display = ""
                }else{

                    document.getElementById("userNameModalVal").style.display = "none"
                }

                  
                if(email == ""){
                    document.getElementById("eamilVal").style.display = ""
                }else{

                    document.getElementById("eamilVal").style.display = "none"
                }

                if(userContact == ""){
                    document.getElementById("pmobileNoidval").style.display = ""
                }else{

                    document.getElementById("pmobileNoidval").style.display = "none"
                }

                if(useraddress == ""){
                    document.getElementById("addressid").style.display = ""
                }else{
                    document.getElementById("addressid").style.display = "none"
                }


            }
         
        }
    
    
}

function getBusinessTypeList(params) {
    while(document.getElementById("BusinessTypeList").childElementCount!==0){
        document.getElementById("BusinessTypeList").firstChild.remove();
    }
    
    if(params == "मराठी"){

        businessTypemarathi.forEach(element => {
            $("#BusinessTypeList").append(`<option>${element}</option>`)
        });
    }else if(params == "English"){
        businessTypeEnglish.forEach(element => {
            $("#BusinessTypeList").append(`<option>${element}</option>`)
        });
    }
}

function getBusinessTypeAsPerL(params) {
    var index = businessTypeEnglish.indexOf(params)!== -1 ?  businessTypeEnglish.indexOf(params) : businessTypemarathi.indexOf(params)
    // index = businessTypemarathi.findIndex("Select your business type");
    businessTypeEnglishInput = businessTypeEnglish.at(index)
    businessTypeMarathiInput = businessTypemarathi.at(index)

}

document.getElementById("planlistinput").addEventListener("keyup", planlist);

function planlist(e) {

    e.target.value == "" ? GetUserList() : ""
    
}

document.getElementById("SearchPost").addEventListener("keyup", searchthings);

function searchthings(e) {

    if(e.target.value == ""){
      if(FilterFlag == "proff_Logo"){
        proff_Logo();
      }else if(FilterFlag == "proff_Web"){
        proff_Web();
      }else if(FilterFlag == "proff_logo_Web"){
        proff_logo_Web();
      }else if( FilterFlag == "Default"){
        GetUserList();
      }
    }

}


document.getElementById("logoFilter").addEventListener("change", logofun);

function logofun(e) {
var proffInput = document.getElementById("planlistinput").value
var logoInput = document.getElementById("logoFilter").value
var Webinput = document.getElementById("webFilter").value
console.log(proffInput,logoInput,Webinput)
  if(proffInput!=="" && logoInput!== "Select" && Webinput == "Select"  ){

    proff_Logo(proffInput,logoInput);
  }else if(proffInput !=="" &&  Webinput !== "Select" && logoInput!== "Select" ){
    proff_logo_Web();
  }else if(proffInput =="" &&  Webinput == "Select" && logoInput!== "Select" ){
    console.log("in Logo")
    GetUSerListBylogo(logoInput);
  }

}

document.getElementById("webFilter").addEventListener("change", webFun);

function webFun(e) {
var proffInput = document.getElementById("planlistinput").value
var logoInput = document.getElementById("logoFilter").value
var Webinput = document.getElementById("webFilter").value
console.log(proffInput,logoInput,Webinput)
  if(proffInput!=="" && logoInput == "Select" && Webinput !== "Select"  ){
    console.log("in Logo")
    proff_Web(proffInput,logoInput);
  }else if(proffInput !=="" &&  Webinput !== "Select" && logoInput!== "Select" ){
    proff_logo_Web();
  }else if(proffInput == "" &&  Webinput !== "Select" && logoInput == "Select" ){
    GetUSerListByWeb(Webinput);
  }

}



function SearchUser(params) {

    SearchDataTObeExport = [];
    SearchDataTObeExportIndex = 0;
 
  var tobeSearch =  document.getElementById("SearchPost").value;
 
  if(search == "default"){
 Sr_Search = 1;


   firestore.collection("Businesses").where("keywords","array-contains",tobeSearch.toLowerCase()).get()
   .then((querySnapshot) => {
 
     if( querySnapshot.docs.length == 0 ){
      
       document.getElementById("SubAdminTbodyAnimation").style.display = "flex"
       document.getElementById("SubadminBody").style.display = "none"
    swal("No Business Found ")
   }
 
     while(document.getElementById("UsersTableBody").childElementCount!==0){
 
       document.getElementById("UsersTableBody").firstChild.remove();
     }
 
     querySnapshot.forEach((doc)=>{
 
        $("#UsersTableBody").append(`<tr>

            <td>${Sr++}</td>
            <td id="${doc.data().userPhoneNumber}" onclick="redirectToUserProfile(this.id)">
              <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
            </td>
            <td id="SubAdminEmail">${doc.data().businessName}</td> 
            <td id="SubAdminPassword">${doc.data().email}</td>
            <td id="SubAdminPassword">${doc.data().mobNumber}</td>

   
            <td>
              <div style="display: flex;justify-content: space-evenly;">
                <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
                

              </div>
            </td>
          </tr>`)
 
     })
   }).then(()=>{
 
   })
 
  }else if(search == "profession"){
 //alert("Vivek Dhande")
 
 Sr_Search = 1;
   firestore.collection("Businesses").where("businessTypeEnglish","==",Selected_Plan).where("keywords","array-contains",tobeSearch.toLowerCase()).get()
   .then((querySnapshot) => {
 
     if( querySnapshot.docs.length == 0 ){
      
       document.getElementById("SubAdminTbodyAnimation").style.display = "flex"
       document.getElementById("SubadminBody").style.display = "none"
   }
 
     while(document.getElementById("UsersTableBody").childElementCount!==0){
 
       document.getElementById("UsersTableBody").firstChild.remove();
     }
 
     querySnapshot.forEach((doc)=>{
 
        $("#UsersTableBody").append(`<tr>

        <td>${Sr++}</td>
        <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
        </td>
        <td id="SubAdminEmail">${doc.data().businessName}</td> 
        <td id="SubAdminPassword">${doc.data().email}</td>
        <td id="SubAdminPassword">${doc.data().mobNumber}</td>


        <td>
          <div style="display: flex;justify-content: space-evenly;">
            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
            

          </div>
        </td>
      </tr>`)
 
     })
   })
 
 
  }else if(search == "logo"){
   //alert("profession")
 
   Sr_Search = 1;
     firestore.collection("UserInfo").where("haveLogo","==",Selected_Plan == "Yes"? true : false).where("keywords","array-contains",tobeSearch.toLowerCase()).get()
     .then((querySnapshot) => {
 
       if( querySnapshot.docs.length == 0 ){
      
         document.getElementById("SubAdminTbodyAnimation").style.display = "flex"
         document.getElementById("SubadminBody").style.display = "none"
     }
   
       while(document.getElementById("UsersTableBody").childElementCount!==0){
   
         document.getElementById("UsersTableBody").firstChild.remove();
     }
   
       querySnapshot.forEach((doc)=>{
   
        $("#UsersTableBody").append(`<tr>

        <td>${Sr++}</td>
        <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
        </td>
        <td id="SubAdminEmail">${doc.data().businessName}</td> 
        <td id="SubAdminPassword">${doc.data().email}</td>
        <td id="SubAdminPassword">${doc.data().mobNumber}</td>


        <td>
          <div style="display: flex;justify-content: space-evenly;">
            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
            

          </div>
        </td>
      </tr>`)
   
       })
     })

  }
  else if(search == "website"){
     //alert("Both")
     Sr_Search = 1;
       firestore.collection("UserInfo").where("haveWebsite","==",Selected_Plan == "Yes"? true : false).where("keywords","array-contains",tobeSearch.toLowerCase()).get()
       .then((querySnapshot) => {
     
         while(document.getElementById("UsersTableBody").childElementCount!==0){
     
           document.getElementById("UsersTableBody").firstChild.remove();
       }
     
         querySnapshot.forEach((doc)=>{
     
            $("#UsersTableBody").append(`<tr>

        <td>${Sr++}</td>
        <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
          <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
        </td>
        <td id="SubAdminEmail">${doc.data().businessName}</td> 
        <td id="SubAdminPassword">${doc.data().email}</td>
        <td id="SubAdminPassword">${doc.data().mobNumber}</td>


        <td>
          <div style="display: flex;justify-content: space-evenly;">
            <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
            

          </div>
        </td>
      </tr>`)
     
         })
       })
     
     
  }else if(search == "proff_Logo"){
    //alert("Both")
    Sr_Search = 1;
      firestore.collection("UserInfo").where("businessTypeEnglish","==",Selected_Plan1 == "Yes"? true : false).where("haveLogo","==",Selected_Plan2 == "Yes"? true : false).where("keywords","array-contains",tobeSearch.toLowerCase()).get()
      .then((querySnapshot) => {
    
        while(document.getElementById("UsersTableBody").childElementCount!==0){
    
          document.getElementById("UsersTableBody").firstChild.remove();
      }
    
        querySnapshot.forEach((doc)=>{
    
           $("#UsersTableBody").append(`<tr>

       <td>${Sr++}</td>
       <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
         <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
       </td>
       <td id="SubAdminEmail">${doc.data().businessName}</td> 
       <td id="SubAdminPassword">${doc.data().email}</td>
       <td id="SubAdminPassword">${doc.data().mobNumber}</td>


       <td>
         <div style="display: flex;justify-content: space-evenly;">
           <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
           

         </div>
       </td>
     </tr>`)
    
        })
      })
    
    
 }else if(search == "proff_Web"){
  //alert("Both")
  Sr_Search = 1;
    firestore.collection("UserInfo").where("businessTypeEnglish","==",Selected_Plan1 == "Yes"? true : false).where("haveWebsite","==",Selected_Plan2 == "Yes"? true : false).where("keywords","array-contains",tobeSearch.toLowerCase()).get()
    .then((querySnapshot) => {
  
      while(document.getElementById("UsersTableBody").childElementCount!==0){
  
        document.getElementById("UsersTableBody").firstChild.remove();
    }
  
      querySnapshot.forEach((doc)=>{
  
         $("#UsersTableBody").append(`<tr>

     <td>${Sr++}</td>
     <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
       <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
     </td>
     <td id="SubAdminEmail">${doc.data().businessName}</td> 
     <td id="SubAdminPassword">${doc.data().email}</td>
     <td id="SubAdminPassword">${doc.data().mobNumber}</td>


     <td>
       <div style="display: flex;justify-content: space-evenly;">
         <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
         

       </div>
     </td>
   </tr>`)
  
      })
    })
  
  
}else if(search == "proff_logo_Web"){
  //alert("Both")
  Sr_Search = 1;
    firestore.collection("UserInfo").where("businessTypeEnglish","==",Selected_Plan1 == "Yes"? true : false).where("haveWebsite","==",Selected_Plan2 == "Yes"? true : false).where("haveLogo","==",Selected_Plan3 == "Yes"? true : false).where("keywords","array-contains",tobeSearch.toLowerCase()).get()
    .then((querySnapshot) => {
  
      while(document.getElementById("UsersTableBody").childElementCount!==0){
  
        document.getElementById("UsersTableBody").firstChild.remove();
    }
  
      querySnapshot.forEach((doc)=>{
  
         $("#UsersTableBody").append(`<tr>

     <td>${Sr++}</td>
     <td id=${doc.data().userPhoneNumber} onclick="redirectToUserProfile(this.id)">
       <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().userName}</strong>
     </td>
     <td id="SubAdminEmail">${doc.data().businessName}</td> 
     <td id="SubAdminPassword">${doc.data().email}</td>
     <td id="SubAdminPassword">${doc.data().mobNumber}</td>


     <td>
       <div style="display: flex;justify-content: space-evenly;">
         <button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditSubAdmin" id="${doc.id}" onclick="openUserModal(this.id)" >Edit</button>
         

       </div>
     </td>
   </tr>`)
  
      })
    })
  
  
}
 
 }

 function createKeywords(name){   
    const arrName = [];
    let curName = '';
    name.split('').forEach(letter => {
    curName += letter;
    arrName.push(curName.trim());
    });
    // tagsKey = tagsKey.concat(arrName);
    console.log("tagsKey",arrName)

}

function ExportData(params) {
  var csv = `${ExportUserName},${moment().toDate()}\nUSER NAME,USER CONTACT,ADDRESS,USER BUSINESS TYPE,BUSINESS TYPE,BUSINESS NAME,BUSINESS CONATCT,LOGO,WEBSITE,\n`;

  console.log("DataTObeExport",DataTObeExport)
  //merge the data with CSV
  DataTObeExport.forEach(function (row) {
    //console.log(row)
    csv += row.join(',');
    csv += "\n";
  });

  //display the created CSV data on the web browser 
  


  var hiddenElement = document.createElement('a');
  hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
  hiddenElement.target = '_blank';

  //provide the name for the CSV file to be downloaded
  hiddenElement.download = `${ExportUserName}.csv`;

  hiddenElement.click();
}

function redirectToUserProfile(params) {
    
  localStorage.setItem("userDoc", params);
  window.open('/Users/userprofile.html', '_blank');
}

// Sample data in an array
// const mydata = [
//     { name: 'John Doe', age: 30, email: 'johndoe@example.com' },
//     { name: 'Jane Smith', age: 25, email: 'janesmith@example.com' },
//     { name: 'Bob Johnson', age: 40, email: 'bobjohnson@example.com' }
//   ];
  
//   // Convert array to CSV format
//   const csv = mydata.map(row => Object.values(row).join(',')).join('\n');
  
//   // Create a download link for the CSV file
//   const downloadLink = document.createElement('a');
//   downloadLink.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
//   downloadLink.download = 'data.csv';
//   downloadLink.click();


//   const Mydata = [
//     { name: 'John Doe', age: 30, email: 'johndoe@example.com' },
//     { name: 'Jane Smith', age: 25, email: 'janesmith@example.com' },
//     { name: 'Bob Johnson', age: 40, email: 'bobjohnson@example.com' }
//   ];
  
//   // Extract column names from the first row of data
//   const columnNames = Object.keys(Mydata[0]);
  
//   // Convert array to CSV format, including column names
//   const csv = [
//     columnNames.join(','),
//     ...Mydata.map(row => columnNames.map(name => row[name]).join(','))
//   ].join('\n');
  
//   // Create a download link for the CSV file
//   const downloadLink = document.createElement('a');
//   downloadLink.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
//   downloadLink.download = 'data.csv';
//   downloadLink.click();