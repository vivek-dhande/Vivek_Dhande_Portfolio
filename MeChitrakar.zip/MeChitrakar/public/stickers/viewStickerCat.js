var firestore = firebase.firestore();
var FrameCatToBeEditedDoc;
var LastFrameCat;

var FrameCategoryList = [] ;
var FrameCategoryList_index = 0;
var data = [];
var dataindex = 0;
var paginationindex=0
var CurrentPage=0;

viewFrameCategory();
function viewFrameCategory(params) {
FrameCategoryList = [] ;
FrameCategoryList_index = 0;
data = [];
dataindex = 0;
paginationindex=0
CurrentPage=0;
    
    firestore.collection("stickersCat").limit(5).get().then((querySnapshot) => {

        LastFrameCat = querySnapshot.docs[querySnapshot.docs.length-1]
        
        querySnapshot.forEach((doc) => {
            data[dataindex++] = [`${doc.id}`,`${doc.data().name}`]
            // doc.data() is never undefined for query doc snapshots
            $("#ViewFrameCategoryTableBody").append(`<tr>
            <td>${doc.data().name}</td>
            <td><button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditFrameCategoryrModal"  id="${doc.id}" onclick="openEditFrameCategory(this.id)">Edit</button>
            <button type="button" class="btn rounded-pill btn-danger" data-bs-toggle="modal" data-bs-target="#EditFrameCategoryrModal" id="" onclick="openUserModal(this.id)">Delete</button>
            </td>
            </tr>`)
        });
    }).then(()=>{
        FrameCategoryList[FrameCategoryList_index++] = data;
        paginationindex++;
        CurrentPage++;
    })
}

function nextframeCategory(params) {
data = [];
dataindex = 0;

    if(paginationindex == CurrentPage ){


        firestore.collection("FrameCategory").startAfter(LastFrameCat).limit(1).get().then((querySnapshot) => {

        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;
            
            CurrentPage--;
            paginationindex--;
            (swal("There is no Record Found"))
        
        }else{

            while(document.getElementById("ViewFrameCategoryTableBody").childElementCount!==0){

                document.getElementById("ViewFrameCategoryTableBody").firstChild.remove();
            }

            LastFrameCat = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
                data[dataindex++] = [`${doc.id}`,`${doc.data().name}`]

                $("#ViewFrameCategoryTableBody").append(`<tr>
                <td>${doc.data().name}</td>
                <td><button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditFrameCategoryrModal"  id="${doc.id}" onclick="openEditFrameCategory(this.id)">Edit</button>
                <button type="button" class="btn rounded-pill btn-danger" data-bs-toggle="modal" data-bs-target="#EditFrameCategoryrModal" id="" onclick="openUserModal(this.id)">Delete</button>
                </td>
                </tr>`)
            });
            
        }

        }).then(()=>{
            FrameCategoryList[FrameCategoryList_index++] = data;
            console.log("CurrentPage: ",CurrentPage,"paginationindex: ",paginationindex)
            console.log("FrameCategoryList",FrameCategoryList);
            paginationindex++;
            CurrentPage++;
        
        })

    }else{

        console.log("CurrentPage: ",CurrentPage,"paginationindex: ",paginationindex)
        console.log("FrameCategoryList",FrameCategoryList);
        FrameCategoryList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

            while(document.getElementById("ViewFrameCategoryTableBody").childElementCount!==0){

                document.getElementById("ViewFrameCategoryTableBody").firstChild.remove();
            }

            $("#ViewFrameCategoryTableBody").append(`<tr>
            <td>${doc[1]}</td>
            <td><button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditFrameCategoryrModal"  id="${doc[0]}" onclick="openEditFrameCategory(this.id)">Edit</button>
            <button type="button" class="btn rounded-pill btn-danger" data-bs-toggle="modal" data-bs-target="#EditFrameCategoryrModal" id="" onclick="openUserModal(this.id)">Delete</button>
            </td>
            </tr>`)
        });

        CurrentPage++;


    }

}
function previousframeCategory(params) {
    document.getElementById("nextButton").disabled = false; 
    if(CurrentPage!==1){

        while(document.getElementById("ViewFrameCategoryTableBody").childElementCount!==0){ 
            
            document.getElementById("ViewFrameCategoryTableBody").firstChild.remove();
        }
        console.log("CurrentPage: ",CurrentPage,"paginationindex: ",paginationindex)
        CurrentPage--;
        
        FrameCategoryList[CurrentPage-1].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());
    
            $("#ViewFrameCategoryTableBody").append(`<tr>
            <td>${doc[1]}</td>
            <td><button type="button" class="btn rounded-pill btn-info" data-bs-toggle="modal" data-bs-target="#EditFrameCategoryrModal"  id="${doc[0]}" onclick="openEditFrameCategory(this.id)">Edit</button>
            <button type="button" class="btn rounded-pill btn-danger" data-bs-toggle="modal" data-bs-target="#EditFrameCategoryrModal" id="" onclick="openUserModal(this.id)">Delete</button>
            </td>
            </tr>`)
        });
        
    }else{
        document.getElementById("previousButton").disabled = true; 
    }
}



function openEditFrameCategory(params){
    FrameCatToBeEditedDoc = params;
    var docRef = firestore.collection("stickersCat").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {
           document.getElementById("FrameCatModalTitle").value = doc.data().name;
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).then(()=>{
            $("#EditFrameCategoryrModal").show();
    }).catch((error) => {
        console.log("Error getting document:", error);
    });


}

function SaveEditedFrameCateogry(params) {
    
    var FrameCatNameAfterEdit = document.getElementById("FrameCatModalTitle").value;

    if(FrameCatNameAfterEdit!==""){

        firestore.collection("stickersCat").doc(FrameCatToBeEditedDoc).update({
            name : FrameCatNameAfterEdit
        })
        .then((docRef) => {
            document.getElementById("FrameCatvalidation").style.display = "none";
            swal("Frame Category Updated");
            location.reload();
        })
        .catch((error) => {
            console.error("Error adding document: ", error);
        });

    }else{

        if(FrameCatNameAfterEdit ==""){
          document.getElementById("FrameCatvalidation").style.display = "";
        }
    }
        
}