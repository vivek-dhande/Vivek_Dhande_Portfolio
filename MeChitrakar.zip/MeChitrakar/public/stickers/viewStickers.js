var firestore = firebase.firestore();
var tobeEdit;
var Frame_Category;
getCategories();
function getCategories(params) {
    firestore.collection("stickersCat").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
           $("#SelectCatForFrame").append(`<li><a class="dropdown-item" href="javascript:void(0);">${doc.data().name}</a></li>`)
        });
    });
}

renderFrames();
function renderFrames(params) {
    document.getElementById("PostLoading").style.display = "flex";
    document.getElementById("LoadmoreButtondiv").style.display = 'none'
    //alert("In All");
    RednerSubCat = params

    firestore.collection("stickers").limit(6)
    .get()
    .then((querySnapshot) => {

        var SubCatchild = document.getElementById("PostContainer");
    
        while(SubCatchild.children.length!==0){
            
            SubCatchild.children[0].remove();
        }
        if( querySnapshot.docs.length == 0 ){
           
            document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'
            (swal("There is no Record Found")) 

        }

        AllLastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

        querySnapshot.forEach((doc) => {

            console.log("doc.data()",doc.data())
            // doc.data() is never undefined for query doc snapshots
           $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="${doc.id}-postcol" style="width : 32%">
           <div class="card h-100">
        <div>
        </div>
             <div class="card-body">
               <div style="display: flex;
               justify-content: space-between">
               <h5 class="card-title">${doc.data().name}</h5>
               <button type="button" class="btn btn-danger" style="padding: 0.5rem;" id="${doc.id}" onclick="deletepost(this.id)"><i class='bx bx-trash'></i></button>
               </div>
               <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().item_url}" alt="Card image cap" style="width:311.550px;height:311.550px">
            <div style="display:flex;justify-content: space-between;">
               <div>
                      <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="openFrameEdit(this.id)">Edit</a>
               </div>
               
            </div>
             </div>
           </div>
         </div>`)
        });
    }).then(()=>{
        document.getElementById("LoadmoreButtondivAllpost").style.display = "flex"
        // document.getElementById("PostLoading").style.display = "none";
       
        
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    
}

function openFrameEdit(params) {
    
    var docRef = firestore.collection("stickers").doc(params);
    tobeEdit = params;

    docRef.get().then((doc) => {
        if (doc.exists) {
            Frame_Category = doc.data().category_id;
            document.getElementById("AddFrameTitle").value = doc.data().name
            // document.getElementById("FrameCode").value = doc.data().code
            document.getElementById("AddSliderIMG").src = doc.data().item_url
            $('#AddframeCat').html(doc.data().category_id);
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
}

function saveEditedFrame(params) {

    var FrameTitle = document.getElementById("AddFrameTitle").value 
    // var FrameCode = document.getElementById("FrameCode").value 
    var FrameIamge = document.getElementById("AddFramerImg").value 
    console.log("Frame_Category",Frame_Category)
    if(FrameTitle!== "" && FrameIamge!=="" && Frame_Category!== undefined){
        
      document.getElementById("UpaloadSliderImg").style.display = "flex"
      document.getElementById("AddSliderIMG").style.display = "none"
      
        const ref = firebase.storage().ref();
        const file = document.querySelector('#AddFramerImg').files[0]
        const name =  file.name;
        const metadata = {
        contentType: file.type
        };
        const task = ref.child('meChitrakar/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
            firestore.collection("stickers").doc(tobeEdit).update({
                category_id: Frame_Category,
                name : FrameTitle,
                item_url : url,
            })
            .then((docRef) => {
                document.getElementById("UpaloadSliderImg").style.display = "none" 
                document.getElementById("AddSliderIMG").style.display = "flex"
                
                 document.getElementById("AddFrameTitle").value = ""
                //  document.getElementById("FrameCode").value = ""
                 document.getElementById("AddFramerImg").value= "" 
                 document.getElementById("AddSliderIMG").src =  "../assets/img/photo.png"
                 swal("Frame Edited Successfully")
                 location.reload();
            })
            .catch((error) => {
                console.error("Error adding document: ", error);
            });

        })


    }else if(FrameTitle!== "" && FrameIamge=="" && Frame_Category!== undefined){
        firestore.collection("stickers").doc(tobeEdit).update({
            category_id: Frame_Category,
            name : FrameTitle,
         
          })
          .then((docRef) => {
               document.getElementById("AddFrameTitle").value = ""
            //    document.getElementById("FrameCode").value = ""
               document.getElementById("AddFramerImg").value= "" 
               document.getElementById("AddSliderIMG").src =  "../assets/img/photo.png"
                swal("Frame Edited Successfully")
               location.reload();
          })
          .catch((error) => {
              console.error("Error adding document: ", error);
          });
    }
    else{
        if(Frame_Category == undefined ){
            document.getElementById("sliderflag").style.display = ""
        }else{
            document.getElementById("sliderflag").style.display = "none"
        } 

        if(FrameTitle == "" ){
            document.getElementById("AddFramespan").style.display = ""
        }else{
            document.getElementById("AddFramespan").style.display = "none"
        } 

        // if(FrameCode == "" ){
        //     document.getElementById("codeOfFrameSpan").style.display = ""
        // }else{
        //     document.getElementById("codeOfFrameSpan").style.display = "none"
        // } 

        if(FrameIamge == "" ){
            document.getElementById("pngjpegvalidation").style.display = ""
        }else{
            document.getElementById("pngjpegvalidation").style.display = "none"
        } 
    }
}

$('.dropdown-menu').on('click', '.dropdown-item', function(){
    
    Frame_Category = $(this).text();
    $('#AddframeCat').html($(this).text());
})


function AddImgForSLider(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#AddSliderIMG')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}


deletepost = (id) => {

    swal({
        title: "Are you sure?",
        text: "Do you want to Delete this Frame",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        n && firestore.collection("stickers").doc(id).delete()


            .then(function () {
                let subsWrapper = document.getElementById(`${id}-postcol`)
                subsWrapper.remove();
                swal("Successfull", "Frame Deleted ", "success")
            }).catch(function (e) {
                console.error("Error removing document: ", e)
            })
    })
}


function NextRenderAllPost(params) {
   

    
    firestore.collection("stickers")
    .startAfter(AllLastPostReff).limit(6)
    .get()
    .then((querySnapshot) => {

        
        if( querySnapshot.docs.length == 0 ){
            (swal("There is no Record Found"))

            document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'

        }

        AllLastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="${doc.id}-postcol" style="width : 32%">
            <div class="card h-100">
         <div>
         </div>
              <div class="card-body">
                <div style="display: flex;
                justify-content: space-between">
                <h5 class="card-title">${doc.data().name}</h5>
                <button type="button" class="btn btn-danger" style="padding: 0.5rem;" id="${doc.id}" onclick="deletepost(this.id)"><i class='bx bx-trash'></i></button>
                </div>
                <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().item_url}" alt="Card image cap" style="width:311.550px;height:311.550px">
             <div style="display:flex;justify-content: space-between;">
                <div>
                       <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                </div>
  
             </div>
              </div>
            </div>
          </div>`)
        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    
    

}
