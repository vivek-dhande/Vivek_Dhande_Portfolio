var firestore = firebase.firestore();
var check;
firebase.auth().onAuthStateChanged(function(e){if(e){console.log("User Login"); 
var o,t=document.getElementsByClassName("hideLink");

logEmail=e.email,
    firestore.collection("Editer").where("email","==",e.email).get().then(n=>{n.forEach(e=>{
    if(check=e.id,"admin"==e.data().role)
        for(o=0;o<t.length;o++)t[o].classList.remove("d-none")

})

})
}
 else window.location.href="/index.html"});

function signOut(){firebase.auth().signOut(),setTimeout(function(){window.location.href="/index.html"},2e3)}