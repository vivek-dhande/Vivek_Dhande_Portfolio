var firestore = firebase.firestore();
const storage = firebase.storage();
var storageRef = storage.ref();

var LastSliderDoc;
var FlagName;
var SliderDocToUpdate;
var addSliderFlag;



var SliderOpeartion = (params) =>{

    if(params == "AddSlider"){
        document.getElementById("AddSlider").style.display = "flex"
        document.getElementById("SliderContainer").style.display = "none"; 
        document.getElementById("LoadmoreButtondiv").style.display = "none";
    }else if(params == "ViewSlider"){
        document.getElementById("SliderContainer").style.display = "flex";
        document.getElementById("AddSlider").style.display = "none"
        
        ViewSliderOpeartion();
    }

}


function AddSliderOpeartion(params) {
    document.getElementById("AddSlider").style.display = "flex"
    document.getElementById("SliderContainer").style.display = "none";

    var AddSavetitle = document.getElementById("AddSliderTitle").value;
    var AddSaveSliderFlag = document.getElementById("AddSliderFlag").innerText;
    var AddSaveLink = document.getElementById("AddSliderLink").value;
    var AddsSaveImage = document.querySelector('#AddSliderImg').value


    if(AddSavetitle!== "" && AddSaveSliderFlag !== "Select Flag" && AddSaveLink !== "" && AddsSaveImage !== "" ){

        document.getElementById("UpaloadSliderImg").style.display = "flex" 
        document.getElementById("AddSliderIMG").style.display = "none"
        const ref = firebase.storage().ref();
        const file = document.querySelector('#AddSliderImg').files[0]
        const name =  file.name;
        const metadata = {
            contentType: file.type
        };
        const task = ref.child('meChitrakar/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => { 
        
        var docRef = firestore.collection("Sliders")
    
        return docRef.add({
            
            title : AddSavetitle,
            flag : AddSaveSliderFlag,
            link : AddSaveLink,
            image : url,
            date : firebase.firestore.Timestamp.fromDate(new Date()).toDate()
        })
        .then(() => {
            document.getElementById("UpaloadSliderImg").style.display = "none"
            document.getElementById("AddSliderIMG").style.display = "flex"
            document.getElementById("AddSliderIMG").src = "../assets/img/photo.png"
            console.log("Document successfully updated!");
  
            document.getElementById("AddSliderTitle").value = ""
            document.getElementById("AddSliderFlag").innerText = "Select Flag "
            document.getElementById("AddSliderLink").value = ""
            document.querySelector('#AddSliderImg').value = ""
        }).then(()=>{


        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });
    
        })

    }else{
        
        if(AddSavetitle == ""){
            document.getElementById("slidertitlespan").style.display = ""
    
        }else{
            document.getElementById("slidertitlespan").style.display = "none"
        }
    
        if(AddSaveSliderFlag == "Select Flag "){
    
            document.getElementById("sliderflag").style.display = ""
    
        }else{
            document.getElementById("sliderflag").style.display = "none"
        }
    
        if(AddSaveLink == ""){
    
            document.getElementById("sliderlink").style.display = ""
    
        }else{
    
            document.getElementById("sliderlink").style.display = "none"
        }
    
        if(AddsSaveImage == ""){
    
            document.getElementById("pngjpegvalidation").style.display = ""
    
        }else{
            document.getElementById("pngjpegvalidation").style.display = "none"
        }
    }
    

}

function ViewSliderOpeartion(params) {
    document.getElementById("SliderContainer").style.display = "flex";
    document.getElementById("AddSlider").style.display = "none"

    var SliderChild = document.getElementById("SliderContainer");
    
    while(SliderChild.children.length!==0){
        
        SliderChild.children[0].remove();
    }

    firestore.collection("Sliders").orderBy("date","desc").limit(1).get().then((querySnapshot) => {
        

        LastSliderDoc = querySnapshot.docs[querySnapshot.docs.length-1];

        // if(querySnapshot.docs.length !== 0){
            
        //     document.getElementById("LoadmoreButtondiv").style.display = "flex"
        // }

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data());
            $("#SliderContainer").append(`<div class="card mb-3" style="width: 50rem;padding-left: 0;margin-top: 1.5rem;">
                <div class="row g-0">
                <div class="col-md-4">
                    <img class="card-img card-img-left" src="${doc.data().image}" style="height: -webkit-fill-available;; width: 260px;">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                    <h5 class="card-title">${doc.data().title}</h5>
                    <h6>Flag : ${doc.data().flag}</h5>
                    <h6>Link : <a href="${doc.data().link}" target="_blank">${doc.data().link}</a> </h5>
                    <h6>date : ${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</h5>
                    <div style="display:flex;justify-content: flex-end;"> 
                    <button type="button" class="btn btn-primary" style="margin-right:1rem" data-bs-toggle="modal" data-bs-target="#EditSliderModal" id="${doc.id}" onclick="OpenEditSliderModal(this.id)" >Edit</button>
                    <button type="button" class="btn btn-danger" style="margin-right:1rem">Remove</button>
                    </div>
                    </div>
                </div>
                </div>
            </div>`)
        });
    }).then(()=>{
        document.getElementById("LoadmoreButtondiv").style.display = "flex"
    })
        
}

function LoadMoreSlider(params) {

    firestore.collection("Sliders").orderBy("date","desc").startAfter(LastSliderDoc).limit(1).get().then((querySnapshot) => {

        LastSliderDoc = querySnapshot.docs[querySnapshot.docs.length-1];
       
        if( querySnapshot.docs.length == 0 ){
            (swal("There is no Record Found"))

            document.getElementById("LoadmoreButtondiv").style.display = 'none'

           
        }
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data());
            $("#SliderContainer").append(`<div class="card mb-3" style="width: 50rem;padding-left: 0;margin-top: 1.5rem;">
                <div class="row g-0">
                <div class="col-md-4">
                    <img class="card-img card-img-left" src="${doc.data().image}" style="height: -webkit-fill-available;; width: 260px;">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                    <h5 class="card-title">${doc.data().title}</h5>
                    <h6>Flag : ${doc.data().flag}</h5>
                    <h6>Link : <a href="${doc.data().link}" target="_blank">${doc.data().link}</a> </h5>
                    <h6>date : ${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</h5>
                    <div style="display:flex;justify-content: flex-end;"> 
                    <button type="button" class="btn btn-primary" style="margin-right:1rem" id="${doc.id}" data-bs-toggle="modal" data-bs-target="#EditSliderModal" id="${doc.id}" onclick="OpenEditSliderModal(this.id)">Edit</button>
                    <button type="button" class="btn btn-danger" style="margin-right:1rem">Remove</button>
                    </div>
                    </div>
                </div>
                </div>
            </div>`)
        });
    });
        
}

function OpenEditSliderModal(params) {

    SliderDocToUpdate = params;
    
    var docRef = firestore.collection("Sliders").doc(params);

    docRef.get().then((doc) => {
   
            if (doc.exists) {

                document.getElementById("SliderModalTitle").value = doc.data().title
                document.getElementById("btnGroupDrop1").innerText = doc.data().flag
                document.getElementById("SliderModalLink").value = doc.data().link
                document.getElementById("PreviewforSliderModal").src = doc.data().image
           
            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
            }
        // console.log("Jpeg",url);

      
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
    
}

function SaveEditSliderModal() {

    var ToSavetitle = document.getElementById("SliderModalTitle").value;
    var ToSaveSliderFlag = document.getElementById("btnGroupDrop1").innerText;
    var ToSaveLink = document.getElementById("SliderModalLink").value;
    var TosSaveImage = document.querySelector('#pngjpegModal').value

    if(TosSaveImage !== ""){

        document.getElementById("EditPostUploading").style.display = "" 
        document.getElementById("PreviewforSliderModal").style.display = "none"
        const ref = firebase.storage().ref();
        const file = document.querySelector('#pngjpegModal').files[0]
        const name =  file.name;
        const metadata = {
            contentType: file.type
            };
        const task = ref.child('meChitrakar/' + name).put(file, metadata);
        task
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
    
        // console.log("Jpeg",url);
        
        var docRef = firestore.collection("Sliders").doc(SliderDocToUpdate);
    
        return docRef.update({
            
            title : ToSavetitle,
            flag : ToSaveSliderFlag,
            link : ToSaveLink,
            image : url
        })
        .then(() => {
            document.getElementById("EditPostUploading").style.display = "none"
            document.getElementById("PreviewforSliderModal").style.display = ""
            console.log("Document successfully updated!");
        }).then(()=>{
            location.reload();
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });
    
        })
    

    }else{
        document.getElementById("EditPostUploading").style.display = ""
        document.getElementById("PreviewforSliderModal").style.display = "none"
        var docRef = firestore.collection("Sliders").doc(SliderDocToUpdate);
    
        return docRef.update({
            
            title : ToSavetitle,
            flag : ToSaveSliderFlag,
            link : ToSaveLink,
           
        })
        .then(() => {
            document.getElementById("EditPostUploading").style.display = "none"
            document.getElementById("PreviewforSliderModal").style.display = ""
            
           
        }).then(()=>{
            location.reload();
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });

    }
    


    
}

function Image1Modal1(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#PreviewforSliderModal')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}
function AddImgForSLider(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#AddSliderIMG')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}


$(".dropdown-item").click(function(){

    FlagName =  $(this).text();

    $("#btnGroupDrop1").html($(this).text());

  });

  $('#SelectFlagForSlider').on('click', '.dropdown-item', function(){

    addSliderFlag = $(this).text();
    $('#AddSliderFlag').html($(this).text());
   

})
