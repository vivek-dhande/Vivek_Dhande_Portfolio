
firestore = firebase.firestore();
var email = document.getElementById("SubAdminEamil"),
    pass = document.getElementById("SubAdminPass"),
    repass = document.getElementById("RetypePass"),
    adminName = document.getElementById("SubAdminName");

var LastSubAdminListDoc;
var SubAdminList = [] ;
var SubAdminList_index = 0;
var data = [];
var dataindex = 0;
var Subadmindoc;
firebase.auth().onAuthStateChanged((user) => {
    if (user) {
        
        document.getElementById("SubAdminEamil").value = user.email 

    // ...
    } else {
      // User is signed out
      // ...
    }
  });

function getData() {
    console.log("pass.value.length",pass.value)
     "" == pass.value ? swal("Please Enter Password!") : pass.value.length < 6 ? swal("Password Lenght Must Greter than 6!") : "" == repass.value ? swal("Please Enter Retype Password!") : pass.value != repass.value ? swal("Enter Retype Password Not Match with Password") : createUser()
}

function createUser() {

    pass = document.getElementById("SubAdminPass"),
    // firebase.auth().createUserWithEmailAndPassword(email.value, pass.value).then(function(userCredential) {
    //     console.log("userCredential",)
    //     saveData(userCredential.user.uid), console.log("User Created")
    // }).catch(function(e) {
    //     console.log(e)
    // })

    firebase.auth().onAuthStateChanged((user) => {
        if (user) {

           

            firestore.collection("Subadmin").where("email","==",user.email).get().then(n=>{n.forEach(e=>{
               
                Subadmindoc = e.id
                user.updatePassword(pass.value).then(function() {
                    UpdatePassWordToDb();
                    swal("Password Updated Sucessfully");
                }).catch(function(error) {
                // An error happened.
                });
                  
            })
            
            })
          // User is signed in, see docs for a list of available properties
          // https://firebase.google.com/docs/reference/js/firebase.User
          console.log("pass",pass.value)
   
        console.log("user",user)
        // ...
        } else {
          // User is signed out
          // ...
        }
      });
    


}


function UpdatePassWordToDb(params) {
    pass = document.getElementById("SubAdminPass"),

    firestore.collection("Subadmin").doc(Subadmindoc).update({
     
        password: pass.value,
        
    }).then(function() {
        pass.value=""
        repass.value=""
    
    }).catch(function(e) {
        console.log(e)
    })
    
}


// let str = "12345.00";
// str = str.substring(0, str.length - 6);
// console.log(str);

