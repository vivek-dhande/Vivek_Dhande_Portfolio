
var firestore = firebase.firestore();
const storage = firebase.storage();
var storageRef = storage.ref();

let uid;
var RednerSubCat;
var RendermainCat;
var LastPostReff;
var tobeFilter;
var UID_Post_Edit;
var Post_To_Be_Edited;
var result = [];
var i;
var AllLastPostReff;
var ExtensionFlag;
var png_or_jpeg;
var zip_or_rar;
var UserID;
var imageFilter;
var DownloadedFilter;
var LastDocDownloadFiler;
var DownloadFilterNext;
var imagecounttype;
var filtertype ;
var MainCatForDownload;
var SubCatForDownload;
var MainCatDBFieldname;
var LastDoc_MainCat_With_ImageType;
var MainCatForAvoidBlank; 
var SubcatForAvoidBlank; 
var previewImgUrl;
var previewImgUrlEdit;
var tags = [],sptags = [], tagsKey = [];
var keyword = document.getElementById('keyword');

firebase.auth().onAuthStateChanged((user) => {
    if (user) {
      // User is signed in, see docs for a list of available properties
      // https://firebase.google.com/docs/reference/js/firebase.User
      UserID = user.uid;
      console.log("UserID",UserID)
      // ...
    } else {
      // User is signed out
      // ...
    }
  });


  function getAllSubstrings(str) {

    result.push(str);
    for (let j = 1 ; j < str.length + 1; j++) {
        result.push(str.slice(i, j));
    }
    for(let i = 0 ; i<str.length ;i++){
     
        if(str[i] == " "){
    
        for (let j = i+2 ; j < str.length + 1; j++) {
            result.push(str.slice(i+1, j));
        }
    
        }
    }
return result;

}


firestore.collection("UniqueID").get().then((querySnapshot) => {
    querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        uid = doc.data().uniqueID
   
    });
});


getMainCatForPost();
function getMainCatForPost(params) {



    firestore.collection("Category").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $("#mainCatList").append(`<option value="${doc.data().catName}" id ="${doc.id}" onclick="getSubCatForPost(this.id)">`)
       
        });
    });

}

function getSubCatForPost(params) {

    var MainCatDoc;
    var SubcatChild = document.getElementById("subCatList");
    while(SubcatChild.children.length!==0){
        
        SubcatChild.children[0].remove();
    }

    firestore.collection("Category").where("catName", "==",params)
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            MainCatDoc =  doc.id
        });
    }).then(()=>{

        // firestore.collection("Category").doc(MainCatDoc).collection("SubCat").get().then((querySnapshot) => {

        firestore.collection("SubCat").where("mainCat","==",MainCatDoc).get().then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                $("#subCatList").append(`<option value="${doc.data().subCatName}">`)
        
            });
        });

        // firestore. collection("SubCat").where("mainCat","==",params).get().then((querySnapshot) => {
        //     var SubcatChild = document.getElementById("subCatListModal");
        //     while(SubcatChild.children.length!==0){
                
        //         SubcatChild.children[0].remove();
        //     }
        
            
        //     querySnapshot.forEach((doc) => {
        //         // doc.data() is never undefined for query doc snapshots
        //         $("#subCatListModal").append(`<option value="${doc.data().subCatName}">`)
        //     });
        // });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });


}



function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#Image1')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}
function Image1Modal1(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#Image1Modal')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}

// $(".dropdown-item").click(function(){

//     ExtensionFlag = $(this).text();

//     $("#Ext").html($(this).text());

// });

// $(".dropdown-item").click(function(){

//     ExtensionFlag = $(this).text();

//     $("#Ext1").html($(this).text());

// });

function SavePost(params) {

    var Cat_name,Cat_img,Post_pngjpeg,Post_psd,Sub_Cat_Name;
    postTitle = document.getElementById("postTitle").value;
    Cat_name = document.getElementById("mainCatSearch").value;
    Sub_Cat_Name = document.getElementById("subCatSearch").value;
    Post_pngjpeg = document.getElementById("pngjpeg").value;
    Post_psd = document.getElementById("ziprar").value;
    PostCaption = document.getElementById("postCaption").value;
    previewImage = document.getElementById("previewImage").value
    var ForKeyWord = "";
    var ManCatKeywords = [];
     ForKeyWord = `${uid+1} ${Cat_name} ${Sub_Cat_Name} ${postTitle}`;
     ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());

    var pngjpegUrl;
    var psdurl;

if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !=="" && Post_psd !=="" && PostCaption!== "" && tags.length!==0 && previewImage!=="" ){

    document.getElementById("AddPostSaveButton").style.display = "none"
   
    document.getElementById("Uploading").style.display = "flex" 
    document.getElementById("Image1").style.display = "none"
 

    // alert("In true")
    const ref = firebase.storage().ref();
    const file = document.querySelector('#pngjpeg').files[0]
    const file2 =  document.querySelector('#ziprar').files[0]
    const file3 =  document.querySelector('#previewImage').files[0]
    const name =  file.name;
    const name2 = file2.name;
    const name3 = file3.name
    const metadata = {
    contentType: file.type
    };
    const task = ref.child('meChitrakar/' + name).put(file, metadata);
    const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
    const task3 = ref.child('meChitrakar/' + name3).put(file3, metadata);

    task
    .then(snapshot => snapshot.ref.getDownloadURL())
    .then((url) => {

        pngjpegUrl = url; 
    // console.log("Jpeg",url);

    }).then(()=>{
        task3
        .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
            previewImgUrl = url
        })

    }).then(()=>{
        task2 .then(snapshot => snapshot.ref.getDownloadURL())
        .then((url) => {
            psdurl = url
  
               firestore.collection("Post").add({
                postTitle: postTitle,
                postMainCat : Cat_name,
                postSubCat : Sub_Cat_Name,
                pngorjpeg : pngjpegUrl,
                psd : url,
                date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                PostUID : uid+1,
                // keywords : ManCatKeywords,
                pngandjpeg : png_or_jpeg,
                ziporrar : zip_or_rar,
                userUID : UserID,           
                psdDownloadingCount : Number(1),
                jpgDownloadingCount :Number(1),
                keywords : tagsKey,
                keysToShow : tags,
                visibility: false,
                caption: PostCaption,
                previewImg : previewImgUrl
            })
       
    }).then(()=>{
        // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
        console.log("Category Added")
        var washingtonRef = firestore.collection("UniqueID").doc("IY69gSQmwZDPbkuqcTz0");
        uid = uid+1;
        // Set the "capital" field of the city 'DC'
        return washingtonRef.update({
            uniqueID: uid
        })
        .then(() => {
            document.getElementById("Uploading").style.display = "none"
            document.getElementById("Image1").style.display = "flex"
             document.getElementById("postTitle").value ="" 
             document.getElementById("mainCatSearch").value ="" 
             document.getElementById("subCatSearch").value = ""
             document.getElementById("pngjpeg").value = ""
             document.getElementById("ziprar").value = ""
             document.getElementById("Image1").src = "../assets/img/photo.png"
             document.getElementById("AddPostSaveButton").style.display = ""
             document.getElementById("postCaption").value = "";
             while(document.getElementById("tagContainer").childElementCount!==0){
                document.getElementById("tagContainer").firstChild.remove();
             }


                swal("Post Uploaded successfully!")

                location.reload();

           
            // console.log("Document successfully updated!");
        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });

        // alert("Category Added")
        
        
        // Cat_name = document.getElementById("basic-default-fullname").value = "";
        // Cat_img = document.getElementById("formFile").value = "";

    })
    })

}else{

    if(postTitle == ""){
        document.getElementById("posttitlevalidation").style.display = ""

    }else{
        document.getElementById("posttitlevalidation").style.display = "none"
    }

    if(Cat_name == ""){

        document.getElementById("maincatvalidation").style.display = ""

    }else{
        document.getElementById("maincatvalidation").style.display = "none"
    }

    if(Sub_Cat_Name == ""){

        document.getElementById("subcatvalidation").style.display = ""

    }else{

        document.getElementById("subcatvalidation").style.display = "none"
    }

    if(Post_pngjpeg == ""){

        document.getElementById("pngjpegvalidation").style.display = ""

    }else{
        document.getElementById("pngjpegvalidation").style.display = "none"
    }
    
    if(Post_psd == ""){

        document.getElementById("psdvalidation").style.display = ""

    }else{

        document.getElementById("psdvalidation").style.display = "none"
    }

    if(PostCaption == ""){

        document.getElementById("captionSpan").style.display = ""

    }else{

        document.getElementById("captionSpan").style.display = "none"

    }

    if(tags.length == 0){

        document.getElementById("keyword_Span").style.display = ""

    }else{

        document.getElementById("keyword_Span").style.display = "none"

    }

}   
}


function SearchPost(params) {
    document.getElementById("LoadmoreButtondiv").style.display = "none" 
    document.getElementById("LoadmoreButtondivAllpost").style.display = "none"
    var tobeSearch = document.getElementById("SearchPost").value.toLowerCase();

    firestore.collection("Post").where("userUID","==",UserID).where("keywords","array-contains",tobeSearch).get()
        .then((querySnapshot) => {
            var SubCatchild = document.getElementById("PostContainer");
    
            while(SubCatchild.children.length!==0){
                
                SubCatchild.children[0].remove();
            }
            querySnapshot.forEach((doc) => {

                $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
                <div class="card h-100">
             <div>
             </div>
                  <div class="card-body">
     
                  <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
     
                    <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
                 <div style="display:flex;justify-content: space-between;">
                    <div>
                           <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                    </div>
                    <div>
                    <label class="switch switch-slide">
                    <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                    <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                    <span class="switch-handle"></span>
                    </label>
                    </div>
                    <div style="display:flex;margin-top: 0.5rem;">
                         <i class='bx bxs-download'></i>
                         <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                         <i class='bx bxs-download'></i>
                         <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                     </div>
                 </div>
                  </div>
                </div>
              </div>`)
              document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;



        })
    })

    if(MainCatForDownload!== undefined && SubCatForDownload == undefined){
        // alert("In Main Cat")
        firestore.collection("Post").where("userUID","==",UserID).where("postMainCat","==",MainCatForDownload).where("keywords","array-contains",tobeSearch).get()
        .then((querySnapshot) => {
            var SubCatchild = document.getElementById("PostContainer");
    
            while(SubCatchild.children.length!==0){
                
                SubCatchild.children[0].remove();
            }
            querySnapshot.forEach((doc) => {

                $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
                <div class="card h-100">
             <div>
             </div>
                  <div class="card-body">
     
                  <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
     
                    <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
                 <div style="display:flex;justify-content: space-between;">
                    <div>
                           <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                    </div>
                    <div>
                    <label class="switch switch-slide">
                    <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                    <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                    <span class="switch-handle"></span>
                    </label>
                    </div>
                    <div style="display:flex;margin-top: 0.5rem;">
                         <i class='bx bxs-download'></i>
                         <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                         <i class='bx bxs-download'></i>
                         <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                     </div>
                 </div>
                  </div>
                </div>
              </div>`)
              document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;



        })
    })
    }else if(MainCatForDownload!== undefined && SubCatForDownload !== undefined){
        // alert("In SubCat")
        firestore.collection("Post").where("userUID","==",UserID).where("postSubCat","==",SubCatForDownload).where("keywords","array-contains",tobeSearch).get()
        .then((querySnapshot) => {
            var SubCatchild = document.getElementById("PostContainer");
    
            while(SubCatchild.children.length!==0){
                
                SubCatchild.children[0].remove();
            }
            querySnapshot.forEach((doc) => {

                $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
                <div class="card h-100">
             <div>
             </div>
                  <div class="card-body">
     
                  <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
     
                    <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
                 <div style="display:flex;justify-content: space-between;">
                    <div>
                           <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                    </div>
                    <div>
                    <label class="switch switch-slide">
                    <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                    <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                    <span class="switch-handle"></span>
                    </label>
                    </div>
                    <div style="display:flex;margin-top: 0.5rem;">
                         <i class='bx bxs-download'></i>
                         <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                         <i class='bx bxs-download'></i>
                         <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                     </div>
                 </div>
                  </div>
                </div>
              </div>`)
              document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;



        })
    })
    }else{
        firestore.collection("Post").where("userUID","==",UserID).where("keywords","array-contains",tobeSearch).get()
        .then((querySnapshot) => {
            var SubCatchild = document.getElementById("PostContainer");
    
            while(SubCatchild.children.length!==0){
                
                SubCatchild.children[0].remove();
            }
            querySnapshot.forEach((doc) => {

                $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
                <div class="card h-100">
             <div>
             </div>
                  <div class="card-body">
     
                  <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
     
                    <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
                 <div style="display:flex;justify-content: space-between;">
                    <div>
                           <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                    </div>
                    <div>
                    <label class="switch switch-slide">
                    <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                    <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                    <span class="switch-handle"></span>
                    </label>
                    </div>
                    <div style="display:flex;margin-top: 0.5rem;">
                         <i class='bx bxs-download'></i>
                         <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                         <i class='bx bxs-download'></i>
                         <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                     </div>
                 </div>
                  </div>
                </div>
              </div>`)
              document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;



        })
    })

    }
    
}

function ResetSearch(params) {
    
    var SearchBox;
    var maincatDropDown;
    var SubCategory;
    SearchBox = document.getElementById("SearchPost").value;
    maincatDropDown = document.getElementById("PostMainCatinput").value;
    SubCategory = document.getElementById("PostSubCatinput").value;
    
    console.log("SearchBox :",SearchBox,"maincatDropDown :",maincatDropDown,"SubCategory :",SubCategory)
    if(SearchBox == "" && maincatDropDown !== "" && SubCategory !==""){
    // alert("Subcat")
        RenderPost(tobeFilter,'postSubCat');

    }else if(SearchBox == "" && maincatDropDown !=="" && SubCategory ==""){
        // alert("Maincat")
        RenderPost(maincatDropDown,'postMainCat')
    }
    else if(SearchBox == "" && maincatDropDown == "" && SubCategory ==""){
        // alert("Maincat")
        AllPost();
    }
}


$("#mainCatSearch").click(function(){

document.getElementById("mainCatSearch").value = "";
})

$("#subCatSearch").click(function(){

    document.getElementById("subCatSearch").value = "";
})


function PostOperations(params) {

    if(params == "AddPost"){
        var SubCatchild = document.getElementById("PostContainer");
    
        while(SubCatchild.children.length!==0){
            
            SubCatchild.children[0].remove();
        }

        document.getElementById('PostMainCatinput').value = '';
        document.getElementById('PostSubCatinput').value = '';
      
        document.getElementById("AddPostDiv").style.display = "flex";
        document.getElementById("ViewpostDiv").style.display = "none";
        document.getElementById("LoadmoreButtondiv").style.display = "none"; 
        document.getElementById("LoadmoreButtondivAllpost").style.display = "none";

    }else if(params == "ViewPost"){
         AllPost();
        document.getElementById("AddPostDiv").style.display = "none";
        document.getElementById("ViewpostDiv").style.display = "flex";

    }
    
}


getMainCategoryDropDown();
function getMainCategoryDropDown(params) {

    firestore.collection("Category").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $("#PostdefaultSelectMainCat").append(`<option value="${doc.data().catName}" data-id="${doc.id}">`)
        });
    });

}


function getSubCategoryMenu(params) {
     var SubCatchild = document.getElementById("PostdefaultSelectSubcat");
    
        while(SubCatchild.children.length!==0){
            
            SubCatchild.children[0].remove();
        }

    // firestore.collection("Category").doc(params).collection("SubCat").get().then((querySnapshot) => {
    //     querySnapshot.forEach((doc) => {
    //         // doc.data() is never undefined for query doc snapshots
    //         $("#PostdefaultSelectSubcat").append(`<option value="${doc.data().subCatName}">`)
    //     });
    // });

    firestore.collection("SubCat").where("mainCat","==",params).get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $("#PostdefaultSelectSubcat").append(`<option value="${doc.data().subCatName}">`)
        });
    });

}

document.querySelector('#PostMainCatinput').addEventListener('input', (e) => {
    Object.assign(e.target.dataset, document.querySelector('#' + e.target.getAttribute('list') + ' option[value="' + e.target.value + '"]').dataset);
    console.log('dataset of input changed: ', e.target.dataset.id)
    getSubCategoryMenu(e.target.dataset.id)
});


// document.querySelector('#PostSubCatinput').addEventListener('input', (e) => {
//     Object.assign(e.target.dataset, document.querySelector('#' + e.target.getAttribute('list') + ' option[value="' + e.target.value + '"]').dataset);
//     console.log('dataset of input changed: ', e.target.dataset.id)
//     getSubCategoryMenu(e.target.dataset.id)
// });

$("#PostSubCatinput").change(()=>{
    
    tobeFilter = document.getElementById("PostSubCatinput").value;

    SubCatForDownload = tobeFilter;
    RenderPost(tobeFilter,'postSubCat');

    
})

$("#PostMainCatinput").change(()=>{
    
    
    tobeFilter = document.getElementById("PostMainCatinput").value;

    MainCatForDownload = tobeFilter;

    if(tobeFilter!=='All'){
        
        RenderPost(tobeFilter,'postMainCat');
    }else if(tobeFilter=='All'){
        AllPost();
    }
        
    
})

$("#ImageTypeListInput").change(()=>{
    
    imageFilter = document.getElementById("ImageTypeListInput").value;
    // alert(imageFilter);
    
})
$("#mostadnLeastDataInput").change(()=>{
    var MainCAT = document.getElementById("PostMainCatinput")
    var SubCat = document.getElementById("PostSubCatinput")
    DownloadedFilter = document.getElementById("mostadnLeastDataInput").value;

    
    if(imageFilter == "JPEG" && DownloadedFilter == "Most Downloaded" && MainCAT.value == "" || MainCAT.value =="All" ){

        RenderPostByDownloads('jpgDownloadingCount','desc')
    }else if(imageFilter == "PSD" && DownloadedFilter == "Most Downloaded" && MainCAT.value == "" || MainCAT.value =="All"){

        RenderPostByDownloads('psdDownloadingCount','desc')
    }else if(imageFilter == "JPEG" && DownloadedFilter == "Least Downloaded" && MainCAT.value == "" || MainCAT.value =="All"){

        RenderPostByDownloads('jpgDownloadingCount','asc')

    }else if(imageFilter == "PSD" && DownloadedFilter == "Least Downloaded" && MainCAT.value == "" || MainCAT.value =="All"){
    
        RenderPostByDownloads('psdDownloadingCount','asc')

    }else if(MainCAT.value !== "" && SubCat.value == "" && imageFilter == "JPEG" && DownloadedFilter == "Most Downloaded" ){
        //alert("DownloadedFilter");
        console.log("In DownloadedFilter ")
        RenderPostByDownloads_MainCat('postMainCat',`${MainCAT.value}`,'jpgDownloadingCount','desc')
    }else if(MainCAT.value !== "" && SubCat.value == "" && imageFilter == "JPEG" && DownloadedFilter == "Least Downloaded" ){
        //alert("DownloadedFilter");
        console.log("In main jpg asc")
        RenderPostByDownloads_MainCat('postMainCat',`${MainCAT.value}`,'jpgDownloadingCount','asc')
    }else if(MainCAT.value !== "" && SubCat.value == "" && imageFilter == "PSD" && DownloadedFilter == "Most Downloaded" ){
        //alert("DownloadedFilter");
        console.log("In DownloadedFilter ")
        RenderPostByDownloads_MainCat('postMainCat',`${MainCAT.value}`,'psdDownloadingCount','desc')
    }else if(MainCAT.value !== "" && SubCat.value == "" && imageFilter == "PSD" && DownloadedFilter == "Least Downloaded" ){
        //alert("DownloadedFilter");
        console.log("In main jpg asc")
        RenderPostByDownloads_MainCat('postMainCat',`${MainCAT.value}`,'psdDownloadingCount','asc')
    }else if(MainCAT.value !== "" && SubCat.value !== "" && imageFilter == "JPEG" && DownloadedFilter == "Most Downloaded" ){
        //alert("DownloadedFilter");
        console.log("In DownloadedFilter ")
        RenderPostByDownloads_MainCat('postSubCat',`${SubCat.value}`,'jpgDownloadingCount','desc')
    }else if(MainCAT.value !== "" && SubCat.value !== "" && imageFilter == "JPEG" && DownloadedFilter == "Least Downloaded" ){
        //alert("DownloadedFilter");
        console.log("In main jpg asc")
        RenderPostByDownloads_MainCat('postSubCat',`${SubCat.value}`,'jpgDownloadingCount','asc')
    }else if(MainCAT.value !== "" && SubCat.value !== "" && imageFilter == "PSD" && DownloadedFilter == "Most Downloaded" ){
        //alert("DownloadedFilter");
        console.log("In DownloadedFilter ")
        RenderPostByDownloads_MainCat('postSubCat',`${SubCat.value}`,'psdDownloadingCount','desc')
    }else if(MainCAT.value !== "" && SubCat.value !== "" && imageFilter == "PSD" && DownloadedFilter == "Least Downloaded" ){
        //alert("DownloadedFilter");
        console.log("In main jpg asc")
        RenderPostByDownloads_MainCat('postSubCat',`${SubCat.value}`,'psdDownloadingCount','asc')
    }


    
    
})



function RenderPost(params,params1) {

    document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'
    RednerSubCat = params

    firestore.collection("Post").where("userUID","==",UserID).where("userUID","==",UserID).where(params1, "==", params).orderBy("date","desc").limit(5)
    .get()
    .then((querySnapshot) => {

        var SubCatchild = document.getElementById("PostContainer");
    
        while(SubCatchild.children.length!==0){
            
            SubCatchild.children[0].remove();
        }
        if( querySnapshot.docs.length == 0 ){
           
            document.getElementById("LoadmoreButtondiv").style.display = "none"
            (swal("There is no Record Found")) 
           
        }

        LastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
           <div class="card h-100">
        <div>
        </div>
             <div class="card-body">

             <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>

               <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
            <div style="display:flex;justify-content: space-between;">
               <div>
                      <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
               </div>
               <div>
               <label class="switch switch-slide">
               <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
               <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
               <span class="switch-handle"></span>
               </label>
               </div>
               <div style="display:flex;margin-top: 0.5rem;">
                    <i class='bx bxs-download'></i>
                    <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                    <i class='bx bxs-download'></i>
                    <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                </div>
            </div>
             </div>
           </div>
         </div>`)
         document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

        });
    }).then(()=>{

        document.getElementById("LoadmoreButtondiv").style.display = "flex"
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    
}

function NextRenderPost(params) {
    
    if(MainCatForDownload!==undefined && SubCatForDownload == undefined ){
        firestore.collection("Post").where("userUID","==",UserID).where("postMainCat", "==", MainCatForDownload).orderBy("date","desc").startAfter(LastPostReff).limit(5)
        .get()
        .then((querySnapshot) => {
    
            
            if( querySnapshot.docs.length == 0 ){
                (swal("There is no Record Found"))
    
                document.getElementById("LoadmoreButtondiv").style.display = 'none'
               
               
    
               
            }
    
            LastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];
    
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
               <div class="card h-100">
            <div>
            </div>
                 <div class="card-body">
    
                 <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
    
                   <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
                <div style="display:flex;justify-content: space-between;">
                   <div>
                          <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                   </div>
                   <div>
                   <label class="switch switch-slide">
                   <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                   <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                   <span class="switch-handle"></span>
                   </label>
                   </div>
                   <div style="display:flex;margin-top: 0.5rem;">
                        <i class='bx bxs-download'></i>
                        <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                        <i class='bx bxs-download'></i>
                        <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                    </div>
                </div>
                 </div>
               </div>
             </div>`)
             document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

            });
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });

    }else if(SubCatForDownload!== undefined && SubCatForDownload !== undefined){
        firestore.collection("Post").where("userUID","==",UserID).where("postSubCat", "==", SubCatForDownload).orderBy("date","desc").startAfter(LastPostReff).limit(5)
        .get()
        .then((querySnapshot) => {
    
            
            if( querySnapshot.docs.length == 0 ){
                (swal("There is no Record Found"))
    
                document.getElementById("LoadmoreButtondiv").style.display = 'none'
               
               
    
               
            }
    
            LastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];
    
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
               <div class="card h-100">
            <div>
            </div>
                 <div class="card-body">
    
                 <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
    
                   <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
                <div style="display:flex;justify-content: space-between;">
                   <div>
                          <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                   </div>
                   <div>
                   <label class="switch switch-slide">
                   <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                   <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                   <span class="switch-handle"></span>
                   </label>
                   </div>
                   <div style="display:flex;margin-top: 0.5rem;">
                        <i class='bx bxs-download'></i>
                        <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                        <i class='bx bxs-download'></i>
                        <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                    </div>
                </div>
                 </div>
               </div>
             </div>`)
             document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

            });
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });
    

    }
   

}

function AllPost(params) {
    document.getElementById("LoadmoreButtondiv").style.display = 'none'
    // alert("In All");
    RednerSubCat = params

    firestore.collection("Post").where("userUID","==",UserID).orderBy("date","desc").limit(5)
    .get()
    .then((querySnapshot) => {

        var SubCatchild = document.getElementById("PostContainer");
    
        while(SubCatchild.children.length!==0){
            
            SubCatchild.children[0].remove();
        }
        if( querySnapshot.docs.length == 0 ){
           
            document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'
            (swal("There is no Record Found")) 

        }

        AllLastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
           $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
           <div class="card h-100">
        <div>
        </div>
             <div class="card-body">

               <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>

               <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
            <div style="display:flex;justify-content: space-between;">
               <div>
                      <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
               </div>
               <div>
               <label class="switch switch-slide">
               <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
               <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
               <span class="switch-handle"></span>
               </label>
               </div>
               <div style="display:flex;margin-top: 0.5rem;">
                    <i class='bx bxs-download'></i>
                    <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                    <i class='bx bxs-download'></i>
                    <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                </div>
            </div>
             </div>
           </div>
         </div>`)
         document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

        });
    }).then(()=>{

        document.getElementById("LoadmoreButtondivAllpost").style.display = "flex"
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    
}

function NextRenderAllPost(params) {
   

    if(DownloadFilterNext == "download"){

        firestore.collection("Post").where("userUID","==",UserID).orderBy(`${imagecounttype}`,`${filtertype}`).startAfter(LastDocDownloadFiler).limit(5)
        .get()
        .then((querySnapshot) => {
    
            
            if( querySnapshot.docs.length == 0 ){
                (swal("There is no Record Found"))
    
                document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'
    
            }
    
            LastDocDownloadFiler = querySnapshot.docs[querySnapshot.docs.length-1];
    
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
                <div class="card h-100">
             <div>
             </div>
                  <div class="card-body">
     
                  <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
     
                    <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
                 <div style="display:flex;justify-content: space-between;">
                    <div>
                           <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                    </div>
                    <div>
                    <label class="switch switch-slide">
                    <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                    <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                    <span class="switch-handle"></span>
                    </label>
                    </div>
                    <div style="display:flex;margin-top: 0.5rem;">
                         <i class='bx bxs-download'></i>
                         <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                         <i class='bx bxs-download'></i>
                         <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                     </div>
                 </div>
                  </div>
                </div>
              </div>`)
              document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

            });
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });

    }else if(DownloadFilterNext == "download_main_Cat"){

        // alert("In download_main_Cat")
        firestore.collection("Post").where("userUID","==",UserID).where(MainCatDBFieldname, "==", MainCatForDownload).orderBy(`${imagecounttype}`,`${filtertype}`).startAfter(LastDoc_MainCat_With_ImageType).limit(5)
        .get()
        .then((querySnapshot) => {
    
            
            if( querySnapshot.docs.length == 0 ){
                (swal("There is no Record Found"))
    
                document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'

            }
    
            LastDoc_MainCat_With_ImageType = querySnapshot.docs[querySnapshot.docs.length-1];
    
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
               <div class="card h-100">
            <div>
            </div>
                 <div class="card-body">
    
                 <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
    
                   <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
                <div style="display:flex;justify-content: space-between;">
                   <div>
                          <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                   </div>
                   <div>
                   <label class="switch switch-slide">
                   <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                   <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                   <span class="switch-handle"></span>
                   </label>
                   </div>
                   <div style="display:flex;margin-top: 0.5rem;">
                        <i class='bx bxs-download'></i>
                        <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                        <i class='bx bxs-download'></i>
                        <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                    </div>
                </div>
                 </div>
               </div>
             </div>`)
             document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

            });
        })
        .catch((error) => {
            console.log("Error getting documents: ", error);
        });
    

    }else{
         firestore.collection("Post").where("userUID","==",UserID).orderBy("date","desc").startAfter(AllLastPostReff).limit(5)
    .get()
    .then((querySnapshot) => {

        
        if( querySnapshot.docs.length == 0 ){
            (swal("There is no Record Found"))

            document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'

        }

        AllLastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
            <div class="card h-100">
         <div>
         </div>
              <div class="card-body">
 
              <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>
 
                <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
             <div style="display:flex;justify-content: space-between;">
                <div>
                       <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
                </div>
                <div>
                <label class="switch switch-slide">
                <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
                <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
                <span class="switch-handle"></span>
                </label>
                </div>
                <div style="display:flex;margin-top: 0.5rem;">
                     <i class='bx bxs-download'></i>
                     <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                     <i class='bx bxs-download'></i>
                     <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                 </div>
             </div>
              </div>
            </div>
          </div>`)
          document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    }
    

}

document.getElementById('PostMainCatinput').addEventListener('click', (e) => {
    e.target.value = ''

    var SubCatchild = document.getElementById("PostdefaultSelectSubcat");
   
})

document.getElementById('PostSubCatinput').addEventListener('click', (e) => {
    e.target.value = ''
})

document.getElementById('subCatSearchModal').addEventListener('click', (e) => {
    e.target.value = ''
})

function getSubCatForModal(params) {
console.log("params",params)
    // firestore.collection("Category").doc(params).collection("SubCat").get().then((querySnapshot) => {
    //     var SubcatChild = document.getElementById("subCatListModal");
    //     while(SubcatChild.children.length!==0){
            
    //         SubcatChild.children[0].remove();
    //     }
    
        
    //     querySnapshot.forEach((doc) => {
    //         // doc.data() is never undefined for query doc snapshots
    //         $("#subCatListModal").append(`<option value="${doc.data().subCatName}">`)
    //     });
    // });

    firestore. collection("SubCat").where("mainCat","==",params).get().then((querySnapshot) => {
        var SubcatChild = document.getElementById("subCatListModal");
        while(SubcatChild.children.length!==0){
            
            SubcatChild.children[0].remove();
        }
    
        
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $("#subCatListModal").append(`<option value="${doc.data().subCatName}">`)
        });
    });
}

document.querySelector('#mainCatSearchModal').addEventListener('input', (e) => {
    // alert("Vivek Dhande")
    Object.assign(e.target.dataset, document.querySelector('#' + e.target.getAttribute('list') + ' option[value="' + e.target.value + '"]').dataset);
    console.log('dataset of input changed: ', e.target.dataset.id)
   
    getSubCatForModal(e.target.dataset.id)
});

function OpenEditPostModal(params) {

    tagsKey = [];
    tags= [];
    firestore.collection("Category").get().then((querySnapshot) => {
        while(document.getElementById("mainCatListModal").childElementCount!==0){
            document.getElementById("mainCatListModal").firstChild.remove();
        }
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $("#mainCatListModal").append(`<option value="${doc.data().catName}" data-id="${doc.id}">`)
       
        });
    });


       
    UID_Post_Edit
    
    var docRef = firestore.collection("Post").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {
            document.getElementById("postTitleModal").value = doc.data().postTitle
            document.getElementById("mainCatSearchModal").value = doc.data().postMainCat
            document.getElementById("subCatSearchModal").value = doc.data().postSubCat
            document.getElementById("Image1Modal").src = doc.data().pngorjpeg
            document.getElementById("postCaption_Edited").value = doc.data().caption
            UID_Post_Edit = doc.data().PostUID
            Post_To_Be_Edited = doc.id
            MainCatForAvoidBlank = doc.data().postMainCat;
            SubcatForAvoidBlank = doc.data().postSubCat

            while(document.getElementById("tagContainer_EDIT").childElementCount!==0){
                document.getElementById("tagContainer_EDIT").firstChild.remove();
            }
            if(doc.data().keysToShow!==undefined){
                doc.data().keysToShow.forEach((e)=>{
                    $('#tagContainer_EDIT').append(`<span id="${e}" class="badge bg-dark">${e}<span class="closetag" onclick="removeTags_Edited(this)">×</span></span>`)
                })
            }

            if(doc.data().keysToShow!==undefined){
                doc.data().keysToShow.forEach((e)=>{
                tags.push(e);
                createKeywords(e);
                })
            }
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });
    
}

function saveEditedPost(params) {

    var Cat_name,Cat_img,Post_pngjpeg,Post_psd,Sub_Cat_Name;
    postTitle = document.getElementById("postTitleModal").value;
    Cat_name = document.getElementById("mainCatSearchModal").value;
    Sub_Cat_Name = document.getElementById("subCatSearchModal").value;
    Post_pngjpeg = document.getElementById("pngjpegModal").value;
    Post_pngjpeg_Extension = document.getElementById("pngjpegModalExt").value;
    Post_psd = document.getElementById("psdfileModal").value;
    Post_psd_Extension = document.getElementById("psdfileModalExt1").value;
    Post_Caption = document.getElementById("postCaption_Edited").value;
    var previewImage = document.getElementById("previewImageEdit").value

    // var ForKeyWord = `${UID_Post_Edit+1} ${postTitle} `;


    var pngjpegUrl;
    var psdurl;



        if(postTitle =="" || Cat_name =="" || Sub_Cat_Name =="" || Post_Caption == "" || tags.length == 0 ){

            if(postTitle == ""){
                document.getElementById("posttitlevalidation").style.display = ""
        
            }else{
                document.getElementById("posttitlevalidation").style.display = "none"
            }
        
            if(Cat_name == ""){
        
                document.getElementById("mainCatSearchModal").value = MainCatForAvoidBlank;
              
                // document.getElementById("maincatvalidation").style.display = ""
        
            }else{
                document.getElementById("maincatvalidation").style.display = "none"
            }
        
            if(Sub_Cat_Name == ""){
                document.getElementById("subCatSearchModal").value = SubcatForAvoidBlank;
                document.getElementById("subcatvalidation").style.display = ""
        
            }else{
        
                document.getElementById("subcatvalidation").style.display = "none"
            }
        
        
            if(postCaption == ""){
        
                document.getElementById("captionSpan").style.display = ""
        
            }else{
        
                document.getElementById("captionSpan").style.display = "none"
        
            }
        
            if( tags.length == 0){
        
                document.getElementById("Edited_keyword_Span").style.display = ""
                
            }else{
        
                document.getElementById("Edited_keyword_Span").style.display = "none"
        
            }
    
        }else{

            if(previewImage!==""){
                if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !=="" && Post_psd !=="" ){
    
                    // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
                    document.getElementById("EditPostUploading").style.display = "flex" 
                    document.getElementById("SaveEditesButton").style.display = "none" 
                    document.getElementById("Image1Modal").style.display = "none"
                    // //alert("In true")
                    const ref = firebase.storage().ref();
                    const file = document.querySelector('#pngjpegModal').files[0]
                    const file2 =  document.querySelector('#psdfileModal').files[0]
                    const file3 = document.querySelector('#previewImageEdit').files[0]
                    const name =  file.name;
                    const name2 = file2.name;
                    const name3 = file3.name;
                    const metadata = {
                    contentType: file.type
                    };
                    const task = ref.child('meChitrakar/' + name).put(file, metadata);
                    const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
                    const task3 = ref.child('meChitrakar/' + name3).put(file3, metadata);
    
                    task
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
        
                        pngjpegUrl = url; 
                    // console.log("Jpeg",url);
        
        
                
                    }).then(()=>{
                        task3 .then(snapshot => snapshot.ref.getDownloadURL())
                        .then((url) => {
                            previewImgUrlEdit = url
                        })
                    }).then(()=>{
                        task2 .then(snapshot => snapshot.ref.getDownloadURL())
                        .then((url) => {
                            psdurl = url
                
                            firestore.collection("Post").doc(Post_To_Be_Edited).update({
                                postTitle: postTitle,
                                postMainCat : Cat_name,
                                postSubCat : Sub_Cat_Name,
                                pngorjpeg : pngjpegUrl,
                                pngandjpeg : Post_pngjpeg_Extension,
                                psd : url,
                                ziporrar : Post_psd_Extension,
                                // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                                // keywords : ManCatKeywords
                                keywords : tagsKey,
                                keysToShow : tags,
                                caption:Post_Caption,
                                previewImg :previewImgUrlEdit
    
                            })
                    
                    }).then(()=>{
                        // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
                        document.getElementById("EditPostUploading").style.display = "none" 
                        document.getElementById("SaveEditesButton").style.display = "" 
                        document.getElementById("Image1Modal").style.display = "flex"
                        swal("Post Edited Successfully")
                        AllPost();
                        
                        tags = [],sptags = [], tagsKey = [];
                        // Set the "capital" field of the city 'DC'
                    
        
                    
                        
                        
                        // Cat_name = document.getElementById("basic-default-fullname").value = "";
                        // Cat_img = document.getElementById("formFile").value = "";
        
                    })
                    })
                    
                }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !==""  && Post_psd ==""){
                    // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
                    document.getElementById("EditPostUploading").style.display = "flex" 
                    document.getElementById("SaveEditesButton").style.display = "none" 
                    document.getElementById("Image1Modal").style.display = "none"
                    // //alert("In true")
                    const ref = firebase.storage().ref();
                    const file = document.querySelector('#pngjpegModal').files[0]
                    const file3 = document.querySelector('#previewImageEdit').files[0]
                    // const file2 =  document.querySelector('#psdfile').files[0]
                    const name =  file.name;
                    const name3 = file3.name;
                    const metadata = {
                    contentType: file.type
                    };
                    const task = ref.child('meChitrakar/' + name).put(file, metadata);
                    const task3 = ref.child('meChitrakar/' + name3).put(file3, metadata);
                    
    
                    task3
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
        
                        previewImgUrlEdit = url; 
             
                
                    }).then(()=>{
                        task
                        .then(snapshot => snapshot.ref.getDownloadURL())
                        .then((url) => {
            
                            pngjpegUrl = url; 
                            firestore.collection("Post").doc(Post_To_Be_Edited).update({
                                postTitle: postTitle,
                                postMainCat : Cat_name,
                                postSubCat : Sub_Cat_Name,
                                pngorjpeg : url,
                                pngandjpeg : Post_pngjpeg_Extension,
                                // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                                // keywords : ManCatKeywords
                                keywords : tagsKey,
                                keysToShow : tags,
                                caption:Post_Caption,
                                previewImg :previewImgUrlEdit
                            })
            
            
                    
                        }).then(()=>{
                            // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
                            tags = [],sptags = [], tagsKey = [];
                            document.getElementById("EditPostUploading").style.display = "none" 
                            document.getElementById("SaveEditesButton").style.display = "" 
                            document.getElementById("Image1Modal").style.display = "flex"
                            console.log("Category Added")
                            swal("Post Edited Successfully")
                            $('#EditPostModal').modal('hide');
                            AllPost();
                            
            
                        })
                    })
                
                }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg =="" && Post_psd !=="" ){
                    // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
                    document.getElementById("EditPostUploading").style.display = "flex" 
                    document.getElementById("SaveEditesButton").style.display = "flex" 
                    document.getElementById("Image1Modal").style.display = "none"
                    // //alert("In true")
                    const ref = firebase.storage().ref();
                    // const file = document.querySelector('#pngjpeg').files[0]
                    const file2 =  document.querySelector('#psdfileModal').files[0]
                    const file3 = document.querySelector('#previewImageEdit').files[0]
    
                    // const name =  file.name;
                    const name2 = file2.name;
                    const name3 = file3.name;
                    const metadata = {
                    contentType: file.type
                    };
                    // const task = ref.child('meChitrakar/' + name).put(file, metadata);
                    const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
                    const task3 = ref.child('meChitrakar/' + name3).put(file3, metadata);
                    task3
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
        
        
                        previewImgUrlEdit = url;
        
        
                
                    }).then(()=>{
                        task2
                        .then(snapshot => snapshot.ref.getDownloadURL())
                        .then((url) => {
            
                            pngjpegUrl = url; 
                            firestore.collection("Post").doc(Post_To_Be_Edited).update({
                                postTitle: postTitle,
                                postMainCat : Cat_name,
                                postSubCat : Sub_Cat_Name,
                                psd : url,
                                ziporrar : Post_psd_Extension,
                                // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                                // keywords : ManCatKeywords
                                keywords : tagsKey,
                                keysToShow : tags,
                                caption:Post_Caption,
                                previewImg :previewImgUrlEdit
                            })
            
            
                    
                        }).then(()=>{
                            // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
                            document.getElementById("EditPostUploading").style.display = "none" 
                            document.getElementById("SaveEditesButton").style.display = "" 
                            document.getElementById("Image1Modal").style.display = "flex"
                            tags = [],sptags = [], tagsKey = [];
                            console.log("Category Added")
                            swal("Post Edited Successfully")
                            $('#EditPostModal').modal('hide');
                            AllPost();
                            // alert("Category Added")
                            
                            
                            // Cat_name = document.getElementById("basic-default-fullname").value = "";
                            // Cat_img = document.getElementById("formFile").value = "";
            
                        })
                    })
             
                }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg =="" && Post_psd =="" ){
                    // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
                    const ref = firebase.storage().ref();
                    const file3 = document.querySelector('#previewImageEdit').files[0]
                    const name3 = file3.name;
                    const metadata = {
                        contentType: file3.type
                        };
                    const task3 = ref.child('meChitrakar/' + name3).put(file3, metadata);
               
                    
                    document.getElementById("SaveEditesButton").style.display = "none" 
                    document.getElementById("EditPostUploading").style.display = "flex" 
                    document.getElementById("Image1Modal").style.display = "none"
                    // alert("In true")
        
        
                    task3
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
        
        
                        previewImgUrlEdit = url;
        
        
                
                    }).then(()=>{
                        firestore.collection("Post").doc(Post_To_Be_Edited).update({
                            postTitle: postTitle,
                            postMainCat : Cat_name,
                            postSubCat : Sub_Cat_Name,
        
                            // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                            // keywords : ManCatKeywords
                            keywords : tagsKey,
                            keysToShow : tags,
                            caption:Post_Caption,
                            previewImg :previewImgUrlEdit
                        }).then(()=>{
        
                            tags = [],sptags = [], tagsKey = [];
                            document.getElementById("EditPostUploading").style.display = "none" 
                            document.getElementById("Image1Modal").style.display = "flex"
                            document.getElementById("SaveEditesButton").style.display = "" 
                            swal("Post Edited Successfully")
                            $('#EditPostModal').modal('hide');
                            AllPost();
        
        
                
                    
                        // alert("Category Added")
                        
                        
                        // Cat_name = document.getElementById("basic-default-fullname").value = "";
                        // Cat_img = document.getElementById("formFile").value = "";
        
                    })
                    })
                    
                }
    
            }else{
                if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !=="" && Post_psd !=="" ){
    
                    // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
                    document.getElementById("EditPostUploading").style.display = "flex" 
                    document.getElementById("SaveEditesButton").style.display = "none" 
                    document.getElementById("Image1Modal").style.display = "none"
                    // //alert("In true")
                    const ref = firebase.storage().ref();
                    const file = document.querySelector('#pngjpegModal').files[0]
                    const file2 =  document.querySelector('#psdfileModal').files[0]
                    const name =  file.name;
                    const name2 = file2.name;
                    const metadata = {
                    contentType: file.type
                    };
                    const task = ref.child('meChitrakar/' + name).put(file, metadata);
                    const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
                    
                    task
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
        
                        pngjpegUrl = url; 
                    // console.log("Jpeg",url);
        
        
                
                    }).then(()=>{
                        task2 .then(snapshot => snapshot.ref.getDownloadURL())
                        .then((url) => {
                            psdurl = url
                
                            firestore.collection("Post").doc(Post_To_Be_Edited).update({
                                postTitle: postTitle,
                                postMainCat : Cat_name,
                                postSubCat : Sub_Cat_Name,
                                pngorjpeg : pngjpegUrl,
                                pngandjpeg : Post_pngjpeg_Extension,
                                psd : url,
                                ziporrar : Post_psd_Extension,
                                // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                                // keywords : ManCatKeywords
                                keywords : tagsKey,
                                keysToShow : tags,
                                caption:Post_Caption
                            })
                    
                    }).then(()=>{
                        // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
                        document.getElementById("EditPostUploading").style.display = "none" 
                        document.getElementById("SaveEditesButton").style.display = "" 
                        document.getElementById("Image1Modal").style.display = "flex"
                        swal("Post Edited Successfully")
                        AllPost();
                        
                        tags = [],sptags = [], tagsKey = [];
                        // Set the "capital" field of the city 'DC'
                    
        
                    
                        
                        
                        // Cat_name = document.getElementById("basic-default-fullname").value = "";
                        // Cat_img = document.getElementById("formFile").value = "";
        
                    })
                    })
                    
                }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !==""  && Post_psd ==""){
                    // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
                    document.getElementById("EditPostUploading").style.display = "flex" 
                    document.getElementById("SaveEditesButton").style.display = "none" 
                    document.getElementById("Image1Modal").style.display = "none"
                    // //alert("In true")
                    const ref = firebase.storage().ref();
                    const file = document.querySelector('#pngjpegModal').files[0]
                    // const file2 =  document.querySelector('#psdfile').files[0]
                    const name =  file.name;
                    // const name2 = file2.name;
                    const metadata = {
                    contentType: file.type
                    };
                    const task = ref.child('meChitrakar/' + name).put(file, metadata);
                    // const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
                    
                    task
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
        
                        pngjpegUrl = url; 
                        firestore.collection("Post").doc(Post_To_Be_Edited).update({
                            postTitle: postTitle,
                            postMainCat : Cat_name,
                            postSubCat : Sub_Cat_Name,
                            pngorjpeg : url,
                            pngandjpeg : Post_pngjpeg_Extension,
                            // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                            // keywords : ManCatKeywords
                            keywords : tagsKey,
                            keysToShow : tags,
                            caption:Post_Caption
                        })
        
        
                
                    }).then(()=>{
                        // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
                        tags = [],sptags = [], tagsKey = [];
                        document.getElementById("EditPostUploading").style.display = "none" 
                        document.getElementById("SaveEditesButton").style.display = "" 
                        document.getElementById("Image1Modal").style.display = "flex"
                        console.log("Category Added")
                        swal("Post Edited Successfully")
                        $('#EditPostModal').modal('hide');
                        AllPost();
                        
        
                    })
                }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg =="" && Post_psd !=="" ){
                    // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
                    document.getElementById("EditPostUploading").style.display = "flex" 
                    document.getElementById("SaveEditesButton").style.display = "flex" 
                    document.getElementById("Image1Modal").style.display = "none"
                    // //alert("In true")
                    const ref = firebase.storage().ref();
                    // const file = document.querySelector('#pngjpeg').files[0]
                    const file2 =  document.querySelector('#psdfileModal').files[0]
                    // const name =  file.name;
                    const name2 = file2.name;
                    const metadata = {
                    contentType: file.type
                    };
                    // const task = ref.child('meChitrakar/' + name).put(file, metadata);
                    const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
                    
                    task2
                    .then(snapshot => snapshot.ref.getDownloadURL())
                    .then((url) => {
        
                        pngjpegUrl = url; 
                        firestore.collection("Post").doc(Post_To_Be_Edited).update({
                            postTitle: postTitle,
                            postMainCat : Cat_name,
                            postSubCat : Sub_Cat_Name,
                            psd : url,
                            ziporrar : Post_psd_Extension,
                            // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                            // keywords : ManCatKeywords
                            keywords : tagsKey,
                            keysToShow : tags,
                            caption:Post_Caption
                        })
        
        
                
                    }).then(()=>{
                        // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
                        document.getElementById("EditPostUploading").style.display = "none" 
                        document.getElementById("SaveEditesButton").style.display = "" 
                        document.getElementById("Image1Modal").style.display = "flex"
                        tags = [],sptags = [], tagsKey = [];
                        console.log("Category Added")
                        swal("Post Edited Successfully")
                        $('#EditPostModal').modal('hide');
                        AllPost();
                        // alert("Category Added")
                        
                        
                        // Cat_name = document.getElementById("basic-default-fullname").value = "";
                        // Cat_img = document.getElementById("formFile").value = "";
        
                    })
                }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg =="" && Post_psd =="" ){
                    // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
                    document.getElementById("SaveEditesButton").style.display = "none" 
                    document.getElementById("EditPostUploading").style.display = "flex" 
                    document.getElementById("Image1Modal").style.display = "none"
                    // alert("In true")
        
        
                    
                        firestore.collection("Post").doc(Post_To_Be_Edited).update({
                            postTitle: postTitle,
                            postMainCat : Cat_name,
                            postSubCat : Sub_Cat_Name,
        
                            // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                            // keywords : ManCatKeywords
                            keywords : tagsKey,
                            keysToShow : tags,
                            caption:Post_Caption,
                        }).then(()=>{
        
                            tags = [],sptags = [], tagsKey = [];
                            document.getElementById("EditPostUploading").style.display = "none" 
                            document.getElementById("Image1Modal").style.display = "flex"
                            document.getElementById("SaveEditesButton").style.display = "" 
                            swal("Post Edited Successfully")
                            $('#EditPostModal').modal('hide');
                            AllPost();
        
        
                
                    
                        // alert("Category Added")
                        
                        
                        // Cat_name = document.getElementById("basic-default-fullname").value = "";
                        // Cat_img = document.getElementById("formFile").value = "";
        
                    })
                }
            }
        
    
        }
        
        // else{
        //     if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !=="" && Post_psd !=="" && tags.length !== 0){
    
        //         // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
        //         document.getElementById("EditPostUploading").style.display = "flex" 
        //         document.getElementById("SaveEditesButton").style.display = "none" 
        //         document.getElementById("Image1Modal").style.display = "none"
        //         // //alert("In true")
        //         const ref = firebase.storage().ref();
        //         const file = document.querySelector('#pngjpegModal').files[0]
        //         const file2 =  document.querySelector('#psdfileModal').files[0]
        //         const name =  file.name;
        //         const name2 = file2.name;
        //         const metadata = {
        //         contentType: file.type
        //         };
        //         const task = ref.child('meChitrakar/' + name).put(file, metadata);
        //         const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
                
        //         task
        //         .then(snapshot => snapshot.ref.getDownloadURL())
        //         .then((url) => {
    
        //             pngjpegUrl = url; 
        //         // console.log("Jpeg",url);
    
    
            
        //         }).then(()=>{
        //             task2 .then(snapshot => snapshot.ref.getDownloadURL())
        //             .then((url) => {
        //                 psdurl = url
            
        //                 firestore.collection("Post").doc(Post_To_Be_Edited).update({
        //                     postTitle: postTitle,
        //                     postMainCat : Cat_name,
        //                     postSubCat : Sub_Cat_Name,
        //                     pngorjpeg : pngjpegUrl,
        //                     pngandjpeg : Post_pngjpeg_Extension,
        //                     psd : url,
        //                     ziporrar : Post_psd_Extension,
        //                     // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
        //                     // keywords : ManCatKeywords
        //                     keywords : tagsKey,
        //                     keysToShow : tags,
        //                     caption:Post_Caption
        //                 })
                
        //         }).then(()=>{
        //             // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
        //             document.getElementById("EditPostUploading").style.display = "none" 
        //             document.getElementById("SaveEditesButton").style.display = "" 
        //             document.getElementById("Image1Modal").style.display = "flex"
        //             swal("Post Edited Successfully")
        //             AllPost();
                    
                    
        //             // Set the "capital" field of the city 'DC'
                
    
                
                    
                    
        //             // Cat_name = document.getElementById("basic-default-fullname").value = "";
        //             // Cat_img = document.getElementById("formFile").value = "";
    
        //         })
        //         })
                
        //     }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !==""  && Post_psd ==""){
        //         // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
        //         document.getElementById("EditPostUploading").style.display = "flex" 
        //         document.getElementById("SaveEditesButton").style.display = "none" 
        //         document.getElementById("Image1Modal").style.display = "none"
        //         // //alert("In true")
        //         const ref = firebase.storage().ref();
        //         const file = document.querySelector('#pngjpegModal').files[0]
        //         // const file2 =  document.querySelector('#psdfile').files[0]
        //         const name =  file.name;
        //         // const name2 = file2.name;
        //         const metadata = {
        //         contentType: file.type
        //         };
        //         const task = ref.child('meChitrakar/' + name).put(file, metadata);
        //         // const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
                
        //         task
        //         .then(snapshot => snapshot.ref.getDownloadURL())
        //         .then((url) => {
    
        //             pngjpegUrl = url; 
        //             firestore.collection("Post").doc(Post_To_Be_Edited).update({
        //                 postTitle: postTitle,
        //                 postMainCat : Cat_name,
        //                 postSubCat : Sub_Cat_Name,
        //                 pngorjpeg : url,
        //                 pngandjpeg : Post_pngjpeg_Extension,
        //                 // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
        //                 // keywords : ManCatKeywords
        //                 keywords : tagsKey,
        //                 keysToShow : tags,
        //                 caption:Post_Caption
        //             })
    
    
            
        //         }).then(()=>{
        //             // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
        //             document.getElementById("EditPostUploading").style.display = "none" 
        //             document.getElementById("SaveEditesButton").style.display = "" 
        //             document.getElementById("Image1Modal").style.display = "flex"
        //             console.log("Category Added")
        //             swal("Post Edited Successfully")
        //             $('#EditPostModal').modal('hide');
        //             AllPost();
                    
    
        //         })
        //     }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg =="" && Post_psd !=="" ){
        //         // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
        //         document.getElementById("EditPostUploading").style.display = "flex" 
        //         document.getElementById("SaveEditesButton").style.display = "flex" 
        //         document.getElementById("Image1Modal").style.display = "none"
        //         // //alert("In true")
        //         const ref = firebase.storage().ref();
        //         // const file = document.querySelector('#pngjpeg').files[0]
        //         const file2 =  document.querySelector('#psdfileModal').files[0]
        //         // const name =  file.name;
        //         const name2 = file2.name;
        //         const metadata = {
        //         contentType: file.type
        //         };
        //         // const task = ref.child('meChitrakar/' + name).put(file, metadata);
        //         const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
                
        //         task2
        //         .then(snapshot => snapshot.ref.getDownloadURL())
        //         .then((url) => {
    
        //             pngjpegUrl = url; 
        //             firestore.collection("Post").doc(Post_To_Be_Edited).update({
        //                 postTitle: postTitle,
        //                 postMainCat : Cat_name,
        //                 postSubCat : Sub_Cat_Name,
        //                 psd : url,
        //                 ziporrar : Post_psd_Extension,
        //                 // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
        //                 // keywords : ManCatKeywords
        //                 keywords : tagsKey,
        //                 keysToShow : tags,
        //                 caption:Post_Caption
        //             })
    
    
            
        //         }).then(()=>{
        //             // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
        //             document.getElementById("EditPostUploading").style.display = "none" 
        //             document.getElementById("SaveEditesButton").style.display = "" 
        //             document.getElementById("Image1Modal").style.display = "flex"
        //             console.log("Category Added")
        //             swal("Post Edited Successfully")
        //             $('#EditPostModal').modal('hide');
        //             AllPost();
        //             // alert("Category Added")
                    
                    
        //             // Cat_name = document.getElementById("basic-default-fullname").value = "";
        //             // Cat_img = document.getElementById("formFile").value = "";
    
        //         })
        //     }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg =="" && Post_psd =="" ){
        //         // var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
        //         document.getElementById("SaveEditesButton").style.display = "none" 
        //         document.getElementById("EditPostUploading").style.display = "flex" 
        //         document.getElementById("Image1Modal").style.display = "none"
        //         // alert("In true")
    
    
                
        //             firestore.collection("Post").doc(Post_To_Be_Edited).update({
        //                 postTitle: postTitle,
        //                 postMainCat : Cat_name,
        //                 postSubCat : Sub_Cat_Name,
    
        //                 // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
        //                 // keywords : ManCatKeywords
        //                 keywords : tagsKey,
        //                 keysToShow : tags,
        //                 caption:Post_Caption,
        //             }).then(()=>{
    
                    
        //                 document.getElementById("EditPostUploading").style.display = "none" 
        //                 document.getElementById("Image1Modal").style.display = "flex"
        //                 document.getElementById("SaveEditesButton").style.display = "" 
        //                 swal("Post Edited Successfully")
        //                 $('#EditPostModal').modal('hide');
        //                 AllPost();
    
    
            
                
        //             // alert("Category Added")
                    
                    
        //             // Cat_name = document.getElementById("basic-default-fullname").value = "";
        //             // Cat_img = document.getElementById("formFile").value = "";
    
        //         })
        //     }
    
        // }
    
}

function changeExtension(params,params1) {


            // if(params == 'PNG' || params == 'JPEG'){
                
            //     png_or_jpeg = params
            //     $("#pngjpeg").attr("accept",".zip");
            //     document.getElementById("pngjpeg").disabled = false
            //     document.getElementById("Ext").innerText = params

            // }else if(params == 'ZIP' || params == 'RAR'){
            //     zip_or_rar = params

            //     $("#ziprar").attr("accept",".zip");
            //     document.getElementById("ziprar").disabled = false
            //     document.getElementById("Ext1").innerText = params  
            // }

            if(params == 'PNG'){

                png_or_jpeg = params

                $("#pngjpeg").attr("accept",".png");

                document.getElementById("pngjpeg").disabled = false
           
                document.getElementById("Ext").innerText = params

            }
             else if(params == 'JPEG'){

                png_or_jpeg = params

                $("#pngjpeg").attr("accept",".jpeg,.jpg");

                
                document.getElementById("pngjpeg").disabled = false
           
                document.getElementById("Ext").innerText = params

            }else if(params == 'PSD'){

                zip_or_rar = params

                $("#ziprar").attr("accept",".psd");

                document.getElementById("ziprar").disabled = false
           
                document.getElementById("Ext1").innerText = params

            }else if(params == 'TIF'){

                zip_or_rar = params

                $("#ziprar").attr("accept",".tif,.tiff,.TIFF,.TIF");

                document.getElementById("ziprar").disabled = false
           
                document.getElementById("Ext1").innerText = params

            }

}
function changeModalExtension(params,params1) {


    // if(params == 'PNG' || params == 'JPEG'){
        
    //     png_or_jpeg = params
    //     $("#pngjpeg").attr("accept",".zip");
    //     document.getElementById("pngjpeg").disabled = false
    //     document.getElementById("Ext").innerText = params

    // }else if(params == 'ZIP' || params == 'RAR'){
    //     zip_or_rar = params

    //     $("#ziprar").attr("accept",".zip");
    //     document.getElementById("ziprar").disabled = false
    //     document.getElementById("Ext1").innerText = params  
    // }

    if(params == 'PNG'){

        png_or_jpeg = params

        $("#pngjpegModal").attr("accept",".png");

        document.getElementById("pngjpegModal").disabled = false
   
        document.getElementById("pngjpegModalExt").innerText = params

    }
    else if(params == 'JPEG'){

        png_or_jpeg = params

        $("#pngjpegModal").attr("accept",".jpeg,.jpg");

        
        document.getElementById("pngjpegModal").disabled = false
   
        document.getElementById("pngjpegModalExt").innerText = params

    }else if(params == 'ZIP'){

        zip_or_rar = params

        $("#psdfileModal").attr("accept",".zip");

        document.getElementById("psdfileModal").disabled = false
   
        document.getElementById("psdfileModal").innerText = params

    }else if(params == 'TIF'){

        zip_or_rar = params

        $("#psdfileModal").attr("accept",".tif,.TIF,.tiff,.TIFF");

        document.getElementById("psdfileModal").disabled = false
   
        document.getElementById("psdfileModal").innerText = params

    }

}



document.getElementById('mostadnLeastDataInput').addEventListener('click', (e) => {
    e.target.value = ''
})

document.getElementById('ImageTypeListInput').addEventListener('click', (e) => {
    e.target.value = ''
})

function RenderPostByDownloads(params,params1) {
    DownloadFilterNext == "download"
    imagecounttype = params;
    filtertype = params1;

    document.getElementById("LoadmoreButtondiv").style.display = 'none'
    // alert("In All");
    RednerSubCat = params

    firestore.collection("Post").where("userUID","==",UserID).orderBy(`${params}`,`${params1}`).limit(5)
    .get()
    .then((querySnapshot) => {

        var SubCatchild = document.getElementById("PostContainer");
    
        while(SubCatchild.children.length!==0){
            
            SubCatchild.children[0].remove();
        }
        if( querySnapshot.docs.length == 0 ){
           
            document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'
            (swal("There is no Record Found")) 

        }

        LastDocDownloadFiler = querySnapshot.docs[querySnapshot.docs.length-1];

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
           $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
           <div class="card h-100">
        <div>
        </div>
             <div class="card-body">

               <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>

               <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
            <div style="display:flex;justify-content: space-between;">
               <div>
                      <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
               </div>
               <div>
               <label class="switch switch-slide">
               <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
               <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
               <span class="switch-handle"></span>
               </label>
               </div>
               <div style="display:flex;margin-top: 0.5rem;">
                    <i class='bx bxs-download'></i>
                    <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                    <i class='bx bxs-download'></i>
                    <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                </div>
            </div>
             </div>
           </div>
         </div>`)
         document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

        });
    }).then(()=>{

        document.getElementById("LoadmoreButtondivAllpost").style.display = "flex"
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    
}


function RenderPostByDownloads_MainCat(params,params1,params2,params3) {

    // alert("RenderPostByDownloads_MainCat");
    DownloadFilterNext = "download_main_Cat"
    MainCatDBFieldname = params
    imagecounttype = params2;
    filtertype = params3;

    document.getElementById("LoadmoreButtondiv").style.display = 'none'
    // alert("In All");
    RednerSubCat = params

    firestore.collection("Post").where("userUID","==",UserID).where(params,"==",params1).orderBy(`${params2}`,`${params3}`).limit(5)
    .get()
    .then((querySnapshot) => {

        var SubCatchild = document.getElementById("PostContainer");
    
        while(SubCatchild.children.length!==0){
            
            SubCatchild.children[0].remove();
        }
        if( querySnapshot.docs.length == 0 ){
           
            document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'
            (swal("There is no Record Found")) 

        }

        LastDoc_MainCat_With_ImageType = querySnapshot.docs[querySnapshot.docs.length-1];

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
           $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
           <div class="card h-100">
        <div>
        </div>
             <div class="card-body">

               <h5 class="card-title">${doc.data().postTitle}(${doc.data().PostUID})</h5>

               <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
            <div style="display:flex;justify-content: space-between;">
               <div>
                      <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
               </div>
               <div>
               <label class="switch switch-slide">
               <input class="switch-input" type="checkbox" id="${doc.id}-check" onclick="SetVisibilty(this.id)"/>
               <span class="switch-label" data-on="Visible" data-off="Invisible"></span> 
               <span class="switch-handle"></span>
               </label>
               </div>
               <div style="display:flex;margin-top: 0.5rem;">
                    <i class='bx bxs-download'></i>
                    <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
                    <i class='bx bxs-download'></i>
                    <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
                </div>
            </div>
             </div>
           </div>
         </div>`)
         document.getElementById(`${doc.id}-check`).checked = doc.data().visibility;

        });
    }).then(()=>{

        document.getElementById("LoadmoreButtondivAllpost").style.display = "flex"
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    
}


keyword.addEventListener("keyup",function(event){
    //console.log(event);
    if(event.keyCode === 13)
    {
        if(keyword.value == "" || keyword.value == " ")
        {
            swal("Keyword Not be Blank");
            keyword.value = "";
        }
        else
        {
            //let str = (keyword.value).replaceAll(" ","");
            addTags((keyword.value).toLowerCase());
            keyword.value = "";
        }
    }
})

var keyword2 = document.getElementById("keyword_Edited")
keyword2.addEventListener("keyup",function(event){
    //console.log(event);
    if(event.keyCode === 13)
    {
        if(keyword2.value == "" || keyword2.value == " ")
        {
            swal("Keyword Not be Blank");
            keyword2.value = "";
        }
        else
        {
            //let str = (keyword.value).replaceAll(" ","");
            addTags_Edited((keyword2.value).toLowerCase());
            keyword2.value = "";
        }
    }
})

function addTags_Edited(val)
{
    var par = document.getElementById('tagContainer_EDIT');
    var tag = document.createElement('span');
    tag.setAttribute('id',val);
    tag.classList.add('badge','bg-dark');
    tag.innerHTML = val+' <span class="closetag" onclick="removeTags_Edited(this)">&times;</span>';
    par.appendChild(tag);
    tags.push(val);
    createKeywords_Edited(val);
    //console.log(tags,tagsKey);
}
//<span id="vivek" class="badge badge-pill badge-primary">vivek <span class="closetag" onclick="removeTags(this)">×</span></span>
function createKeywords_Edited(name) 
{   
    const arrName = [];
    let curName = '';
    name.split('').forEach(letter => {
    curName += letter;
    arrName.push(curName.trim());
    });
    tagsKey = tagsKey.concat(arrName);
    console.log("tagsKey",tags)

}

function removeTags_Edited(ele)
{
    tagsKey = [];
    let tname = ele.parentElement.id;
    let i = tags.indexOf(tname);
    tags.splice(i,1);
    
    for(var k = 0;k<tags.length;k++)
    {
        createKeywords_Edited(tags[k]);
    }
    
    ele.parentElement.remove();
    //console.log(tags,tagsKey);
}


function addTags(val)
{
    var par = document.getElementById('tagContainer');
    var tag = document.createElement('span');
    tag.setAttribute('id',val);
    tag.classList.add('badge','bg-dark');
    tag.innerHTML = val+' <span class="closetag" onclick="removeTags(this)">&times;</span>';
    par.appendChild(tag);
    tags.push(val);
    createKeywords(val);
    //console.log(tags,tagsKey);
}
//<span id="vivek" class="badge badge-pill badge-primary">vivek <span class="closetag" onclick="removeTags(this)">×</span></span>
function createKeywords(name) 
{   
    const arrName = [];
    let curName = '';
    name.split('').forEach(letter => {
    curName += letter;
    arrName.push(curName.trim());
    });
    tagsKey = tagsKey.concat(arrName);
    console.log("tagsKey",tags)

}

function removeTags(ele)
{
    tagsKey = [];
    let tname = ele.parentElement.id;
    let i = tags.indexOf(tname);
    tags.splice(i,1);
    
    for(var k = 0;k<tags.length;k++)
    {
        createKeywords(tags[k]);
    }
    
    ele.parentElement.remove();
    //console.log(tags,tagsKey);
}

function removeAllTags()
{
    var tagbody = document.getElementById('tagContainer');
    while(tagbody.firstChild)
    {
        tagbody.removeChild(tagbody.firstChild);
    }
    //another 
    var sptagbody = document.getElementById('sptagContainer');
    while(sptagbody.firstChild)
    {
        sptagbody.removeChild(sptagbody.firstChild);
    }
}

function SetVisibilty(params){
    

    var doc = params.substring(0, params.indexOf('-'));
        // var docRef = firestore.collection("Post").doc(params.substring(0, params.indexOf('-')));
    console.log("params",params,doc)
        firestore.collection("Post").doc(doc).update({
            visibility: document.getElementById(params).checked
        })
        .then((docRef) => {
          alert("Visibility Updated")
        })
        .catch((error) => {
            console.error("Error adding document: ", error);
        });
    
}


function readURL(input,input2) {
 
    
    if(input2 == "Preview"){
      
            if(input.files[0].size > 50000){
                input.value = "";
               document.getElementById("previewImagevalidation").style.display = ""
              
            }else{
                document.getElementById("previewImagevalidation").style.display = "none"
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
            
                    reader.onload = function (e) {
                        $('#Image1')
                            .attr('src', e.target.result)
                 
                    };
            
                    reader.readAsDataURL(input.files[0]);
                }
            }
    
    }else{
        if (input.files && input.files[0]) {
            var reader = new FileReader();
    
            reader.onload = function (e) {
                $('#Image1')
                    .attr('src', e.target.result)
         
            };
    
            reader.readAsDataURL(input.files[0]);
        }
    }
}
function Image1Modal1(input,input2) {
    // if (input.files && input.files[0]) {
    //     var reader = new FileReader();

    //     reader.onload = function (e) {
    //         $('#Image1Modal')
    //             .attr('src', e.target.result)
     
    //     };

    //     reader.readAsDataURL(input.files[0]);
    // }

    if(input2 == "Preview"){
      
        if(input.files[0].size > 50000){
            document.getElementById("previewImageEditvalidation").style.display = "flex"
            input.value = "";
   
          
        }else{
            document.getElementById("previewImageEditvalidation").style.display = "none"
            if (input.files && input.files[0]) {
                var reader = new FileReader();
        
                reader.onload = function (e) {
                    $('#Image1Modal')
                        .attr('src', e.target.result)
             
                };
        
                reader.readAsDataURL(input.files[0]);
            }
        }

    }else{
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#Image1Modal')
                    .attr('src', e.target.result)
        
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
}
































































// function getAllSubstrings(str) {

// 	for (let j = 1 ; j < str.length + 1; j++) {
// 	  result.push(str.slice(i, j));

// 	}
// 	for (let j = str.indexOf(" ")+2 ; j < str.length + 1; j++) {
// 	  result.push(str.slice(str.indexOf(" ")+1, j));
//   }
// return result;

// }


// firestore.collection("UniqueID").get().then((querySnapshot) => {
//     querySnapshot.forEach((doc) => {
//         // doc.data() is never undefined for query doc snapshots
//         uid = doc.data().uniqueID
   
//     });
// });


// getMainCatForPost();
// function getMainCatForPost(params) {



//     firestore.collection("Category").get().then((querySnapshot) => {
//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $("#mainCatList").append(`<option value="${doc.data().catName}" onclick="getSubCatForPost(this.value)">`)
       
//         });
//     });

// }

// function getSubCatForPost(params) {
  
   
  
//     var MainCatDoc;
//     var SubcatChild = document.getElementById("subCatList");
//     while(SubcatChild.children.length!==0){
        
//         SubcatChild.children[0].remove();
//     }

//     firestore.collection("Category").where("catName", "==",params)
//     .get()
//     .then((querySnapshot) => {
//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             MainCatDoc =  doc.id
//         });
//     }).then(()=>{

      
//         firestore.collection("Category").doc(MainCatDoc).collection("SubCat").get().then((querySnapshot) => {
//             querySnapshot.forEach((doc) => {
//                 // doc.data() is never undefined for query doc snapshots
//                 $("#subCatList").append(`<option value="${doc.data().subCatName}">`)
        
//             });
//         });
//     })
//     .catch((error) => {
//         console.log("Error getting documents: ", error);
//     });


// }



// function readURL(input) {
//     if (input.files && input.files[0]) {
//         var reader = new FileReader();

//         reader.onload = function (e) {
//             $('#Image1')
//                 .attr('src', e.target.result)
     
//         };

//         reader.readAsDataURL(input.files[0]);
//     }
// }
// function Image1Modal1(input) {
//     if (input.files && input.files[0]) {
//         var reader = new FileReader();

//         reader.onload = function (e) {
//             $('#Image1Modal')
//                 .attr('src', e.target.result)
     
//         };

//         reader.readAsDataURL(input.files[0]);
//     }
// }

// // $(".dropdown-item").click(function(){

// //     ExtensionFlag = $(this).text();

// //     $("#Ext").html($(this).text());

// // });

// // $(".dropdown-item").click(function(){

// //     ExtensionFlag = $(this).text();

// //     $("#Ext1").html($(this).text());

// // });

// $("#PostSubCatinput").change(()=>{
    
//     tobeFilter = document.getElementById("PostSubCatinput").value;

//     RenderPost(tobeFilter,'postSubCat');
    
// })

// $("#PostMainCatinput").change(()=>{
    
//     tobeFilter = document.getElementById("PostMainCatinput").value;

//     if(tobeFilter!=='All'){
        
//         RenderPost(tobeFilter,'postMainCat');
//     }else if(tobeFilter=='All'){
//         AllPost();
//     }
        
    
// })


// function SavePost(params) {

//     console.log("UserID",UserID)

//     var Cat_name,Cat_img,Post_pngjpeg,Post_psd,Sub_Cat_Name;
//     postTitle = document.getElementById("postTitle").value;
//     Cat_name = document.getElementById("mainCatSearch").value;
//     Sub_Cat_Name = document.getElementById("subCatSearch").value;
//     Post_pngjpeg = document.getElementById("pngjpeg").value;
//     Post_psd = document.getElementById("ziprar").value;
//     var ForKeyWord = `${uid+1} ${postTitle} `;



//     var pngjpegUrl;
//     var psdurl;

// if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !=="" && Post_psd !=="" ){
   
//     document.getElementById("Uploading").style.display = "flex" 
//     document.getElementById("Image1").style.display = "none"
//     var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());

//     // alert("In true")
//     const ref = firebase.storage().ref();
//     const file = document.querySelector('#pngjpeg').files[0]
//     const file2 =  document.querySelector('#ziprar').files[0]
//     const name =  file.name;
//     const name2 = file2.name;
//     const metadata = {
//     contentType: file.type
//     };
//     const task = ref.child('meChitrakar/' + name).put(file, metadata);
//     const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
    
//     task
//     .then(snapshot => snapshot.ref.getDownloadURL())
//     .then((url) => {

//         pngjpegUrl = url; 
//     // console.log("Jpeg",url);

//     }).then(()=>{
//         task2 .then(snapshot => snapshot.ref.getDownloadURL())
//         .then((url) => {
//             psdurl = url
  
//                firestore.collection("Post").add({
//                 postTitle: postTitle,
//                 postMainCat : Cat_name,
//                 postSubCat : Sub_Cat_Name,
//                 pngorjpeg : pngjpegUrl,
//                 psd : url,
//                 date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
//                 PostUID : uid+1,
//                 keywords : ManCatKeywords,
//                 pngandjpeg : png_or_jpeg,
//                 ziporrar : zip_or_rar,     
//                 userUID : UserID      

//             })
       
//     }).then(()=>{
//         // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
//         console.log("Category Added")
//         var washingtonRef = firestore.collection("UniqueID").doc("IY69gSQmwZDPbkuqcTz0");
//         uid = uid+1;
//         // Set the "capital" field of the city 'DC'
//         return washingtonRef.update({
//             uniqueID: uid
//         })
//         .then(() => {
//             document.getElementById("Uploading").style.display = "none"
//             document.getElementById("Image1").style.display = "flex"
//              document.getElementById("postTitle").value ="" 
//              document.getElementById("mainCatSearch").value ="" 
//              document.getElementById("subCatSearch").value = ""
//              document.getElementById("pngjpeg").value = ""
//              document.getElementById("ziprar").value = ""
//              document.getElementById("Image1").src = "../assets/img/photo.png"
             
//                 swal("Post Uploaded successfully!")

           
//             // console.log("Document successfully updated!");
//         })
//         .catch((error) => {
//             // The document probably doesn't exist.
//             console.error("Error updating document: ", error);
//         });

//         // alert("Category Added")
        
        
//         // Cat_name = document.getElementById("basic-default-fullname").value = "";
//         // Cat_img = document.getElementById("formFile").value = "";

//     })
//     })

// }else{

//     if(postTitle == ""){
//         document.getElementById("posttitlevalidation").style.display = ""

//     }else{
//         document.getElementById("posttitlevalidation").style.display = "none"
//     }

//     if(Cat_name == ""){

//         document.getElementById("maincatvalidation").style.display = ""

//     }else{
//         document.getElementById("maincatvalidation").style.display = "none"
//     }

//     if(Sub_Cat_Name == ""){

//         document.getElementById("subcatvalidation").style.display = ""

//     }else{

//         document.getElementById("subcatvalidation").style.display = "none"
//     }

//     if(Post_pngjpeg == ""){

//         document.getElementById("pngjpegvalidation").style.display = ""

//     }else{
//         document.getElementById("pngjpegvalidation").style.display = "none"
//     }
    
//     if(Post_psd == ""){

//         document.getElementById("psdvalidation").style.display = ""

//     }else{

//         document.getElementById("psdvalidation").style.display = "none"
//     }

// }   
// }


// function SearchPost(params) {
//     var tobeSearch = document.getElementById("SearchPost").value.toLowerCase();

//     firestore.collection("Post").where("keywords","array-contains",tobeSearch).get()
//         .then((querySnapshot) => {
//             var SubCatchild = document.getElementById("PostContainer");
    
//             while(SubCatchild.children.length!==0){
                
//                 SubCatchild.children[0].remove();
//             }
//             querySnapshot.forEach((doc) => {

//                 $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
//                 <div class="card h-100">
//                   <div class="card-body">
//                     <h5 class="card-title">${doc.data().postTitle}</h5>
//                     <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">

//                   </div>
//                 </div>
//               </div>`)



//         })
//     })
    
// }

// function ResetSearch(params) {
    
//     var SearchBox;
//     var maincatDropDown;
//     var SubCategory;
//     SearchBox = document.getElementById("SearchPost").value;
//     maincatDropDown = document.getElementById("PostMainCatinput").value;
//     SubCategory = document.getElementById("PostSubCatinput").value;
    
//     if(SearchBox == "" && maincatDropDown!== "" && SubCategory !==""){

//         RenderPost(tobeFilter);

//     }else if(SearchBox == "" && maincatDropDown== "" && SubCategory ==""){
        
//     }
// }


// $("#mainCatSearch").click(function(){

// document.getElementById("mainCatSearch").value = "";
// })

// $("#subCatSearch").click(function(){

//     document.getElementById("subCatSearch").value = "";
// })


// function PostOperations(params) {

//     if(params == "AddPost"){
//         var SubCatchild = document.getElementById("PostContainer");
    
//         while(SubCatchild.children.length!==0){
            
//             SubCatchild.children[0].remove();
//         }

//         document.getElementById('PostMainCatinput').value = '';
//         document.getElementById('PostSubCatinput').value = '';
      
//         document.getElementById("AddPostDiv").style.display = "flex";
//         document.getElementById("ViewpostDiv").style.display = "none";
//         document.getElementById("LoadmoreButtondiv").style.display = "none"; 
//         document.getElementById("LoadmoreButtondivAllpost").style.display = "none";

//     }else if(params == "ViewPost"){
//          AllPost();
//         document.getElementById("AddPostDiv").style.display = "none";
//         document.getElementById("ViewpostDiv").style.display = "flex";

//     }
    
// }


// getMainCategoryDropDown();
// function getMainCategoryDropDown(params) {

//     firestore.collection("Category").get().then((querySnapshot) => {
//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $("#PostdefaultSelectMainCat").append(`<option value="${doc.data().catName}" data-id="${doc.id}">`)
//         });
//     });

// }


// function getSubCategoryMenu(params) {
//      var SubCatchild = document.getElementById("PostdefaultSelectSubcat");
    
//         while(SubCatchild.children.length!==0){
            
//             SubCatchild.children[0].remove();
//         }

//     firestore.collection("Category").doc(params).collection("SubCat").get().then((querySnapshot) => {
//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $("#PostdefaultSelectSubcat").append(`<option value="${doc.data().subCatName}">`)
//         });
//     });

// }

// document.querySelector('#PostMainCatinput').addEventListener('input', (e) => {
//     Object.assign(e.target.dataset, document.querySelector('#' + e.target.getAttribute('list') + ' option[value="' + e.target.value + '"]').dataset);
//     console.log('dataset of input changed: ', e.target.dataset.id)
//     getSubCategoryMenu(e.target.dataset.id)
// });


// // document.querySelector('#PostSubCatinput').addEventListener('input', (e) => {
// //     Object.assign(e.target.dataset, document.querySelector('#' + e.target.getAttribute('list') + ' option[value="' + e.target.value + '"]').dataset);
// //     console.log('dataset of input changed: ', e.target.dataset.id)
// //     getSubCategoryMenu(e.target.dataset.id)
// // });

// // $("#PostSubCatinput").change(()=>{
    
// //     tobeFilter = document.getElementById("PostSubCatinput").value;

// //     RenderPost(tobeFilter);
    
// // })


// function RenderPost(params,params1) {

//     document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'
//     RednerSubCat = params
//     RendermainCat = params1
//     firestore.collection("Post").where(params1, "==", params).where("userUID","==",UserID).orderBy("date","desc").limit(5)
//     .get()
//     .then((querySnapshot) => {

//         var SubCatchild = document.getElementById("PostContainer");
    
//         while(SubCatchild.children.length!==0){
            
//             SubCatchild.children[0].remove();
//         }
//         if( querySnapshot.docs.length == 0 ){
           
//             document.getElementById("LoadmoreButtondiv").style.display = "none"
//             (swal("There is no Record Found")) 
           
//         }

//         LastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
//             <div class="card h-100">
//          <div>
//          </div>
//               <div class="card-body">
 
//                 <h5 class="card-title">${doc.data().postTitle}</h5>
 
//                 <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
//              <div style="display:flex;justify-content: space-between;">
//                 <div>
//                        <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
//                 </div>
//                 <div style="display:flex;margin-top: 0.5rem;">
//                      <i class='bx bxs-download'></i>
//                      <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
//                      <i class='bx bxs-download'></i>
//                      <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
//                  </div>
//              </div>
//               </div>
//             </div>
//           </div>`)
//         });
//     }).then(()=>{

//         document.getElementById("LoadmoreButtondiv").style.display = "flex"
//     })
//     .catch((error) => {
//         console.log("Error getting documents: ", error);
//     });

    
// }

// function NextRenderPost(params) {
//     firestore.collection("Post").where(RendermainCat, "==", RednerSubCat).where("userUID","==",UserID).orderBy("date","desc").startAfter(LastPostReff).limit(5)
//     .get()
//     .then((querySnapshot) => {

        
//         if( querySnapshot.docs.length == 0 ){
//             (swal("There is no Record Found"))

//             document.getElementById("LoadmoreButtondiv").style.display = 'none'
           
       
           
//         }

//         LastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
//             <div class="card h-100">
//          <div>
//          </div>
//               <div class="card-body">
 
//                 <h5 class="card-title">${doc.data().postTitle}</h5>
 
//                 <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
//              <div style="display:flex;justify-content: space-between;">
//                 <div>
//                        <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
//                 </div>
//                 <div style="display:flex;margin-top: 0.5rem;">
//                      <i class='bx bxs-download'></i>
//                      <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
//                      <i class='bx bxs-download'></i>
//                      <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
//                  </div>
//              </div>
//               </div>
//             </div>
//           </div>`)
//         });
//     })
//     .catch((error) => {
//         console.log("Error getting documents: ", error);
//     });
    

// }

// function AllPost(params) {
//     alert("All Post");
//     RednerSubCat = params

//     firestore.collection("Post").where("userUID","==",UserID).orderBy("date","desc").limit(5)
//     .get()
//     .then((querySnapshot) => {

//         var SubCatchild = document.getElementById("PostContainer");
    
//         while(SubCatchild.children.length!==0){
            
//             SubCatchild.children[0].remove();
//         }
//         if( querySnapshot.docs.length == 0 ){
           
//             document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'
//             (swal("There is no Record Found")) 

//         }

//         AllLastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
//             <div class="card h-100">
//          <div>
//          </div>
//               <div class="card-body">
 
//                 <h5 class="card-title">${doc.data().postTitle}</h5>
 
//                 <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
//              <div style="display:flex;justify-content: space-between;">
//                 <div>
//                        <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
//                 </div>
//                 <div style="display:flex;margin-top: 0.5rem;">
//                      <i class='bx bxs-download'></i>
//                      <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
//                      <i class='bx bxs-download'></i>
//                      <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
//                  </div>
//              </div>
//               </div>
//             </div>
//           </div>`)
//         });
//     }).then(()=>{

//         document.getElementById("LoadmoreButtondivAllpost").style.display = "flex"
//     })
//     .catch((error) => {
//         console.log("Error getting documents: ", error);
//     });

    
// }

// function NextRenderAllPost(params) {
//     firestore.collection("Post").where("userUID","==",UserID).orderBy("date","desc").startAfter(AllLastPostReff).limit(5)
//     .get()
//     .then((querySnapshot) => {

        
//         if( querySnapshot.docs.length == 0 ){
//             (swal("There is no Record Found"))

//             document.getElementById("LoadmoreButtondivAllpost").style.display = 'none'

//         }

//         AllLastPostReff = querySnapshot.docs[querySnapshot.docs.length-1];

//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $('#PostContainer').append(`<div class="col-md-6 col-lg-4 mb-3" id="postcol">
//             <div class="card h-100">
//          <div>
//          </div>
//               <div class="card-body">
 
//                 <h5 class="card-title">${doc.data().postTitle}</h5>
 
//                 <img class="img-fluid d-flex mx-auto my-4" src="${doc.data().pngorjpeg}" alt="Card image cap" style="width:311.550px;height:311.550px">
//              <div style="display:flex;justify-content: space-between;">
//                 <div>
//                        <a data-bs-toggle="modal" data-bs-target="#EditPostModal" class="btn btn-outline-primary" id=${doc.id} onclick="OpenEditPostModal(this.id)">Edit</a>
//                 </div>
//                 <div style="display:flex;margin-top: 0.5rem;">
//                      <i class='bx bxs-download'></i>
//                      <span style="margin-right:0.5rem">JPEG: ${doc.data().jpgDownloadingCount !== undefined ? doc.data().jpgDownloadingCount : 0  }</span>
//                      <i class='bx bxs-download'></i>
//                      <span>PSD: ${doc.data().psdDownloadingCount !== undefined ? doc.data().psdDownloadingCount : 0 }</span>
//                  </div>
//              </div>
//               </div>
//             </div>
//           </div>`)
//         });
//     })
//     .catch((error) => {
//         console.log("Error getting documents: ", error);
//     });
    

// }

// document.getElementById('PostMainCatinput').addEventListener('click', (e) => {
//     e.target.value = ''

//     var SubCatchild = document.getElementById("PostdefaultSelectSubcat");
   
// })

// document.getElementById('PostSubCatinput').addEventListener('click', (e) => {
//     e.target.value = ''
// })

// document.getElementById('subCatSearchModal').addEventListener('click', (e) => {
//     e.target.value = ''
// })

// function getSubCatForModal(params) {

//     firestore.collection("Category").doc(params).collection("SubCat").get().then((querySnapshot) => {
//         var SubcatChild = document.getElementById("subCatListModal");
//         while(SubcatChild.children.length!==0){
            
//             SubcatChild.children[0].remove();
//         }
    
        
//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $("#subCatListModal").append(`<option value="${doc.data().subCatName}">`)
//         });
//     });
// }

// document.querySelector('#mainCatSearchModal').addEventListener('input', (e) => {
//     // alert("Vivek Dhande")
//     Object.assign(e.target.dataset, document.querySelector('#' + e.target.getAttribute('list') + ' option[value="' + e.target.value + '"]').dataset);
//     console.log('dataset of input changed: ', e.target.dataset.id)
   
//     getSubCatForModal(e.target.dataset.id)
// });

// function OpenEditPostModal(params) {

//     firestore.collection("Category").get().then((querySnapshot) => {
//         querySnapshot.forEach((doc) => {
//             // doc.data() is never undefined for query doc snapshots
//             $("#mainCatListModal").append(`<option value="${doc.data().catName}" data-id="${doc.id}">`)
       
//         });
//     });


       
//     UID_Post_Edit
    
//     var docRef = firestore.collection("Post").doc(params);

//     docRef.get().then((doc) => {
//         if (doc.exists) {
//             document.getElementById("postTitleModal").value = doc.data().postTitle
//             document.getElementById("mainCatSearchModal").value = doc.data().postMainCat
//             document.getElementById("subCatSearchModal").value = doc.data().postSubCat
//             document.getElementById("Image1Modal").src = doc.data().pngorjpeg
//             UID_Post_Edit = doc.data().PostUID
//             Post_To_Be_Edited = doc.id
//         } else {
//             // doc.data() will be undefined in this case
//             console.log("No such document!");
//         }
//     }).catch((error) => {
//         console.log("Error getting document:", error);
//     });
    
// }

// function saveEditedPost(params) {

//     var Cat_name,Cat_img,Post_pngjpeg,Post_psd,Sub_Cat_Name;
//     postTitle = document.getElementById("postTitleModal").value;
//     Cat_name = document.getElementById("mainCatSearchModal").value;
//     Sub_Cat_Name = document.getElementById("subCatSearchModal").value;
//     Post_pngjpeg = document.getElementById("pngjpegModal").value;
//     Post_psd = document.getElementById("psdfileModal").value;
 
//     var ForKeyWord = `${UID_Post_Edit+1} ${postTitle} `;


//     var pngjpegUrl;
//     var psdurl;

// if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !=="" && Post_psd !=="" ){

//     var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
//     document.getElementById("EditPostUploading").style.display = "flex" 
//     document.getElementById("Image1Modal").style.display = "none"
//     // alert("In true")
//     const ref = firebase.storage().ref();
//     const file = document.querySelector('#pngjpeg').files[0]
//     const file2 =  document.querySelector('#psdfile').files[0]
//     const name =  file.name;
//     const name2 = file2.name;
//     const metadata = {
//     contentType: file.type
//     };
//     const task = ref.child('meChitrakar/' + name).put(file, metadata);
//     const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
    
//     task
//     .then(snapshot => snapshot.ref.getDownloadURL())
//     .then((url) => {

//         pngjpegUrl = url; 
//     // console.log("Jpeg",url);


 
//     }).then(()=>{
//         task2 .then(snapshot => snapshot.ref.getDownloadURL())
//         .then((url) => {
//             psdurl = url
  
//                firestore.collection("Post").doc(Post_To_Be_Edited).update({
//                 postTitle: postTitle,
//                 postMainCat : Cat_name,
//                 postSubCat : Sub_Cat_Name,
//                 pngorjpeg : pngjpegUrl,
//                 psd : url,
//                 // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
//                 keywords : ManCatKeywords
//             })
       
//     }).then(()=>{
//         // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
//         document.getElementById("EditPostUploading").style.display = "none" 
//         document.getElementById("Image1Modal").style.display = "flex"
//          alert("Category Added")

//         // Set the "capital" field of the city 'DC'
       

//         // alert("Category Added")
        
        
//         // Cat_name = document.getElementById("basic-default-fullname").value = "";
//         // Cat_img = document.getElementById("formFile").value = "";

//     })
//     })
    
// }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg !=="" && Post_psd ==""){
//     var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
//     document.getElementById("EditPostUploading").style.display = "flex" 
//     document.getElementById("Image1Modal").style.display = "none"
//     // alert("In true")
//     const ref = firebase.storage().ref();
//     const file = document.querySelector('#pngjpegModal').files[0]
//     // const file2 =  document.querySelector('#psdfile').files[0]
//     const name =  file.name;
//     // const name2 = file2.name;
//     const metadata = {
//     contentType: file.type
//     };
//     const task = ref.child('meChitrakar/' + name).put(file, metadata);
//     // const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
    
//     task
//     .then(snapshot => snapshot.ref.getDownloadURL())
//     .then((url) => {

//         pngjpegUrl = url; 
//         firestore.collection("Post").doc(Post_To_Be_Edited).update({
//             postTitle: postTitle,
//             postMainCat : Cat_name,
//             postSubCat : Sub_Cat_Name,
//             pngorjpeg : url,
//             // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
//             keywords : ManCatKeywords
//         })


 
//     }).then(()=>{
//         // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
//         document.getElementById("EditPostUploading").style.display = "none" 
//         document.getElementById("Image1Modal").style.display = "flex"
//         console.log("Category Added")

//     }).then(()=>{

//        RenderPost(tobeFilter)
//     }).then(()=>{

//         $('#EditPostModal').modal('hide');
//     })
// }else if(postTitle !=="" && Cat_name !=="" && Sub_Cat_Name !=="" && Post_pngjpeg =="" && Post_psd !==""){
//     var ManCatKeywords = getAllSubstrings(ForKeyWord.toLowerCase());
//     document.getElementById("EditPostUploading").style.display = "flex" 
//     document.getElementById("Image1Modal").style.display = "none"
//     // alert("In true")
//     const ref = firebase.storage().ref();
//     // const file = document.querySelector('#pngjpeg').files[0]
//     const file2 =  document.querySelector('#psdfileModal').files[0]
//     // const name =  file.name;
//     const name2 = file2.name;
//     const metadata = {
//     contentType: file.type
//     };
//     // const task = ref.child('meChitrakar/' + name).put(file, metadata);
//     const task2 = ref.child('meChitrakar/' + name2).put(file2, metadata);
    
//     task2
//     .then(snapshot => snapshot.ref.getDownloadURL())
//     .then((url) => {

//         pngjpegUrl = url; 
//         firestore.collection("Post").doc(Post_To_Be_Edited).update({
//             postTitle: postTitle,
//             postMainCat : Cat_name,
//             postSubCat : Sub_Cat_Name,
//             psd : url,
//             // date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
//             keywords : ManCatKeywords
//         })


 
//     }).then(()=>{
//         // console.log("pngjpegUrl",pngjpegUrl,"psdurl",psdurl)
//         document.getElementById("EditPostUploading").style.display = "none" 
//         document.getElementById("Image1Modal").style.display = "flex"
//         console.log("Category Added")
//         $('#EditPostModal').modal('hide');
//         location.reload();
//         // alert("Category Added")
        
        
//         // Cat_name = document.getElementById("basic-default-fullname").value = "";
//         // Cat_img = document.getElementById("formFile").value = "";

//     })
// }
    
// }


// function changeExtension(params,params1) {


//             // if(params == 'PNG' || params == 'JPEG'){
                
//             //     png_or_jpeg = params
//             //     $("#pngjpeg").attr("accept",".zip");
//             //     document.getElementById("pngjpeg").disabled = false
//             //     document.getElementById("Ext").innerText = params

//             // }else if(params == 'ZIP' || params == 'RAR'){
//             //     zip_or_rar = params

//             //     $("#ziprar").attr("accept",".zip");
//             //     document.getElementById("ziprar").disabled = false
//             //     document.getElementById("Ext1").innerText = params  
//             // }

//             if(params == 'PNG'){

//                 png_or_jpeg = params

//                 $("#pngjpeg").attr("accept",".png");

//                 document.getElementById("pngjpeg").disabled = false
           
//                 document.getElementById("Ext").innerText = params

//             }else if(params == 'JPEG'){

//                 png_or_jpeg = params

//                 $("#pngjpeg").attr("accept",".jpeg");

                
//                 document.getElementById("pngjpeg").disabled = false
           
//                 document.getElementById("Ext").innerText = params

//             }else if(params == 'ZIP'){

//                 zip_or_rar = params

//                 $("#ziprar").attr("accept",".zip");

//                 document.getElementById("ziprar").disabled = false
           
//                 document.getElementById("Ext1").innerText = params

//             }else if(params == 'RAR'){

//                 zip_or_rar = params

//                 $("#ziprar").attr("accept",".rar");

//                 document.getElementById("ziprar").disabled = false
           
//                 document.getElementById("Ext1").innerText = params

//             }

// }


