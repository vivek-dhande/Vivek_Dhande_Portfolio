
firestore = firebase.firestore();
var email = document.getElementById("SubAdminEamil"),
    pass = document.getElementById("SubAdminPass"),
    repass = document.getElementById("RetypePass"),
    adminName = document.getElementById("SubAdminName");

var LastSubAdminListDoc;
var SubAdminList = [] ;
var SubAdminList_index = 0;
var data = [];
var dataindex = 0;


function getData() {
    console.log("pass.value.length",pass.value)
    "" == adminName.value ? swal("Please Enter Name!") : "" == email.value ? swal("Please Enter Email!") : "" == pass.value ? swal("Please Enter Password!") : pass.value.length < 6 ? swal("Password Lenght Must Greter than 6!") : "" == repass.value ? swal("Please Enter Retype Password!") : pass.value != repass.value ? swal("Enter Retype Password Not Match with Password") : createUser()
}

function createUser() {
    firebase.auth().createUserWithEmailAndPassword(email.value, pass.value).then(function(userCredential) {
        console.log("userCredential",)
        saveData(userCredential.user.uid), console.log("User Created")
    }).catch(function(e) {
        console.log(e)
    })
}

function saveData(params) {
    firestore.collection("Subadmin").add({
        name: adminName.value,
        email: email.value,
        password: pass.value,
        role: "editer",
        status : false,     
        uid:params   
    }).then(function() {
        
        swal("Successful", "Editer Added Sucessfully", "success"), resetAll()
    }).catch(function(e) {
        console.log(e)
    })
}

function resetAll() {
    adminName.value = "", email.value = "", pass.value = "", repass.value = ""
}

GetAdminList();
function GetAdminList(params) {
    

    firestore.collection("Subadmin").get().then((querySnapshot) => {
        LastSubAdminListDoc = querySnapshot.docs[querySnapshot.docs.length-1]
        querySnapshot.forEach((doc) => {
            console.log("doc.data()",doc.data())
            data[dataindex++] = [doc.id,doc.data().name,doc.data().email,doc.data().password];
            // document.getElementById(`${doc.id}`).checked = doc.data().status
            // doc.data() is never undefined for query doc snapshots
            if(doc.data().email!== "admin@gmail.com"){
                $("#SubAdminTableBody").append(`<tr id="${doc.id}">
                <td>
                  <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong id="Sub_AdminName">${doc.data().name}</strong>
                </td>
                <td id="SubAdminEmail">${doc.data().email}</td> 
                <td id="SubAdminPassword">${doc.data().password}</td>
                <td><div class="form-check form-switch mb-2">
                <input class="form-check-input" type="checkbox" id="${doc.id}Switch" onclick="ChangeStatus(this.id,this.checked)">
          
              </div> </td>
           
              </tr>`)

              if(doc.data().status === true){
                
                document.getElementById(`${doc.id}Switch`).checked = true
                }else{
                    document.getElementById(`${doc.id}Switch`).checked = false
                }
            }
           

           
        });
    }).then(()=>{

   
    })    
}

function ChangeStatus(params,params1) {
    var DocToUpdate =  params.substring(0, params.length - 6);
   

    var washingtonRef = firestore.collection("Subadmin").doc(DocToUpdate);

    // Set the "capital" field of the city 'DC'
    return washingtonRef.update({
        status: params1
    })
    .then(() => {
        swal("Subadmin Status updated!");
    })
    .catch((error) => {
        // The document probably doesn't exist.
        console.error("Error updating document: ", error);
    });


}

function deleteEditer(t) {
    swal({
        title: "Are you sure?",
        text: "Once Deleted, You Will Not Be Able To Recover This Editer Record!",
        icon: "warning",
        buttons: !0,
        dangerMode: !0
    }).then(n => {
        n && firestore.collection("Subadmin").doc(t).delete().then(function() {
         document.getElementById(`${t}`).remove();
        }).then(function() {
            swal("Successfull", "Editer Deleted Successfully From Record", "success")
        }).catch(function(e) {
            console.error("Error removing document: ", e)
        })
    })
}

// let str = "12345.00";
// str = str.substring(0, str.length - 6);
// console.log(str);

