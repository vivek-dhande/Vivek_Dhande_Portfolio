var firestore = firebase.firestore();

var docRef = firestore.collection("AppInfo").doc("shareMsg");

docRef.get().then((doc) => {
    if (doc.exists) {
        document.getElementById("AddSliderTitle").value = doc.data().msg
    } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
    }
}).catch((error) => {
    console.log("Error getting document:", error);
});

function AddSliderOpeartion(params) {


    var AddSavetitle = document.getElementById("AddSliderTitle").value;



    if(AddSavetitle!== "" ){

        var docRef = firestore.collection("AppInfo").doc("shareMsg")
    
        return docRef.update({
            
            msg : AddSavetitle,
        
        })
        .then(() => {
         
            swal("Document successfully updated!");
  
           location.reload();

        }).then(()=>{


        })
        .catch((error) => {
            // The document probably doesn't exist.
            console.error("Error updating document: ", error);
        });

    }else{
        
        if(AddSavetitle == ""){
            document.getElementById("slidertitlespan").style.display = ""
    
        }else{
            document.getElementById("slidertitlespan").style.display = "none"
        }
    
 
    }
    

}