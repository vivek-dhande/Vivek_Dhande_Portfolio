
function verifyData() {
    userEmail = document.getElementById("userEmail").value, userPass = document.getElementById("userPass").value, "" == userEmail ? swal("Email Not Be Blank!") : "" == userPass ? swal("Password Not Be Blank!") : ValidateEmail(userEmail) ? (load.classList.add("d-none"), loading.classList.remove("d-none"), firebase.auth().signInWithEmailAndPassword(userEmail, userPass).then(function() {
        document.getElementById("userEmail").value = "", document.getElementById("userPass").value = "", CheckTheStatus()
        
        //window.location.href = "/Post/post.html"
    }).catch(function(a) {
        var e = a.message;
        swal(e), load.classList.remove("d-none"), loading.classList.add("d-none")
    })) : swal("Enter Valid Email!")
}

function ValidateEmail(a) {
    return !!a.match(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
}

function CheckTheStatus(params) {

    firebase.auth().onAuthStateChanged(function(a) {
    
    
        // console.log("a.email",a.email)
      
        if(a.email!=="mechitrakarofficial@gmail.com"){

            firestore.collection("Subadmin").where("email", "==", a.email)
            .get()
            .then((querySnapshot) => {

            if(querySnapshot.docs.length == 0){
              
                a.delete().then(function() {
                
                    window.location.href = "accessRemoved.html"
                    
                }).catch(function(error) {
                    // An error happened.
                });
               
            }else{

              
                querySnapshot.forEach((doc) => {
                    
                    localStorage.setItem('user', `${doc.data().name}`);
                    // doc.data() is never undefined for query doc snapshots
                    if(doc.data().status === true){
    
                        // a && (window.location.href = "")
                        a && (window.location.href = "/SubAdmin/SubAdminPage.html")
    
                    }else if((doc.data().status === false)){
                       
                        a && (window.location.href = "accessdenied.html")
                    }

                    
                });
            }
               
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });

        }else{
            a && (window.location.href = "/Post/post.html")
        }
    
    
    
       
        //   a && (window.location.href = "/Post/post.html")
    
        
    });
    
    
}


var userEmail, userPass, load = document.getElementById("load"),
    loading = document.getElementById("loading");

    var firestore = firebase.firestore();
 