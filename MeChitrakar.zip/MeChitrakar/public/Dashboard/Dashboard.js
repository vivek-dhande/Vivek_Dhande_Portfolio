

var firestore = firebase.firestore();

getCount();
function getCount(params) {

    firestore.collection("UserInfo")
    .get()
    .then((querySnapshot) => {
        document.getElementById("alluser").innerText = querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    firestore.collection("UserInfo").where("plan", "==", "FREE")
    .get()
    .then((querySnapshot) => {
        document.getElementById("byplan").innerText = querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    firestore.collection("UserInfo").where("flag", "==", "INDIVIDUAL")
    .get()
    .then((querySnapshot) => {
        document.getElementById("byproff").innerText = querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });


    firestore.collection("SubsciptionPlans")
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach(element => {

            $("#planInputId").append(`<option value="${element.data().plan}">${element.data().plan}</option>`)
        });

      
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    


}

planInputId.addEventListener("change",function(params){
    
    firestore.collection("UserInfo").where("plan", "==", params.target.value)
    .get()
    .then((querySnapshot) => {
        document.getElementById("byplan").innerText = querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
  
})

proffessionInputId.addEventListener("change",function(params){
    firestore.collection("UserInfo").where("flag", "==", params.target.value)
    .get()
    .then((querySnapshot) => {
        document.getElementById("byproff").innerText = querySnapshot.size
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
   
})

