var firestore = firebase.firestore();
const storage = firebase.storage();
var storageRef = storage.ref();

var Vibhag_List = [];
var Vibhag_List_index = 0;
var LastMainCatDocReff ;

var data = [];
var dataindex = 0;
var maincatTableList = [];
var maincatTableList_index = 0;

var paginationindex = 0;
var CurrentPage = 0;

var selected_Main_Cat;
var maincatEditReff ; 
var SubEditReff;
var LastSubCatDocReff ;

var subCatTableList = [];
var subCatTableList_index = 0;
var sub_paginationindex = 0 ;
var Sub_CurrentPage = 0;

var SubCatNameID;
var dateActiveorNot = false;

var MainCatNameBeforeEdit;
var SubCatNameBeforeEdit;
getMainCategoryMenu();
function getMainCategoryMenu(params) {


    firestore.collection("Category").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            $("#defaultSelect").append(`<option value="${doc.data().catName}">`)
        });
    });

}

// document.querySelector('#dropdown_coins').toggle().hide()



function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}
function readURL_Sub(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah_subcat')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}

function readURL_Main_cat_URL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah_Main_cat')
                .attr('src', e.target.result)
     
        };

        reader.readAsDataURL(input.files[0]);
    }
}


function saveCategory(params) {

    var Cat_name,Cat_img;

    Cat_name = document.getElementById("basic-default-fullname").value;
    Cat_img = document.getElementById("formFile").value;



   if(Cat_name!=="" && Cat_img!=="" ){

    document.getElementById("addcatUpload").style.display = "flex"
    document.getElementById("blah").style.display = "none"
    var ManCatKeywords = getAllSubstrings(Cat_name.toLowerCase());

    const ref = firebase.storage().ref();
    const file = document.querySelector('#formFile').files[0]
    const name =  file.name;
    const metadata = {
    contentType: file.type
    };
    const task = ref.child('meChitrakar/' + name).put(file, metadata);
    task
    .then(snapshot => snapshot.ref.getDownloadURL())
    .then((url) => {
    console.log(url);
    firestore.collection("Category").add({
        catName: Cat_name ,
        date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
        catImg : url,
        keywords :ManCatKeywords
    })
    }).then(()=>{
        document.getElementById("addcatUpload").style.display = "none" 
        document.getElementById("blah").style.display = "flex"

        alert("Category Added")
     
        Cat_name = document.getElementById("basic-default-fullname").value = "";
        Cat_img = document.getElementById("formFile").value = "";

    })
   }else{

            if(Cat_name == ""){

                document.getElementById("addMainCatValidation").style.display = ""

            }else{
                document.getElementById("addMainCatValidation").style.display = "none"

            }

            if(Cat_img == ""){

                document.getElementById("addMainCatPhotoValidation").style.display = ""

            }else{

                document.getElementById("addMainCatPhotoValidation").style.display = "none"


            }
   }
    
}


$("#exampleDataList").change(()=>{

    var tempvalue = document.getElementById("exampleDataList").value
    //tempvalue == "आगामी विशेष दिन"
    if(1){
        dateActiveorNot = true
        document.getElementById("SubCatDate").style.display = "";

    }else{
        document.getElementById("SubCatDate").style.display = "none";
    }

    
})

function saveSubCategory(params) {

    console.log("View",document.getElementById("html5-date-input").value)

    var Cat_Sub_name,Cat_sub_img,mainCat;
    var MainCatDoc;
    var tempImg;
    var Cat_Sub_date;

    mainCat = document.getElementById("exampleDataList").value
    Cat_Sub_name = document.getElementById("basic-default-fullname_subcat").value;
    Cat_sub_img = document.getElementById("formFile_subcat").value; 
    Cat_Sub_date = document.getElementById("html5-date-input").value;

    console.log("mainCat",mainCat)

    var ManCatKeywords = getAllSubstrings(Cat_Sub_name.toLowerCase());
    
   if(Cat_Sub_name!=="" && Cat_sub_img!=="" && mainCat!=="" && dateActiveorNot == false ){

    // alert("In Without Date")
    document.getElementById("addSubCatUpload").style.display = "flex" 
    document.getElementById("blah_subcat").style.display = "none"

    const ref = firebase.storage().ref();
    const file = document.querySelector('#formFile_subcat').files[0]
    const name =  file.name;
    const metadata = {
    contentType: file.type
    };
    const task = ref.child('meChitrakar/' + name).put(file, metadata);
    task
    .then(snapshot => snapshot.ref.getDownloadURL())
    .then((url) => {
    console.log(url);

    tempImg = url;

    }).then(()=>{
        firestore.collection("Category").where("catName", "==", mainCat).limit(1)
        .get()
        .then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                // categoryDocId = doc.id
                MainCatDoc = doc.id
                mainCatname = doc.data().catName
                // console.log("MainCatDoc",MainCatDoc)
                    
            })
        }).then(()=>{

        
    
            firestore.collection('SubCat').add({
                subCatName: Cat_Sub_name ,
                date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                subCatImg : tempImg,
                festival : firebase.firestore.Timestamp.fromDate(new Date(Cat_Sub_date)).toDate(),
                keywords : ManCatKeywords,
                mainCat : MainCatDoc,
                mainCatname : mainCatname
            })
    
    
        })
    })
    .then(()=>{

        if(dateActiveorNot == true){
            dateActiveorNot = false;
        }

        document.getElementById("addSubCatUpload").style.display = "none" 
        document.getElementById("blah_subcat").style.display = "flex"

        document.getElementById("exampleDataList").value = ""
         document.getElementById("basic-default-fullname_subcat").value = ""
        document.getElementById("formFile_subcat").value = ""
       document.getElementById("html5-date-input").value =""
        
        alert("Category Added")
        // location.reload();

       
        
        // Cat_name = document.getElementById("basic-default-fullname_subcat").value = "";
        // Cat_img = document.getElementById("formFile_subcat").value = "";

    })
   }else if(Cat_Sub_name!=="" && Cat_sub_img!=="" && mainCat!=="" && dateActiveorNot == true && Cat_Sub_date !== ""){
    console.log(Cat_Sub_date)
    // alert("In Date")
    document.getElementById("addSubCatUpload").style.display = "flex"
    document.getElementById("blah_subcat").style.display = "none"
    const ref = firebase.storage().ref();
    const file = document.querySelector('#formFile_subcat').files[0]
    const name =  file.name;
    const metadata = {
    contentType: file.type
    };
    const task = ref.child('meChitrakar/' + name).put(file, metadata);
    task
    .then(snapshot => snapshot.ref.getDownloadURL())
    .then((url) => {
    console.log(url);

    tempImg = url;

    }).then(()=>{
        firestore.collection("Category").where("catName", "==", mainCat).limit(1)
        .get()
        .then((querySnapshot) => {
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                // categoryDocId = doc.id
                MainCatDoc = doc.id
                mainCatname = doc.data().catName
                // console.log("MainCatDoc",MainCatDoc)
                    
            })
        }).then(()=>{

        
    
            firestore.collection('SubCat').add({
                subCatName: Cat_Sub_name ,
                date:  firebase.firestore.Timestamp.fromDate(new Date()).toDate(),
                subCatImg : tempImg,
                festival : firebase.firestore.Timestamp.fromDate(new Date(Cat_Sub_date)).toDate(),
                keywords : ManCatKeywords,
                mainCat : MainCatDoc,
                mainCatname :mainCatname
            })

        })
    })
    .then(()=>{

        if(dateActiveorNot == true){
            dateActiveorNot = false;
        }
        document.getElementById("addSubCatUpload").style.display = "none" 
        document.getElementById("blah_subcat").style.display = "flex"
        document.getElementById("exampleDataList").value = ""
        document.getElementById("basic-default-fullname_subcat").value = ""
       document.getElementById("formFile_subcat").value = ""
      document.getElementById("html5-date-input").value =""
        // location.reload();
        alert("Category Added")
        // location.reload();
       
        
        // Cat_name = document.getElementById("basic-default-fullname_subcat").value = "";
        // Cat_img = document.getElementById("formFile_subcat").value = "";

    })

   }
   else{
    console.log("Cat_Sub_date",Cat_Sub_date);
    if(mainCat == ""){

        document.getElementById("MaincatForSubValidation").style.display = "";

    }else{

        document.getElementById("MaincatForSubValidation").style.display = "none";

    }

    if(Cat_Sub_name == ""){

        document.getElementById("SubcatValidation").style.display = "";

    }else{

        document.getElementById("SubcatValidation").style.display = "none";

    }

    if(Cat_sub_img == ""){

        document.getElementById("SubcatimgValidation").style.display = "";

    }else{

        document.getElementById("SubcatimgValidation").style.display = "none";

    }
    if(dateActiveorNot == true && Cat_Sub_date == ""){
        document.getElementById("dateValidation").style.display = "";
    }else{
        document.getElementById("dateValidation").style.display = "none";
    }



   }
    
}

document.getElementById('exampleDataList').addEventListener('click', (e) => {
    e.target.value = ''
})



function CategoryOperations(params) {

    if(params == "addmain"){

        document.getElementById("ADDCATEGORY").style.display = "";
        document.getElementById("ADDSUBCATEGORY").style.display = "none";
        document.getElementById("SHOWANDEDIT").style.display = "none";
        document.getElementById("SHOWANDEDIT_Sub").style.display = "none";

    }else if(params == "addsub"){

        document.getElementById("ADDSUBCATEGORY").style.display = "";
        document.getElementById("ADDCATEGORY").style.display = "none";
        document.getElementById("SHOWANDEDIT").style.display = "none"; 
        document.getElementById("SHOWANDEDIT_Sub").style.display = "none";
    }else if(params == "editandshow"){

        document.getElementById("SHOWANDEDIT").style.display = "flex";
        document.getElementById("SHOWANDEDIT_Sub").style.display = "none";

        document.getElementById("ADDSUBCATEGORY").style.display = "none";
        document.getElementById("ADDCATEGORY").style.display = "none";
    } 
    
}
getCategoryinTable();

function getCategoryinTable(params) {
    maincatTableList = [] ;
    maincatTableList_index = 0;
    data = [];
    dataindex = 0;
    paginationindex = 0;
    CurrentPage = 0;

    firestore.collection("Category").orderBy("date","desc").limit(5).get().then((querySnapshot) => {

        while(document.getElementById("mainCattable").childElementCount!==0){

            document.getElementById("mainCattable").firstChild.remove();
        }
        LastMainCatDocReff = querySnapshot.docs[querySnapshot.docs.length-1]

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());
            data[dataindex++] = [doc.id,moment(doc.data().date.toDate()).format("DD/MM/YYYY"),doc.data().catName]

            $("#mainCattable").append(`<tr id="${doc.id}" >
            <td id=${doc.id} data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)"><strong>${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</strong></td>
            <td id="${doc.id}-main" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)">${doc.data().catName}</td>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" id=${doc.id} data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_MainCategory_Modal(this.id)"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                  <a class="dropdown-item" id=${doc.id} onclick="getSubCategoryinTable(this.id)" ><i class="bx bx-trash me-1" ></i> View Sub-Category</a>
                  <a class="dropdown-item" id=${doc.id} onclick="DeleteMainCat(this.id)"><i class="bx bx-trash me-1"></i> Delete</a>
                  <div style="display: flex;
                  margin-left: 1.3rem;">
                  <i class='bx bx-bullseye' style="margin-top: 0.5rem;"></i><input class="form-control" list="Mainpramote" id="MainpramotetohomeInput-${doc.id}" autocomplete="off" style="width: 7rem;margin-left: 0.5rem;" onchange="MaingetpramotetohomeInput(this.id,this.data-value)" placeholder="Select"></i>
                  <datalist id="Mainpramote">
                <option value="1"></option>
                <option value="2"></option> 
                </datalist>
                  </div>
                </div>
              </div>
            </td>
          </tr>`)
        });
    }).then(()=>{

        maincatTableList[maincatTableList_index++] = data;
        paginationindex++;
        CurrentPage++;

    })
 
  
}

function NextgetCategoryinTable(params) {

    document.getElementById("previousButton").disabled = false; 

    console.log("Data",CurrentPage,paginationindex);
    data = [];
    dataindex = 0;
 
    if(paginationindex == CurrentPage ){


        firestore.collection("Category").orderBy("date","desc").startAfter(LastMainCatDocReff).limit(5).get().then((querySnapshot) => {

        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#nextButton').disabled = true;
            
             CurrentPage--;
            paginationindex--;
             (swal("There is no Record Found"))
          
        }else{

            while(document.getElementById("mainCattable").childElementCount!==0){

                document.getElementById("mainCattable").firstChild.remove();
            }
    
            LastMainCatDocReff = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
                data[dataindex++] = [doc.id,moment(doc.data().date.toDate()).format("DD/MM/YYYY"),doc.data().catName]
    
                $("#mainCattable").append(`<tr id="${doc.id}">
                <td id=${doc.id} data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)"><strong>${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</strong></td>
                <td id="${doc.id}-main" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)">${doc.data().catName}</td>
                <td>
                  <div class="dropdown">
                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                      <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" id="${doc.id}"  data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_MainCategory_Modal(this.id)""><i class="bx bx-edit-alt me-1"></i> Edit</a>
                      <a class="dropdown-item" id=${doc.id} onclick="getSubCategoryinTable(this.id)" ><i class="bx bx-trash me-1" ></i> View Sub-Category</a>
                      <a class="dropdown-item" id="${doc.id}" onclick="DeleteMainCat(this.id)" ><i class="bx bx-trash me-1"></i> Delete</a>
                      <div style="display: flex;
                      margin-left: 1.3rem;">
                      <i class='bx bx-bullseye' style="margin-top: 0.5rem;"></i><input class="form-control" list="Mainpramote" id="MainpramotetohomeInput-${doc.id}" autocomplete="off" style="width: 7rem;margin-left: 0.5rem;" onchange="MaingetpramotetohomeInput(this.id,this.data-value)" placeholder="Select"></i>
                      <datalist id="Mainpramote">
                    <option value="1"></option>
                    <option value="2"></option> 
                    </datalist>
                      </div>
                      </div>
                  </div>
                </td>
              </tr>`)
            });
            
        }

        }).then(()=>{
            maincatTableList[maincatTableList_index++] = data;
            console.log("maincatTableList",maincatTableList);
            paginationindex++;
            CurrentPage++;
        })

    }else{

        console.log("maincatTableList",maincatTableList);
        while(document.getElementById("mainCattable").childElementCount!==0){

            document.getElementById("mainCattable").firstChild.remove();
        }

        maincatTableList[CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

            
            $("#mainCattable").append(`<tr id="${doc[0]}">
            <td id=${doc[0]} data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)"><strong>${doc[1]}</strong></td>
            <td id="${doc[0]}-main" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)">${doc[2]}</td>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" id="${doc[0]}"  data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_MainCategory_Modal(this.id)"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                  <a class="dropdown-item" id=${doc[0]} onclick="getSubCategoryinTable(this.id)" ><i class="bx bx-trash me-1" ></i> View Sub-Category</a>
                  <a class="dropdown-item" id="${doc[0]}"  href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                  <div style="display: flex;
                  margin-left: 1.3rem;">
                  <i class='bx bx-bullseye' style="margin-top: 0.5rem;"></i><input class="form-control" list="Mainpramote" id="MainpramotetohomeInput-${doc[0]}" autocomplete="off" style="width: 7rem;margin-left: 0.5rem;" onchange="MaingetpramotetohomeInput(this.id,this.data-value)" placeholder="Select"></i>
                  <datalist id="Mainpramote">
                <option value="1"></option>
                <option value="2"></option> 
                </datalist>
                  </div>
                </div>
              </div>
            </td>
          </tr>`)
        });

        CurrentPage++;


    }
  
    
}

function Previous_getCategoryinTable(params) {

    document.getElementById("nextButton").disabled = false; 
         console.log("maincatTableList",maincatTableList);
    if(CurrentPage!==1){

        while(document.getElementById("mainCattable").childElementCount!==0){ 
            
            document.getElementById("mainCattable").firstChild.remove();
        }
    
        CurrentPage--;
        console.log("Data",CurrentPage,paginationindex);
        maincatTableList[CurrentPage-1].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());
    
            $("#mainCattable").append(`<tr id="${doc[0]}">
            <td id=${doc[0]} data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)"><strong>${doc[1]}</strong></td>
            <td id="${doc[0]}-main" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)">${doc[2]}</td>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                  <button class="dropdown-item" id="${doc[0]}" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_MainCategory_Modal(this.id)"><i class="bx bx-edit-alt me-1"></i> Edit</button>
                  <a class="dropdown-item" id=${doc[0]} onclick="getSubCategoryinTable(this.id)" ><i class="bx bx-trash me-1" ></i> View Sub-Category</a>
                  <button class="dropdown-item" id="${doc[0]}" onclick="DeleteMainCat(this.id)" data-bs-toggle="modal" data-bs-target="#myModal""><i class="bx bx-trash me-1"></i> Delete</button>
                  <div style="display: flex;
                  margin-left: 1.3rem;">
                  <i class='bx bx-bullseye' style="margin-top: 0.5rem;"></i><input class="form-control" list="Mainpramote" id="MainpramotetohomeInput-${doc[0]}" autocomplete="off" style="width: 7rem;margin-left: 0.5rem;" onchange="MaingetpramotetohomeInput(this.id,this.data-value)" placeholder="Select"></i>
                  <datalist id="Mainpramote">
                <option value="1"></option>
                <option value="2"></option> 
                </datalist>
                  </div>
                  </div>
              </div>
            </td>
          </tr>`)
        });
        
    }else{
        document.getElementById("previousButton").disabled = true; 
    }


    
}

function getSubCategoryinTable(params) {
    subCatTableList = [];
    subCatTableList_index = 0;
    sub_paginationindex = 0;
    Sub_CurrentPage = 0;

    selected_Main_Cat = params;

    data = [];
    dataindex = 0;
    document.getElementById("SHOWANDEDIT_Sub").style.display = "";
    
    document.getElementById("Sub_previousButton").disabled= false; 
    document.getElementById("Sub_nextButton").disabled= false;
    firestore.collection("SubCat").where("mainCat", "==", params).orderBy("date","desc").limit(5).get().then((querySnapshot) => {

        LastSubCatDocReff = querySnapshot.docs[querySnapshot.docs.length-1]

        while(document.getElementById("SubCattable").childElementCount!==0){

            document.getElementById("SubCattable").firstChild.remove();
        }

        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());
            data[dataindex++] = [doc.id,moment(doc.data().date.toDate()).format("DD/MM/YYYY"),doc.data().subCatName]

            $("#SubCattable").append(`<tr id="${doc.id}" >
            <td id="${doc.id}" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)"><strong>${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</strong></td>
            <td id="${doc.id}-subcat" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)">${doc.data().subCatName}</td>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" id=${doc.id} data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_Sub_Category_Modal(this.id)"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                  <a class="dropdown-item" id=${doc.id}href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                  <div style="display: flex;
                  margin-left: 1.3rem;">
                  <i class='bx bx-bullseye' style="margin-top: 0.5rem;"></i><input class="form-control" list="pramote" id="pramotetohomeInput-${doc.id}" autocomplete="off" style="width: 7rem;margin-left: 0.5rem;" onchange="getpramotetohomeInput(this.id,this.data-value)" placeholder="Select"></i>
                  <datalist id="pramote">
                <option value="1"></option>
                <option value="2"></option>
                <option value="3"></option>
                <option value="4"></option>
                <option value="5"></option>       
                </datalist>
                  </div>
                  </div>
              </div>
            </td>

          
            </tr>`)
        });
    }).then(()=>{

        subCatTableList[subCatTableList_index++] = data;
        sub_paginationindex++;
        Sub_CurrentPage++;

    })
 
  
}

function NextgetSubCategoryinTable(params) {

    document.getElementById("Sub_previousButton").disabled = false; 


    data = [];
    dataindex = 0;
 
    if(sub_paginationindex == Sub_CurrentPage ){

        
//        firestore.collection("Category").doc(selected_Main_Cat).collection("SubCat").orderBy("date","desc").startAfter(LastSubCatDocReff).limit(5).get().then((querySnapshot) => {

        firestore.collection("SubCat").where("mainCat", "==", selected_Main_Cat).orderBy("date","desc").startAfter(LastSubCatDocReff).limit(5).get().then((querySnapshot) => {

            
            
      
        if( querySnapshot.docs.length == 0 ){
            document.querySelector('#Sub_nextButton').disabled = true;
            
            Sub_CurrentPage--;
             sub_paginationindex--;
             (swal("There is no Record Found"))
          
        }else{

            while(document.getElementById("SubCattable").childElementCount!==0){

                document.getElementById("SubCattable").firstChild.remove();
            }
    
            LastSubCatDocReff = querySnapshot.docs[querySnapshot.docs.length-1]
            querySnapshot.forEach((doc) => {
                // doc.data() is never undefined for query doc snapshots
                //console.log(doc.id, " => ", doc.data());
                data[dataindex++] = [doc.id,moment(doc.data().date.toDate()).format("DD/MM/YYYY"),doc.data().subCatName]

                $("#SubCattable").append(`<tr id="${doc.id}">
                <td id=${doc.id} data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)"><strong>${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</strong></td>
                <td id="${doc.id}-subcat" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)">${doc.data().subCatName}</td>
                <td>
                  <div class="dropdown">
                    <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                      <i class="bx bx-dots-vertical-rounded"></i>
                    </button>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" id="${doc.id}"  data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_Sub_Category_Modal(this.id)""><i class="bx bx-edit-alt me-1"></i> Edit</a>
                      <a class="dropdown-item" id="${doc.id}"  href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                      <div style="display: flex;
                      margin-left: 1.3rem;">
                      <i class="bx bx-bullseye" style="margin-top: 0.5rem;"></i><input class="form-control" list="pramote" id="pramotetohomeInput-${doc.id}" autocomplete="off" style="width: 7rem;margin-left: 0.5rem;" onchange="getpramotetohomeInput(this.id,this.data-value)" placeholder="Select">
                      <datalist id="pramote">
                    <option value="1"></option>
                    <option value="2"></option>
                    <option value="3"></option>
                    <option value="4"></option>
                    <option value="5"></option>       
                    </datalist>
                      </div>
                      </div>
                  </div>
                </td>
              </tr>`)
            });
            
        }

        }).then(()=>{
            subCatTableList[subCatTableList_index++] = data;
            sub_paginationindex++;
            Sub_CurrentPage++;
        })

    }else{

        while(document.getElementById("SubCattable").childElementCount!==0){

            document.getElementById("SubCattable").firstChild.remove();
        }

        subCatTableList[Sub_CurrentPage].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());

          
            $("#SubCattable").append(`<tr id="${doc[0]}">
            <td id=${doc[0]} data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)"><strong>${doc[1]}</strong></td>
            <td id="${doc[0]}-subcat" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)">${doc[2]}</td>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" id="${doc[0]}"  data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_Sub_Category_Modal(this.id)"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                  <a class="dropdown-item" id="${doc[0]}"  href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                  <div style="display: flex;
                  margin-left: 1.3rem;">
                  <i class="bx bx-bullseye" style="margin-top: 0.5rem;"></i><input class="form-control" list="pramote" id="pramotetohomeInput-${doc[0]}" autocomplete="off" style="width: 7rem;margin-left: 0.5rem;" onchange="getpramotetohomeInput(this.id,this.data-value)" placeholder="Select">
                  <datalist id="pramote">
                <option value="1"></option>
                <option value="2"></option>
                <option value="3"></option>
                <option value="4"></option>
                <option value="5"></option>       
                </datalist>
                  </div>
                  </div>
              </div>
            </td>

          </tr>`)
        });

        Sub_CurrentPage++;


    }
  
    
}

function Previous_get_Sub_CategoryinTable(params) {

    document.getElementById("Sub_nextButton").disabled = false; 

    if(Sub_CurrentPage!==1){

        while(document.getElementById("SubCattable").childElementCount!==0){ 
            
            document.getElementById("SubCattable").firstChild.remove();
        }
    
        Sub_CurrentPage--;
        console.log("Data",CurrentPage,paginationindex);
        subCatTableList[Sub_CurrentPage-1].forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            //console.log(doc.id, " => ", doc.data());
    
            $("#SubCattable").append(`<tr id="${doc[0]}">
            <td id=${doc[0]} data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)"><strong>${doc[1]}</strong></td>
            <td id="${doc[0]}-subcat" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)">${doc[2]}</td>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" id="${doc[0]}"  data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_Sub_Category_Modal(this.id)"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                  <a class="dropdown-item" id="${doc[0]}"  href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                  <div style="display: flex;
                  margin-left: 1.3rem;">
                  <i class="bx bx-bullseye" style="margin-top: 0.5rem;"></i><input class="form-control" list="pramote" id="pramotetohomeInput-${doc[0]}" autocomplete="off" style="width: 7rem;margin-left: 0.5rem;" onchange="getpramotetohomeInput(this.id,this.data-value)" placeholder="Select">
                  <datalist id="pramote">
                <option value="1"></option>
                <option value="2"></option>
                <option value="3"></option>
                <option value="4"></option>
                <option value="5"></option>       
                </datalist>
                  </div>
                  </div>
              </div>
            </td>

          </tr>`)
        });
        
    }else{
        document.getElementById("Sub_previousButton").disabled = true; 
    }


    
}



function DeleteMainCat(params) {
    

    

}

function getpramotetohomeInput(params) {

    var id = params.substring(params.length, params.indexOf('-')+1)
    var SrNo = document.getElementById(params).value
    var pramoteDoc ;

   var MainCatName;
   var SubcatName;

console.log("SrNo",SrNo)
   firestore.collection("HomeScreenSubCat").where("sno", "==", Number(SrNo))
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            pramoteDoc = doc.id;
            console.log(doc.id, " => ", doc.data());
        });
    }).then(()=>{
        var docRef = firestore.collection("Category").doc(selected_Main_Cat)

        docRef.get().then((doc) => {
            if (doc.exists) {
             MainCatName = doc.data().catName
            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
            }
        }).then(()=>{
     
        //  var docRef = firestore.collection("Category").doc(selected_Main_Cat).collection("SubCat").doc(id)
         var docRef = firestore.collection("SubCat").doc(id)
         docRef.get().then((doc) => {
             if (doc.exists) {
                 SubcatName = doc.data().subCatName
                
             } else {
                 // doc.data() will be undefined in this case
                 console.log("No such document!");
             }
         }).then(()=>{
       
             firestore.collection("HomeScreenSubCat").doc(pramoteDoc).update({
                 mainCat: MainCatName ,
                 subCat: SubcatName,
                 sno : Number(SrNo),
                 mainCatDocId : selected_Main_Cat,
             })
             }).then(()=>{
         
                 alert("Subcat Pramoted")
     
             })
          
         })       
         .catch((error) => {
             console.log("Error getting document:", error);
         });
     
    })

    .catch((error) => {
        console.log("Error getting documents: ", error);
    });



 
    
}

function MaingetpramotetohomeInput(params){


    
    var id = params.substring(params.length, params.indexOf('-')+1)
    console.log("id",id)
    var SrNo = document.getElementById(params).value
    var pramoteDoc ;
    var MainCatID;

   var MainCatName;
   var SubcatName;

console.log("SrNo",SrNo)
   firestore.collection("HomeScreenMainCat").where("sno", "==", Number(SrNo))
    .get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // doc.data() is never undefined for query doc snapshots
            pramoteDoc = doc.id;
            console.log(doc.id, " => ", doc.data());
        });
    }).then(()=>{
        var docRef = firestore.collection("Category").doc(id)

        docRef.get().then((docI) => {
            if (docI.exists) {
            //    MainCatName = doc.data().catName

            console.log("doc.data().catName",docI.data().catName)
            firestore.collection("HomeScreenMainCat").doc(pramoteDoc).update({
                mainCat: docI.data().catName ,
                sno : Number(SrNo),
                mainCatDocId :docI.id,
            })
            } else {
                // doc.data() will be undefined in this case
                console.log("No such document!");
            }
        }).then(()=>{
         
            alert("Main Category Pramoted")

        })
     

    .catch((error) => {
        console.log("Error getting documents: ", error);
    });

    })

}


function GetInput_For_Edit_MainCategory_Modal(params) {

    document.getElementById("SubCatDateEdit").style.display = "none"

    document.getElementById("MaincatformFile").value = "";

    document.getElementById("maincat").style.display = "";
    document.getElementById("subcat").style.display = "none";

    // SubEditReff = params;
    maincatEditReff = params;
    
    var MaincatName = document.getElementById("basic-default-fullname").value; 

    document.getElementById("MaincatModalName").disabled = "false"
    var docRef = firestore.collection("Category").doc(params);
    docRef.get().then((doc) => {
        if (doc.exists) {
            console.log("Document data:", doc.data());
            MainCatNameBeforeEdit = doc.data().catName;
            document.getElementById("MaincatModalName").value  =  doc.data().catName
            document.getElementById("blah_Main_cat").src = doc.data().catImg

            firestore.collection("Post").where("postMainCat", "==", doc.data().catName)
            .get()
            .then((querySnapshot) => {

                console.log("Count",querySnapshot.size) 
                console.log("Count",document.getElementById("MaincatModalName"))
                if(querySnapshot.size == 0){
                    document.getElementById("MaincatModalName").disabled = false
                }else{
                    document.getElementById("MaincatModalName").disabled = true
                }
                
                // querySnapshot.forEach((doc) => {
                //     // doc.data() is never undefined for query doc snapshots
                //     console.log(doc.id, " => ", doc.data());
                // });
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}


function GetInput_For_Open_MainCategory_Modal(params) {

    document.getElementById("SubCatDateEdit").style.display = "none"

    maincatEditReff = params;

    var id = params.substring(0, params.indexOf('-'))
    
    var docRef = firestore.collection("Category").doc(id);

    docRef.get().then((doc) => {
        if (doc.exists) {
            
            document.getElementById("exampleModalLabel1").innerText  =  doc.data().catName
            document.getElementById("mainCatModalImg").src  =  doc.data().catImg
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

function GetInput_For_Edit_Sub_Category_Modal(params) {
    document.getElementById("SubCatDateEdit").style.display = ""

    document.getElementById("MaincatformFile").value = ""

    document.getElementById("maincat").style.display = "none";
    document.getElementById("subcat").style.display = "";

    SubEditReff = params;

     SubCatNameID = params ;

    var docRef = firestore.collection("SubCat").doc(params);

    docRef.get().then((doc) => {
        if (doc.exists) {

            console.log("Data",moment(doc.data().festival.toDate()).format("YYYY-MM-DD"));
            document.getElementById("html5-date-input2").value = `${moment(doc.data().festival.toDate()).format("YYYY-MM-DD")}`
            SubCatNameBeforeEdit = doc.data().subCatName ;
            document.getElementById("MaincatModalName").value  =  doc.data().subCatName
            document.getElementById("blah_Main_cat").src = doc.data().subCatImg
            firestore.collection("Post").where("postSubCat", "==", doc.data().subCatName)
            .get()
            .then((querySnapshot) => {

       
             
                if(querySnapshot.size == 0){
                    document.getElementById("MaincatModalName").disabled = false
                }else{
                    document.getElementById("MaincatModalName").disabled = true
                }
                
                // querySnapshot.forEach((doc) => {
                //     // doc.data() is never undefined for query doc snapshots
                //     console.log(doc.id, " => ", doc.data());
                // });
            })
            .catch((error) => {
                console.log("Error getting documents: ", error);
            });
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

function GetInput_For_Open_Sub_Category_Modal(params) {

    console.log("params",params);
    console.log("ID",params.substring(0, params.indexOf('-')));

  
    var id = params.substring(0, params.indexOf('-'))
    // var docRef = firestore.collection("Category").doc(selected_Main_Cat).collection("SubCat").doc(id);
    var docRef = firestore.collection("SubCat").doc(id);

    docRef.get().then((doc) => {
        if (doc.exists) {
            
            document.getElementById("exampleModalLabel1").innerText  =  doc.data().subCatName
            document.getElementById("mainCatModalImg").src  =  doc.data().subCatImg
        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch((error) => {
        console.log("Error getting document:", error);
    });

}

function saveEditiedMainCategory (params) {
    var EditedCatName =  document.getElementById("MaincatModalName").value
    var EditedCatImage = document.getElementById("MaincatformFile").value
    var MyModal = document.getElementById("exampleModal");
    var washingtonRef = firestore.collection("Category").doc(maincatEditReff);

    var tempId = `${maincatEditReff}-main`
   

    firestore.collection("Post").where("postSubCat", "==", MainCatNameBeforeEdit)
    .get()
    .then((querySnapshot) => {

        console.log("Count",querySnapshot.size) 
        console.log("Count",document.getElementById("MaincatModalName"))
        if(querySnapshot.size == 0){

            if(EditedCatImage !== "" && EditedCatName!=="" ){

                var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());
        
                const ref = firebase.storage().ref();
                const file = document.querySelector('#MaincatformFile').files[0]
                const name =  file.name;
                const metadata = {
                contentType: file.type
                };
                const task = ref.child('meChitrakar/' + name).put(file, metadata);
                task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
        
                    return washingtonRef.update({
                        catName: EditedCatName,
                        catImg :url,
                        keywords : ManCatKeywords
                    })
                    .then(() => {
                        result = [];
                        // location.reload();
                        swal("Category Edited Successfully");
        
                    })
                    .catch((error) => {
                        // The document probably doesn't exist.
                        console.error("Error updating document: ", error);
                    });
        
        
                })
            }else if(EditedCatImage == "" && EditedCatName!==""){
                var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());
                washingtonRef.update({
                    catName: EditedCatName,
                    keywords : ManCatKeywords
                })
                .then(() => {
                    result = [];
                   
                    swal("Category Edited Successfully");                   
                    var myModalEl = document.getElementById("exampleModal");
                    var modal = bootstrap.Modal.getInstance(myModalEl)
                    modal.hide();
                  
    
                })
            }
            // document.getElementById("MaincatModalName").disabled = false
        }else{
            // document.getElementById("MaincatModalName").disabled = true

          
            if(EditedCatImage !== "" ){
                document.getElementById("EditUploading").style.display = "flex"
                document.getElementById("blah_Main_cat").style.display = "none"
                var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());
        
                const ref = firebase.storage().ref();
                const file = document.querySelector('#MaincatformFile').files[0]
                const name =  file.name;
                const metadata = {
                contentType: file.type
                };
                const task = ref.child('meChitrakar/' + name).put(file, metadata);
                task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
        
                    return washingtonRef.update({
                        catImg :url
                    })
                    .then(() => {
                        result = [];
                        document.getElementById("EditUploading").style.display = "none"
                        document.getElementById("blah_Main_cat").style.display = "flex"
                        swal("Category Edited Successfully");
                        location.reload();
                    })
                    .catch((error) => {
                        // The document probably doesn't exist.
                        console.error("Error updating document: ", error);
                    });
        
        
                })
        
                }
        
        }
        
        // querySnapshot.forEach((doc) => {
        //     // doc.data() is never undefined for query doc snapshots
        //     console.log(doc.id, " => ", doc.data());
        // });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });


   

    // if(EditedCatImage == "" && EditedCatName!=="" ){

    //     var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());
    //     return washingtonRef.update({
    //         catName: EditedCatName,
    //         keywords: ManCatKeywords
    //     })
    //     .then(() => {
    //         result = []
    //         location.reload();
    //         document.getElementById(tempId).innerText = EditedCatName
    //         alert("Document successfully updated!");
    //     })
    //     .catch((error) => {
    //         // The document probably doesn't exist.
    //         console.error("Error updating document: ", error);
    //     });
//}
//    if(EditedCatImage !== "" && EditedCatName!=="" ){

//         var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());

//         const ref = firebase.storage().ref();
//         const file = document.querySelector('#MaincatformFile').files[0]
//         const name =  file.name;
//         const metadata = {
//         contentType: file.type
//         };
//         const task = ref.child('meChitrakar/' + name).put(file, metadata);
//         task
//         .then(snapshot => snapshot.ref.getDownloadURL())
//         .then((url) => {

//             return washingtonRef.update({
//                 catName: EditedCatName,
//                 catImg :url,
//                 keywords : ManCatKeywords
//             })
//             .then(() => {
//                 result = [];
//                 location.reload();
//                 alert("Document successfully updated!");

//             })
//             .catch((error) => {
//                 // The document probably doesn't exist.
//                 console.error("Error updating document: ", error);
//             });


//         })
//     }


       
  
    
}

function saveEditiedSubCategory (params) {
    var EditedCatName =  document.getElementById("MaincatModalName").value
    var EditedCatImage = document.getElementById("MaincatformFile").value
    var EditedDate = document.getElementById("html5-date-input2").value
    // var washingtonRef = firestore.collection("Category").doc(selected_Main_Cat).collection("SubCat").doc(SubEditReff);
    var washingtonRef = firestore.collection("SubCat").doc(SubEditReff);

    // if(EditedCatImage == "" && EditedCatName!=="" ){

    //     var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());
    //     return washingtonRef.update({
    //         subCatName: EditedCatName,
    //         keywords: ManCatKeywords
    //     })
    //     .then(() => {
    //         result = []

    //         var tempId = `${SubEditReff}-subcat`

            
            
    //         // document.getElementById(`"${SubCatNameID}"`).innerText = EditedCatName;
    //         document.getElementById(tempId).innerText = EditedCatName;
    //         location.reload();
    //         alert("Document successfully updated!");
    //     })
    //     .catch((error) => {
    //         // The document probably doesn't exist.
    //         console.error("Error updating document: ", error);
    //     });
    // }else if(EditedCatImage !== "" && EditedCatName!=="" ){

    //     var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());

    //     const ref = firebase.storage().ref();
    //     const file = document.querySelector('#MaincatformFile').files[0]
    //     const name =  file.name;
    //     const metadata = {
    //     contentType: file.type
    //     };
    //     const task = ref.child('meChitrakar/' + name).put(file, metadata);
    //     task
    //     .then(snapshot => snapshot.ref.getDownloadURL())
    //     .then((url) => {

    //         return washingtonRef.update({
    //             subCatName: EditedCatName,
    //             subCatImg :url,
    //             keywords: ManCatKeywords
    //         })
    //         .then(() => {
    //             result = [];
    //             location.reload();
    //             alert("Document successfully updated!");
    //         })
    //         .catch((error) => {
    //             // The document probably doesn't exist.
    //             console.error("Error updating document: ", error);
    //         });


    //     })
    // }

    firestore.collection("Post").where("postMainCat", "==", SubCatNameBeforeEdit)
    .get()
    .then((querySnapshot) => {

        console.log("Count",querySnapshot.size) 
        console.log("Count",document.getElementById("MaincatModalName"))
        if(querySnapshot.size == 0){

            if(EditedCatImage !== "" && EditedCatName!==""){
                document.getElementById("EditUploading").style.display = "flex"
                document.getElementById("blah_Main_cat").style.display = "none"
                var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());
        
                const ref = firebase.storage().ref();
                const file = document.querySelector('#MaincatformFile').files[0]
                const name =  file.name;
                const metadata = {
                contentType: file.type
                };
                const task = ref.child('meChitrakar/' + name).put(file, metadata);
                task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
        
                    return washingtonRef.update({
                        subCatImg :url,
                        subCatName: EditedCatName,
                        keywords : ManCatKeywords,
                        festival : firebase.firestore.Timestamp.fromDate(new Date(EditedDate)).toDate(),

                    })
                    .then(() => {
                        document.getElementById("EditUploading").style.display = "none"
                        document.getElementById("blah_Main_cat").style.display = "flex"
                        result = [];
                        // location.reload();
                        swal("Sub-Category Edited Successfully");
                        CategoryOperations('editandshow');
                        getCategoryinTable();
                    })
                    .catch((error) => {
                        // The document probably doesn't exist.
                        console.error("Error updating document: ", error);
                    });
        
        
                })
        
            }else if(EditedCatImage == "" && EditedCatName !==""){
                var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());
                washingtonRef.update({
                    subCatName: EditedCatName,
                    keywords : ManCatKeywords,
                    festival : firebase.firestore.Timestamp.fromDate(new Date(EditedDate)).toDate(),
                })
                .then(() => {
                    result = [];
                   
                    swal("Sub-Category Edited Successfully");               
                    var myModalEl = document.getElementById("exampleModal");
                    var modal = bootstrap.Modal.getInstance(myModalEl)
                    modal.hide();
                    // location.reload();
                    CategoryOperations('editandshow');
                    getCategoryinTable();
                })
            }
            // document.getElementById("MaincatModalName").disabled = false
        }else{
            // document.getElementById("MaincatModalName").disabled = true

            if(EditedCatImage !== "" ){
                
                document.getElementById("EditUploading").style.display = "flex"
                document.getElementById("blah_Main_cat").style.display = "none"
                var ManCatKeywords = getAllSubstrings(EditedCatName.toLowerCase());
        
                const ref = firebase.storage().ref();
                const file = document.querySelector('#MaincatformFile').files[0]
                const name =  file.name;
                const metadata = {
                contentType: file.type
                };
                const task = ref.child('meChitrakar/' + name).put(file, metadata);
                task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
        
                    return washingtonRef.update({
                        subCatImg :url,
                        festival : firebase.firestore.Timestamp.fromDate(new Date(EditedDate)).toDate(),
                    })
                    .then(() => {
                        result = [];
                        document.getElementById("EditUploading").style.display = "none"
                        document.getElementById("blah_Main_cat").style.display = "flex"
                        swal("Sub-Category Edited Successfully");
                        CategoryOperations('editandshow');
                        
                        getCategoryinTable();
                    })
                    .catch((error) => {
                        // The document probably doesn't exist.
                        console.error("Error updating document: ", error);
                    });
        
        
                })
        
                }
        
        }
        
        // querySnapshot.forEach((doc) => {
        //     // doc.data() is never undefined for query doc snapshots
        //     console.log(doc.id, " => ", doc.data());
        // });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });




    

}

var result = [];
var i;

function getAllSubstrings(str) {
    result = [];
	for (let j = 1 ; j < str.length + 1; j++) {
	  result.push(str.slice(i, j));

	}
	for (let j = str.indexOf(" ")+2 ; j < str.length + 1; j++) {
	  result.push(str.slice(str.indexOf(" ")+1, j));
  }
return result;

}


function searchMainCat(params) {
  
    var tobeSearch = document.getElementById("SearchMainCat").value.toLowerCase();

    firestore.collection("Category").where("keywords","array-contains",tobeSearch).get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {

            while(document.getElementById("mainCattable").childElementCount!==0){

                document.getElementById("mainCattable").firstChild.remove();
            }
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data());
            $("#mainCattable").append(`<tr id="${doc.id}" >
            <td id=${doc.id} data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)"><strong>${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</strong></td>
            <td id="${doc.id}-main" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_MainCategory_Modal(this.id)">${doc.data().catName}</td>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" id=${doc.id} data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_MainCategory_Modal(this.id)"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                  <a class="dropdown-item" id=${doc.id} onclick="getSubCategoryinTable(this.id)" ><i class="bx bx-trash me-1" ></i> View Sub-Category</a>
                  <a class="dropdown-item" id=${doc.id}href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                </div>
              </div>
            </td>
          </tr>`)

        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    
}

function ResetSearch(params) {
    
var SearchBox;

SearchBox = document.getElementById("SearchMainCat").value;

if(SearchBox == ""){

    getCategoryinTable();
}
    
}


function searchSubCat(params) {
  
    var tobeSearch = document.getElementById("SubcatSearch").value.toLowerCase();
    // firestore.collection("Category").doc(selected_Main_Cat).collection("SubCat").where("keywords","array-contains",tobeSearch).get()

    firestore.collection("SubCat").where("keywords","array-contains",tobeSearch).get()
    .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {

            while(document.getElementById("SubCattable").childElementCount!==0){

                document.getElementById("SubCattable").firstChild.remove();
            }
            // doc.data() is never undefined for query doc snapshots
            console.log(doc.id, " => ", doc.data());
   
            $("#SubCattable").append(`<tr id="${doc.id}" >
            <td id="${doc.id}" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)"><strong>${moment(doc.data().date.toDate()).format("DD/MM/YYYY")}</strong></td>
            <td id="${doc.id}-subcat" data-bs-toggle="modal" data-bs-target="#exampleModal1" onclick="GetInput_For_Open_Sub_Category_Modal(this.id)">${doc.data().subCatName}</td>
            <td>
              <div class="dropdown">
                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                  <i class="bx bx-dots-vertical-rounded"></i>
                </button>
                <div class="dropdown-menu">
                  <a class="dropdown-item" id=${doc.id} data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="GetInput_For_Edit_Sub_Category_Modal(this.id)"><i class="bx bx-edit-alt me-1"></i> Edit</a>
                  <a class="dropdown-item" id=${doc.id} ><i class="bx bx-trash me-1"></i> View Sub-Category</a>
                  <a class="dropdown-item" id=${doc.id}href="javascript:void(0);"><i class="bx bx-trash me-1"></i> Delete</a>
                </div>
              </div>
            </td>
          </tr>`)

        });
    })
    .catch((error) => {
        console.log("Error getting documents: ", error);
    });
    
}

function ResetSearch_Sub(params) {
    
    var SearchBox;
    
    SearchBox = document.getElementById("SubcatSearch").value;
    
    if(SearchBox == ""){
    
        getSubCategoryinTable(selected_Main_Cat);
    }
        

}

